package com.google.android.gms.common.data;

public interface ObjectExclusionFilterable<T> {
    void filterOut(T t);
}
