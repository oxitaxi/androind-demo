package com.google.android.gms.common.internal;

import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.internal.PendingResultUtil.ResultConverter;

final class zzn implements ResultConverter<R, Void> {
    zzn() {
    }

    public final /* bridge */ /* synthetic */ Object convert(Result result) {
        return null;
    }
}
