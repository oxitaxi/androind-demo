package com.google.android.gms.common.util;

import android.os.SystemClock;

public /* synthetic */ class Clock$$CC {
    public static long currentThreadTimeMillis(Clock clock) {
        return SystemClock.currentThreadTimeMillis();
    }
}
