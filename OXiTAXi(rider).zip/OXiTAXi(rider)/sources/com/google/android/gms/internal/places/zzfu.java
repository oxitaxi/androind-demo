package com.google.android.gms.internal.places;

final class zzfu extends zzfy {
    private final int zznx;
    private final int zzny;

    zzfu(byte[] bArr, int i, int i2) {
        super(bArr);
        zzfr.zzc(i, i + i2, bArr.length);
        this.zznx = i;
        this.zzny = i2;
    }

    public final int size() {
        return this.zzny;
    }

    public final byte zzaf(int i) {
        int size = size();
        if (((size - (i + 1)) | i) >= 0) {
            return this.zzoa[this.zznx + i];
        }
        if (i < 0) {
            StringBuilder stringBuilder = new StringBuilder(22);
            stringBuilder.append("Index < 0: ");
            stringBuilder.append(i);
            throw new ArrayIndexOutOfBoundsException(stringBuilder.toString());
        }
        StringBuilder stringBuilder2 = new StringBuilder(40);
        stringBuilder2.append("Index > length: ");
        stringBuilder2.append(i);
        stringBuilder2.append(", ");
        stringBuilder2.append(size);
        throw new ArrayIndexOutOfBoundsException(stringBuilder2.toString());
    }

    protected final void zzb(byte[] bArr, int i, int i2, int i3) {
        System.arraycopy(this.zzoa, zzcg(), bArr, 0, i3);
    }

    protected final int zzcg() {
        return this.zznx;
    }
}
