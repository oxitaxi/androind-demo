package com.google.android.gms.internal.places;

import java.io.IOException;
import java.util.Iterator;
import java.util.Map.Entry;

final class zzim<T> implements zziy<T> {
    private final zzih zzvf;
    private final boolean zzvg;
    private final zzjq<?, ?> zzvp;
    private final zzgm<?> zzvq;

    private zzim(zzjq<?, ?> zzjq, zzgm<?> zzgm, zzih zzih) {
        this.zzvp = zzjq;
        this.zzvg = zzgm.zzf(zzih);
        this.zzvq = zzgm;
        this.zzvf = zzih;
    }

    static <T> zzim<T> zzb(zzjq<?, ?> zzjq, zzgm<?> zzgm, zzih zzih) {
        return new zzim(zzjq, zzgm, zzih);
    }

    public final boolean equals(T t, T t2) {
        return !this.zzvp.zzq(t).equals(this.zzvp.zzq(t2)) ? false : this.zzvg ? this.zzvq.zzb((Object) t).equals(this.zzvq.zzb((Object) t2)) : true;
    }

    public final int hashCode(T t) {
        int hashCode = this.zzvp.zzq(t).hashCode();
        return this.zzvg ? (hashCode * 53) + this.zzvq.zzb((Object) t).hashCode() : hashCode;
    }

    public final T newInstance() {
        return this.zzvf.zzdr().zzdw();
    }

    public final void zzb(T t, zzix zzix, zzgl zzgl) throws IOException {
        zzjq zzjq = this.zzvp;
        zzgm zzgm = this.zzvq;
        Object zzr = zzjq.zzr(t);
        zzgq zzc = zzgm.zzc(t);
        while (zzix.zzbg() != Integer.MAX_VALUE) {
            try {
                boolean zzb;
                int tag = zzix.getTag();
                if (tag != 11) {
                    if ((tag & 7) == 2) {
                        Object zzb2 = zzgm.zzb(zzgl, this.zzvf, tag >>> 3);
                        if (zzb2 != null) {
                            zzgm.zzb(zzix, zzb2, zzgl, zzc);
                        } else {
                            zzb = zzjq.zzb(zzr, zzix);
                            continue;
                        }
                    } else {
                        zzb = zzix.zzbh();
                        continue;
                    }
                    if (!zzb) {
                        return;
                    }
                }
                Object obj = null;
                zzfr zzfr = null;
                int i = 0;
                while (zzix.zzbg() != Integer.MAX_VALUE) {
                    int tag2 = zzix.getTag();
                    if (tag2 == 16) {
                        i = zzix.zzbq();
                        obj = zzgm.zzb(zzgl, this.zzvf, i);
                    } else if (tag2 == 26) {
                        if (obj != null) {
                            zzgm.zzb(zzix, obj, zzgl, zzc);
                        } else {
                            zzfr = zzix.zzbp();
                        }
                    } else if (!zzix.zzbh()) {
                        break;
                    }
                }
                if (zzix.getTag() != 12) {
                    throw zzhh.zzec();
                } else if (zzfr != null) {
                    if (obj != null) {
                        zzgm.zzb(zzfr, obj, zzgl, zzc);
                    } else {
                        zzjq.zzb(zzr, i, zzfr);
                    }
                }
                zzb = true;
                continue;
                if (zzb) {
                    return;
                }
            } finally {
                zzjq.zzg(t, zzr);
            }
        }
        zzjq.zzg(t, zzr);
    }

    public final void zzb(T t, zzkk zzkk) throws IOException {
        Iterator it = this.zzvq.zzb((Object) t).iterator();
        while (it.hasNext()) {
            Entry entry = (Entry) it.next();
            zzgs zzgs = (zzgs) entry.getKey();
            if (zzgs.zzdj() != zzkj.MESSAGE || zzgs.zzdk() || zzgs.zzdl()) {
                throw new IllegalStateException("Found invalid MessageSet item.");
            }
            int zzap;
            Object zzax;
            if (entry instanceof zzhm) {
                zzap = zzgs.zzap();
                zzax = ((zzhm) entry).zzej().zzax();
            } else {
                zzap = zzgs.zzap();
                zzax = entry.getValue();
            }
            zzkk.zzb(zzap, zzax);
        }
        zzjq zzjq = this.zzvp;
        zzjq.zzd(zzjq.zzq(t), zzkk);
    }

    public final void zzd(T t) {
        this.zzvp.zzd(t);
        this.zzvq.zzd(t);
    }

    public final void zzd(T t, T t2) {
        zzja.zzb(this.zzvp, (Object) t, (Object) t2);
        if (this.zzvg) {
            zzja.zzb(this.zzvq, (Object) t, (Object) t2);
        }
    }

    public final int zzn(T t) {
        zzjq zzjq = this.zzvp;
        int zzs = zzjq.zzs(zzjq.zzq(t)) + 0;
        return this.zzvg ? zzs + this.zzvq.zzb((Object) t).zzdh() : zzs;
    }

    public final boolean zzo(T t) {
        return this.zzvq.zzb((Object) t).isInitialized();
    }
}
