package com.google.android.gms.internal.places;

import com.google.android.gms.internal.places.zzgz.zzh;
import java.io.IOException;
import java.util.Arrays;

public final class zzjr {
    private static final zzjr zzxr = new zzjr(0, new int[0], new Object[0], false);
    private int count;
    private boolean zznk;
    private int zzsh;
    private Object[] zzvb;
    private int[] zzxs;

    private zzjr() {
        this(0, new int[8], new Object[8], true);
    }

    private zzjr(int i, int[] iArr, Object[] objArr, boolean z) {
        this.zzsh = -1;
        this.count = i;
        this.zzxs = iArr;
        this.zzvb = objArr;
        this.zznk = z;
    }

    static zzjr zzb(zzjr zzjr, zzjr zzjr2) {
        int i = zzjr.count + zzjr2.count;
        Object copyOf = Arrays.copyOf(zzjr.zzxs, i);
        System.arraycopy(zzjr2.zzxs, 0, copyOf, zzjr.count, zzjr2.count);
        Object copyOf2 = Arrays.copyOf(zzjr.zzvb, i);
        System.arraycopy(zzjr2.zzvb, 0, copyOf2, zzjr.count, zzjr2.count);
        return new zzjr(i, copyOf, copyOf2, true);
    }

    private static void zzc(int i, Object obj, zzkk zzkk) throws IOException {
        int i2 = i >>> 3;
        i &= 7;
        if (i != 5) {
            switch (i) {
                case 0:
                    zzkk.zzj(i2, ((Long) obj).longValue());
                    return;
                case 1:
                    zzkk.zzd(i2, ((Long) obj).longValue());
                    return;
                case 2:
                    zzkk.zzb(i2, (zzfr) obj);
                    return;
                case 3:
                    if (zzkk.zzcv() == zzh.zztg) {
                        zzkk.zzbb(i2);
                        ((zzjr) obj).zzc(zzkk);
                        zzkk.zzbc(i2);
                        return;
                    }
                    zzkk.zzbc(i2);
                    ((zzjr) obj).zzc(zzkk);
                    zzkk.zzbb(i2);
                    return;
                default:
                    throw new RuntimeException(zzhh.zzed());
            }
        }
        zzkk.zzh(i2, ((Integer) obj).intValue());
    }

    public static zzjr zzgp() {
        return zzxr;
    }

    static zzjr zzgq() {
        return new zzjr();
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !(obj instanceof zzjr)) {
            return false;
        }
        zzjr zzjr = (zzjr) obj;
        if (this.count == zzjr.count) {
            Object obj2;
            int[] iArr = this.zzxs;
            int[] iArr2 = zzjr.zzxs;
            int i = this.count;
            for (int i2 = 0; i2 < i; i2++) {
                if (iArr[i2] != iArr2[i2]) {
                    obj2 = null;
                    break;
                }
            }
            obj2 = 1;
            if (obj2 != null) {
                Object[] objArr = this.zzvb;
                Object[] objArr2 = zzjr.zzvb;
                int i3 = this.count;
                for (i = 0; i < i3; i++) {
                    if (!objArr[i].equals(objArr2[i])) {
                        obj = null;
                        break;
                    }
                }
                obj = 1;
                if (obj != null) {
                    return true;
                }
            }
        }
        return false;
    }

    public final int hashCode() {
        int i = (this.count + 527) * 31;
        int[] iArr = this.zzxs;
        int i2 = 17;
        int i3 = 17;
        for (int i4 = 0; i4 < this.count; i4++) {
            i3 = (i3 * 31) + iArr[i4];
        }
        i = (i + i3) * 31;
        Object[] objArr = this.zzvb;
        for (int i5 = 0; i5 < this.count; i5++) {
            i2 = (i2 * 31) + objArr[i5].hashCode();
        }
        return i + i2;
    }

    final void zzb(zzkk zzkk) throws IOException {
        int i;
        if (zzkk.zzcv() == zzh.zzth) {
            for (i = this.count - 1; i >= 0; i--) {
                zzkk.zzb(this.zzxs[i] >>> 3, this.zzvb[i]);
            }
            return;
        }
        for (i = 0; i < this.count; i++) {
            zzkk.zzb(this.zzxs[i] >>> 3, this.zzvb[i]);
        }
    }

    final void zzb(StringBuilder stringBuilder, int i) {
        for (int i2 = 0; i2 < this.count; i2++) {
            zzik.zzb(stringBuilder, i, String.valueOf(this.zzxs[i2] >>> 3), this.zzvb[i2]);
        }
    }

    public final void zzbb() {
        this.zznk = false;
    }

    final void zzc(int i, Object obj) {
        if (this.zznk) {
            if (this.count == this.zzxs.length) {
                int i2 = this.count + (this.count < 4 ? 8 : this.count >> 1);
                this.zzxs = Arrays.copyOf(this.zzxs, i2);
                this.zzvb = Arrays.copyOf(this.zzvb, i2);
            }
            this.zzxs[this.count] = i;
            this.zzvb[this.count] = obj;
            this.count++;
            return;
        }
        throw new UnsupportedOperationException();
    }

    public final void zzc(zzkk zzkk) throws IOException {
        if (this.count != 0) {
            int i;
            if (zzkk.zzcv() == zzh.zztg) {
                for (i = 0; i < this.count; i++) {
                    zzc(this.zzxs[i], this.zzvb[i], zzkk);
                }
                return;
            }
            for (i = this.count - 1; i >= 0; i--) {
                zzc(this.zzxs[i], this.zzvb[i], zzkk);
            }
        }
    }

    public final int zzdg() {
        int i = this.zzsh;
        if (i != -1) {
            return i;
        }
        int i2 = 0;
        for (i = 0; i < this.count; i++) {
            int i3 = this.zzxs[i];
            int i4 = i3 >>> 3;
            i3 &= 7;
            if (i3 != 5) {
                switch (i3) {
                    case 0:
                        i3 = zzgf.zzf(i4, ((Long) this.zzvb[i]).longValue());
                        break;
                    case 1:
                        i3 = zzgf.zzh(i4, ((Long) this.zzvb[i]).longValue());
                        break;
                    case 2:
                        i3 = zzgf.zzd(i4, (zzfr) this.zzvb[i]);
                        break;
                    case 3:
                        i3 = (zzgf.zzas(i4) << 1) + ((zzjr) this.zzvb[i]).zzdg();
                        break;
                    default:
                        throw new IllegalStateException(zzhh.zzed());
                }
            }
            i3 = zzgf.zzl(i4, ((Integer) this.zzvb[i]).intValue());
            i2 += i3;
        }
        this.zzsh = i2;
        return i2;
    }

    public final int zzgr() {
        int i = this.zzsh;
        if (i != -1) {
            return i;
        }
        int i2 = 0;
        for (i = 0; i < this.count; i++) {
            i2 += zzgf.zze(this.zzxs[i] >>> 3, (zzfr) this.zzvb[i]);
        }
        this.zzsh = i2;
        return i2;
    }
}
