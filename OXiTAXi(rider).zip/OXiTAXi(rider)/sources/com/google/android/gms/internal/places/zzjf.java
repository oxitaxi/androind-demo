package com.google.android.gms.internal.places;

import java.util.Iterator;

final class zzjf {
    private static final Iterator<Object> zzxl = new zzjg();
    private static final Iterable<Object> zzxm = new zzjh();

    static <T> Iterable<T> zzgm() {
        return zzxm;
    }
}
