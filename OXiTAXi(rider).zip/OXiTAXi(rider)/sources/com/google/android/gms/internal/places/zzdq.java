package com.google.android.gms.internal.places;

import java.io.IOException;

public final class zzdq extends zzko<zzdq> {
    public String[] zzhw;
    public int[] zzhx;
    public byte[][] zzhy;

    public zzdq() {
        this.zzhw = zzkx.zzaaz;
        this.zzhx = zzkx.zzaau;
        this.zzhy = zzkx.zzaba;
        this.zzaaf = null;
        this.zzaap = -1;
    }

    public static zzdq zzb(byte[] bArr) throws zzkt {
        return (zzdq) zzku.zzb(new zzdq(), bArr);
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof zzdq)) {
            return false;
        }
        zzdq zzdq = (zzdq) obj;
        if (!zzks.equals(this.zzhw, zzdq.zzhw) || !zzks.equals(this.zzhx, zzdq.zzhx) || !zzks.zzb(this.zzhy, zzdq.zzhy)) {
            return false;
        }
        if (this.zzaaf != null) {
            if (!this.zzaaf.isEmpty()) {
                return this.zzaaf.equals(zzdq.zzaaf);
            }
        }
        if (zzdq.zzaaf != null) {
            if (!zzdq.zzaaf.isEmpty()) {
                return false;
            }
        }
        return true;
    }

    public final int hashCode() {
        int hashCode;
        int hashCode2 = (((((((getClass().getName().hashCode() + 527) * 31) + zzks.hashCode(this.zzhw)) * 31) + zzks.hashCode(this.zzhx)) * 31) + zzks.zzb(this.zzhy)) * 31;
        if (this.zzaaf != null) {
            if (!this.zzaaf.isEmpty()) {
                hashCode = this.zzaaf.hashCode();
                return hashCode2 + hashCode;
            }
        }
        hashCode = 0;
        return hashCode2 + hashCode;
    }

    protected final int zzal() {
        int i;
        int i2;
        int i3;
        int zzal = super.zzal();
        if (this.zzhw != null && this.zzhw.length > 0) {
            i = 0;
            i2 = 0;
            for (String str : this.zzhw) {
                if (str != null) {
                    i2++;
                    i += zzkm.zzl(str);
                }
            }
            zzal = (zzal + i) + (i2 * 1);
        }
        if (this.zzhx != null && this.zzhx.length > 0) {
            i = 0;
            for (int i22 : this.zzhx) {
                i += zzkm.zzat(i22);
            }
            zzal = (zzal + i) + (this.zzhx.length * 1);
        }
        if (this.zzhy == null || this.zzhy.length <= 0) {
            return zzal;
        }
        i3 = 0;
        i = 0;
        for (byte[] bArr : this.zzhy) {
            if (bArr != null) {
                i++;
                i3 += zzkm.zzj(bArr);
            }
        }
        return (zzal + i3) + (i * 1);
    }

    public final /* synthetic */ zzku zzb(zzkl zzkl) throws IOException {
        while (true) {
            int zzcj = zzkl.zzcj();
            if (zzcj == 0) {
                return this;
            }
            int length;
            Object obj;
            if (zzcj == 10) {
                zzcj = zzkx.zzc(zzkl, 10);
                length = this.zzhw == null ? 0 : this.zzhw.length;
                obj = new String[(zzcj + length)];
                if (length != 0) {
                    System.arraycopy(this.zzhw, 0, obj, 0, length);
                }
                while (length < obj.length - 1) {
                    obj[length] = zzkl.readString();
                    zzkl.zzcj();
                    length++;
                }
                obj[length] = zzkl.readString();
                this.zzhw = obj;
            } else if (zzcj == 16) {
                zzcj = zzkx.zzc(zzkl, 16);
                length = this.zzhx == null ? 0 : this.zzhx.length;
                obj = new int[(zzcj + length)];
                if (length != 0) {
                    System.arraycopy(this.zzhx, 0, obj, 0, length);
                }
                while (length < obj.length - 1) {
                    obj[length] = zzkl.zzcm();
                    zzkl.zzcj();
                    length++;
                }
                obj[length] = zzkl.zzcm();
                this.zzhx = obj;
            } else if (zzcj == 18) {
                zzcj = zzkl.zzak(zzkl.zzcm());
                length = zzkl.getPosition();
                int i = 0;
                while (zzkl.zzhb() > 0) {
                    zzkl.zzcm();
                    i++;
                }
                zzkl.zzbr(length);
                length = this.zzhx == null ? 0 : this.zzhx.length;
                Object obj2 = new int[(i + length)];
                if (length != 0) {
                    System.arraycopy(this.zzhx, 0, obj2, 0, length);
                }
                while (length < obj2.length) {
                    obj2[length] = zzkl.zzcm();
                    length++;
                }
                this.zzhx = obj2;
                zzkl.zzal(zzcj);
            } else if (zzcj == 26) {
                zzcj = zzkx.zzc(zzkl, 26);
                length = this.zzhy == null ? 0 : this.zzhy.length;
                obj = new byte[(zzcj + length)][];
                if (length != 0) {
                    System.arraycopy(this.zzhy, 0, obj, 0, length);
                }
                while (length < obj.length - 1) {
                    obj[length] = zzkl.readBytes();
                    zzkl.zzcj();
                    length++;
                }
                obj[length] = zzkl.readBytes();
                this.zzhy = obj;
            } else if (!super.zzb(zzkl, zzcj)) {
                return this;
            }
        }
    }

    public final void zzb(zzkm zzkm) throws IOException {
        if (this.zzhw != null && this.zzhw.length > 0) {
            for (String str : this.zzhw) {
                if (str != null) {
                    zzkm.zzb(1, str);
                }
            }
        }
        if (this.zzhx != null && this.zzhx.length > 0) {
            for (int zze : this.zzhx) {
                zzkm.zze(2, zze);
            }
        }
        if (this.zzhy != null && this.zzhy.length > 0) {
            for (byte[] bArr : this.zzhy) {
                if (bArr != null) {
                    zzkm.zzb(3, bArr);
                }
            }
        }
        super.zzb(zzkm);
    }
}
