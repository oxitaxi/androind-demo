package com.google.android.gms.internal.places;

public abstract class zzfh<MessageType extends zzfh<MessageType, BuilderType>, BuilderType extends zzfi<MessageType, BuilderType>> implements zzih {
    private static boolean zzni = false;
    protected int zznh = 0;

    public final zzfr zzax() {
        try {
            zzfw zzag = zzfr.zzag(zzdg());
            zzc(zzag.zzci());
            return zzag.zzch();
        } catch (Throwable e) {
            String str = "ByteString";
            String name = getClass().getName();
            StringBuilder stringBuilder = new StringBuilder((String.valueOf(name).length() + 62) + String.valueOf(str).length());
            stringBuilder.append("Serializing ");
            stringBuilder.append(name);
            stringBuilder.append(" to a ");
            stringBuilder.append(str);
            stringBuilder.append(" threw an IOException (should never happen).");
            throw new RuntimeException(stringBuilder.toString(), e);
        }
    }

    int zzay() {
        throw new UnsupportedOperationException();
    }

    void zzv(int i) {
        throw new UnsupportedOperationException();
    }
}
