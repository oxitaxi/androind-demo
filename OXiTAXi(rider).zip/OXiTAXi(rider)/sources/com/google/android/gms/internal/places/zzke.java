package com.google.android.gms.internal.places;

public enum zzke {
    DOUBLE(zzkj.DOUBLE, 1),
    FLOAT(zzkj.FLOAT, 5),
    INT64(zzkj.LONG, 0),
    UINT64(zzkj.LONG, 0),
    INT32(zzkj.INT, 0),
    FIXED64(zzkj.LONG, 1),
    FIXED32(zzkj.INT, 5),
    BOOL(zzkj.BOOLEAN, 0),
    STRING(zzkj.STRING, 2),
    GROUP(zzkj.MESSAGE, 3),
    MESSAGE(zzkj.MESSAGE, 2),
    BYTES(zzkj.BYTE_STRING, 2),
    UINT32(zzkj.INT, 0),
    ENUM(zzkj.ENUM, 0),
    SFIXED32(zzkj.INT, 5),
    SFIXED64(zzkj.LONG, 1),
    SINT32(zzkj.INT, 0),
    SINT64(zzkj.LONG, 0);
    
    private final zzkj zzzl;
    private final int zzzm;

    private zzke(zzkj zzkj, int i) {
        this.zzzl = zzkj;
        this.zzzm = i;
    }

    public final zzkj zzgz() {
        return this.zzzl;
    }

    public final int zzha() {
        return this.zzzm;
    }
}
