package com.google.android.gms.internal.places;

final class zzhx implements zzig {
    zzhx() {
    }

    public final boolean zzc(Class<?> cls) {
        return false;
    }

    public final zzif zzd(Class<?> cls) {
        throw new IllegalStateException("This should never be called.");
    }
}
