package com.google.android.gms.internal.places;

import java.io.IOException;
import java.nio.BufferOverflowException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.ReadOnlyBufferException;

public final class zzkm {
    private zzgf zzaad;
    private int zzaae;
    private final ByteBuffer zzot;

    private zzkm(ByteBuffer byteBuffer) {
        this.zzot = byteBuffer;
        this.zzot.order(ByteOrder.LITTLE_ENDIAN);
    }

    private zzkm(byte[] bArr, int i, int i2) {
        this(ByteBuffer.wrap(bArr, i, i2));
    }

    public static int zzas(int i) {
        return zzba(i << 3);
    }

    public static int zzat(int i) {
        return i >= 0 ? zzba(i) : 10;
    }

    private static int zzb(CharSequence charSequence) {
        int length = charSequence.length();
        int i = 0;
        int i2 = 0;
        while (i2 < length && charSequence.charAt(i2) < '') {
            i2++;
        }
        int i3 = length;
        while (i2 < length) {
            char charAt = charSequence.charAt(i2);
            if (charAt < 'ࠀ') {
                i3 += (127 - charAt) >>> 31;
                i2++;
            } else {
                int length2 = charSequence.length();
                while (i2 < length2) {
                    char charAt2 = charSequence.charAt(i2);
                    if (charAt2 < 'ࠀ') {
                        i += (127 - charAt2) >>> 31;
                    } else {
                        i += 2;
                        if ('?' <= charAt2 && charAt2 <= '?') {
                            if (Character.codePointAt(charSequence, i2) >= 65536) {
                                i2++;
                            } else {
                                StringBuilder stringBuilder = new StringBuilder(39);
                                stringBuilder.append("Unpaired surrogate at index ");
                                stringBuilder.append(i2);
                                throw new IllegalArgumentException(stringBuilder.toString());
                            }
                        }
                    }
                    i2++;
                }
                i3 += i;
                if (i3 >= length) {
                    return i3;
                }
                long j = ((long) i3) + 4294967296L;
                StringBuilder stringBuilder2 = new StringBuilder(54);
                stringBuilder2.append("UTF-8 length does not fit in int: ");
                stringBuilder2.append(j);
                throw new IllegalArgumentException(stringBuilder2.toString());
            }
        }
        if (i3 >= length) {
            return i3;
        }
        long j2 = ((long) i3) + 4294967296L;
        StringBuilder stringBuilder22 = new StringBuilder(54);
        stringBuilder22.append("UTF-8 length does not fit in int: ");
        stringBuilder22.append(j2);
        throw new IllegalArgumentException(stringBuilder22.toString());
    }

    public static int zzba(int i) {
        return (i & -128) == 0 ? 1 : (i & -16384) == 0 ? 2 : (-2097152 & i) == 0 ? 3 : (i & -268435456) == 0 ? 4 : 5;
    }

    private final void zzbs(int i) throws IOException {
        byte b = (byte) i;
        if (this.zzot.hasRemaining()) {
            this.zzot.put(b);
            return;
        }
        throw new zzkn(this.zzot.position(), this.zzot.limit());
    }

    public static int zzc(int i, zzku zzku) {
        i = zzas(i);
        int zzdg = zzku.zzdg();
        return i + (zzba(zzdg) + zzdg);
    }

    public static int zzc(int i, String str) {
        return zzas(i) + zzl(str);
    }

    public static int zze(int i, long j) {
        i = zzas(i);
        int i2 = (-128 & j) == 0 ? 1 : (-16384 & j) == 0 ? 2 : (-2097152 & j) == 0 ? 3 : (-268435456 & j) == 0 ? 4 : (-34359738368L & j) == 0 ? 5 : (-4398046511104L & j) == 0 ? 6 : (-562949953421312L & j) == 0 ? 7 : (-72057594037927936L & j) == 0 ? 8 : (j & Long.MIN_VALUE) == 0 ? 9 : 10;
        return i + i2;
    }

    private static void zze(CharSequence charSequence, ByteBuffer byteBuffer) {
        if (byteBuffer.isReadOnly()) {
            throw new ReadOnlyBufferException();
        }
        int i = 0;
        int arrayOffset;
        int remaining;
        char charAt;
        if (byteBuffer.hasArray()) {
            try {
                int i2;
                byte[] array = byteBuffer.array();
                arrayOffset = byteBuffer.arrayOffset() + byteBuffer.position();
                remaining = byteBuffer.remaining();
                int length = charSequence.length();
                remaining += arrayOffset;
                while (i < length) {
                    i2 = i + arrayOffset;
                    if (i2 >= remaining) {
                        break;
                    }
                    char charAt2 = charSequence.charAt(i);
                    if (charAt2 >= '') {
                        break;
                    }
                    array[i2] = (byte) charAt2;
                    i++;
                }
                if (i == length) {
                    arrayOffset += length;
                } else {
                    arrayOffset += i;
                    while (i < length) {
                        int i3;
                        char charAt3 = charSequence.charAt(i);
                        if (charAt3 < '' && arrayOffset < remaining) {
                            i3 = arrayOffset + 1;
                            array[arrayOffset] = (byte) charAt3;
                        } else if (charAt3 < 'ࠀ' && arrayOffset <= remaining - 2) {
                            i3 = arrayOffset + 1;
                            array[arrayOffset] = (byte) ((charAt3 >>> 6) | 960);
                            arrayOffset = i3 + 1;
                            array[i3] = (byte) ((charAt3 & 63) | 128);
                            i++;
                        } else if ((charAt3 < '?' || '?' < charAt3) && arrayOffset <= remaining - 3) {
                            i3 = arrayOffset + 1;
                            array[arrayOffset] = (byte) ((charAt3 >>> 12) | 480);
                            arrayOffset = i3 + 1;
                            array[i3] = (byte) (((charAt3 >>> 6) & 63) | 128);
                            i3 = arrayOffset + 1;
                            array[arrayOffset] = (byte) ((charAt3 & 63) | 128);
                        } else if (arrayOffset <= remaining - 4) {
                            i3 = i + 1;
                            if (i3 != charSequence.length()) {
                                charAt = charSequence.charAt(i3);
                                if (Character.isSurrogatePair(charAt3, charAt)) {
                                    i = Character.toCodePoint(charAt3, charAt);
                                    i2 = arrayOffset + 1;
                                    array[arrayOffset] = (byte) ((i >>> 18) | 240);
                                    arrayOffset = i2 + 1;
                                    array[i2] = (byte) (((i >>> 12) & 63) | 128);
                                    i2 = arrayOffset + 1;
                                    array[arrayOffset] = (byte) (((i >>> 6) & 63) | 128);
                                    arrayOffset = i2 + 1;
                                    array[i2] = (byte) ((i & 63) | 128);
                                    i = i3;
                                    i++;
                                } else {
                                    i = i3;
                                }
                            }
                            i--;
                            StringBuilder stringBuilder = new StringBuilder(39);
                            stringBuilder.append("Unpaired surrogate at index ");
                            stringBuilder.append(i);
                            throw new IllegalArgumentException(stringBuilder.toString());
                        } else {
                            StringBuilder stringBuilder2 = new StringBuilder(37);
                            stringBuilder2.append("Failed writing ");
                            stringBuilder2.append(charAt3);
                            stringBuilder2.append(" at index ");
                            stringBuilder2.append(arrayOffset);
                            throw new ArrayIndexOutOfBoundsException(stringBuilder2.toString());
                        }
                        arrayOffset = i3;
                        i++;
                    }
                }
                byteBuffer.position(arrayOffset - byteBuffer.arrayOffset());
                return;
            } catch (Throwable e) {
                BufferOverflowException bufferOverflowException = new BufferOverflowException();
                bufferOverflowException.initCause(e);
                throw bufferOverflowException;
            }
        }
        int length2 = charSequence.length();
        while (i < length2) {
            arrayOffset = charSequence.charAt(i);
            if (arrayOffset >= 128) {
                if (arrayOffset < 2048) {
                    remaining = (arrayOffset >>> 6) | 960;
                } else {
                    if (arrayOffset >= 55296) {
                        if (57343 >= arrayOffset) {
                            remaining = i + 1;
                            if (remaining != charSequence.length()) {
                                charAt = charSequence.charAt(remaining);
                                if (Character.isSurrogatePair(arrayOffset, charAt)) {
                                    i = Character.toCodePoint(arrayOffset, charAt);
                                    byteBuffer.put((byte) ((i >>> 18) | 240));
                                    byteBuffer.put((byte) (((i >>> 12) & 63) | 128));
                                    byteBuffer.put((byte) (((i >>> 6) & 63) | 128));
                                    byteBuffer.put((byte) ((i & 63) | 128));
                                    i = remaining;
                                    i++;
                                } else {
                                    i = remaining;
                                }
                            }
                            i--;
                            stringBuilder = new StringBuilder(39);
                            stringBuilder.append("Unpaired surrogate at index ");
                            stringBuilder.append(i);
                            throw new IllegalArgumentException(stringBuilder.toString());
                        }
                    }
                    byteBuffer.put((byte) ((arrayOffset >>> 12) | 480));
                    remaining = ((arrayOffset >>> 6) & 63) | 128;
                }
                byteBuffer.put((byte) remaining);
                arrayOffset = (arrayOffset & 63) | 128;
            }
            byteBuffer.put((byte) arrayOffset);
            i++;
        }
    }

    private final zzgf zzhc() throws IOException {
        if (this.zzaad == null) {
            this.zzaad = zzgf.zzb(this.zzot);
        } else {
            if (this.zzaae != this.zzot.position()) {
                this.zzaad.write(this.zzot.array(), this.zzaae, this.zzot.position() - this.zzaae);
            }
            return this.zzaad;
        }
        this.zzaae = this.zzot.position();
        return this.zzaad;
    }

    public static int zzi(int i, int i2) {
        return zzas(i) + zzat(i2);
    }

    public static zzkm zzi(byte[] bArr) {
        return zzl(bArr, 0, bArr.length);
    }

    public static int zzj(byte[] bArr) {
        return zzba(bArr.length) + bArr.length;
    }

    public static int zzl(String str) {
        int zzb = zzb(str);
        return zzba(zzb) + zzb;
    }

    public static zzkm zzl(byte[] bArr, int i, int i2) {
        return new zzkm(bArr, 0, i2);
    }

    private final void zzq(long j) throws IOException {
        while ((-128 & j) != 0) {
            zzbs((((int) j) & 127) | 128);
            j >>>= 7;
        }
        zzbs((int) j);
    }

    public final void zzb(int i, double d) throws IOException {
        zzd(i, 1);
        long doubleToLongBits = Double.doubleToLongBits(d);
        if (this.zzot.remaining() >= 8) {
            this.zzot.putLong(doubleToLongBits);
            return;
        }
        throw new zzkn(this.zzot.position(), this.zzot.limit());
    }

    public final void zzb(int i, zzku zzku) throws IOException {
        zzd(i, 2);
        zzc(zzku);
    }

    public final void zzb(int i, String str) throws IOException {
        zzd(i, 2);
        try {
            i = zzba(str.length());
            if (i == zzba(str.length() * 3)) {
                int position = this.zzot.position();
                if (this.zzot.remaining() >= i) {
                    this.zzot.position(position + i);
                    zze((CharSequence) str, this.zzot);
                    int position2 = this.zzot.position();
                    this.zzot.position(position);
                    zzbt((position2 - position) - i);
                    this.zzot.position(position2);
                    return;
                }
                throw new zzkn(position + i, this.zzot.limit());
            }
            zzbt(zzb(str));
            zze((CharSequence) str, this.zzot);
        } catch (Throwable e) {
            zzkn zzkn = new zzkn(this.zzot.position(), this.zzot.limit());
            zzkn.initCause(e);
            throw zzkn;
        }
    }

    public final void zzb(int i, byte[] bArr) throws IOException {
        zzd(3, 2);
        zzbt(bArr.length);
        zzk(bArr);
    }

    public final void zzbt(int i) throws IOException {
        while ((i & -128) != 0) {
            zzbs((i & 127) | 128);
            i >>>= 7;
        }
        zzbs(i);
    }

    public final void zzc(byte b) throws IOException {
        if (this.zzot.hasRemaining()) {
            this.zzot.put(b);
            return;
        }
        throw new zzkn(this.zzot.position(), this.zzot.limit());
    }

    public final void zzc(int i, float f) throws IOException {
        zzd(i, 5);
        i = Float.floatToIntBits(f);
        if (this.zzot.remaining() >= 4) {
            this.zzot.putInt(i);
            return;
        }
        throw new zzkn(this.zzot.position(), this.zzot.limit());
    }

    public final void zzc(zzku zzku) throws IOException {
        if (zzku.zzaap < 0) {
            zzku.zzdg();
        }
        zzbt(zzku.zzaap);
        zzku.zzb(this);
    }

    public final void zzd(int i, int i2) throws IOException {
        zzbt((i << 3) | i2);
    }

    public final void zze(int i, int i2) throws IOException {
        zzd(i, 0);
        if (i2 >= 0) {
            zzbt(i2);
        } else {
            zzq((long) i2);
        }
    }

    public final void zzf(int i, zzih zzih) throws IOException {
        zzgf zzhc = zzhc();
        zzhc.zzb(6, zzih);
        zzhc.flush();
        this.zzaae = this.zzot.position();
    }

    public final void zzhd() {
        if (this.zzot.remaining() != 0) {
            throw new IllegalStateException(String.format("Did not write as much data as expected, %s bytes remaining.", new Object[]{Integer.valueOf(this.zzot.remaining())}));
        }
    }

    public final void zzj(int i, long j) throws IOException {
        zzd(i, 0);
        zzq(j);
    }

    public final void zzk(byte[] bArr) throws IOException {
        int length = bArr.length;
        if (this.zzot.remaining() >= length) {
            this.zzot.put(bArr, 0, length);
            return;
        }
        throw new zzkn(this.zzot.position(), this.zzot.limit());
    }
}
