package com.google.android.gms.internal.places;

public final class zzkq implements Cloneable {
    private static final zzkr zzaai = new zzkr();
    private int mSize;
    private boolean zzaaj;
    private int[] zzaak;
    private zzkr[] zzaal;

    zzkq() {
        this(10);
    }

    private zzkq(int i) {
        this.zzaaj = false;
        i = idealIntArraySize(i);
        this.zzaak = new int[i];
        this.zzaal = new zzkr[i];
        this.mSize = 0;
    }

    private static int idealIntArraySize(int i) {
        i <<= 2;
        for (int i2 = 4; i2 < 32; i2++) {
            int i3 = (1 << i2) - 12;
            if (i <= i3) {
                i = i3;
                break;
            }
        }
        return i / 4;
    }

    private final int zzbw(int i) {
        int i2 = this.mSize - 1;
        int i3 = 0;
        while (i3 <= i2) {
            int i4 = (i3 + i2) >>> 1;
            int i5 = this.zzaak[i4];
            if (i5 < i) {
                i3 = i4 + 1;
            } else if (i5 <= i) {
                return i4;
            } else {
                i2 = i4 - 1;
            }
        }
        return i3 ^ -1;
    }

    public final /* synthetic */ Object clone() throws CloneNotSupportedException {
        int i = this.mSize;
        zzkq zzkq = new zzkq(i);
        int i2 = 0;
        System.arraycopy(this.zzaak, 0, zzkq.zzaak, 0, i);
        while (i2 < i) {
            if (this.zzaal[i2] != null) {
                zzkq.zzaal[i2] = (zzkr) this.zzaal[i2].clone();
            }
            i2++;
        }
        zzkq.mSize = i;
        return zzkq;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof zzkq)) {
            return false;
        }
        zzkq zzkq = (zzkq) obj;
        if (this.mSize != zzkq.mSize) {
            return false;
        }
        Object obj2;
        int[] iArr = this.zzaak;
        int[] iArr2 = zzkq.zzaak;
        int i = this.mSize;
        for (int i2 = 0; i2 < i; i2++) {
            if (iArr[i2] != iArr2[i2]) {
                obj2 = null;
                break;
            }
        }
        obj2 = 1;
        if (obj2 != null) {
            zzkr[] zzkrArr = this.zzaal;
            zzkr[] zzkrArr2 = zzkq.zzaal;
            int i3 = this.mSize;
            for (i = 0; i < i3; i++) {
                if (!zzkrArr[i].equals(zzkrArr2[i])) {
                    obj = null;
                    break;
                }
            }
            obj = 1;
            if (obj != null) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        int i = 17;
        for (int i2 = 0; i2 < this.mSize; i2++) {
            i = (((i * 31) + this.zzaak[i2]) * 31) + this.zzaal[i2].hashCode();
        }
        return i;
    }

    public final boolean isEmpty() {
        return this.mSize == 0;
    }

    final int size() {
        return this.mSize;
    }

    final void zzb(int i, zzkr zzkr) {
        int zzbw = zzbw(i);
        if (zzbw >= 0) {
            this.zzaal[zzbw] = zzkr;
            return;
        }
        zzbw ^= -1;
        if (zzbw >= this.mSize || this.zzaal[zzbw] != zzaai) {
            if (this.mSize >= this.zzaak.length) {
                int idealIntArraySize = idealIntArraySize(this.mSize + 1);
                Object obj = new int[idealIntArraySize];
                Object obj2 = new zzkr[idealIntArraySize];
                System.arraycopy(this.zzaak, 0, obj, 0, this.zzaak.length);
                System.arraycopy(this.zzaal, 0, obj2, 0, this.zzaal.length);
                this.zzaak = obj;
                this.zzaal = obj2;
            }
            if (this.mSize - zzbw != 0) {
                int i2 = zzbw + 1;
                System.arraycopy(this.zzaak, zzbw, this.zzaak, i2, this.mSize - zzbw);
                System.arraycopy(this.zzaal, zzbw, this.zzaal, i2, this.mSize - zzbw);
            }
            this.zzaak[zzbw] = i;
            this.zzaal[zzbw] = zzkr;
            this.mSize++;
            return;
        }
        this.zzaak[zzbw] = i;
        this.zzaal[zzbw] = zzkr;
    }

    final zzkr zzbu(int i) {
        i = zzbw(i);
        if (i >= 0) {
            if (this.zzaal[i] != zzaai) {
                return this.zzaal[i];
            }
        }
        return null;
    }

    final zzkr zzbv(int i) {
        return this.zzaal[i];
    }
}
