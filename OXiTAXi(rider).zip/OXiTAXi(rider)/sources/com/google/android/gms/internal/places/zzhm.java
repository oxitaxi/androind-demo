package com.google.android.gms.internal.places;

import java.util.Map.Entry;

final class zzhm<K> implements Entry<K, Object> {
    private Entry<K, zzhk> zzud;

    private zzhm(Entry<K, zzhk> entry) {
        this.zzud = entry;
    }

    public final K getKey() {
        return this.zzud.getKey();
    }

    public final Object getValue() {
        return ((zzhk) this.zzud.getValue()) == null ? null : zzhk.zzei();
    }

    public final Object setValue(Object obj) {
        if (obj instanceof zzih) {
            return ((zzhk) this.zzud.getValue()).zzj((zzih) obj);
        }
        throw new IllegalArgumentException("LazyField now only used for MessageSet, and the value of MessageSet must be an instance of MessageLite");
    }

    public final zzhk zzej() {
        return (zzhk) this.zzud.getValue();
    }
}
