package com.google.android.gms.internal.places;

public class zzgj<ContainingType extends zzih, Type> {
}
