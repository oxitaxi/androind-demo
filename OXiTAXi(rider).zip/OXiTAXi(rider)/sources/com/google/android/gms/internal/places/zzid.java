package com.google.android.gms.internal.places;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

final class zzid implements zzic {
    zzid() {
    }

    public final int zzc(int i, Object obj, Object obj2) {
        zzib zzib = (zzib) obj;
        if (zzib.isEmpty()) {
            return 0;
        }
        Iterator it = zzib.entrySet().iterator();
        if (!it.hasNext()) {
            return 0;
        }
        Entry entry = (Entry) it.next();
        entry.getKey();
        entry.getValue();
        throw new NoSuchMethodError();
    }

    public final Object zzc(Object obj, Object obj2) {
        obj = (zzib) obj;
        zzib zzib = (zzib) obj2;
        if (!zzib.isEmpty()) {
            if (!obj.isMutable()) {
                obj = obj.zzeq();
            }
            obj.zzb(zzib);
        }
        return obj;
    }

    public final Map<?, ?> zzh(Object obj) {
        return (zzib) obj;
    }

    public final Map<?, ?> zzi(Object obj) {
        return (zzib) obj;
    }

    public final boolean zzj(Object obj) {
        return !((zzib) obj).isMutable();
    }

    public final Object zzk(Object obj) {
        ((zzib) obj).zzbb();
        return obj;
    }

    public final Object zzl(Object obj) {
        return zzib.zzep().zzeq();
    }

    public final zzia<?, ?> zzm(Object obj) {
        throw new NoSuchMethodError();
    }
}
