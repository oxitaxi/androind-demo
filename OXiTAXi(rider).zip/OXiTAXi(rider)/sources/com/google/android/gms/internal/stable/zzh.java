package com.google.android.gms.internal.stable;

import java.util.HashMap;
import java.util.concurrent.atomic.AtomicBoolean;

final class zzh {
    HashMap<String, String> zzags = new HashMap();
    Object zzagt = new Object();
    AtomicBoolean zzagu = new AtomicBoolean(false);

    zzh() {
    }
}
