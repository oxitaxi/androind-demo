package com.google.android.gms.internal.places;

final class zzia<K, V> {
    public final V zzss;
    public final zzke zzut;
    public final K zzuu;
    public final zzke zzuv;
}
