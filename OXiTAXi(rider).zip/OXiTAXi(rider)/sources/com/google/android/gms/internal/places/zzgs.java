package com.google.android.gms.internal.places;

public interface zzgs<T extends zzgs<T>> extends Comparable<T> {
    int zzap();

    zzii zzb(zzii zzii, zzih zzih);

    zzin zzb(zzin zzin, zzin zzin2);

    zzke zzdi();

    zzkj zzdj();

    boolean zzdk();

    boolean zzdl();
}
