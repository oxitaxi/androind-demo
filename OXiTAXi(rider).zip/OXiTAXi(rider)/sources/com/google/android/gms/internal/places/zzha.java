package com.google.android.gms.internal.places;

import java.util.Arrays;
import java.util.Collection;
import java.util.RandomAccess;

final class zzha extends zzfk<Integer> implements zzhe, RandomAccess {
    private static final zzha zztj;
    private int size;
    private int[] zztk;

    static {
        zzfk zzha = new zzha();
        zztj = zzha;
        zzha.zzbb();
    }

    zzha() {
        this(new int[10], 0);
    }

    private zzha(int[] iArr, int i) {
        this.zztk = iArr;
        this.size = i;
    }

    private final void zzac(int i) {
        if (i < 0 || i >= this.size) {
            throw new IndexOutOfBoundsException(zzad(i));
        }
    }

    private final String zzad(int i) {
        int i2 = this.size;
        StringBuilder stringBuilder = new StringBuilder(35);
        stringBuilder.append("Index:");
        stringBuilder.append(i);
        stringBuilder.append(", Size:");
        stringBuilder.append(i2);
        return stringBuilder.toString();
    }

    public static zzha zzdy() {
        return zztj;
    }

    private final void zzq(int i, int i2) {
        zzbc();
        if (i < 0 || i > this.size) {
            throw new IndexOutOfBoundsException(zzad(i));
        }
        if (this.size < this.zztk.length) {
            System.arraycopy(this.zztk, i, this.zztk, i + 1, this.size - i);
        } else {
            Object obj = new int[(((this.size * 3) / 2) + 1)];
            System.arraycopy(this.zztk, 0, obj, 0, i);
            System.arraycopy(this.zztk, i, obj, i + 1, this.size - i);
            this.zztk = obj;
        }
        this.zztk[i] = i2;
        this.size++;
        this.modCount++;
    }

    public final /* synthetic */ void add(int i, Object obj) {
        zzq(i, ((Integer) obj).intValue());
    }

    public final boolean addAll(Collection<? extends Integer> collection) {
        zzbc();
        zzhb.checkNotNull(collection);
        if (!(collection instanceof zzha)) {
            return super.addAll(collection);
        }
        zzha zzha = (zzha) collection;
        if (zzha.size == 0) {
            return false;
        }
        if (Integer.MAX_VALUE - this.size >= zzha.size) {
            int i = this.size + zzha.size;
            if (i > this.zztk.length) {
                this.zztk = Arrays.copyOf(this.zztk, i);
            }
            System.arraycopy(zzha.zztk, 0, this.zztk, this.size, zzha.size);
            this.size = i;
            this.modCount++;
            return true;
        }
        throw new OutOfMemoryError();
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof zzha)) {
            return super.equals(obj);
        }
        zzha zzha = (zzha) obj;
        if (this.size != zzha.size) {
            return false;
        }
        int[] iArr = zzha.zztk;
        for (int i = 0; i < this.size; i++) {
            if (this.zztk[i] != iArr[i]) {
                return false;
            }
        }
        return true;
    }

    public final /* synthetic */ Object get(int i) {
        return Integer.valueOf(getInt(i));
    }

    public final int getInt(int i) {
        zzac(i);
        return this.zztk[i];
    }

    public final int hashCode() {
        int i = 1;
        for (int i2 = 0; i2 < this.size; i2++) {
            i = (i * 31) + this.zztk[i2];
        }
        return i;
    }

    public final /* synthetic */ Object remove(int i) {
        zzbc();
        zzac(i);
        int i2 = this.zztk[i];
        if (i < this.size - 1) {
            System.arraycopy(this.zztk, i + 1, this.zztk, i, this.size - i);
        }
        this.size--;
        this.modCount++;
        return Integer.valueOf(i2);
    }

    public final boolean remove(Object obj) {
        zzbc();
        for (int i = 0; i < this.size; i++) {
            if (obj.equals(Integer.valueOf(this.zztk[i]))) {
                System.arraycopy(this.zztk, i + 1, this.zztk, i, this.size - i);
                this.size--;
                this.modCount++;
                return true;
            }
        }
        return false;
    }

    protected final void removeRange(int i, int i2) {
        zzbc();
        if (i2 >= i) {
            System.arraycopy(this.zztk, i2, this.zztk, i, this.size - i2);
            this.size -= i2 - i;
            this.modCount++;
            return;
        }
        throw new IndexOutOfBoundsException("toIndex < fromIndex");
    }

    public final /* synthetic */ Object set(int i, Object obj) {
        int intValue = ((Integer) obj).intValue();
        zzbc();
        zzac(i);
        int i2 = this.zztk[i];
        this.zztk[i] = intValue;
        return Integer.valueOf(i2);
    }

    public final int size() {
        return this.size;
    }

    public final /* synthetic */ zzhg zzae(int i) {
        return zzbd(i);
    }

    public final zzhe zzbd(int i) {
        if (i >= this.size) {
            return new zzha(Arrays.copyOf(this.zztk, i), this.size);
        }
        throw new IllegalArgumentException();
    }

    public final void zzbe(int i) {
        zzq(this.size, i);
    }
}
