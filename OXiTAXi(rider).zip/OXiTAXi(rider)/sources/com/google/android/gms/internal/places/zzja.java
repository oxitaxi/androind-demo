package com.google.android.gms.internal.places;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.RandomAccess;

final class zzja {
    private static final Class<?> zzwz = zzge();
    private static final zzjq<?, ?> zzxa = zzg(false);
    private static final zzjq<?, ?> zzxb = zzg(true);
    private static final zzjq<?, ?> zzxc = new zzjs();

    static int zzaa(List<Integer> list) {
        int size = list.size();
        int i = 0;
        if (size == 0) {
            return 0;
        }
        int i2;
        if (list instanceof zzha) {
            zzha zzha = (zzha) list;
            i2 = 0;
            while (i < size) {
                i2 += zzgf.zzav(zzha.getInt(i));
                i++;
            }
        } else {
            i2 = 0;
            while (i < size) {
                i2 += zzgf.zzav(((Integer) list.get(i)).intValue());
                i++;
            }
        }
        return i2;
    }

    static int zzab(List<?> list) {
        return list.size() << 2;
    }

    static int zzac(List<?> list) {
        return list.size() << 3;
    }

    static int zzad(List<?> list) {
        return list.size();
    }

    static <UT, UB> UB zzb(int i, int i2, UB ub, zzjq<UT, UB> zzjq) {
        Object zzgo;
        if (ub == null) {
            zzgo = zzjq.zzgo();
        }
        zzjq.zzb(zzgo, i, (long) i2);
        return zzgo;
    }

    static <UT, UB> UB zzb(int i, List<Integer> list, zzhd<?> zzhd, UB ub, zzjq<UT, UB> zzjq) {
        if (zzhd == null) {
            return ub;
        }
        UB ub2;
        int intValue;
        if (!(list instanceof RandomAccess)) {
            Iterator it = list.iterator();
            loop1:
            while (true) {
                ub2 = ub;
                while (it.hasNext()) {
                    intValue = ((Integer) it.next()).intValue();
                    if (zzhd.zzi(intValue) == null) {
                        ub = zzb(i, intValue, (Object) ub2, (zzjq) zzjq);
                        it.remove();
                    }
                }
                break loop1;
            }
        }
        int size = list.size();
        ub2 = ub;
        intValue = 0;
        for (int i2 = 0; i2 < size; i2++) {
            int intValue2 = ((Integer) list.get(i2)).intValue();
            if (zzhd.zzi(intValue2) != null) {
                if (i2 != intValue) {
                    list.set(intValue, Integer.valueOf(intValue2));
                }
                intValue++;
            } else {
                ub2 = zzb(i, intValue2, (Object) ub2, (zzjq) zzjq);
            }
        }
        if (intValue != size) {
            list.subList(intValue, size).clear();
        }
        return ub2;
    }

    public static void zzb(int i, List<String> list, zzkk zzkk) throws IOException {
        if (list != null && !list.isEmpty()) {
            zzkk.zzc(i, (List) list);
        }
    }

    public static void zzb(int i, List<?> list, zzkk zzkk, zziy zziy) throws IOException {
        if (list != null && !list.isEmpty()) {
            zzkk.zzb(i, (List) list, zziy);
        }
    }

    public static void zzb(int i, List<Double> list, zzkk zzkk, boolean z) throws IOException {
        if (list != null && !list.isEmpty()) {
            zzkk.zzh(i, list, z);
        }
    }

    static <T, FT extends zzgs<FT>> void zzb(zzgm<FT> zzgm, T t, T t2) {
        zzgq zzb = zzgm.zzb((Object) t2);
        if (!zzb.isEmpty()) {
            zzgm.zzc(t).zzb(zzb);
        }
    }

    static <T> void zzb(zzic zzic, T t, T t2, long j) {
        zzjw.zzb((Object) t, j, zzic.zzc(zzjw.zzq(t, j), zzjw.zzq(t2, j)));
    }

    static <T, UT, UB> void zzb(zzjq<UT, UB> zzjq, T t, T t2) {
        zzjq.zzf(t, zzjq.zzh(zzjq.zzq(t), zzjq.zzq(t2)));
    }

    public static void zzc(int i, List<zzfr> list, zzkk zzkk) throws IOException {
        if (list != null && !list.isEmpty()) {
            zzkk.zzd(i, (List) list);
        }
    }

    public static void zzc(int i, List<?> list, zzkk zzkk, zziy zziy) throws IOException {
        if (list != null && !list.isEmpty()) {
            zzkk.zzc(i, (List) list, zziy);
        }
    }

    public static void zzc(int i, List<Float> list, zzkk zzkk, boolean z) throws IOException {
        if (list != null && !list.isEmpty()) {
            zzkk.zzg(i, list, z);
        }
    }

    static int zzd(int i, Object obj, zziy zziy) {
        return obj instanceof zzho ? zzgf.zzb(i, (zzho) obj) : zzgf.zzc(i, (zzih) obj, zziy);
    }

    static int zzd(int i, List<?> list, zziy zziy) {
        int size = list.size();
        int i2 = 0;
        if (size == 0) {
            return 0;
        }
        i = zzgf.zzas(i) * size;
        while (i2 < size) {
            Object obj = list.get(i2);
            i += obj instanceof zzho ? zzgf.zzb((zzho) obj) : zzgf.zzc((zzih) obj, zziy);
            i2++;
        }
        return i;
    }

    public static void zzd(int i, List<Long> list, zzkk zzkk, boolean z) throws IOException {
        if (list != null && !list.isEmpty()) {
            zzkk.zzd(i, list, z);
        }
    }

    public static boolean zzd(int i, int i2, int i3) {
        if (i2 < 40) {
            return true;
        }
        long j = (long) i3;
        return ((((long) i2) - ((long) i)) + 1) + 9 <= ((2 * j) + 3) + ((j + 3) * 3);
    }

    static int zze(int i, List<?> list) {
        int size = list.size();
        int i2 = 0;
        if (size == 0) {
            return 0;
        }
        i = zzgf.zzas(i) * size;
        Object raw;
        if (list instanceof zzhq) {
            zzhq zzhq = (zzhq) list;
            while (i2 < size) {
                raw = zzhq.getRaw(i2);
                i += raw instanceof zzfr ? zzgf.zzc((zzfr) raw) : zzgf.zzl((String) raw);
                i2++;
            }
        } else {
            while (i2 < size) {
                raw = list.get(i2);
                i += raw instanceof zzfr ? zzgf.zzc((zzfr) raw) : zzgf.zzl((String) raw);
                i2++;
            }
        }
        return i;
    }

    static int zze(int i, List<zzih> list, zziy zziy) {
        int size = list.size();
        int i2 = 0;
        if (size == 0) {
            return 0;
        }
        int i3 = 0;
        while (i2 < size) {
            i3 += zzgf.zzd(i, (zzih) list.get(i2), zziy);
            i2++;
        }
        return i3;
    }

    public static void zze(int i, List<Long> list, zzkk zzkk, boolean z) throws IOException {
        if (list != null && !list.isEmpty()) {
            zzkk.zze(i, list, z);
        }
    }

    static boolean zze(Object obj, Object obj2) {
        if (obj != obj2) {
            if (obj == null || !obj.equals(obj2)) {
                return false;
            }
        }
        return true;
    }

    static int zzf(int i, List<zzfr> list) {
        int size = list.size();
        int i2 = 0;
        if (size == 0) {
            return 0;
        }
        size *= zzgf.zzas(i);
        while (i2 < list.size()) {
            size += zzgf.zzc((zzfr) list.get(i2));
            i2++;
        }
        return size;
    }

    public static void zzf(int i, List<Long> list, zzkk zzkk, boolean z) throws IOException {
        if (list != null && !list.isEmpty()) {
            zzkk.zzo(i, list, z);
        }
    }

    private static com.google.android.gms.internal.places.zzjq<?, ?> zzg(boolean r6) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/952562199.run(Unknown Source)
*/
        /*
        r0 = 0;
        r1 = zzgf();	 Catch:{ Throwable -> 0x0023 }
        if (r1 != 0) goto L_0x0008;	 Catch:{ Throwable -> 0x0023 }
    L_0x0007:
        return r0;	 Catch:{ Throwable -> 0x0023 }
    L_0x0008:
        r2 = 1;	 Catch:{ Throwable -> 0x0023 }
        r3 = new java.lang.Class[r2];	 Catch:{ Throwable -> 0x0023 }
        r4 = java.lang.Boolean.TYPE;	 Catch:{ Throwable -> 0x0023 }
        r5 = 0;	 Catch:{ Throwable -> 0x0023 }
        r3[r5] = r4;	 Catch:{ Throwable -> 0x0023 }
        r1 = r1.getConstructor(r3);	 Catch:{ Throwable -> 0x0023 }
        r2 = new java.lang.Object[r2];	 Catch:{ Throwable -> 0x0023 }
        r6 = java.lang.Boolean.valueOf(r6);	 Catch:{ Throwable -> 0x0023 }
        r2[r5] = r6;	 Catch:{ Throwable -> 0x0023 }
        r6 = r1.newInstance(r2);	 Catch:{ Throwable -> 0x0023 }
        r6 = (com.google.android.gms.internal.places.zzjq) r6;	 Catch:{ Throwable -> 0x0023 }
        return r6;
    L_0x0023:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.places.zzja.zzg(boolean):com.google.android.gms.internal.places.zzjq<?, ?>");
    }

    public static void zzg(int i, List<Long> list, zzkk zzkk, boolean z) throws IOException {
        if (list != null && !list.isEmpty()) {
            zzkk.zzf(i, list, z);
        }
    }

    public static zzjq<?, ?> zzgb() {
        return zzxa;
    }

    public static zzjq<?, ?> zzgc() {
        return zzxb;
    }

    public static zzjq<?, ?> zzgd() {
        return zzxc;
    }

    private static java.lang.Class<?> zzge() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/952562199.run(Unknown Source)
*/
        /*
        r0 = "com.google.protobuf.GeneratedMessage";	 Catch:{ Throwable -> 0x0007 }
        r0 = java.lang.Class.forName(r0);	 Catch:{ Throwable -> 0x0007 }
        return r0;
    L_0x0007:
        r0 = 0;
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.places.zzja.zzge():java.lang.Class<?>");
    }

    private static java.lang.Class<?> zzgf() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/952562199.run(Unknown Source)
*/
        /*
        r0 = "com.google.protobuf.UnknownFieldSetSchema";	 Catch:{ Throwable -> 0x0007 }
        r0 = java.lang.Class.forName(r0);	 Catch:{ Throwable -> 0x0007 }
        return r0;
    L_0x0007:
        r0 = 0;
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.places.zzja.zzgf():java.lang.Class<?>");
    }

    public static void zzh(int i, List<Long> list, zzkk zzkk, boolean z) throws IOException {
        if (list != null && !list.isEmpty()) {
            zzkk.zzm(i, list, z);
        }
    }

    public static void zzh(Class<?> cls) {
        if (!zzgz.class.isAssignableFrom(cls) && zzwz != null) {
            if (!zzwz.isAssignableFrom(cls)) {
                throw new IllegalArgumentException("Message classes must extend GeneratedMessage or GeneratedMessageLite");
            }
        }
    }

    public static void zzi(int i, List<Integer> list, zzkk zzkk, boolean z) throws IOException {
        if (list != null && !list.isEmpty()) {
            zzkk.zzb(i, (List) list, z);
        }
    }

    public static void zzj(int i, List<Integer> list, zzkk zzkk, boolean z) throws IOException {
        if (list != null && !list.isEmpty()) {
            zzkk.zzk(i, list, z);
        }
    }

    public static void zzk(int i, List<Integer> list, zzkk zzkk, boolean z) throws IOException {
        if (list != null && !list.isEmpty()) {
            zzkk.zzn(i, list, z);
        }
    }

    public static void zzl(int i, List<Integer> list, zzkk zzkk, boolean z) throws IOException {
        if (list != null && !list.isEmpty()) {
            zzkk.zzc(i, (List) list, z);
        }
    }

    public static void zzm(int i, List<Integer> list, zzkk zzkk, boolean z) throws IOException {
        if (list != null && !list.isEmpty()) {
            zzkk.zzl(i, list, z);
        }
    }

    public static void zzn(int i, List<Integer> list, zzkk zzkk, boolean z) throws IOException {
        if (list != null && !list.isEmpty()) {
            zzkk.zzi(i, list, z);
        }
    }

    public static void zzo(int i, List<Boolean> list, zzkk zzkk, boolean z) throws IOException {
        if (list != null && !list.isEmpty()) {
            zzkk.zzj(i, list, z);
        }
    }

    static int zzp(int i, List<Long> list, boolean z) {
        return list.size() == 0 ? 0 : zzu(list) + (list.size() * zzgf.zzas(i));
    }

    static int zzq(int i, List<Long> list, boolean z) {
        int size = list.size();
        return size == 0 ? 0 : zzv(list) + (size * zzgf.zzas(i));
    }

    static int zzr(int i, List<Long> list, boolean z) {
        int size = list.size();
        return size == 0 ? 0 : zzw(list) + (size * zzgf.zzas(i));
    }

    static int zzs(int i, List<Integer> list, boolean z) {
        int size = list.size();
        return size == 0 ? 0 : zzx(list) + (size * zzgf.zzas(i));
    }

    static int zzt(int i, List<Integer> list, boolean z) {
        int size = list.size();
        return size == 0 ? 0 : zzy(list) + (size * zzgf.zzas(i));
    }

    static int zzu(int i, List<Integer> list, boolean z) {
        int size = list.size();
        return size == 0 ? 0 : zzz(list) + (size * zzgf.zzas(i));
    }

    static int zzu(List<Long> list) {
        int size = list.size();
        int i = 0;
        if (size == 0) {
            return 0;
        }
        int i2;
        if (list instanceof zzhv) {
            zzhv zzhv = (zzhv) list;
            i2 = 0;
            while (i < size) {
                i2 += zzgf.zzh(zzhv.getLong(i));
                i++;
            }
        } else {
            i2 = 0;
            while (i < size) {
                i2 += zzgf.zzh(((Long) list.get(i)).longValue());
                i++;
            }
        }
        return i2;
    }

    static int zzv(int i, List<Integer> list, boolean z) {
        int size = list.size();
        return size == 0 ? 0 : zzaa(list) + (size * zzgf.zzas(i));
    }

    static int zzv(List<Long> list) {
        int size = list.size();
        int i = 0;
        if (size == 0) {
            return 0;
        }
        int i2;
        if (list instanceof zzhv) {
            zzhv zzhv = (zzhv) list;
            i2 = 0;
            while (i < size) {
                i2 += zzgf.zzi(zzhv.getLong(i));
                i++;
            }
        } else {
            i2 = 0;
            while (i < size) {
                i2 += zzgf.zzi(((Long) list.get(i)).longValue());
                i++;
            }
        }
        return i2;
    }

    static int zzw(int i, List<?> list, boolean z) {
        int size = list.size();
        return size == 0 ? 0 : size * zzgf.zzl(i, 0);
    }

    static int zzw(List<Long> list) {
        int size = list.size();
        int i = 0;
        if (size == 0) {
            return 0;
        }
        int i2;
        if (list instanceof zzhv) {
            zzhv zzhv = (zzhv) list;
            i2 = 0;
            while (i < size) {
                i2 += zzgf.zzj(zzhv.getLong(i));
                i++;
            }
        } else {
            i2 = 0;
            while (i < size) {
                i2 += zzgf.zzj(((Long) list.get(i)).longValue());
                i++;
            }
        }
        return i2;
    }

    static int zzx(int i, List<?> list, boolean z) {
        int size = list.size();
        return size == 0 ? 0 : size * zzgf.zzh(i, 0);
    }

    static int zzx(List<Integer> list) {
        int size = list.size();
        int i = 0;
        if (size == 0) {
            return 0;
        }
        int i2;
        if (list instanceof zzha) {
            zzha zzha = (zzha) list;
            i2 = 0;
            while (i < size) {
                i2 += zzgf.zzay(zzha.getInt(i));
                i++;
            }
        } else {
            i2 = 0;
            while (i < size) {
                i2 += zzgf.zzay(((Integer) list.get(i)).intValue());
                i++;
            }
        }
        return i2;
    }

    static int zzy(int i, List<?> list, boolean z) {
        int size = list.size();
        return size == 0 ? 0 : size * zzgf.zzd(i, true);
    }

    static int zzy(List<Integer> list) {
        int size = list.size();
        int i = 0;
        if (size == 0) {
            return 0;
        }
        int i2;
        if (list instanceof zzha) {
            zzha zzha = (zzha) list;
            i2 = 0;
            while (i < size) {
                i2 += zzgf.zzat(zzha.getInt(i));
                i++;
            }
        } else {
            i2 = 0;
            while (i < size) {
                i2 += zzgf.zzat(((Integer) list.get(i)).intValue());
                i++;
            }
        }
        return i2;
    }

    static int zzz(List<Integer> list) {
        int size = list.size();
        int i = 0;
        if (size == 0) {
            return 0;
        }
        int i2;
        if (list instanceof zzha) {
            zzha zzha = (zzha) list;
            i2 = 0;
            while (i < size) {
                i2 += zzgf.zzau(zzha.getInt(i));
                i++;
            }
        } else {
            i2 = 0;
            while (i < size) {
                i2 += zzgf.zzau(((Integer) list.get(i)).intValue());
                i++;
            }
        }
        return i2;
    }
}
