package com.google.android.gms.internal.places;

import java.io.IOException;

public final class zzhz<K, V> {
    static <K, V> int zzb(zzia<K, V> zzia, K k, V v) {
        return zzgq.zzb(zzia.zzut, 1, k) + zzgq.zzb(zzia.zzuv, 2, v);
    }

    static <K, V> void zzb(zzgf zzgf, zzia<K, V> zzia, K k, V v) throws IOException {
        zzgq.zzb(zzgf, zzia.zzut, 1, k);
        zzgq.zzb(zzgf, zzia.zzuv, 2, v);
    }
}
