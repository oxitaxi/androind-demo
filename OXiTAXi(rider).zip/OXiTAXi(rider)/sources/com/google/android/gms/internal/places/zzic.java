package com.google.android.gms.internal.places;

import java.util.Map;

interface zzic {
    int zzc(int i, Object obj, Object obj2);

    Object zzc(Object obj, Object obj2);

    Map<?, ?> zzh(Object obj);

    Map<?, ?> zzi(Object obj);

    boolean zzj(Object obj);

    Object zzk(Object obj);

    Object zzl(Object obj);

    zzia<?, ?> zzm(Object obj);
}
