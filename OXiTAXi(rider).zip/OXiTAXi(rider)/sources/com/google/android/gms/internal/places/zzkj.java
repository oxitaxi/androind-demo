package com.google.android.gms.internal.places;

public enum zzkj {
    INT(Integer.valueOf(0)),
    LONG(Long.valueOf(0)),
    FLOAT(Float.valueOf(0.0f)),
    DOUBLE(Double.valueOf(0.0d)),
    BOOLEAN(Boolean.valueOf(false)),
    STRING(""),
    BYTE_STRING(zzfr.zznt),
    ENUM(null),
    MESSAGE(null);
    
    private final Object zzub;

    private zzkj(Object obj) {
        this.zzub = obj;
    }
}
