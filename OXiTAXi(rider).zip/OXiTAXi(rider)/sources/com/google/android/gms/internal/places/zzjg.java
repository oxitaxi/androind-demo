package com.google.android.gms.internal.places;

import java.util.Iterator;
import java.util.NoSuchElementException;

final class zzjg implements Iterator<Object> {
    zzjg() {
    }

    public final boolean hasNext() {
        return false;
    }

    public final Object next() {
        throw new NoSuchElementException();
    }

    public final void remove() {
        throw new UnsupportedOperationException();
    }
}
