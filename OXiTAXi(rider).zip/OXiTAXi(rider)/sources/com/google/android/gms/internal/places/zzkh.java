package com.google.android.gms.internal.places;

enum zzkh extends zzke {
    zzkh(String str, int i, zzkj zzkj, int i2) {
        super(str, 10, zzkj, 2);
    }
}
