package com.google.android.gms.internal.places;

import java.io.IOException;
import java.util.List;

final class zzgd implements zzix {
    private int tag;
    private int zznq;
    private final zzga zzom;
    private int zzon = 0;

    private zzgd(zzga zzga) {
        this.zzom = (zzga) zzhb.zzb((Object) zzga, "input");
        this.zzom.zzoe = this;
    }

    private static void zzaa(int i) throws IOException {
        if ((i & 3) != 0) {
            throw zzhh.zzef();
        }
    }

    private final void zzab(int i) throws IOException {
        if (this.zzom.zzcl() != i) {
            throw zzhh.zzdz();
        }
    }

    public static zzgd zzb(zzga zzga) {
        return zzga.zzoe != null ? zzga.zzoe : new zzgd(zzga);
    }

    private final Object zzb(zzke zzke, Class<?> cls, zzgl zzgl) throws IOException {
        switch (zzge.zznn[zzke.ordinal()]) {
            case 1:
                return Boolean.valueOf(zzbn());
            case 2:
                return zzbp();
            case 3:
                return Double.valueOf(readDouble());
            case 4:
                return Integer.valueOf(zzbr());
            case 5:
                return Integer.valueOf(zzbm());
            case 6:
                return Long.valueOf(zzbl());
            case 7:
                return Float.valueOf(readFloat());
            case 8:
                return Integer.valueOf(zzbk());
            case 9:
                return Long.valueOf(zzbj());
            case 10:
                return zzb((Class) cls, zzgl);
            case 11:
                return Integer.valueOf(zzbs());
            case 12:
                return Long.valueOf(zzbt());
            case 13:
                return Integer.valueOf(zzbu());
            case 14:
                return Long.valueOf(zzbv());
            case 15:
                return zzbo();
            case 16:
                return Integer.valueOf(zzbq());
            case 17:
                return Long.valueOf(zzbi());
            default:
                throw new RuntimeException("unsupported field type.");
        }
    }

    private final void zzb(List<String> list, boolean z) throws IOException {
        if ((this.tag & 7) != 2) {
            throw zzhh.zzed();
        } else if (!(list instanceof zzhq) || z) {
            int zzcj;
            do {
                list.add(z ? zzbo() : readString());
                if (!this.zzom.zzbf()) {
                    zzcj = this.zzom.zzcj();
                } else {
                    return;
                }
            } while (zzcj == this.tag);
            this.zzon = zzcj;
        } else {
            int zzcj2;
            zzhq zzhq = (zzhq) list;
            do {
                zzhq.zzd(zzbp());
                if (!this.zzom.zzbf()) {
                    zzcj2 = this.zzom.zzcj();
                } else {
                    return;
                }
            } while (zzcj2 == this.tag);
            this.zzon = zzcj2;
        }
    }

    private final <T> T zzc(zziy<T> zziy, zzgl zzgl) throws IOException {
        int zzbq = this.zzom.zzbq();
        if (this.zzom.zzob < this.zzom.zzoc) {
            zzbq = this.zzom.zzak(zzbq);
            T newInstance = zziy.newInstance();
            zzga zzga = this.zzom;
            zzga.zzob++;
            zziy.zzb(newInstance, this, zzgl);
            zziy.zzd(newInstance);
            this.zzom.zzah(0);
            zzga zzga2 = this.zzom;
            zzga2.zzob--;
            this.zzom.zzal(zzbq);
            return newInstance;
        }
        throw zzhh.zzee();
    }

    private final <T> T zze(zziy<T> zziy, zzgl zzgl) throws IOException {
        int i = this.zznq;
        T t = ((this.tag >>> 3) << 3) | 4;
        this.zznq = t;
        try {
            t = zziy.newInstance();
            zziy.zzb(t, this, zzgl);
            zziy.zzd(t);
            if (this.tag == this.zznq) {
                return t;
            }
            throw zzhh.zzef();
        } finally {
            this.zznq = i;
        }
    }

    private final void zzy(int i) throws IOException {
        if ((this.tag & 7) != i) {
            throw zzhh.zzed();
        }
    }

    private static void zzz(int i) throws IOException {
        if ((i & 7) != 0) {
            throw zzhh.zzef();
        }
    }

    public final int getTag() {
        return this.tag;
    }

    public final double readDouble() throws IOException {
        zzy(1);
        return this.zzom.readDouble();
    }

    public final float readFloat() throws IOException {
        zzy(5);
        return this.zzom.readFloat();
    }

    public final String readString() throws IOException {
        zzy(2);
        return this.zzom.readString();
    }

    public final void readStringList(List<String> list) throws IOException {
        zzb((List) list, false);
    }

    public final <T> T zzb(zziy<T> zziy, zzgl zzgl) throws IOException {
        zzy(2);
        return zzc((zziy) zziy, zzgl);
    }

    public final <T> T zzb(Class<T> cls, zzgl zzgl) throws IOException {
        zzy(2);
        return zzc(zzis.zzfc().zzg(cls), zzgl);
    }

    public final <T> void zzb(List<T> list, zziy<T> zziy, zzgl zzgl) throws IOException {
        if ((this.tag & 7) == 2) {
            int zzcj;
            int i = this.tag;
            do {
                list.add(zzc((zziy) zziy, zzgl));
                if (!this.zzom.zzbf()) {
                    if (this.zzon == 0) {
                        zzcj = this.zzom.zzcj();
                    } else {
                        return;
                    }
                }
                return;
            } while (zzcj == i);
            this.zzon = zzcj;
            return;
        }
        throw zzhh.zzed();
    }

    public final <K, V> void zzb(java.util.Map<K, V> r6, com.google.android.gms.internal.places.zzia<K, V> r7, com.google.android.gms.internal.places.zzgl r8) throws java.io.IOException {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/952562199.run(Unknown Source)
*/
        /*
        r5 = this;
        r0 = 2;
        r5.zzy(r0);
        r0 = r5.zzom;
        r0 = r0.zzbq();
        r1 = r5.zzom;
        r0 = r1.zzak(r0);
        r1 = r7.zzuu;
        r2 = r7.zzss;
    L_0x0014:
        r3 = r5.zzbg();	 Catch:{ all -> 0x0067 }
        r4 = 2147483647; // 0x7fffffff float:NaN double:1.060997895E-314;	 Catch:{ all -> 0x0067 }
        if (r3 == r4) goto L_0x005e;	 Catch:{ all -> 0x0067 }
    L_0x001d:
        r4 = r5.zzom;	 Catch:{ all -> 0x0067 }
        r4 = r4.zzbf();	 Catch:{ all -> 0x0067 }
        if (r4 != 0) goto L_0x005e;
    L_0x0025:
        switch(r3) {
            case 1: goto L_0x003b;
            case 2: goto L_0x002d;
            default: goto L_0x0028;
        };
    L_0x0028:
        r3 = r5.zzbh();	 Catch:{ zzhi -> 0x004f }
        goto L_0x0044;	 Catch:{ zzhi -> 0x004f }
    L_0x002d:
        r3 = r7.zzuv;	 Catch:{ zzhi -> 0x004f }
        r4 = r7.zzss;	 Catch:{ zzhi -> 0x004f }
        r4 = r4.getClass();	 Catch:{ zzhi -> 0x004f }
        r3 = r5.zzb(r3, r4, r8);	 Catch:{ zzhi -> 0x004f }
        r2 = r3;	 Catch:{ zzhi -> 0x004f }
        goto L_0x0014;	 Catch:{ zzhi -> 0x004f }
    L_0x003b:
        r3 = r7.zzut;	 Catch:{ zzhi -> 0x004f }
        r4 = 0;	 Catch:{ zzhi -> 0x004f }
        r3 = r5.zzb(r3, r4, r4);	 Catch:{ zzhi -> 0x004f }
        r1 = r3;	 Catch:{ zzhi -> 0x004f }
        goto L_0x0014;	 Catch:{ zzhi -> 0x004f }
    L_0x0044:
        if (r3 == 0) goto L_0x0047;	 Catch:{ zzhi -> 0x004f }
    L_0x0046:
        goto L_0x0014;	 Catch:{ zzhi -> 0x004f }
    L_0x0047:
        r3 = new com.google.android.gms.internal.places.zzhh;	 Catch:{ zzhi -> 0x004f }
        r4 = "Unable to parse map entry.";	 Catch:{ zzhi -> 0x004f }
        r3.<init>(r4);	 Catch:{ zzhi -> 0x004f }
        throw r3;	 Catch:{ zzhi -> 0x004f }
    L_0x004f:
        r3 = r5.zzbh();	 Catch:{ all -> 0x0067 }
        if (r3 == 0) goto L_0x0056;	 Catch:{ all -> 0x0067 }
    L_0x0055:
        goto L_0x0014;	 Catch:{ all -> 0x0067 }
    L_0x0056:
        r6 = new com.google.android.gms.internal.places.zzhh;	 Catch:{ all -> 0x0067 }
        r7 = "Unable to parse map entry.";	 Catch:{ all -> 0x0067 }
        r6.<init>(r7);	 Catch:{ all -> 0x0067 }
        throw r6;	 Catch:{ all -> 0x0067 }
    L_0x005e:
        r6.put(r1, r2);	 Catch:{ all -> 0x0067 }
        r6 = r5.zzom;
        r6.zzal(r0);
        return;
    L_0x0067:
        r6 = move-exception;
        r7 = r5.zzom;
        r7.zzal(r0);
        throw r6;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.places.zzgd.zzb(java.util.Map, com.google.android.gms.internal.places.zzia, com.google.android.gms.internal.places.zzgl):void");
    }

    public final int zzbg() throws IOException {
        if (this.zzon != 0) {
            this.tag = this.zzon;
            this.zzon = 0;
        } else {
            this.tag = this.zzom.zzcj();
        }
        if (this.tag != 0) {
            if (this.tag != this.zznq) {
                return this.tag >>> 3;
            }
        }
        return Integer.MAX_VALUE;
    }

    public final boolean zzbh() throws IOException {
        if (!this.zzom.zzbf()) {
            if (this.tag != this.zznq) {
                return this.zzom.zzai(this.tag);
            }
        }
        return false;
    }

    public final long zzbi() throws IOException {
        zzy(0);
        return this.zzom.zzbi();
    }

    public final long zzbj() throws IOException {
        zzy(0);
        return this.zzom.zzbj();
    }

    public final int zzbk() throws IOException {
        zzy(0);
        return this.zzom.zzbk();
    }

    public final long zzbl() throws IOException {
        zzy(1);
        return this.zzom.zzbl();
    }

    public final int zzbm() throws IOException {
        zzy(5);
        return this.zzom.zzbm();
    }

    public final boolean zzbn() throws IOException {
        zzy(0);
        return this.zzom.zzbn();
    }

    public final String zzbo() throws IOException {
        zzy(2);
        return this.zzom.zzbo();
    }

    public final zzfr zzbp() throws IOException {
        zzy(2);
        return this.zzom.zzbp();
    }

    public final int zzbq() throws IOException {
        zzy(0);
        return this.zzom.zzbq();
    }

    public final int zzbr() throws IOException {
        zzy(0);
        return this.zzom.zzbr();
    }

    public final int zzbs() throws IOException {
        zzy(5);
        return this.zzom.zzbs();
    }

    public final long zzbt() throws IOException {
        zzy(1);
        return this.zzom.zzbt();
    }

    public final int zzbu() throws IOException {
        zzy(0);
        return this.zzom.zzbu();
    }

    public final long zzbv() throws IOException {
        zzy(0);
        return this.zzom.zzbv();
    }

    public final <T> T zzc(Class<T> cls, zzgl zzgl) throws IOException {
        zzy(3);
        return zze(zzis.zzfc().zzg(cls), zzgl);
    }

    public final <T> void zzc(List<T> list, zziy<T> zziy, zzgl zzgl) throws IOException {
        if ((this.tag & 7) == 3) {
            int zzcj;
            int i = this.tag;
            do {
                list.add(zze(zziy, zzgl));
                if (!this.zzom.zzbf()) {
                    if (this.zzon == 0) {
                        zzcj = this.zzom.zzcj();
                    } else {
                        return;
                    }
                }
                return;
            } while (zzcj == i);
            this.zzon = zzcj;
            return;
        }
        throw zzhh.zzed();
    }

    public final <T> T zzd(zziy<T> zziy, zzgl zzgl) throws IOException {
        zzy(3);
        return zze(zziy, zzgl);
    }

    public final void zze(List<Double> list) throws IOException {
        int zzbq;
        int zzcl;
        if (list instanceof zzgi) {
            zzgi zzgi = (zzgi) list;
            switch (this.tag & 7) {
                case 1:
                    break;
                case 2:
                    zzbq = this.zzom.zzbq();
                    zzz(zzbq);
                    zzcl = this.zzom.zzcl() + zzbq;
                    do {
                        zzgi.zzd(this.zzom.readDouble());
                    } while (this.zzom.zzcl() < zzcl);
                    return;
                default:
                    throw zzhh.zzed();
            }
            do {
                zzgi.zzd(this.zzom.readDouble());
                if (!this.zzom.zzbf()) {
                    zzbq = this.zzom.zzcj();
                } else {
                    return;
                }
            } while (zzbq == this.tag);
            this.zzon = zzbq;
            return;
        }
        switch (this.tag & 7) {
            case 1:
                break;
            case 2:
                zzbq = this.zzom.zzbq();
                zzz(zzbq);
                zzcl = this.zzom.zzcl() + zzbq;
                do {
                    list.add(Double.valueOf(this.zzom.readDouble()));
                } while (this.zzom.zzcl() < zzcl);
                return;
            default:
                throw zzhh.zzed();
        }
        do {
            list.add(Double.valueOf(this.zzom.readDouble()));
            if (!this.zzom.zzbf()) {
                zzbq = this.zzom.zzcj();
            } else {
                return;
            }
        } while (zzbq == this.tag);
        this.zzon = zzbq;
    }

    public final void zzf(List<Float> list) throws IOException {
        if (list instanceof zzgw) {
            zzgw zzgw = (zzgw) list;
            int i = this.tag & 7;
            if (i == 2) {
                i = this.zzom.zzbq();
                zzaa(i);
                int zzcl = this.zzom.zzcl() + i;
                do {
                    zzgw.zzf(this.zzom.readFloat());
                } while (this.zzom.zzcl() < zzcl);
                return;
            } else if (i == 5) {
                do {
                    zzgw.zzf(this.zzom.readFloat());
                    if (!this.zzom.zzbf()) {
                        i = this.zzom.zzcj();
                    } else {
                        return;
                    }
                } while (i == this.tag);
                this.zzon = i;
                return;
            } else {
                throw zzhh.zzed();
            }
        }
        int i2 = this.tag & 7;
        if (i2 == 2) {
            i2 = this.zzom.zzbq();
            zzaa(i2);
            int zzcl2 = this.zzom.zzcl() + i2;
            do {
                list.add(Float.valueOf(this.zzom.readFloat()));
            } while (this.zzom.zzcl() < zzcl2);
        } else if (i2 == 5) {
            do {
                list.add(Float.valueOf(this.zzom.readFloat()));
                if (!this.zzom.zzbf()) {
                    i2 = this.zzom.zzcj();
                } else {
                    return;
                }
            } while (i2 == this.tag);
            this.zzon = i2;
        } else {
            throw zzhh.zzed();
        }
    }

    public final void zzg(List<Long> list) throws IOException {
        if (list instanceof zzhv) {
            zzhv zzhv = (zzhv) list;
            int i = this.tag & 7;
            if (i == 0) {
                do {
                    zzhv.zzp(this.zzom.zzbi());
                    if (!this.zzom.zzbf()) {
                        i = this.zzom.zzcj();
                    } else {
                        return;
                    }
                } while (i == this.tag);
                this.zzon = i;
                return;
            } else if (i == 2) {
                int zzcl;
                zzcl = this.zzom.zzcl() + this.zzom.zzbq();
                do {
                    zzhv.zzp(this.zzom.zzbi());
                } while (this.zzom.zzcl() < zzcl);
                zzab(zzcl);
                return;
            } else {
                throw zzhh.zzed();
            }
        }
        int i2 = this.tag & 7;
        if (i2 == 0) {
            do {
                list.add(Long.valueOf(this.zzom.zzbi()));
                if (!this.zzom.zzbf()) {
                    i2 = this.zzom.zzcj();
                } else {
                    return;
                }
            } while (i2 == this.tag);
            this.zzon = i2;
        } else if (i2 == 2) {
            zzcl = this.zzom.zzcl() + this.zzom.zzbq();
            do {
                list.add(Long.valueOf(this.zzom.zzbi()));
            } while (this.zzom.zzcl() < zzcl);
            zzab(zzcl);
        } else {
            throw zzhh.zzed();
        }
    }

    public final void zzh(List<Long> list) throws IOException {
        if (list instanceof zzhv) {
            zzhv zzhv = (zzhv) list;
            int i = this.tag & 7;
            if (i == 0) {
                do {
                    zzhv.zzp(this.zzom.zzbj());
                    if (!this.zzom.zzbf()) {
                        i = this.zzom.zzcj();
                    } else {
                        return;
                    }
                } while (i == this.tag);
                this.zzon = i;
                return;
            } else if (i == 2) {
                int zzcl;
                zzcl = this.zzom.zzcl() + this.zzom.zzbq();
                do {
                    zzhv.zzp(this.zzom.zzbj());
                } while (this.zzom.zzcl() < zzcl);
                zzab(zzcl);
                return;
            } else {
                throw zzhh.zzed();
            }
        }
        int i2 = this.tag & 7;
        if (i2 == 0) {
            do {
                list.add(Long.valueOf(this.zzom.zzbj()));
                if (!this.zzom.zzbf()) {
                    i2 = this.zzom.zzcj();
                } else {
                    return;
                }
            } while (i2 == this.tag);
            this.zzon = i2;
        } else if (i2 == 2) {
            zzcl = this.zzom.zzcl() + this.zzom.zzbq();
            do {
                list.add(Long.valueOf(this.zzom.zzbj()));
            } while (this.zzom.zzcl() < zzcl);
            zzab(zzcl);
        } else {
            throw zzhh.zzed();
        }
    }

    public final void zzi(List<Integer> list) throws IOException {
        if (list instanceof zzha) {
            zzha zzha = (zzha) list;
            int i = this.tag & 7;
            if (i == 0) {
                do {
                    zzha.zzbe(this.zzom.zzbk());
                    if (!this.zzom.zzbf()) {
                        i = this.zzom.zzcj();
                    } else {
                        return;
                    }
                } while (i == this.tag);
                this.zzon = i;
                return;
            } else if (i == 2) {
                int zzcl;
                zzcl = this.zzom.zzcl() + this.zzom.zzbq();
                do {
                    zzha.zzbe(this.zzom.zzbk());
                } while (this.zzom.zzcl() < zzcl);
                zzab(zzcl);
                return;
            } else {
                throw zzhh.zzed();
            }
        }
        int i2 = this.tag & 7;
        if (i2 == 0) {
            do {
                list.add(Integer.valueOf(this.zzom.zzbk()));
                if (!this.zzom.zzbf()) {
                    i2 = this.zzom.zzcj();
                } else {
                    return;
                }
            } while (i2 == this.tag);
            this.zzon = i2;
        } else if (i2 == 2) {
            zzcl = this.zzom.zzcl() + this.zzom.zzbq();
            do {
                list.add(Integer.valueOf(this.zzom.zzbk()));
            } while (this.zzom.zzcl() < zzcl);
            zzab(zzcl);
        } else {
            throw zzhh.zzed();
        }
    }

    public final void zzj(List<Long> list) throws IOException {
        int zzbq;
        int zzcl;
        if (list instanceof zzhv) {
            zzhv zzhv = (zzhv) list;
            switch (this.tag & 7) {
                case 1:
                    break;
                case 2:
                    zzbq = this.zzom.zzbq();
                    zzz(zzbq);
                    zzcl = this.zzom.zzcl() + zzbq;
                    do {
                        zzhv.zzp(this.zzom.zzbl());
                    } while (this.zzom.zzcl() < zzcl);
                    return;
                default:
                    throw zzhh.zzed();
            }
            do {
                zzhv.zzp(this.zzom.zzbl());
                if (!this.zzom.zzbf()) {
                    zzbq = this.zzom.zzcj();
                } else {
                    return;
                }
            } while (zzbq == this.tag);
            this.zzon = zzbq;
            return;
        }
        switch (this.tag & 7) {
            case 1:
                break;
            case 2:
                zzbq = this.zzom.zzbq();
                zzz(zzbq);
                zzcl = this.zzom.zzcl() + zzbq;
                do {
                    list.add(Long.valueOf(this.zzom.zzbl()));
                } while (this.zzom.zzcl() < zzcl);
                return;
            default:
                throw zzhh.zzed();
        }
        do {
            list.add(Long.valueOf(this.zzom.zzbl()));
            if (!this.zzom.zzbf()) {
                zzbq = this.zzom.zzcj();
            } else {
                return;
            }
        } while (zzbq == this.tag);
        this.zzon = zzbq;
    }

    public final void zzk(List<Integer> list) throws IOException {
        if (list instanceof zzha) {
            zzha zzha = (zzha) list;
            int i = this.tag & 7;
            if (i == 2) {
                i = this.zzom.zzbq();
                zzaa(i);
                int zzcl = this.zzom.zzcl() + i;
                do {
                    zzha.zzbe(this.zzom.zzbm());
                } while (this.zzom.zzcl() < zzcl);
                return;
            } else if (i == 5) {
                do {
                    zzha.zzbe(this.zzom.zzbm());
                    if (!this.zzom.zzbf()) {
                        i = this.zzom.zzcj();
                    } else {
                        return;
                    }
                } while (i == this.tag);
                this.zzon = i;
                return;
            } else {
                throw zzhh.zzed();
            }
        }
        int i2 = this.tag & 7;
        if (i2 == 2) {
            i2 = this.zzom.zzbq();
            zzaa(i2);
            int zzcl2 = this.zzom.zzcl() + i2;
            do {
                list.add(Integer.valueOf(this.zzom.zzbm()));
            } while (this.zzom.zzcl() < zzcl2);
        } else if (i2 == 5) {
            do {
                list.add(Integer.valueOf(this.zzom.zzbm()));
                if (!this.zzom.zzbf()) {
                    i2 = this.zzom.zzcj();
                } else {
                    return;
                }
            } while (i2 == this.tag);
            this.zzon = i2;
        } else {
            throw zzhh.zzed();
        }
    }

    public final void zzl(List<Boolean> list) throws IOException {
        int zzcl;
        if (list instanceof zzfp) {
            zzfp zzfp = (zzfp) list;
            int i = this.tag & 7;
            if (i == 0) {
                do {
                    zzfp.addBoolean(this.zzom.zzbn());
                    if (!this.zzom.zzbf()) {
                        i = this.zzom.zzcj();
                    } else {
                        return;
                    }
                } while (i == this.tag);
                this.zzon = i;
                return;
            } else if (i == 2) {
                zzcl = this.zzom.zzcl() + this.zzom.zzbq();
                do {
                    zzfp.addBoolean(this.zzom.zzbn());
                } while (this.zzom.zzcl() < zzcl);
                zzab(zzcl);
                return;
            } else {
                throw zzhh.zzed();
            }
        }
        int i2 = this.tag & 7;
        if (i2 == 0) {
            do {
                list.add(Boolean.valueOf(this.zzom.zzbn()));
                if (!this.zzom.zzbf()) {
                    i2 = this.zzom.zzcj();
                } else {
                    return;
                }
            } while (i2 == this.tag);
            this.zzon = i2;
        } else if (i2 == 2) {
            zzcl = this.zzom.zzcl() + this.zzom.zzbq();
            do {
                list.add(Boolean.valueOf(this.zzom.zzbn()));
            } while (this.zzom.zzcl() < zzcl);
            zzab(zzcl);
        } else {
            throw zzhh.zzed();
        }
    }

    public final void zzm(List<String> list) throws IOException {
        zzb((List) list, true);
    }

    public final void zzn(List<zzfr> list) throws IOException {
        if ((this.tag & 7) == 2) {
            int zzcj;
            do {
                list.add(zzbp());
                if (!this.zzom.zzbf()) {
                    zzcj = this.zzom.zzcj();
                } else {
                    return;
                }
            } while (zzcj == this.tag);
            this.zzon = zzcj;
            return;
        }
        throw zzhh.zzed();
    }

    public final void zzo(List<Integer> list) throws IOException {
        int zzcl;
        if (list instanceof zzha) {
            zzha zzha = (zzha) list;
            int i = this.tag & 7;
            if (i == 0) {
                do {
                    zzha.zzbe(this.zzom.zzbq());
                    if (!this.zzom.zzbf()) {
                        i = this.zzom.zzcj();
                    } else {
                        return;
                    }
                } while (i == this.tag);
                this.zzon = i;
                return;
            } else if (i == 2) {
                zzcl = this.zzom.zzcl() + this.zzom.zzbq();
                do {
                    zzha.zzbe(this.zzom.zzbq());
                } while (this.zzom.zzcl() < zzcl);
                zzab(zzcl);
                return;
            } else {
                throw zzhh.zzed();
            }
        }
        int i2 = this.tag & 7;
        if (i2 == 0) {
            do {
                list.add(Integer.valueOf(this.zzom.zzbq()));
                if (!this.zzom.zzbf()) {
                    i2 = this.zzom.zzcj();
                } else {
                    return;
                }
            } while (i2 == this.tag);
            this.zzon = i2;
        } else if (i2 == 2) {
            zzcl = this.zzom.zzcl() + this.zzom.zzbq();
            do {
                list.add(Integer.valueOf(this.zzom.zzbq()));
            } while (this.zzom.zzcl() < zzcl);
            zzab(zzcl);
        } else {
            throw zzhh.zzed();
        }
    }

    public final void zzp(List<Integer> list) throws IOException {
        int zzcl;
        if (list instanceof zzha) {
            zzha zzha = (zzha) list;
            int i = this.tag & 7;
            if (i == 0) {
                do {
                    zzha.zzbe(this.zzom.zzbr());
                    if (!this.zzom.zzbf()) {
                        i = this.zzom.zzcj();
                    } else {
                        return;
                    }
                } while (i == this.tag);
                this.zzon = i;
                return;
            } else if (i == 2) {
                zzcl = this.zzom.zzcl() + this.zzom.zzbq();
                do {
                    zzha.zzbe(this.zzom.zzbr());
                } while (this.zzom.zzcl() < zzcl);
                zzab(zzcl);
                return;
            } else {
                throw zzhh.zzed();
            }
        }
        int i2 = this.tag & 7;
        if (i2 == 0) {
            do {
                list.add(Integer.valueOf(this.zzom.zzbr()));
                if (!this.zzom.zzbf()) {
                    i2 = this.zzom.zzcj();
                } else {
                    return;
                }
            } while (i2 == this.tag);
            this.zzon = i2;
        } else if (i2 == 2) {
            zzcl = this.zzom.zzcl() + this.zzom.zzbq();
            do {
                list.add(Integer.valueOf(this.zzom.zzbr()));
            } while (this.zzom.zzcl() < zzcl);
            zzab(zzcl);
        } else {
            throw zzhh.zzed();
        }
    }

    public final void zzq(List<Integer> list) throws IOException {
        if (list instanceof zzha) {
            zzha zzha = (zzha) list;
            int i = this.tag & 7;
            if (i == 2) {
                i = this.zzom.zzbq();
                zzaa(i);
                int zzcl = this.zzom.zzcl() + i;
                do {
                    zzha.zzbe(this.zzom.zzbs());
                } while (this.zzom.zzcl() < zzcl);
                return;
            } else if (i == 5) {
                do {
                    zzha.zzbe(this.zzom.zzbs());
                    if (!this.zzom.zzbf()) {
                        i = this.zzom.zzcj();
                    } else {
                        return;
                    }
                } while (i == this.tag);
                this.zzon = i;
                return;
            } else {
                throw zzhh.zzed();
            }
        }
        int i2 = this.tag & 7;
        if (i2 == 2) {
            i2 = this.zzom.zzbq();
            zzaa(i2);
            int zzcl2 = this.zzom.zzcl() + i2;
            do {
                list.add(Integer.valueOf(this.zzom.zzbs()));
            } while (this.zzom.zzcl() < zzcl2);
        } else if (i2 == 5) {
            do {
                list.add(Integer.valueOf(this.zzom.zzbs()));
                if (!this.zzom.zzbf()) {
                    i2 = this.zzom.zzcj();
                } else {
                    return;
                }
            } while (i2 == this.tag);
            this.zzon = i2;
        } else {
            throw zzhh.zzed();
        }
    }

    public final void zzr(List<Long> list) throws IOException {
        int zzbq;
        int zzcl;
        if (list instanceof zzhv) {
            zzhv zzhv = (zzhv) list;
            switch (this.tag & 7) {
                case 1:
                    break;
                case 2:
                    zzbq = this.zzom.zzbq();
                    zzz(zzbq);
                    zzcl = this.zzom.zzcl() + zzbq;
                    do {
                        zzhv.zzp(this.zzom.zzbt());
                    } while (this.zzom.zzcl() < zzcl);
                    return;
                default:
                    throw zzhh.zzed();
            }
            do {
                zzhv.zzp(this.zzom.zzbt());
                if (!this.zzom.zzbf()) {
                    zzbq = this.zzom.zzcj();
                } else {
                    return;
                }
            } while (zzbq == this.tag);
            this.zzon = zzbq;
            return;
        }
        switch (this.tag & 7) {
            case 1:
                break;
            case 2:
                zzbq = this.zzom.zzbq();
                zzz(zzbq);
                zzcl = this.zzom.zzcl() + zzbq;
                do {
                    list.add(Long.valueOf(this.zzom.zzbt()));
                } while (this.zzom.zzcl() < zzcl);
                return;
            default:
                throw zzhh.zzed();
        }
        do {
            list.add(Long.valueOf(this.zzom.zzbt()));
            if (!this.zzom.zzbf()) {
                zzbq = this.zzom.zzcj();
            } else {
                return;
            }
        } while (zzbq == this.tag);
        this.zzon = zzbq;
    }

    public final void zzs(List<Integer> list) throws IOException {
        int zzcl;
        if (list instanceof zzha) {
            zzha zzha = (zzha) list;
            int i = this.tag & 7;
            if (i == 0) {
                do {
                    zzha.zzbe(this.zzom.zzbu());
                    if (!this.zzom.zzbf()) {
                        i = this.zzom.zzcj();
                    } else {
                        return;
                    }
                } while (i == this.tag);
                this.zzon = i;
                return;
            } else if (i == 2) {
                zzcl = this.zzom.zzcl() + this.zzom.zzbq();
                do {
                    zzha.zzbe(this.zzom.zzbu());
                } while (this.zzom.zzcl() < zzcl);
                zzab(zzcl);
                return;
            } else {
                throw zzhh.zzed();
            }
        }
        int i2 = this.tag & 7;
        if (i2 == 0) {
            do {
                list.add(Integer.valueOf(this.zzom.zzbu()));
                if (!this.zzom.zzbf()) {
                    i2 = this.zzom.zzcj();
                } else {
                    return;
                }
            } while (i2 == this.tag);
            this.zzon = i2;
        } else if (i2 == 2) {
            zzcl = this.zzom.zzcl() + this.zzom.zzbq();
            do {
                list.add(Integer.valueOf(this.zzom.zzbu()));
            } while (this.zzom.zzcl() < zzcl);
            zzab(zzcl);
        } else {
            throw zzhh.zzed();
        }
    }

    public final void zzt(List<Long> list) throws IOException {
        if (list instanceof zzhv) {
            zzhv zzhv = (zzhv) list;
            int i = this.tag & 7;
            if (i == 0) {
                do {
                    zzhv.zzp(this.zzom.zzbv());
                    if (!this.zzom.zzbf()) {
                        i = this.zzom.zzcj();
                    } else {
                        return;
                    }
                } while (i == this.tag);
                this.zzon = i;
                return;
            } else if (i == 2) {
                int zzcl;
                zzcl = this.zzom.zzcl() + this.zzom.zzbq();
                do {
                    zzhv.zzp(this.zzom.zzbv());
                } while (this.zzom.zzcl() < zzcl);
                zzab(zzcl);
                return;
            } else {
                throw zzhh.zzed();
            }
        }
        int i2 = this.tag & 7;
        if (i2 == 0) {
            do {
                list.add(Long.valueOf(this.zzom.zzbv()));
                if (!this.zzom.zzbf()) {
                    i2 = this.zzom.zzcj();
                } else {
                    return;
                }
            } while (i2 == this.tag);
            this.zzon = i2;
        } else if (i2 == 2) {
            zzcl = this.zzom.zzcl() + this.zzom.zzbq();
            do {
                list.add(Long.valueOf(this.zzom.zzbv()));
            } while (this.zzom.zzcl() < zzcl);
            zzab(zzcl);
        } else {
            throw zzhh.zzed();
        }
    }
}
