package com.google.android.gms.internal.places;

final class zzjm {
    static String zze(zzfr zzfr) {
        zzjo zzjn = new zzjn(zzfr);
        StringBuilder stringBuilder = new StringBuilder(zzjn.size());
        for (int i = 0; i < zzjn.size(); i++) {
            String str;
            int zzaf = zzjn.zzaf(i);
            if (zzaf == 34) {
                str = "\\\"";
            } else if (zzaf == 39) {
                str = "\\'";
            } else if (zzaf != 92) {
                switch (zzaf) {
                    case 7:
                        str = "\\a";
                        break;
                    case 8:
                        str = "\\b";
                        break;
                    case 9:
                        str = "\\t";
                        break;
                    case 10:
                        str = "\\n";
                        break;
                    case 11:
                        str = "\\v";
                        break;
                    case 12:
                        str = "\\f";
                        break;
                    case 13:
                        str = "\\r";
                        break;
                    default:
                        if (zzaf < 32 || zzaf > 126) {
                            stringBuilder.append('\\');
                            stringBuilder.append((char) (((zzaf >>> 6) & 3) + 48));
                            stringBuilder.append((char) (((zzaf >>> 3) & 7) + 48));
                            zzaf = (zzaf & 7) + 48;
                        }
                        stringBuilder.append((char) zzaf);
                        continue;
                }
            } else {
                str = "\\\\";
            }
            stringBuilder.append(str);
        }
        return stringBuilder.toString();
    }
}
