package com.google.android.gms.internal.places;

import java.io.IOException;

public abstract class zzfq {
    public abstract void zzb(byte[] bArr, int i, int i2) throws IOException;
}
