package com.google.android.gms.internal.places;

interface zzif {
    int zzev();

    boolean zzew();

    zzih zzex();
}
