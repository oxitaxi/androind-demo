package com.google.android.gms.internal.places;

import java.util.Collections;
import java.util.List;
import java.util.Map.Entry;

final class zzjc extends zzjb<FieldDescriptorType, Object> {
    zzjc(int i) {
        super(i);
    }

    public final void zzbb() {
        if (!isImmutable()) {
            Entry zzbn;
            for (int i = 0; i < zzgg(); i++) {
                zzbn = zzbn(i);
                if (((zzgs) zzbn.getKey()).zzdk()) {
                    zzbn.setValue(Collections.unmodifiableList((List) zzbn.getValue()));
                }
            }
            for (Entry zzbn2 : zzgh()) {
                if (((zzgs) zzbn2.getKey()).zzdk()) {
                    zzbn2.setValue(Collections.unmodifiableList((List) zzbn2.getValue()));
                }
            }
        }
        super.zzbb();
    }
}
