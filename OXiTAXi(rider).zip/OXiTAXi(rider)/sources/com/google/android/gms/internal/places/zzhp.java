package com.google.android.gms.internal.places;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.RandomAccess;

public final class zzhp extends zzfk<String> implements zzhq, RandomAccess {
    private static final zzhp zzui;
    private static final zzhq zzuj = zzui;
    private final List<Object> zzuk;

    static {
        zzfk zzhp = new zzhp();
        zzui = zzhp;
        zzhp.zzbb();
    }

    public zzhp() {
        this(10);
    }

    public zzhp(int i) {
        this(new ArrayList(i));
    }

    private zzhp(ArrayList<Object> arrayList) {
        this.zzuk = arrayList;
    }

    private static String zzf(Object obj) {
        return obj instanceof String ? (String) obj : obj instanceof zzfr ? ((zzfr) obj).zzcd() : zzhb.zzg((byte[]) obj);
    }

    public final /* synthetic */ void add(int i, Object obj) {
        String str = (String) obj;
        zzbc();
        this.zzuk.add(i, str);
        this.modCount++;
    }

    public final boolean addAll(int i, Collection<? extends String> collection) {
        Collection zzek;
        zzbc();
        if (collection instanceof zzhq) {
            zzek = ((zzhq) collection).zzek();
        }
        boolean addAll = this.zzuk.addAll(i, zzek);
        this.modCount++;
        return addAll;
    }

    public final boolean addAll(Collection<? extends String> collection) {
        return addAll(size(), collection);
    }

    public final void clear() {
        zzbc();
        this.zzuk.clear();
        this.modCount++;
    }

    public final /* bridge */ /* synthetic */ boolean equals(Object obj) {
        return super.equals(obj);
    }

    public final /* synthetic */ Object get(int i) {
        Object obj = this.zzuk.get(i);
        if (obj instanceof String) {
            return (String) obj;
        }
        String zzcd;
        if (obj instanceof zzfr) {
            zzfr zzfr = (zzfr) obj;
            zzcd = zzfr.zzcd();
            if (zzfr.zzce()) {
                this.zzuk.set(i, zzcd);
            }
            return zzcd;
        }
        byte[] bArr = (byte[]) obj;
        zzcd = zzhb.zzg(bArr);
        if (zzhb.zzf(bArr)) {
            this.zzuk.set(i, zzcd);
        }
        return zzcd;
    }

    public final Object getRaw(int i) {
        return this.zzuk.get(i);
    }

    public final /* bridge */ /* synthetic */ int hashCode() {
        return super.hashCode();
    }

    public final /* synthetic */ Object remove(int i) {
        zzbc();
        Object remove = this.zzuk.remove(i);
        this.modCount++;
        return zzf(remove);
    }

    public final /* bridge */ /* synthetic */ boolean removeAll(Collection collection) {
        return super.removeAll(collection);
    }

    public final /* bridge */ /* synthetic */ boolean retainAll(Collection collection) {
        return super.retainAll(collection);
    }

    public final /* synthetic */ Object set(int i, Object obj) {
        String str = (String) obj;
        zzbc();
        return zzf(this.zzuk.set(i, str));
    }

    public final int size() {
        return this.zzuk.size();
    }

    public final /* synthetic */ zzhg zzae(int i) {
        if (i >= size()) {
            ArrayList arrayList = new ArrayList(i);
            arrayList.addAll(this.zzuk);
            return new zzhp(arrayList);
        }
        throw new IllegalArgumentException();
    }

    public final /* bridge */ /* synthetic */ boolean zzba() {
        return super.zzba();
    }

    public final void zzd(zzfr zzfr) {
        zzbc();
        this.zzuk.add(zzfr);
        this.modCount++;
    }

    public final List<?> zzek() {
        return Collections.unmodifiableList(this.zzuk);
    }

    public final zzhq zzel() {
        return zzba() ? new zzjt(this) : this;
    }
}
