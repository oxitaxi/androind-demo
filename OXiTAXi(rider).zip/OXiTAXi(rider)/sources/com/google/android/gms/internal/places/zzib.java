package com.google.android.gms.internal.places;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public final class zzib<K, V> extends LinkedHashMap<K, V> {
    private static final zzib zzuw;
    private boolean zznk = true;

    static {
        zzib zzib = new zzib();
        zzuw = zzib;
        zzib.zznk = false;
    }

    private zzib() {
    }

    private zzib(Map<K, V> map) {
        super(map);
    }

    public static <K, V> zzib<K, V> zzep() {
        return zzuw;
    }

    private final void zzer() {
        if (!this.zznk) {
            throw new UnsupportedOperationException();
        }
    }

    private static int zzg(Object obj) {
        if (obj instanceof byte[]) {
            return zzhb.hashCode((byte[]) obj);
        }
        if (!(obj instanceof zzhc)) {
            return obj.hashCode();
        }
        throw new UnsupportedOperationException();
    }

    public final void clear() {
        zzer();
        super.clear();
    }

    public final Set<Entry<K, V>> entrySet() {
        return isEmpty() ? Collections.emptySet() : super.entrySet();
    }

    public final boolean equals(Object obj) {
        if (obj instanceof Map) {
            obj = (Map) obj;
            if (this != obj) {
                if (size() == obj.size()) {
                    for (Entry entry : entrySet()) {
                        if (obj.containsKey(entry.getKey())) {
                            boolean equals;
                            Object value = entry.getValue();
                            Object obj2 = obj.get(entry.getKey());
                            if ((value instanceof byte[]) && (obj2 instanceof byte[])) {
                                equals = Arrays.equals((byte[]) value, (byte[]) obj2);
                                continue;
                            } else {
                                equals = value.equals(obj2);
                                continue;
                            }
                            if (!equals) {
                            }
                        }
                    }
                }
                obj = null;
                if (obj != null) {
                }
            }
            obj = 1;
            return obj != null;
        }
    }

    public final int hashCode() {
        int i = 0;
        for (Entry entry : entrySet()) {
            i += zzg(entry.getValue()) ^ zzg(entry.getKey());
        }
        return i;
    }

    public final boolean isMutable() {
        return this.zznk;
    }

    public final V put(K k, V v) {
        zzer();
        zzhb.checkNotNull(k);
        zzhb.checkNotNull(v);
        return super.put(k, v);
    }

    public final void putAll(Map<? extends K, ? extends V> map) {
        zzer();
        for (Object next : map.keySet()) {
            zzhb.checkNotNull(next);
            zzhb.checkNotNull(map.get(next));
        }
        super.putAll(map);
    }

    public final V remove(Object obj) {
        zzer();
        return super.remove(obj);
    }

    public final void zzb(zzib<K, V> zzib) {
        zzer();
        if (!zzib.isEmpty()) {
            putAll(zzib);
        }
    }

    public final void zzbb() {
        this.zznk = false;
    }

    public final zzib<K, V> zzeq() {
        return isEmpty() ? new zzib() : new zzib(this);
    }
}
