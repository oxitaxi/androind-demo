package com.google.android.gms.internal.places;

import java.io.IOException;

public abstract class zzku {
    protected volatile int zzaap = -1;

    public static final <T extends zzku> T zzb(T t, byte[] bArr) throws zzkt {
        return zzb(t, bArr, 0, bArr.length);
    }

    private static final <T extends zzku> T zzb(T t, byte[] bArr, int i, int i2) throws zzkt {
        try {
            zzkl zzk = zzkl.zzk(bArr, 0, i2);
            t.zzb(zzk);
            zzk.zzah(0);
            return t;
        } catch (zzkt e) {
            throw e;
        } catch (Throwable e2) {
            throw new RuntimeException("Reading from a byte array threw an IOException (should never happen).", e2);
        }
    }

    public static final byte[] zzd(zzku zzku) {
        byte[] bArr = new byte[zzku.zzdg()];
        try {
            zzkm zzl = zzkm.zzl(bArr, 0, bArr.length);
            zzku.zzb(zzl);
            zzl.zzhd();
            return bArr;
        } catch (Throwable e) {
            throw new RuntimeException("Serializing to a byte array threw an IOException (should never happen).", e);
        }
    }

    public /* synthetic */ Object clone() throws CloneNotSupportedException {
        return zzhe();
    }

    public String toString() {
        return zzkv.zze(this);
    }

    protected int zzal() {
        return 0;
    }

    public abstract zzku zzb(zzkl zzkl) throws IOException;

    public void zzb(zzkm zzkm) throws IOException {
    }

    public final int zzdg() {
        int zzal = zzal();
        this.zzaap = zzal;
        return zzal;
    }

    public zzku zzhe() throws CloneNotSupportedException {
        return (zzku) super.clone();
    }
}
