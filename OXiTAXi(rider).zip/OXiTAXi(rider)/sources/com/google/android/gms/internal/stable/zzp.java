package com.google.android.gms.internal.stable;

final class zzp extends zzl {
    zzp() {
    }

    public final void zza(Throwable th, Throwable th2) {
        th.addSuppressed(th2);
    }
}
