package com.google.android.gms.internal.places;

interface zzig {
    boolean zzc(Class<?> cls);

    zzif zzd(Class<?> cls);
}
