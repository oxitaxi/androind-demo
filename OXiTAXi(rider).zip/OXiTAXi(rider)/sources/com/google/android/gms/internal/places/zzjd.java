package com.google.android.gms.internal.places;

import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

final class zzjd implements Iterator<Entry<K, V>> {
    private int pos;
    private Iterator<Entry<K, V>> zzxj;
    private final /* synthetic */ zzjb zzxk;

    private zzjd(zzjb zzjb) {
        this.zzxk = zzjb;
        this.pos = this.zzxk.zzxe.size();
    }

    private final Iterator<Entry<K, V>> zzgl() {
        if (this.zzxj == null) {
            this.zzxj = this.zzxk.zzxh.entrySet().iterator();
        }
        return this.zzxj;
    }

    public final boolean hasNext() {
        return (this.pos > 0 && this.pos <= this.zzxk.zzxe.size()) || zzgl().hasNext();
    }

    public final /* synthetic */ Object next() {
        Object next;
        if (zzgl().hasNext()) {
            next = zzgl().next();
        } else {
            List zzc = this.zzxk.zzxe;
            int i = this.pos - 1;
            this.pos = i;
            next = zzc.get(i);
        }
        return (Entry) next;
    }

    public final void remove() {
        throw new UnsupportedOperationException();
    }
}
