package com.google.android.gms.internal.places;

import java.util.List;

final class zzhu extends zzhr {
    private zzhu() {
        super();
    }

    private static <E> zzhg<E> zze(Object obj, long j) {
        return (zzhg) zzjw.zzq(obj, j);
    }

    final <L> List<L> zzb(Object obj, long j) {
        List zze = zze(obj, j);
        if (zze.zzba()) {
            return zze;
        }
        int size = zze.size();
        Object zzae = zze.zzae(size == 0 ? 10 : size << 1);
        zzjw.zzb(obj, j, zzae);
        return zzae;
    }

    final <E> void zzb(Object obj, Object obj2, long j) {
        zzhg zze = zze(obj, j);
        obj2 = zze(obj2, j);
        int size = zze.size();
        int size2 = obj2.size();
        if (size > 0 && size2 > 0) {
            if (!zze.zzba()) {
                zze = zze.zzae(size2 + size);
            }
            zze.addAll(obj2);
        }
        if (size > 0) {
            obj2 = zze;
        }
        zzjw.zzb(obj, j, obj2);
    }

    final void zzc(Object obj, long j) {
        zze(obj, j).zzbb();
    }
}
