package com.google.android.gms.internal.places;

import java.util.Iterator;

final class zzjv implements Iterator<String> {
    private final /* synthetic */ zzjt zzxv;
    private Iterator<String> zzxw = this.zzxv.zzxt.iterator();

    zzjv(zzjt zzjt) {
        this.zzxv = zzjt;
    }

    public final boolean hasNext() {
        return this.zzxw.hasNext();
    }

    public final /* synthetic */ Object next() {
        return (String) this.zzxw.next();
    }

    public final void remove() {
        throw new UnsupportedOperationException();
    }
}
