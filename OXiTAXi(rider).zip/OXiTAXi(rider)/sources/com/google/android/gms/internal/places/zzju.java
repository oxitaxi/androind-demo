package com.google.android.gms.internal.places;

import java.util.ListIterator;

final class zzju implements ListIterator<String> {
    private final /* synthetic */ int zzfx;
    private ListIterator<String> zzxu = this.zzxv.zzxt.listIterator(this.zzfx);
    private final /* synthetic */ zzjt zzxv;

    zzju(zzjt zzjt, int i) {
        this.zzxv = zzjt;
        this.zzfx = i;
    }

    public final /* synthetic */ void add(Object obj) {
        throw new UnsupportedOperationException();
    }

    public final boolean hasNext() {
        return this.zzxu.hasNext();
    }

    public final boolean hasPrevious() {
        return this.zzxu.hasPrevious();
    }

    public final /* synthetic */ Object next() {
        return (String) this.zzxu.next();
    }

    public final int nextIndex() {
        return this.zzxu.nextIndex();
    }

    public final /* synthetic */ Object previous() {
        return (String) this.zzxu.previous();
    }

    public final int previousIndex() {
        return this.zzxu.previousIndex();
    }

    public final void remove() {
        throw new UnsupportedOperationException();
    }

    public final /* synthetic */ void set(Object obj) {
        throw new UnsupportedOperationException();
    }
}
