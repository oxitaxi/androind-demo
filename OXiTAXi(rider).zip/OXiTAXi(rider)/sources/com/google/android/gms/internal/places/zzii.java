package com.google.android.gms.internal.places;

public interface zzii extends zzij, Cloneable {
    zzii zzb(zzih zzih);

    zzih zzdw();

    zzih zzdx();
}
