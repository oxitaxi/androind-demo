package com.google.android.gms.internal.places;

import com.google.android.gms.internal.places.zzgz.zzh;

final class zzgy implements zzig {
    private static final zzgy zzsf = new zzgy();

    private zzgy() {
    }

    public static zzgy zzdn() {
        return zzsf;
    }

    public final boolean zzc(Class<?> cls) {
        return zzgz.class.isAssignableFrom(cls);
    }

    public final zzif zzd(Class<?> cls) {
        if (zzgz.class.isAssignableFrom(cls)) {
            try {
                return (zzif) zzgz.zze(cls.asSubclass(zzgz.class)).zzb(zzh.zzsx, null, null);
            } catch (Throwable e) {
                String str = "Unable to get message info for ";
                String valueOf = String.valueOf(cls.getName());
                throw new RuntimeException(valueOf.length() != 0 ? str.concat(valueOf) : new String(str), e);
            }
        }
        String str2 = "Unsupported message type: ";
        valueOf = String.valueOf(cls.getName());
        throw new IllegalArgumentException(valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2));
    }
}
