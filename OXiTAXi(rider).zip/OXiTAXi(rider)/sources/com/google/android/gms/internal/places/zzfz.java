package com.google.android.gms.internal.places;

final class zzfz implements zzfv {
    private zzfz() {
    }

    public final byte[] zze(byte[] bArr, int i, int i2) {
        Object obj = new byte[i2];
        System.arraycopy(bArr, i, obj, 0, i2);
        return obj;
    }
}
