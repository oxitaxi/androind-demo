package com.google.android.gms.internal.places;

import java.io.IOException;

interface zziy<T> {
    boolean equals(T t, T t2);

    int hashCode(T t);

    T newInstance();

    void zzb(T t, zzix zzix, zzgl zzgl) throws IOException;

    void zzb(T t, zzkk zzkk) throws IOException;

    void zzd(T t);

    void zzd(T t, T t2);

    int zzn(T t);

    boolean zzo(T t);
}
