package com.google.android.gms.internal.places;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

final class zzht extends zzhr {
    private static final Class<?> zzun = Collections.unmodifiableList(Collections.emptyList()).getClass();

    private zzht() {
        super();
    }

    private static <L> List<L> zzb(Object obj, long j, int i) {
        List<L> zzd = zzd(obj, j);
        if (zzd.isEmpty()) {
            Object zzhp = zzd instanceof zzhq ? new zzhp(i) : new ArrayList(i);
            zzjw.zzb(obj, j, zzhp);
            return zzhp;
        }
        List<L> arrayList;
        if (zzun.isAssignableFrom(zzd.getClass())) {
            arrayList = new ArrayList(zzd.size() + i);
            arrayList.addAll(zzd);
        } else if (!(zzd instanceof zzjt)) {
            return zzd;
        } else {
            arrayList = new zzhp(zzd.size() + i);
            arrayList.addAll((zzjt) zzd);
        }
        zzjw.zzb(obj, j, (Object) arrayList);
        return arrayList;
    }

    private static <E> List<E> zzd(Object obj, long j) {
        return (List) zzjw.zzq(obj, j);
    }

    final <L> List<L> zzb(Object obj, long j) {
        return zzb(obj, j, 10);
    }

    final <E> void zzb(Object obj, Object obj2, long j) {
        obj2 = zzd(obj2, j);
        List zzb = zzb(obj, j, obj2.size());
        int size = zzb.size();
        int size2 = obj2.size();
        if (size > 0 && size2 > 0) {
            zzb.addAll(obj2);
        }
        if (size > 0) {
            obj2 = zzb;
        }
        zzjw.zzb(obj, j, obj2);
    }

    final void zzc(Object obj, long j) {
        Object zzel;
        List list = (List) zzjw.zzq(obj, j);
        if (list instanceof zzhq) {
            zzel = ((zzhq) list).zzel();
        } else if (!zzun.isAssignableFrom(list.getClass())) {
            zzel = Collections.unmodifiableList(list);
        } else {
            return;
        }
        zzjw.zzb(obj, j, zzel);
    }
}
