package com.google.android.gms.internal.places;

interface zzio {
    Object newInstance(Object obj);
}
