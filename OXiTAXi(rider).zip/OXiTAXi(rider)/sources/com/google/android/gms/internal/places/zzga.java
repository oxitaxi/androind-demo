package com.google.android.gms.internal.places;

import java.io.IOException;

public abstract class zzga {
    private static volatile boolean zzog = true;
    int zzob;
    int zzoc;
    private int zzod;
    zzgd zzoe;
    private boolean zzof;

    private zzga() {
        this.zzoc = 100;
        this.zzod = Integer.MAX_VALUE;
        this.zzof = false;
    }

    public static int zzan(int i) {
        return (-(i & 1)) ^ (i >>> 1);
    }

    static zzga zzb(byte[] bArr, int i, int i2, boolean z) {
        zzga zzgc = new zzgc(bArr, i, i2, false, null);
        try {
            zzgc.zzak(i2);
            return zzgc;
        } catch (Throwable e) {
            throw new IllegalArgumentException(e);
        }
    }

    public static long zzd(long j) {
        return (-(j & 1)) ^ (j >>> 1);
    }

    public static zzga zzf(byte[] bArr, int i, int i2) {
        return zzb(bArr, i, i2, false);
    }

    public abstract double readDouble() throws IOException;

    public abstract float readFloat() throws IOException;

    public abstract String readString() throws IOException;

    public abstract void zzah(int i) throws zzhh;

    public abstract boolean zzai(int i) throws IOException;

    public final int zzaj(int i) {
        if (i >= 0) {
            int i2 = this.zzoc;
            this.zzoc = i;
            return i2;
        }
        StringBuilder stringBuilder = new StringBuilder(47);
        stringBuilder.append("Recursion limit cannot be negative: ");
        stringBuilder.append(i);
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    public abstract int zzak(int i) throws zzhh;

    public abstract void zzal(int i);

    public abstract void zzam(int i) throws IOException;

    public abstract <T extends zzih> T zzb(zzir<T> zzir, zzgl zzgl) throws IOException;

    public abstract boolean zzbf() throws IOException;

    public abstract long zzbi() throws IOException;

    public abstract long zzbj() throws IOException;

    public abstract int zzbk() throws IOException;

    public abstract long zzbl() throws IOException;

    public abstract int zzbm() throws IOException;

    public abstract boolean zzbn() throws IOException;

    public abstract String zzbo() throws IOException;

    public abstract zzfr zzbp() throws IOException;

    public abstract int zzbq() throws IOException;

    public abstract int zzbr() throws IOException;

    public abstract int zzbs() throws IOException;

    public abstract long zzbt() throws IOException;

    public abstract int zzbu() throws IOException;

    public abstract long zzbv() throws IOException;

    public abstract int zzcj() throws IOException;

    abstract long zzck() throws IOException;

    public abstract int zzcl();
}
