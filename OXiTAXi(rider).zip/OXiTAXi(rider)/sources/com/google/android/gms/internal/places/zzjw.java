package com.google.android.gms.internal.places;

import java.lang.reflect.Field;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.logging.Level;
import java.util.logging.Logger;
import libcore.io.Memory;
import sun.misc.Unsafe;

final class zzjw {
    private static final Logger logger = Logger.getLogger(zzjw.class.getName());
    private static final Class<?> zznl = zzfl.zzbe();
    private static final boolean zzoo = zzgv();
    private static final Unsafe zzuz = zzgu();
    private static final boolean zzxx = zzk(Long.TYPE);
    private static final boolean zzxy = zzk(Integer.TYPE);
    private static final zze zzxz;
    private static final boolean zzya = zzgw();
    private static final long zzyb = ((long) zzi(byte[].class));
    private static final long zzyc = ((long) zzi(boolean[].class));
    private static final long zzyd = ((long) zzj(boolean[].class));
    private static final long zzye = ((long) zzi(int[].class));
    private static final long zzyf = ((long) zzj(int[].class));
    private static final long zzyg = ((long) zzi(long[].class));
    private static final long zzyh = ((long) zzj(long[].class));
    private static final long zzyi = ((long) zzi(float[].class));
    private static final long zzyj = ((long) zzj(float[].class));
    private static final long zzyk = ((long) zzi(double[].class));
    private static final long zzyl = ((long) zzj(double[].class));
    private static final long zzym = ((long) zzi(Object[].class));
    private static final long zzyn = ((long) zzj(Object[].class));
    private static final long zzyo = zzc(zzgx());
    private static final long zzyp;
    private static final boolean zzyq = (ByteOrder.nativeOrder() != ByteOrder.BIG_ENDIAN);

    static abstract class zze {
        Unsafe zzyr;

        zze(Unsafe unsafe) {
            this.zzyr = unsafe;
        }

        public final long zzb(Field field) {
            return this.zzyr.objectFieldOffset(field);
        }

        public abstract void zzb(long j, byte b);

        public abstract void zzb(Object obj, long j, double d);

        public abstract void zzb(Object obj, long j, float f);

        public final void zzb(Object obj, long j, long j2) {
            this.zzyr.putLong(obj, j, j2);
        }

        public abstract void zzb(Object obj, long j, boolean z);

        public abstract void zzb(byte[] bArr, long j, long j2, long j3);

        public final void zzc(Object obj, long j, int i) {
            this.zzyr.putInt(obj, j, i);
        }

        public abstract void zzf(Object obj, long j, byte b);

        public final int zzl(Object obj, long j) {
            return this.zzyr.getInt(obj, j);
        }

        public final long zzm(Object obj, long j) {
            return this.zzyr.getLong(obj, j);
        }

        public abstract boolean zzn(Object obj, long j);

        public abstract float zzo(Object obj, long j);

        public abstract double zzp(Object obj, long j);

        public abstract byte zzz(Object obj, long j);
    }

    static final class zzb extends zze {
        zzb(Unsafe unsafe) {
            super(unsafe);
        }

        public final void zzb(long j, byte b) {
            Memory.pokeByte((int) (j & -1), b);
        }

        public final void zzb(Object obj, long j, double d) {
            zzb(obj, j, Double.doubleToLongBits(d));
        }

        public final void zzb(Object obj, long j, float f) {
            zzc(obj, j, Float.floatToIntBits(f));
        }

        public final void zzb(Object obj, long j, boolean z) {
            if (zzjw.zzyq) {
                zzjw.zzc(obj, j, z);
            } else {
                zzjw.zzd(obj, j, z);
            }
        }

        public final void zzb(byte[] bArr, long j, long j2, long j3) {
            Memory.pokeByteArray((int) (j2 & -1), bArr, (int) j, (int) j3);
        }

        public final void zzf(Object obj, long j, byte b) {
            if (zzjw.zzyq) {
                zzjw.zzb(obj, j, b);
            } else {
                zzjw.zzc(obj, j, b);
            }
        }

        public final boolean zzn(Object obj, long j) {
            return zzjw.zzyq ? zzjw.zzt(obj, j) : zzjw.zzu(obj, j);
        }

        public final float zzo(Object obj, long j) {
            return Float.intBitsToFloat(zzl(obj, j));
        }

        public final double zzp(Object obj, long j) {
            return Double.longBitsToDouble(zzm(obj, j));
        }

        public final byte zzz(Object obj, long j) {
            return zzjw.zzyq ? zzjw.zzr(obj, j) : zzjw.zzs(obj, j);
        }
    }

    static final class zzc extends zze {
        zzc(Unsafe unsafe) {
            super(unsafe);
        }

        public final void zzb(long j, byte b) {
            Memory.pokeByte(j, b);
        }

        public final void zzb(Object obj, long j, double d) {
            zzb(obj, j, Double.doubleToLongBits(d));
        }

        public final void zzb(Object obj, long j, float f) {
            zzc(obj, j, Float.floatToIntBits(f));
        }

        public final void zzb(Object obj, long j, boolean z) {
            if (zzjw.zzyq) {
                zzjw.zzc(obj, j, z);
            } else {
                zzjw.zzd(obj, j, z);
            }
        }

        public final void zzb(byte[] bArr, long j, long j2, long j3) {
            Memory.pokeByteArray(j2, bArr, (int) j, (int) j3);
        }

        public final void zzf(Object obj, long j, byte b) {
            if (zzjw.zzyq) {
                zzjw.zzb(obj, j, b);
            } else {
                zzjw.zzc(obj, j, b);
            }
        }

        public final boolean zzn(Object obj, long j) {
            return zzjw.zzyq ? zzjw.zzt(obj, j) : zzjw.zzu(obj, j);
        }

        public final float zzo(Object obj, long j) {
            return Float.intBitsToFloat(zzl(obj, j));
        }

        public final double zzp(Object obj, long j) {
            return Double.longBitsToDouble(zzm(obj, j));
        }

        public final byte zzz(Object obj, long j) {
            return zzjw.zzyq ? zzjw.zzr(obj, j) : zzjw.zzs(obj, j);
        }
    }

    static final class zzd extends zze {
        zzd(Unsafe unsafe) {
            super(unsafe);
        }

        public final void zzb(long j, byte b) {
            this.zzyr.putByte(j, b);
        }

        public final void zzb(Object obj, long j, double d) {
            this.zzyr.putDouble(obj, j, d);
        }

        public final void zzb(Object obj, long j, float f) {
            this.zzyr.putFloat(obj, j, f);
        }

        public final void zzb(Object obj, long j, boolean z) {
            this.zzyr.putBoolean(obj, j, z);
        }

        public final void zzb(byte[] bArr, long j, long j2, long j3) {
            this.zzyr.copyMemory(bArr, zzjw.zzyb + j, null, j2, j3);
        }

        public final void zzf(Object obj, long j, byte b) {
            this.zzyr.putByte(obj, j, b);
        }

        public final boolean zzn(Object obj, long j) {
            return this.zzyr.getBoolean(obj, j);
        }

        public final float zzo(Object obj, long j) {
            return this.zzyr.getFloat(obj, j);
        }

        public final double zzp(Object obj, long j) {
            return this.zzyr.getDouble(obj, j);
        }

        public final byte zzz(Object obj, long j) {
            return this.zzyr.getByte(obj, j);
        }
    }

    static {
        zze zzd;
        Field zzc;
        if (zzuz != null) {
            if (!zzfl.zzbd()) {
                zzd = new zzd(zzuz);
            } else if (zzxx) {
                zzd = new zzc(zzuz);
            } else if (zzxy) {
                zzd = new zzb(zzuz);
            }
            zzxz = zzd;
            zzc = zzc(String.class, "value");
            if (zzc != null || zzc.getType() != char[].class) {
                zzc = null;
            }
            zzyp = zzc(zzc);
        }
        zzd = null;
        zzxz = zzd;
        zzc = zzc(String.class, "value");
        if (zzc != null) {
        }
        zzc = null;
        zzyp = zzc(zzc);
        if (ByteOrder.nativeOrder() != ByteOrder.BIG_ENDIAN) {
        }
    }

    private zzjw() {
    }

    static byte zzb(byte[] bArr, long j) {
        return zzxz.zzz(bArr, zzyb + j);
    }

    static long zzb(Field field) {
        return zzxz.zzb(field);
    }

    static void zzb(long j, byte b) {
        zzxz.zzb(j, b);
    }

    private static void zzb(Object obj, long j, byte b) {
        long j2 = -4 & j;
        int i = ((((int) j) ^ -1) & 3) << 3;
        zzc(obj, j2, ((255 & b) << i) | (zzl(obj, j2) & ((255 << i) ^ -1)));
    }

    static void zzb(Object obj, long j, double d) {
        zzxz.zzb(obj, j, d);
    }

    static void zzb(Object obj, long j, float f) {
        zzxz.zzb(obj, j, f);
    }

    static void zzb(Object obj, long j, long j2) {
        zzxz.zzb(obj, j, j2);
    }

    static void zzb(Object obj, long j, Object obj2) {
        zzxz.zzyr.putObject(obj, j, obj2);
    }

    static void zzb(Object obj, long j, boolean z) {
        zzxz.zzb(obj, j, z);
    }

    static void zzb(byte[] bArr, long j, byte b) {
        zzxz.zzf(bArr, zzyb + j, b);
    }

    static void zzb(byte[] bArr, long j, long j2, long j3) {
        zzxz.zzb(bArr, j, j2, j3);
    }

    private static long zzc(Field field) {
        if (field != null) {
            if (zzxz != null) {
                return zzxz.zzb(field);
            }
        }
        return -1;
    }

    static long zzc(ByteBuffer byteBuffer) {
        return zzxz.zzm(byteBuffer, zzyo);
    }

    private static java.lang.reflect.Field zzc(java.lang.Class<?> r0, java.lang.String r1) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/952562199.run(Unknown Source)
*/
        /*
        r0 = r0.getDeclaredField(r1);	 Catch:{ Throwable -> 0x0009 }
        r1 = 1;	 Catch:{ Throwable -> 0x0009 }
        r0.setAccessible(r1);	 Catch:{ Throwable -> 0x0009 }
        goto L_0x000a;
    L_0x0009:
        r0 = 0;
    L_0x000a:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.places.zzjw.zzc(java.lang.Class, java.lang.String):java.lang.reflect.Field");
    }

    private static void zzc(Object obj, long j, byte b) {
        long j2 = -4 & j;
        int i = (((int) j) & 3) << 3;
        zzc(obj, j2, ((255 & b) << i) | (zzl(obj, j2) & ((255 << i) ^ -1)));
    }

    static void zzc(Object obj, long j, int i) {
        zzxz.zzc(obj, j, i);
    }

    private static void zzc(Object obj, long j, boolean z) {
        zzb(obj, j, (byte) z);
    }

    private static void zzd(Object obj, long j, boolean z) {
        zzc(obj, j, (byte) z);
    }

    static boolean zzgs() {
        return zzoo;
    }

    static boolean zzgt() {
        return zzya;
    }

    static sun.misc.Unsafe zzgu() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/952562199.run(Unknown Source)
*/
        /*
        r0 = new com.google.android.gms.internal.places.zzjx;	 Catch:{ Throwable -> 0x000c }
        r0.<init>();	 Catch:{ Throwable -> 0x000c }
        r0 = java.security.AccessController.doPrivileged(r0);	 Catch:{ Throwable -> 0x000c }
        r0 = (sun.misc.Unsafe) r0;	 Catch:{ Throwable -> 0x000c }
        goto L_0x000d;
    L_0x000c:
        r0 = 0;
    L_0x000d:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.places.zzjw.zzgu():sun.misc.Unsafe");
    }

    private static boolean zzgv() {
        if (zzuz == null) {
            return false;
        }
        try {
            Class cls = zzuz.getClass();
            cls.getMethod("objectFieldOffset", new Class[]{Field.class});
            cls.getMethod("arrayBaseOffset", new Class[]{Class.class});
            cls.getMethod("arrayIndexScale", new Class[]{Class.class});
            cls.getMethod("getInt", new Class[]{Object.class, Long.TYPE});
            cls.getMethod("putInt", new Class[]{Object.class, Long.TYPE, Integer.TYPE});
            cls.getMethod("getLong", new Class[]{Object.class, Long.TYPE});
            cls.getMethod("putLong", new Class[]{Object.class, Long.TYPE, Long.TYPE});
            cls.getMethod("getObject", new Class[]{Object.class, Long.TYPE});
            cls.getMethod("putObject", new Class[]{Object.class, Long.TYPE, Object.class});
            if (zzfl.zzbd()) {
                return true;
            }
            cls.getMethod("getByte", new Class[]{Object.class, Long.TYPE});
            cls.getMethod("putByte", new Class[]{Object.class, Long.TYPE, Byte.TYPE});
            cls.getMethod("getBoolean", new Class[]{Object.class, Long.TYPE});
            cls.getMethod("putBoolean", new Class[]{Object.class, Long.TYPE, Boolean.TYPE});
            cls.getMethod("getFloat", new Class[]{Object.class, Long.TYPE});
            cls.getMethod("putFloat", new Class[]{Object.class, Long.TYPE, Float.TYPE});
            cls.getMethod("getDouble", new Class[]{Object.class, Long.TYPE});
            cls.getMethod("putDouble", new Class[]{Object.class, Long.TYPE, Double.TYPE});
            return true;
        } catch (Throwable th) {
            String valueOf = String.valueOf(th);
            StringBuilder stringBuilder = new StringBuilder(String.valueOf(valueOf).length() + 71);
            stringBuilder.append("platform method missing - proto runtime falling back to safer methods: ");
            stringBuilder.append(valueOf);
            logger.logp(Level.WARNING, "com.google.protobuf.UnsafeUtil", "supportsUnsafeArrayOperations", stringBuilder.toString());
            return false;
        }
    }

    private static boolean zzgw() {
        if (zzuz == null) {
            return false;
        }
        try {
            Class cls = zzuz.getClass();
            cls.getMethod("objectFieldOffset", new Class[]{Field.class});
            cls.getMethod("getLong", new Class[]{Object.class, Long.TYPE});
            if (zzgx() == null) {
                return false;
            }
            if (zzfl.zzbd()) {
                return true;
            }
            cls.getMethod("getByte", new Class[]{Long.TYPE});
            cls.getMethod("putByte", new Class[]{Long.TYPE, Byte.TYPE});
            cls.getMethod("getInt", new Class[]{Long.TYPE});
            cls.getMethod("putInt", new Class[]{Long.TYPE, Integer.TYPE});
            cls.getMethod("getLong", new Class[]{Long.TYPE});
            cls.getMethod("putLong", new Class[]{Long.TYPE, Long.TYPE});
            cls.getMethod("copyMemory", new Class[]{Long.TYPE, Long.TYPE, Long.TYPE});
            cls.getMethod("copyMemory", new Class[]{Object.class, Long.TYPE, Object.class, Long.TYPE, Long.TYPE});
            return true;
        } catch (Throwable th) {
            String valueOf = String.valueOf(th);
            StringBuilder stringBuilder = new StringBuilder(String.valueOf(valueOf).length() + 71);
            stringBuilder.append("platform method missing - proto runtime falling back to safer methods: ");
            stringBuilder.append(valueOf);
            logger.logp(Level.WARNING, "com.google.protobuf.UnsafeUtil", "supportsUnsafeByteBufferOperations", stringBuilder.toString());
            return false;
        }
    }

    private static Field zzgx() {
        Field zzc;
        if (zzfl.zzbd()) {
            zzc = zzc(Buffer.class, "effectiveDirectAddress");
            if (zzc != null) {
                return zzc;
            }
        }
        zzc = zzc(Buffer.class, "address");
        return (zzc == null || zzc.getType() != Long.TYPE) ? null : zzc;
    }

    private static int zzi(Class<?> cls) {
        return zzoo ? zzxz.zzyr.arrayBaseOffset(cls) : -1;
    }

    private static int zzj(Class<?> cls) {
        return zzoo ? zzxz.zzyr.arrayIndexScale(cls) : -1;
    }

    private static boolean zzk(java.lang.Class<?> r9) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/952562199.run(Unknown Source)
*/
        /*
        r0 = com.google.android.gms.internal.places.zzfl.zzbd();
        r1 = 0;
        if (r0 != 0) goto L_0x0008;
    L_0x0007:
        return r1;
    L_0x0008:
        r0 = zznl;	 Catch:{ Throwable -> 0x008b }
        r2 = "peekLong";	 Catch:{ Throwable -> 0x008b }
        r3 = 2;	 Catch:{ Throwable -> 0x008b }
        r4 = new java.lang.Class[r3];	 Catch:{ Throwable -> 0x008b }
        r4[r1] = r9;	 Catch:{ Throwable -> 0x008b }
        r5 = java.lang.Boolean.TYPE;	 Catch:{ Throwable -> 0x008b }
        r6 = 1;	 Catch:{ Throwable -> 0x008b }
        r4[r6] = r5;	 Catch:{ Throwable -> 0x008b }
        r0.getMethod(r2, r4);	 Catch:{ Throwable -> 0x008b }
        r2 = "pokeLong";	 Catch:{ Throwable -> 0x008b }
        r4 = 3;	 Catch:{ Throwable -> 0x008b }
        r5 = new java.lang.Class[r4];	 Catch:{ Throwable -> 0x008b }
        r5[r1] = r9;	 Catch:{ Throwable -> 0x008b }
        r7 = java.lang.Long.TYPE;	 Catch:{ Throwable -> 0x008b }
        r5[r6] = r7;	 Catch:{ Throwable -> 0x008b }
        r7 = java.lang.Boolean.TYPE;	 Catch:{ Throwable -> 0x008b }
        r5[r3] = r7;	 Catch:{ Throwable -> 0x008b }
        r0.getMethod(r2, r5);	 Catch:{ Throwable -> 0x008b }
        r2 = "pokeInt";	 Catch:{ Throwable -> 0x008b }
        r5 = new java.lang.Class[r4];	 Catch:{ Throwable -> 0x008b }
        r5[r1] = r9;	 Catch:{ Throwable -> 0x008b }
        r7 = java.lang.Integer.TYPE;	 Catch:{ Throwable -> 0x008b }
        r5[r6] = r7;	 Catch:{ Throwable -> 0x008b }
        r7 = java.lang.Boolean.TYPE;	 Catch:{ Throwable -> 0x008b }
        r5[r3] = r7;	 Catch:{ Throwable -> 0x008b }
        r0.getMethod(r2, r5);	 Catch:{ Throwable -> 0x008b }
        r2 = "peekInt";	 Catch:{ Throwable -> 0x008b }
        r5 = new java.lang.Class[r3];	 Catch:{ Throwable -> 0x008b }
        r5[r1] = r9;	 Catch:{ Throwable -> 0x008b }
        r7 = java.lang.Boolean.TYPE;	 Catch:{ Throwable -> 0x008b }
        r5[r6] = r7;	 Catch:{ Throwable -> 0x008b }
        r0.getMethod(r2, r5);	 Catch:{ Throwable -> 0x008b }
        r2 = "pokeByte";	 Catch:{ Throwable -> 0x008b }
        r5 = new java.lang.Class[r3];	 Catch:{ Throwable -> 0x008b }
        r5[r1] = r9;	 Catch:{ Throwable -> 0x008b }
        r7 = java.lang.Byte.TYPE;	 Catch:{ Throwable -> 0x008b }
        r5[r6] = r7;	 Catch:{ Throwable -> 0x008b }
        r0.getMethod(r2, r5);	 Catch:{ Throwable -> 0x008b }
        r2 = "peekByte";	 Catch:{ Throwable -> 0x008b }
        r5 = new java.lang.Class[r6];	 Catch:{ Throwable -> 0x008b }
        r5[r1] = r9;	 Catch:{ Throwable -> 0x008b }
        r0.getMethod(r2, r5);	 Catch:{ Throwable -> 0x008b }
        r2 = "pokeByteArray";	 Catch:{ Throwable -> 0x008b }
        r5 = 4;	 Catch:{ Throwable -> 0x008b }
        r7 = new java.lang.Class[r5];	 Catch:{ Throwable -> 0x008b }
        r7[r1] = r9;	 Catch:{ Throwable -> 0x008b }
        r8 = byte[].class;	 Catch:{ Throwable -> 0x008b }
        r7[r6] = r8;	 Catch:{ Throwable -> 0x008b }
        r8 = java.lang.Integer.TYPE;	 Catch:{ Throwable -> 0x008b }
        r7[r3] = r8;	 Catch:{ Throwable -> 0x008b }
        r8 = java.lang.Integer.TYPE;	 Catch:{ Throwable -> 0x008b }
        r7[r4] = r8;	 Catch:{ Throwable -> 0x008b }
        r0.getMethod(r2, r7);	 Catch:{ Throwable -> 0x008b }
        r2 = "peekByteArray";	 Catch:{ Throwable -> 0x008b }
        r5 = new java.lang.Class[r5];	 Catch:{ Throwable -> 0x008b }
        r5[r1] = r9;	 Catch:{ Throwable -> 0x008b }
        r9 = byte[].class;	 Catch:{ Throwable -> 0x008b }
        r5[r6] = r9;	 Catch:{ Throwable -> 0x008b }
        r9 = java.lang.Integer.TYPE;	 Catch:{ Throwable -> 0x008b }
        r5[r3] = r9;	 Catch:{ Throwable -> 0x008b }
        r9 = java.lang.Integer.TYPE;	 Catch:{ Throwable -> 0x008b }
        r5[r4] = r9;	 Catch:{ Throwable -> 0x008b }
        r0.getMethod(r2, r5);	 Catch:{ Throwable -> 0x008b }
        return r6;
    L_0x008b:
        return r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.places.zzjw.zzk(java.lang.Class):boolean");
    }

    static int zzl(Object obj, long j) {
        return zzxz.zzl(obj, j);
    }

    static long zzm(Object obj, long j) {
        return zzxz.zzm(obj, j);
    }

    static boolean zzn(Object obj, long j) {
        return zzxz.zzn(obj, j);
    }

    static float zzo(Object obj, long j) {
        return zzxz.zzo(obj, j);
    }

    static double zzp(Object obj, long j) {
        return zzxz.zzp(obj, j);
    }

    static Object zzq(Object obj, long j) {
        return zzxz.zzyr.getObject(obj, j);
    }

    private static byte zzr(Object obj, long j) {
        return (byte) (zzl(obj, -4 & j) >>> ((int) (((j ^ -1) & 3) << 3)));
    }

    private static byte zzs(Object obj, long j) {
        return (byte) (zzl(obj, -4 & j) >>> ((int) ((j & 3) << 3)));
    }

    private static boolean zzt(Object obj, long j) {
        return zzr(obj, j) != (byte) 0;
    }

    private static boolean zzu(Object obj, long j) {
        return zzs(obj, j) != (byte) 0;
    }
}
