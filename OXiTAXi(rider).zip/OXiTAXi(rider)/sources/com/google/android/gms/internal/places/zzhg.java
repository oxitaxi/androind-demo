package com.google.android.gms.internal.places;

import java.util.List;
import java.util.RandomAccess;

public interface zzhg<E> extends List<E>, RandomAccess {
    zzhg<E> zzae(int i);

    boolean zzba();

    void zzbb();
}
