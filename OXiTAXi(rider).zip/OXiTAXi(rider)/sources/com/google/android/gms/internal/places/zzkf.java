package com.google.android.gms.internal.places;

enum zzkf extends zzke {
    zzkf(String str, int i, zzkj zzkj, int i2) {
        super(str, 8, zzkj, 2);
    }
}
