package com.google.android.gms.internal.places;

import java.io.IOException;

public final class zzkl {
    private final byte[] buffer;
    private int zzaaa;
    private int zzaab;
    private zzga zzaac;
    private int zzob;
    private int zzoc = 64;
    private int zzod = 67108864;
    private int zzoi;
    private int zzok;
    private int zzol = Integer.MAX_VALUE;
    private final int zzzy;
    private final int zzzz;

    private zzkl(byte[] bArr, int i, int i2) {
        this.buffer = bArr;
        this.zzzy = i;
        i2 += i;
        this.zzaaa = i2;
        this.zzzz = i2;
        this.zzaab = i;
    }

    private final void zzam(int i) throws IOException {
        if (i < 0) {
            throw zzkt.zzhh();
        } else if (this.zzaab + i > this.zzol) {
            zzam(this.zzol - this.zzaab);
            throw zzkt.zzhg();
        } else if (i <= this.zzaaa - this.zzaab) {
            this.zzaab += i;
        } else {
            throw zzkt.zzhg();
        }
    }

    private final void zzcq() {
        this.zzaaa += this.zzoi;
        int i = this.zzaaa;
        if (i > this.zzol) {
            this.zzoi = i - this.zzol;
            this.zzaaa -= this.zzoi;
            return;
        }
        this.zzoi = 0;
    }

    private final byte zzcr() throws IOException {
        if (this.zzaab != this.zzaaa) {
            byte[] bArr = this.buffer;
            int i = this.zzaab;
            this.zzaab = i + 1;
            return bArr[i];
        }
        throw zzkt.zzhg();
    }

    public static zzkl zzh(byte[] bArr) {
        return zzk(bArr, 0, bArr.length);
    }

    public static zzkl zzk(byte[] bArr, int i, int i2) {
        return new zzkl(bArr, 0, i2);
    }

    public final int getPosition() {
        return this.zzaab - this.zzzy;
    }

    public final byte[] readBytes() throws IOException {
        int zzcm = zzcm();
        if (zzcm < 0) {
            throw zzkt.zzhh();
        } else if (zzcm == 0) {
            return zzkx.zzabb;
        } else {
            if (zzcm <= this.zzaaa - this.zzaab) {
                Object obj = new byte[zzcm];
                System.arraycopy(this.buffer, this.zzaab, obj, 0, zzcm);
                this.zzaab += zzcm;
                return obj;
            }
            throw zzkt.zzhg();
        }
    }

    public final String readString() throws IOException {
        int zzcm = zzcm();
        if (zzcm < 0) {
            throw zzkt.zzhh();
        } else if (zzcm <= this.zzaaa - this.zzaab) {
            String str = new String(this.buffer, this.zzaab, zzcm, zzks.UTF_8);
            this.zzaab += zzcm;
            return str;
        } else {
            throw zzkt.zzhg();
        }
    }

    public final void zzah(int i) throws zzkt {
        if (this.zzok != i) {
            throw new zzkt("Protocol message end-group tag did not match expected tag.");
        }
    }

    public final boolean zzai(int i) throws IOException {
        switch (i & 7) {
            case 0:
                zzcm();
                return true;
            case 1:
                zzcp();
                return true;
            case 2:
                zzam(zzcm());
                return true;
            case 3:
                break;
            case 4:
                return false;
            case 5:
                zzco();
                return true;
            default:
                throw new zzkt("Protocol message tag had invalid wire type.");
        }
        int zzcj;
        do {
            zzcj = zzcj();
            if (zzcj != 0) {
            }
            zzah(((i >>> 3) << 3) | 4);
            return true;
        } while (zzai(zzcj));
        zzah(((i >>> 3) << 3) | 4);
        return true;
    }

    public final int zzak(int i) throws zzkt {
        if (i >= 0) {
            i += this.zzaab;
            int i2 = this.zzol;
            if (i <= i2) {
                this.zzol = i;
                zzcq();
                return i2;
            }
            throw zzkt.zzhg();
        }
        throw zzkt.zzhh();
    }

    public final void zzal(int i) {
        this.zzol = i;
        zzcq();
    }

    public final <T extends zzgz<T, ?>> T zzb(zzir<T> zzir) throws IOException {
        if (this.zzaac == null) {
            this.zzaac = zzga.zzf(this.buffer, this.zzzy, this.zzzz);
        }
        int zzcl = this.zzaac.zzcl();
        int i = this.zzaab - this.zzzy;
        if (zzcl <= i) {
            this.zzaac.zzam(i - zzcl);
            this.zzaac.zzaj(this.zzoc - this.zzob);
            zzgz zzgz = (zzgz) this.zzaac.zzb(zzir, zzgl.zzdb());
            zzai(this.zzok);
            return zzgz;
        }
        throw new IOException(String.format("CodedInputStream read ahead of CodedInputByteBufferNano: %s > %s", new Object[]{Integer.valueOf(zzcl), Integer.valueOf(i)}));
    }

    public final void zzb(zzku zzku) throws IOException {
        int zzcm = zzcm();
        if (this.zzob < this.zzoc) {
            zzcm = zzak(zzcm);
            this.zzob++;
            zzku.zzb(this);
            zzah(0);
            this.zzob--;
            zzal(zzcm);
            return;
        }
        throw zzkt.zzhj();
    }

    public final void zzb(zzku zzku, int i) throws IOException {
        if (this.zzob < this.zzoc) {
            this.zzob++;
            zzku.zzb(this);
            zzah((i << 3) | 4);
            this.zzob--;
            return;
        }
        throw zzkt.zzhj();
    }

    public final void zzbr(int i) {
        zzu(i, this.zzok);
    }

    public final int zzcj() throws IOException {
        if (this.zzaab == this.zzaaa) {
            this.zzok = 0;
            return 0;
        }
        this.zzok = zzcm();
        if (this.zzok != 0) {
            return this.zzok;
        }
        throw new zzkt("Protocol message contained an invalid tag (zero).");
    }

    public final int zzcm() throws IOException {
        byte zzcr = zzcr();
        if (zzcr >= (byte) 0) {
            return zzcr;
        }
        int i;
        int i2 = zzcr & 127;
        byte zzcr2 = zzcr();
        if (zzcr2 >= (byte) 0) {
            i = zzcr2 << 7;
        } else {
            i2 |= (zzcr2 & 127) << 7;
            zzcr2 = zzcr();
            if (zzcr2 >= (byte) 0) {
                i = zzcr2 << 14;
            } else {
                i2 |= (zzcr2 & 127) << 14;
                zzcr2 = zzcr();
                if (zzcr2 >= (byte) 0) {
                    i = zzcr2 << 21;
                } else {
                    i2 |= (zzcr2 & 127) << 21;
                    zzcr2 = zzcr();
                    i2 |= zzcr2 << 28;
                    if (zzcr2 < (byte) 0) {
                        for (i = 0; i < 5; i++) {
                            if (zzcr() >= (byte) 0) {
                                return i2;
                            }
                        }
                        throw zzkt.zzhi();
                    }
                    return i2;
                }
            }
        }
        i2 |= i;
        return i2;
    }

    public final long zzcn() throws IOException {
        long j = 0;
        for (int i = 0; i < 64; i += 7) {
            byte zzcr = zzcr();
            j |= ((long) (zzcr & 127)) << i;
            if ((zzcr & 128) == 0) {
                return j;
            }
        }
        throw zzkt.zzhi();
    }

    public final int zzco() throws IOException {
        return (((zzcr() & 255) | ((zzcr() & 255) << 8)) | ((zzcr() & 255) << 16)) | ((zzcr() & 255) << 24);
    }

    public final long zzcp() throws IOException {
        byte zzcr = zzcr();
        byte zzcr2 = zzcr();
        return ((((((((((long) zzcr2) & 255) << 8) | (((long) zzcr) & 255)) | ((((long) zzcr()) & 255) << 16)) | ((((long) zzcr()) & 255) << 24)) | ((((long) zzcr()) & 255) << 32)) | ((((long) zzcr()) & 255) << 40)) | ((((long) zzcr()) & 255) << 48)) | ((((long) zzcr()) & 255) << 56);
    }

    public final int zzhb() {
        if (this.zzol == Integer.MAX_VALUE) {
            return -1;
        }
        return this.zzol - this.zzaab;
    }

    public final byte[] zzt(int i, int i2) {
        if (i2 == 0) {
            return zzkx.zzabb;
        }
        Object obj = new byte[i2];
        System.arraycopy(this.buffer, this.zzzy + i, obj, 0, i2);
        return obj;
    }

    final void zzu(int i, int i2) {
        if (i > this.zzaab - this.zzzy) {
            int i3 = this.zzaab - this.zzzy;
            StringBuilder stringBuilder = new StringBuilder(50);
            stringBuilder.append("Position ");
            stringBuilder.append(i);
            stringBuilder.append(" is beyond current ");
            stringBuilder.append(i3);
            throw new IllegalArgumentException(stringBuilder.toString());
        } else if (i >= 0) {
            this.zzaab = this.zzzy + i;
            this.zzok = i2;
        } else {
            StringBuilder stringBuilder2 = new StringBuilder(24);
            stringBuilder2.append("Bad position ");
            stringBuilder2.append(i);
            throw new IllegalArgumentException(stringBuilder2.toString());
        }
    }
}
