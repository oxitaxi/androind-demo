package com.google.android.gms.internal.places;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public abstract class zzgz<MessageType extends zzgz<MessageType, BuilderType>, BuilderType extends zzb<MessageType, BuilderType>> extends zzfh<MessageType, BuilderType> {
    private static Map<Object, zzgz<?, ?>> zzsi = new ConcurrentHashMap();
    protected zzjr zzsg = zzjr.zzgp();
    private int zzsh = -1;

    public enum zzh {
        public static final int zzsv = 1;
        public static final int zzsw = 2;
        public static final int zzsx = 3;
        public static final int zzsy = 4;
        public static final int zzsz = 5;
        public static final int zzta = 6;
        public static final int zztb = 7;
        private static final /* synthetic */ int[] zztc = new int[]{zzsv, zzsw, zzsx, zzsy, zzsz, zzta, zztb};
        public static final int zztd = 1;
        public static final int zzte = 2;
        private static final /* synthetic */ int[] zztf = new int[]{zztd, zzte};
        public static final int zztg = 1;
        public static final int zzth = 2;
        private static final /* synthetic */ int[] zzti = new int[]{zztg, zzth};

        /* renamed from: values$50KLMJ33DTMIUPRFDTJMOP9FE1P6UT3FC9QMCBQ7CLN6ASJ1EHIM8JB5EDPM2PR59HKN8P949LIN8Q3FCHA6UIBEEPNMMP9R0 */
        public static int[] m24x126d66cb() {
            return (int[]) zztc.clone();
        }
    }

    static final class zzf implements zzgs<zzf> {
        final int number = 77815057;
        final zzhd<?> zzsn = null;
        final zzke zzso;
        final boolean zzsp;
        final boolean zzsq;

        zzf(zzhd<?> zzhd, int i, zzke zzke, boolean z, boolean z2) {
            this.zzso = zzke;
            this.zzsp = false;
            this.zzsq = false;
        }

        public final /* synthetic */ int compareTo(Object obj) {
            return this.number - ((zzf) obj).number;
        }

        public final int zzap() {
            return this.number;
        }

        public final zzii zzb(zzii zzii, zzih zzih) {
            return ((zzb) zzii).zzb((zzgz) zzih);
        }

        public final zzin zzb(zzin zzin, zzin zzin2) {
            throw new UnsupportedOperationException();
        }

        public final zzke zzdi() {
            return this.zzso;
        }

        public final zzkj zzdj() {
            return this.zzso.zzgz();
        }

        public final boolean zzdk() {
            return false;
        }

        public final boolean zzdl() {
            return false;
        }
    }

    public static class zzg<ContainingType extends zzih, Type> extends zzgj<ContainingType, Type> {
        private final ContainingType zzsr;
        private final Type zzss;
        final zzih zzst;
        final zzf zzsu;

        zzg(ContainingType containingType, Type type, zzih zzih, zzf zzf, Class cls) {
            if (containingType != null) {
                if (zzf.zzso == zzke.MESSAGE) {
                    if (zzih == null) {
                        throw new IllegalArgumentException("Null messageDefaultInstance");
                    }
                }
                this.zzsr = containingType;
                this.zzss = type;
                this.zzst = zzih;
                this.zzsu = zzf;
                return;
            }
            throw new IllegalArgumentException("Null containingTypeDefaultInstance");
        }
    }

    public static class zzc<T extends zzgz<T, ?>> extends zzfj<T> {
        private T zzsj;

        public zzc(T t) {
            this.zzsj = t;
        }

        public final /* synthetic */ Object zzb(zzga zzga, zzgl zzgl) throws zzhh {
            return zzgz.zzb(this.zzsj, zzga, zzgl);
        }
    }

    public static abstract class zzb<MessageType extends zzgz<MessageType, BuilderType>, BuilderType extends zzb<MessageType, BuilderType>> extends zzfi<MessageType, BuilderType> {
        private final MessageType zzsj;
        protected MessageType zzsk;
        protected boolean zzsl = false;

        protected zzb(MessageType messageType) {
            this.zzsj = messageType;
            this.zzsk = (zzgz) messageType.zzb(zzh.zzsy, null, null);
        }

        private static void zzb(MessageType messageType, MessageType messageType2) {
            zzis.zzfc().zzp((Object) messageType).zzd(messageType, messageType2);
        }

        public /* synthetic */ Object clone() throws CloneNotSupportedException {
            zzb zzb = (zzb) this.zzsj.zzb(zzh.zzsz, null, null);
            zzb.zzb((zzgz) zzdw());
            return zzb;
        }

        public final boolean isInitialized() {
            return zzgz.zzb(this.zzsk, false);
        }

        public final /* synthetic */ zzfi zzaz() {
            return (zzb) clone();
        }

        protected final /* synthetic */ zzfi zzb(zzfh zzfh) {
            return zzb((zzgz) zzfh);
        }

        public final BuilderType zzb(MessageType messageType) {
            zzdt();
            zzb(this.zzsk, messageType);
            return this;
        }

        public final /* synthetic */ zzih zzds() {
            return this.zzsj;
        }

        protected void zzdt() {
            if (this.zzsl) {
                zzgz zzgz = (zzgz) this.zzsk.zzb(zzh.zzsy, null, null);
                zzb(zzgz, this.zzsk);
                this.zzsk = zzgz;
                this.zzsl = false;
            }
        }

        public MessageType zzdu() {
            if (this.zzsl) {
                return this.zzsk;
            }
            Object obj = this.zzsk;
            zzis.zzfc().zzp(obj).zzd(obj);
            this.zzsl = true;
            return this.zzsk;
        }

        public final MessageType zzdv() {
            Object obj = (zzgz) zzdw();
            boolean booleanValue = Boolean.TRUE.booleanValue();
            byte byteValue = ((Byte) obj.zzb(zzh.zzsv, null, null)).byteValue();
            boolean z = true;
            if (byteValue != (byte) 1) {
                if (byteValue == (byte) 0) {
                    z = false;
                } else {
                    z = zzis.zzfc().zzp(obj).zzo(obj);
                    if (booleanValue) {
                        obj.zzb(zzh.zzsw, z ? obj : null, null);
                    }
                }
            }
            if (z) {
                return obj;
            }
            throw new zzjp(obj);
        }

        public /* synthetic */ zzih zzdw() {
            return zzdu();
        }

        public final /* synthetic */ zzih zzdx() {
            Object obj = (zzgz) zzdw();
            boolean booleanValue = Boolean.TRUE.booleanValue();
            byte byteValue = ((Byte) obj.zzb(zzh.zzsv, null, null)).byteValue();
            boolean z = true;
            if (byteValue != (byte) 1) {
                if (byteValue == (byte) 0) {
                    z = false;
                } else {
                    z = zzis.zzfc().zzp(obj).zzo(obj);
                    if (booleanValue) {
                        obj.zzb(zzh.zzsw, z ? obj : null, null);
                    }
                }
            }
            if (z) {
                return obj;
            }
            throw new zzjp(obj);
        }
    }

    public static abstract class zzd<MessageType extends zze<MessageType, BuilderType>, BuilderType extends zzd<MessageType, BuilderType>> extends zzb<MessageType, BuilderType> implements zzij {
        protected zzd(MessageType messageType) {
            super(messageType);
        }

        protected final void zzdt() {
            if (this.zzsl) {
                super.zzdt();
                ((zze) this.zzsk).zzsm = (zzgq) ((zze) this.zzsk).zzsm.clone();
            }
        }

        public final /* synthetic */ zzgz zzdu() {
            return (zze) zzdw();
        }

        public final /* synthetic */ zzih zzdw() {
            zzgz zzgz;
            if (this.zzsl) {
                zzgz = this.zzsk;
            } else {
                ((zze) this.zzsk).zzsm.zzbb();
                zzgz = super.zzdu();
            }
            return (zze) zzgz;
        }
    }

    public static abstract class zze<MessageType extends zze<MessageType, BuilderType>, BuilderType extends zzd<MessageType, BuilderType>> extends zzgz<MessageType, BuilderType> implements zzij {
        protected zzgq<zzf> zzsm = zzgq.zzdf();
    }

    public static <ContainingType extends zzih, Type> zzg<ContainingType, Type> zzb(ContainingType containingType, Type type, zzih zzih, zzhd<?> zzhd, int i, zzke zzke, Class cls) {
        return new zzg(containingType, type, zzih, new zzf(null, 77815057, zzke, false, false), cls);
    }

    static <T extends zzgz<T, ?>> T zzb(T t, zzga zzga, zzgl zzgl) throws zzhh {
        Object obj = (zzgz) t.zzb(zzh.zzsy, null, null);
        try {
            zzis.zzfc().zzp(obj).zzb(obj, zzgd.zzb(zzga), zzgl);
            zzis.zzfc().zzp(obj).zzd(obj);
            return obj;
        } catch (IOException e) {
            if (e.getCause() instanceof zzhh) {
                throw ((zzhh) e.getCause());
            }
            throw new zzhh(e.getMessage()).zzh(obj);
        } catch (RuntimeException e2) {
            if (e2.getCause() instanceof zzhh) {
                throw ((zzhh) e2.getCause());
            }
            throw e2;
        }
    }

    protected static Object zzb(zzih zzih, String str, Object[] objArr) {
        return new zziu(zzih, str, objArr);
    }

    static Object zzb(Method method, Object obj, Object... objArr) {
        Throwable e;
        try {
            return method.invoke(obj, objArr);
        } catch (Throwable e2) {
            throw new RuntimeException("Couldn't use Java reflection to implement protocol message reflection.", e2);
        } catch (InvocationTargetException e3) {
            e2 = e3.getCause();
            if (e2 instanceof RuntimeException) {
                throw ((RuntimeException) e2);
            } else if (e2 instanceof Error) {
                throw ((Error) e2);
            } else {
                throw new RuntimeException("Unexpected exception thrown by generated accessor method.", e2);
            }
        }
    }

    protected static <T extends zzgz<?, ?>> void zzb(Class<T> cls, T t) {
        zzsi.put(cls, t);
    }

    protected static final <T extends zzgz<T, ?>> boolean zzb(T t, boolean z) {
        byte byteValue = ((Byte) t.zzb(zzh.zzsv, null, null)).byteValue();
        return byteValue == (byte) 1 ? true : byteValue == (byte) 0 ? false : zzis.zzfc().zzp((Object) t).zzo(t);
    }

    protected static zzhe zzdo() {
        return zzha.zzdy();
    }

    protected static <E> zzhg<E> zzdp() {
        return zzit.zzfd();
    }

    static <T extends zzgz<?, ?>> T zze(Class<T> cls) {
        T t = (zzgz) zzsi.get(cls);
        if (t == null) {
            try {
                Class.forName(cls.getName(), true, cls.getClassLoader());
                t = (zzgz) zzsi.get(cls);
            } catch (Throwable e) {
                throw new IllegalStateException("Class initialization cannot fail.", e);
            }
        }
        if (t != null) {
            return t;
        }
        String str = "Unable to get default instance for: ";
        String valueOf = String.valueOf(cls.getName());
        throw new IllegalStateException(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
    }

    public boolean equals(Object obj) {
        return this == obj ? true : !((zzgz) zzb(zzh.zzta, null, null)).getClass().isInstance(obj) ? false : zzis.zzfc().zzp((Object) this).equals(this, (zzgz) obj);
    }

    public int hashCode() {
        if (this.zznh != 0) {
            return this.zznh;
        }
        this.zznh = zzis.zzfc().zzp((Object) this).hashCode(this);
        return this.zznh;
    }

    public final boolean isInitialized() {
        boolean booleanValue = Boolean.TRUE.booleanValue();
        byte byteValue = ((Byte) zzb(zzh.zzsv, null, null)).byteValue();
        if (byteValue == (byte) 1) {
            return true;
        }
        if (byteValue == (byte) 0) {
            return false;
        }
        boolean zzo = zzis.zzfc().zzp((Object) this).zzo(this);
        if (booleanValue) {
            zzb(zzh.zzsw, zzo ? this : null, null);
        }
        return zzo;
    }

    public String toString() {
        return zzik.zzb(this, super.toString());
    }

    final int zzay() {
        return this.zzsh;
    }

    protected abstract Object zzb(int i, Object obj, Object obj2);

    public final void zzc(zzgf zzgf) throws IOException {
        zzis.zzfc().zzg(getClass()).zzb(this, zzgh.zzb(zzgf));
    }

    public final int zzdg() {
        if (this.zzsh == -1) {
            this.zzsh = zzis.zzfc().zzp((Object) this).zzn(this);
        }
        return this.zzsh;
    }

    public final /* synthetic */ zzii zzdq() {
        zzb zzb = (zzb) zzb(zzh.zzsz, null, null);
        zzb.zzb(this);
        return zzb;
    }

    public final /* synthetic */ zzii zzdr() {
        return (zzb) zzb(zzh.zzsz, null, null);
    }

    public final /* synthetic */ zzih zzds() {
        return (zzgz) zzb(zzh.zzta, null, null);
    }

    final void zzv(int i) {
        this.zzsh = i;
    }
}
