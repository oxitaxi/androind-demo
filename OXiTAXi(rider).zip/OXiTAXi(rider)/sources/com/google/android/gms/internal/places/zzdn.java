package com.google.android.gms.internal.places;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.Objects;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelWriter;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable.Class;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable.Constructor;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable.Field;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable.Param;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable.Reserved;
import java.util.List;

@Class(creator = "PlaceUserDataCreator")
@Reserved({1000})
@Deprecated
public final class zzdn extends AbstractSafeParcelable {
    public static final Creator<zzdn> CREATOR = new zzdp();
    @Field(getter = "getPlaceId", id = 2)
    private final String placeId;
    @Field(getter = "getUserAccountName", id = 1)
    private final String zzcx;
    @Field(getter = "getPlaceAliases", id = 6)
    private final List<zzdl> zzhm;

    @Constructor
    zzdn(@Param(id = 1) String str, @Param(id = 2) String str2, @Param(id = 6) List<zzdl> list) {
        this.zzcx = str;
        this.placeId = str2;
        this.zzhm = list;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof zzdn)) {
            return false;
        }
        zzdn zzdn = (zzdn) obj;
        return this.zzcx.equals(zzdn.zzcx) && this.placeId.equals(zzdn.placeId) && this.zzhm.equals(zzdn.zzhm);
    }

    public final int hashCode() {
        return Objects.hashCode(this.zzcx, this.placeId, this.zzhm);
    }

    public final String toString() {
        return Objects.toStringHelper(this).add("accountName", this.zzcx).add("placeId", this.placeId).add("placeAliases", this.zzhm).toString();
    }

    public final void writeToParcel(Parcel parcel, int i) {
        i = SafeParcelWriter.beginObjectHeader(parcel);
        SafeParcelWriter.writeString(parcel, 1, this.zzcx, false);
        SafeParcelWriter.writeString(parcel, 2, this.placeId, false);
        SafeParcelWriter.writeTypedList(parcel, 6, this.zzhm, false);
        SafeParcelWriter.finishObjectHeader(parcel, i);
    }
}
