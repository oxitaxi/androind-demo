package com.google.android.gms.internal.places;

interface zzjo {
    int size();

    byte zzaf(int i);
}
