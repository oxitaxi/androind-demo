package com.google.android.gms.internal.places;

abstract class zzfm implements zzix {
    private zzfm() {
    }
}
