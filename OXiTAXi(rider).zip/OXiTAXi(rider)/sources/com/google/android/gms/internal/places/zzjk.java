package com.google.android.gms.internal.places;

import java.util.AbstractSet;
import java.util.Iterator;
import java.util.Map.Entry;

class zzjk extends AbstractSet<Entry<K, V>> {
    private final /* synthetic */ zzjb zzxk;

    private zzjk(zzjb zzjb) {
        this.zzxk = zzjb;
    }

    public /* synthetic */ boolean add(Object obj) {
        Entry entry = (Entry) obj;
        if (contains(entry)) {
            return false;
        }
        this.zzxk.zzb((Comparable) entry.getKey(), entry.getValue());
        return true;
    }

    public void clear() {
        this.zzxk.clear();
    }

    public boolean contains(Object obj) {
        Entry entry = (Entry) obj;
        Object obj2 = this.zzxk.get(entry.getKey());
        obj = entry.getValue();
        if (obj2 != obj) {
            if (obj2 == null || !obj2.equals(obj)) {
                return false;
            }
        }
        return true;
    }

    public Iterator<Entry<K, V>> iterator() {
        return new zzjj(this.zzxk, null);
    }

    public boolean remove(Object obj) {
        Entry entry = (Entry) obj;
        if (!contains(entry)) {
            return false;
        }
        this.zzxk.remove(entry.getKey());
        return true;
    }

    public int size() {
        return this.zzxk.size();
    }
}
