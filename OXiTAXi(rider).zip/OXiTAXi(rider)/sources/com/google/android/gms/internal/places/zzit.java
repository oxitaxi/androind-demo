package com.google.android.gms.internal.places;

import java.util.ArrayList;
import java.util.List;

final class zzit<E> extends zzfk<E> {
    private static final zzit<Object> zzvx;
    private final List<E> zzuk;

    static {
        zzfk zzit = new zzit();
        zzvx = zzit;
        zzit.zzbb();
    }

    zzit() {
        this(new ArrayList(10));
    }

    private zzit(List<E> list) {
        this.zzuk = list;
    }

    public static <E> zzit<E> zzfd() {
        return zzvx;
    }

    public final void add(int i, E e) {
        zzbc();
        this.zzuk.add(i, e);
        this.modCount++;
    }

    public final E get(int i) {
        return this.zzuk.get(i);
    }

    public final E remove(int i) {
        zzbc();
        E remove = this.zzuk.remove(i);
        this.modCount++;
        return remove;
    }

    public final E set(int i, E e) {
        zzbc();
        E e2 = this.zzuk.set(i, e);
        this.modCount++;
        return e2;
    }

    public final int size() {
        return this.zzuk.size();
    }

    public final /* synthetic */ zzhg zzae(int i) {
        if (i >= size()) {
            List arrayList = new ArrayList(i);
            arrayList.addAll(this.zzuk);
            return new zzit(arrayList);
        }
        throw new IllegalArgumentException();
    }
}
