package com.google.android.gms.internal.places;

public class zzho {
    private static final zzgl zznj = zzgl.zzda();
    private zzfr zzuf;
    private volatile zzih zzug;
    private volatile zzfr zzuh;

    private final com.google.android.gms.internal.places.zzih zzi(com.google.android.gms.internal.places.zzih r2) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/952562199.run(Unknown Source)
*/
        /*
        r1 = this;
        r0 = r1.zzug;
        if (r0 != 0) goto L_0x001c;
    L_0x0004:
        monitor-enter(r1);
        r0 = r1.zzug;	 Catch:{ all -> 0x0019 }
        if (r0 == 0) goto L_0x000b;	 Catch:{ all -> 0x0019 }
    L_0x0009:
        monitor-exit(r1);	 Catch:{ all -> 0x0019 }
        goto L_0x001c;
    L_0x000b:
        r1.zzug = r2;	 Catch:{ zzhh -> 0x0012 }
        r0 = com.google.android.gms.internal.places.zzfr.zznt;	 Catch:{ zzhh -> 0x0012 }
        r1.zzuh = r0;	 Catch:{ zzhh -> 0x0012 }
        goto L_0x0009;
    L_0x0012:
        r1.zzug = r2;	 Catch:{ all -> 0x0019 }
        r2 = com.google.android.gms.internal.places.zzfr.zznt;	 Catch:{ all -> 0x0019 }
        r1.zzuh = r2;	 Catch:{ all -> 0x0019 }
        goto L_0x0009;	 Catch:{ all -> 0x0019 }
    L_0x0019:
        r2 = move-exception;	 Catch:{ all -> 0x0019 }
        monitor-exit(r1);	 Catch:{ all -> 0x0019 }
        throw r2;
    L_0x001c:
        r2 = r1.zzug;
        return r2;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.places.zzho.zzi(com.google.android.gms.internal.places.zzih):com.google.android.gms.internal.places.zzih");
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof zzho)) {
            return false;
        }
        zzho zzho = (zzho) obj;
        zzih zzih = this.zzug;
        zzih zzih2 = zzho.zzug;
        return (zzih == null && zzih2 == null) ? zzax().equals(zzho.zzax()) : (zzih == null || zzih2 == null) ? zzih != null ? zzih.equals(zzho.zzi(zzih.zzds())) : zzi(zzih2.zzds()).equals(zzih2) : zzih.equals(zzih2);
    }

    public int hashCode() {
        return 1;
    }

    public final zzfr zzax() {
        if (this.zzuh != null) {
            return this.zzuh;
        }
        synchronized (this) {
            if (this.zzuh != null) {
                zzfr zzfr = this.zzuh;
                return zzfr;
            }
            this.zzuh = this.zzug == null ? zzfr.zznt : this.zzug.zzax();
            zzfr = this.zzuh;
            return zzfr;
        }
    }

    public final int zzdg() {
        return this.zzuh != null ? this.zzuh.size() : this.zzug != null ? this.zzug.zzdg() : 0;
    }

    public final zzih zzj(zzih zzih) {
        zzih zzih2 = this.zzug;
        this.zzuf = null;
        this.zzuh = null;
        this.zzug = zzih;
        return zzih2;
    }
}
