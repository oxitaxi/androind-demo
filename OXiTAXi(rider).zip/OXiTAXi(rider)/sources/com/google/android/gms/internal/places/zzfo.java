package com.google.android.gms.internal.places;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.List;

final class zzfo extends zzfm {
    private final byte[] buffer;
    private int limit;
    private int pos;
    private int tag;
    private final boolean zzno = true;
    private final int zznp;
    private int zznq;

    public zzfo(ByteBuffer byteBuffer, boolean z) {
        super();
        this.buffer = byteBuffer.array();
        int arrayOffset = byteBuffer.arrayOffset() + byteBuffer.position();
        this.pos = arrayOffset;
        this.zznp = arrayOffset;
        this.limit = byteBuffer.arrayOffset() + byteBuffer.limit();
    }

    private final byte readByte() throws IOException {
        if (this.pos != this.limit) {
            byte[] bArr = this.buffer;
            int i = this.pos;
            this.pos = i + 1;
            return bArr[i];
        }
        throw zzhh.zzdz();
    }

    private final void zzaa(int i) throws IOException {
        zzx(i);
        if ((i & 3) != 0) {
            throw zzhh.zzef();
        }
    }

    private final void zzab(int i) throws IOException {
        if (this.pos != i) {
            throw zzhh.zzdz();
        }
    }

    private final Object zzb(zzke zzke, Class<?> cls, zzgl zzgl) throws IOException {
        switch (zzfn.zznn[zzke.ordinal()]) {
            case 1:
                return Boolean.valueOf(zzbn());
            case 2:
                return zzbp();
            case 3:
                return Double.valueOf(readDouble());
            case 4:
                return Integer.valueOf(zzbr());
            case 5:
                return Integer.valueOf(zzbm());
            case 6:
                return Long.valueOf(zzbl());
            case 7:
                return Float.valueOf(readFloat());
            case 8:
                return Integer.valueOf(zzbk());
            case 9:
                return Long.valueOf(zzbj());
            case 10:
                return zzb((Class) cls, zzgl);
            case 11:
                return Integer.valueOf(zzbs());
            case 12:
                return Long.valueOf(zzbt());
            case 13:
                return Integer.valueOf(zzbu());
            case 14:
                return Long.valueOf(zzbv());
            case 15:
                return zzc(true);
            case 16:
                return Integer.valueOf(zzbq());
            case 17:
                return Long.valueOf(zzbi());
            default:
                throw new RuntimeException("unsupported field type.");
        }
    }

    private final void zzb(List<String> list, boolean z) throws IOException {
        if ((this.tag & 7) != 2) {
            throw zzhh.zzed();
        } else if (!(list instanceof zzhq) || z) {
            int i;
            do {
                list.add(zzc(z));
                if (!zzbf()) {
                    i = this.pos;
                } else {
                    return;
                }
            } while (zzbw() == this.tag);
            this.pos = i;
        } else {
            int i2;
            zzhq zzhq = (zzhq) list;
            do {
                zzhq.zzd(zzbp());
                if (!zzbf()) {
                    i2 = this.pos;
                } else {
                    return;
                }
            } while (zzbw() == this.tag);
            this.pos = i2;
        }
    }

    private final boolean zzbf() {
        return this.pos == this.limit;
    }

    private final int zzbw() throws IOException {
        int i = this.pos;
        if (this.limit != this.pos) {
            int i2 = i + 1;
            byte b = this.buffer[i];
            if (b >= (byte) 0) {
                this.pos = i2;
                return b;
            } else if (this.limit - i2 < 9) {
                return (int) zzby();
            } else {
                int i3 = i2 + 1;
                i = b ^ (this.buffer[i2] << 7);
                if (i < 0) {
                    i ^= -128;
                } else {
                    i2 = i3 + 1;
                    i ^= this.buffer[i3] << 14;
                    if (i >= 0) {
                        i ^= 16256;
                    } else {
                        i3 = i2 + 1;
                        i ^= this.buffer[i2] << 21;
                        if (i < 0) {
                            i ^= -2080896;
                        } else {
                            i2 = i3 + 1;
                            byte b2 = this.buffer[i3];
                            i = (i ^ (b2 << 28)) ^ 266354560;
                            if (b2 < (byte) 0) {
                                i3 = i2 + 1;
                                if (this.buffer[i2] < (byte) 0) {
                                    i2 = i3 + 1;
                                    if (this.buffer[i3] < (byte) 0) {
                                        i3 = i2 + 1;
                                        if (this.buffer[i2] < (byte) 0) {
                                            i2 = i3 + 1;
                                            if (this.buffer[i3] < (byte) 0) {
                                                i3 = i2 + 1;
                                                if (this.buffer[i2] < (byte) 0) {
                                                    throw zzhh.zzeb();
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    i3 = i2;
                }
                this.pos = i3;
                return i;
            }
        }
        throw zzhh.zzdz();
    }

    private final long zzbx() throws IOException {
        int i = this.pos;
        if (this.limit != i) {
            byte[] bArr = this.buffer;
            int i2 = i + 1;
            byte b = bArr[i];
            if (b >= (byte) 0) {
                this.pos = i2;
                return (long) b;
            } else if (this.limit - i2 < 9) {
                return zzby();
            } else {
                long j;
                long j2;
                int i3 = i2 + 1;
                i = b ^ (bArr[i2] << 7);
                if (i < 0) {
                    i ^= -128;
                } else {
                    i2 = i3 + 1;
                    i ^= bArr[i3] << 14;
                    if (i >= 0) {
                        j = (long) (i ^ 16256);
                        i = i2;
                        j2 = j;
                        this.pos = i;
                        return j2;
                    }
                    i3 = i2 + 1;
                    i ^= bArr[i2] << 21;
                    if (i < 0) {
                        i ^= -2080896;
                    } else {
                        long j3 = (long) i;
                        i = i3 + 1;
                        j2 = (((long) bArr[i3]) << 28) ^ j3;
                        if (j2 >= 0) {
                            j3 = 266354560;
                        } else {
                            long j4;
                            int i4 = i + 1;
                            j2 ^= ((long) bArr[i]) << 35;
                            if (j2 < 0) {
                                j4 = -34093383808L;
                            } else {
                                i = i4 + 1;
                                j2 ^= ((long) bArr[i4]) << 42;
                                if (j2 >= 0) {
                                    j3 = 4363953127296L;
                                } else {
                                    i4 = i + 1;
                                    j2 ^= ((long) bArr[i]) << 49;
                                    if (j2 < 0) {
                                        j4 = -558586000294016L;
                                    } else {
                                        i = i4 + 1;
                                        j2 = (j2 ^ (((long) bArr[i4]) << 56)) ^ 71499008037633920L;
                                        if (j2 < 0) {
                                            i4 = i + 1;
                                            if (((long) bArr[i]) >= 0) {
                                                i = i4;
                                            } else {
                                                throw zzhh.zzeb();
                                            }
                                        }
                                        this.pos = i;
                                        return j2;
                                    }
                                }
                            }
                            j2 = j4 ^ j2;
                            i = i4;
                            this.pos = i;
                            return j2;
                        }
                        j2 ^= j3;
                        this.pos = i;
                        return j2;
                    }
                }
                j = (long) i;
                i = i3;
                j2 = j;
                this.pos = i;
                return j2;
            }
        }
        throw zzhh.zzdz();
    }

    private final long zzby() throws IOException {
        long j = 0;
        for (int i = 0; i < 64; i += 7) {
            byte readByte = readByte();
            j |= ((long) (readByte & 127)) << i;
            if ((readByte & 128) == 0) {
                return j;
            }
        }
        throw zzhh.zzeb();
    }

    private final int zzbz() throws IOException {
        zzx(4);
        return zzcb();
    }

    private final <T> T zzc(zziy<T> zziy, zzgl zzgl) throws IOException {
        T zzbw = zzbw();
        zzx(zzbw);
        int i = this.limit;
        int i2 = this.pos + zzbw;
        this.limit = i2;
        try {
            zzbw = zziy.newInstance();
            zziy.zzb(zzbw, this, zzgl);
            zziy.zzd(zzbw);
            if (this.pos == i2) {
                return zzbw;
            }
            throw zzhh.zzef();
        } finally {
            this.limit = i;
        }
    }

    private final String zzc(boolean z) throws IOException {
        zzy(2);
        int zzbw = zzbw();
        if (zzbw == 0) {
            return "";
        }
        zzx(zzbw);
        if (z) {
            if (!zzjy.zzh(this.buffer, this.pos, this.pos + zzbw)) {
                throw zzhh.zzeg();
            }
        }
        String str = new String(this.buffer, this.pos, zzbw, zzhb.UTF_8);
        this.pos += zzbw;
        return str;
    }

    private final long zzca() throws IOException {
        zzx(8);
        return zzcc();
    }

    private final int zzcb() {
        int i = this.pos;
        byte[] bArr = this.buffer;
        this.pos = i + 4;
        return ((bArr[i + 3] & 255) << 24) | (((bArr[i] & 255) | ((bArr[i + 1] & 255) << 8)) | ((bArr[i + 2] & 255) << 16));
    }

    private final long zzcc() {
        int i = this.pos;
        byte[] bArr = this.buffer;
        this.pos = i + 8;
        return ((((long) bArr[i + 7]) & 255) << 56) | (((((((((long) bArr[i]) & 255) | ((((long) bArr[i + 1]) & 255) << 8)) | ((((long) bArr[i + 2]) & 255) << 16)) | ((((long) bArr[i + 3]) & 255) << 24)) | ((((long) bArr[i + 4]) & 255) << 32)) | ((((long) bArr[i + 5]) & 255) << 40)) | ((((long) bArr[i + 6]) & 255) << 48));
    }

    private final <T> T zze(zziy<T> zziy, zzgl zzgl) throws IOException {
        int i = this.zznq;
        T t = ((this.tag >>> 3) << 3) | 4;
        this.zznq = t;
        try {
            t = zziy.newInstance();
            zziy.zzb(t, this, zzgl);
            zziy.zzd(t);
            if (this.tag == this.zznq) {
                return t;
            }
            throw zzhh.zzef();
        } finally {
            this.zznq = i;
        }
    }

    private final void zzw(int i) throws IOException {
        zzx(i);
        this.pos += i;
    }

    private final void zzx(int i) throws IOException {
        if (i < 0 || i > this.limit - this.pos) {
            throw zzhh.zzdz();
        }
    }

    private final void zzy(int i) throws IOException {
        if ((this.tag & 7) != i) {
            throw zzhh.zzed();
        }
    }

    private final void zzz(int i) throws IOException {
        zzx(i);
        if ((i & 7) != 0) {
            throw zzhh.zzef();
        }
    }

    public final int getTag() {
        return this.tag;
    }

    public final double readDouble() throws IOException {
        zzy(1);
        return Double.longBitsToDouble(zzca());
    }

    public final float readFloat() throws IOException {
        zzy(5);
        return Float.intBitsToFloat(zzbz());
    }

    public final String readString() throws IOException {
        return zzc(false);
    }

    public final void readStringList(List<String> list) throws IOException {
        zzb((List) list, false);
    }

    public final <T> T zzb(zziy<T> zziy, zzgl zzgl) throws IOException {
        zzy(2);
        return zzc((zziy) zziy, zzgl);
    }

    public final <T> T zzb(Class<T> cls, zzgl zzgl) throws IOException {
        zzy(2);
        return zzc(zzis.zzfc().zzg(cls), zzgl);
    }

    public final <T> void zzb(List<T> list, zziy<T> zziy, zzgl zzgl) throws IOException {
        if ((this.tag & 7) == 2) {
            int i;
            int i2 = this.tag;
            do {
                list.add(zzc((zziy) zziy, zzgl));
                if (!zzbf()) {
                    i = this.pos;
                } else {
                    return;
                }
            } while (zzbw() == i2);
            this.pos = i;
            return;
        }
        throw zzhh.zzed();
    }

    public final <K, V> void zzb(java.util.Map<K, V> r6, com.google.android.gms.internal.places.zzia<K, V> r7, com.google.android.gms.internal.places.zzgl r8) throws java.io.IOException {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/952562199.run(Unknown Source)
*/
        /*
        r5 = this;
        r0 = 2;
        r5.zzy(r0);
        r0 = r5.zzbw();
        r5.zzx(r0);
        r1 = r5.limit;
        r2 = r5.pos;
        r2 = r2 + r0;
        r5.limit = r2;
        r0 = r7.zzuu;	 Catch:{ all -> 0x005e }
        r2 = r7.zzss;	 Catch:{ all -> 0x005e }
    L_0x0016:
        r3 = r5.zzbg();	 Catch:{ all -> 0x005e }
        r4 = 2147483647; // 0x7fffffff float:NaN double:1.060997895E-314;
        if (r3 == r4) goto L_0x0058;
    L_0x001f:
        switch(r3) {
            case 1: goto L_0x0035;
            case 2: goto L_0x0027;
            default: goto L_0x0022;
        };
    L_0x0022:
        r3 = r5.zzbh();	 Catch:{ zzhi -> 0x0049 }
        goto L_0x003e;	 Catch:{ zzhi -> 0x0049 }
    L_0x0027:
        r3 = r7.zzuv;	 Catch:{ zzhi -> 0x0049 }
        r4 = r7.zzss;	 Catch:{ zzhi -> 0x0049 }
        r4 = r4.getClass();	 Catch:{ zzhi -> 0x0049 }
        r3 = r5.zzb(r3, r4, r8);	 Catch:{ zzhi -> 0x0049 }
        r2 = r3;	 Catch:{ zzhi -> 0x0049 }
        goto L_0x0016;	 Catch:{ zzhi -> 0x0049 }
    L_0x0035:
        r3 = r7.zzut;	 Catch:{ zzhi -> 0x0049 }
        r4 = 0;	 Catch:{ zzhi -> 0x0049 }
        r3 = r5.zzb(r3, r4, r4);	 Catch:{ zzhi -> 0x0049 }
        r0 = r3;	 Catch:{ zzhi -> 0x0049 }
        goto L_0x0016;	 Catch:{ zzhi -> 0x0049 }
    L_0x003e:
        if (r3 == 0) goto L_0x0041;	 Catch:{ zzhi -> 0x0049 }
    L_0x0040:
        goto L_0x0016;	 Catch:{ zzhi -> 0x0049 }
    L_0x0041:
        r3 = new com.google.android.gms.internal.places.zzhh;	 Catch:{ zzhi -> 0x0049 }
        r4 = "Unable to parse map entry.";	 Catch:{ zzhi -> 0x0049 }
        r3.<init>(r4);	 Catch:{ zzhi -> 0x0049 }
        throw r3;	 Catch:{ zzhi -> 0x0049 }
    L_0x0049:
        r3 = r5.zzbh();	 Catch:{ all -> 0x005e }
        if (r3 == 0) goto L_0x0050;	 Catch:{ all -> 0x005e }
    L_0x004f:
        goto L_0x0016;	 Catch:{ all -> 0x005e }
    L_0x0050:
        r6 = new com.google.android.gms.internal.places.zzhh;	 Catch:{ all -> 0x005e }
        r7 = "Unable to parse map entry.";	 Catch:{ all -> 0x005e }
        r6.<init>(r7);	 Catch:{ all -> 0x005e }
        throw r6;	 Catch:{ all -> 0x005e }
    L_0x0058:
        r6.put(r0, r2);	 Catch:{ all -> 0x005e }
        r5.limit = r1;
        return;
    L_0x005e:
        r6 = move-exception;
        r5.limit = r1;
        throw r6;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.places.zzfo.zzb(java.util.Map, com.google.android.gms.internal.places.zzia, com.google.android.gms.internal.places.zzgl):void");
    }

    public final int zzbg() throws IOException {
        if (zzbf()) {
            return Integer.MAX_VALUE;
        }
        this.tag = zzbw();
        return this.tag == this.zznq ? Integer.MAX_VALUE : this.tag >>> 3;
    }

    public final boolean zzbh() throws IOException {
        int i = 0;
        if (!zzbf()) {
            if (this.tag != this.zznq) {
                int i2 = this.tag & 7;
                if (i2 != 5) {
                    switch (i2) {
                        case 0:
                            if (this.limit - this.pos >= 10) {
                                byte[] bArr = this.buffer;
                                int i3 = this.pos;
                                int i4 = 0;
                                while (i4 < 10) {
                                    int i5 = i3 + 1;
                                    if (bArr[i3] >= (byte) 0) {
                                        this.pos = i5;
                                        return true;
                                    }
                                    i4++;
                                    i3 = i5;
                                }
                            }
                            while (i < 10) {
                                if (readByte() >= (byte) 0) {
                                    return true;
                                }
                                i++;
                            }
                            throw zzhh.zzeb();
                        case 1:
                            i2 = 8;
                            break;
                        case 2:
                            i2 = zzbw();
                            break;
                        case 3:
                            i2 = this.zznq;
                            this.zznq = ((this.tag >>> 3) << 3) | 4;
                            while (zzbg() != Integer.MAX_VALUE) {
                                if (!zzbh()) {
                                    if (this.tag != this.zznq) {
                                        this.zznq = i2;
                                        return true;
                                    }
                                    throw zzhh.zzef();
                                }
                            }
                            if (this.tag != this.zznq) {
                                throw zzhh.zzef();
                            }
                            this.zznq = i2;
                            return true;
                        default:
                            throw zzhh.zzed();
                    }
                    zzw(i2);
                    return true;
                }
                zzw(4);
                return true;
            }
        }
        return false;
    }

    public final long zzbi() throws IOException {
        zzy(0);
        return zzbx();
    }

    public final long zzbj() throws IOException {
        zzy(0);
        return zzbx();
    }

    public final int zzbk() throws IOException {
        zzy(0);
        return zzbw();
    }

    public final long zzbl() throws IOException {
        zzy(1);
        return zzca();
    }

    public final int zzbm() throws IOException {
        zzy(5);
        return zzbz();
    }

    public final boolean zzbn() throws IOException {
        zzy(0);
        return zzbw() != 0;
    }

    public final String zzbo() throws IOException {
        return zzc(true);
    }

    public final zzfr zzbp() throws IOException {
        zzy(2);
        int zzbw = zzbw();
        if (zzbw == 0) {
            return zzfr.zznt;
        }
        zzx(zzbw);
        zzfr zzd = this.zzno ? zzfr.zzd(this.buffer, this.pos, zzbw) : zzfr.zzc(this.buffer, this.pos, zzbw);
        this.pos += zzbw;
        return zzd;
    }

    public final int zzbq() throws IOException {
        zzy(0);
        return zzbw();
    }

    public final int zzbr() throws IOException {
        zzy(0);
        return zzbw();
    }

    public final int zzbs() throws IOException {
        zzy(5);
        return zzbz();
    }

    public final long zzbt() throws IOException {
        zzy(1);
        return zzca();
    }

    public final int zzbu() throws IOException {
        zzy(0);
        return zzga.zzan(zzbw());
    }

    public final long zzbv() throws IOException {
        zzy(0);
        return zzga.zzd(zzbx());
    }

    public final <T> T zzc(Class<T> cls, zzgl zzgl) throws IOException {
        zzy(3);
        return zze(zzis.zzfc().zzg(cls), zzgl);
    }

    public final <T> void zzc(List<T> list, zziy<T> zziy, zzgl zzgl) throws IOException {
        if ((this.tag & 7) == 3) {
            int i;
            int i2 = this.tag;
            do {
                list.add(zze(zziy, zzgl));
                if (!zzbf()) {
                    i = this.pos;
                } else {
                    return;
                }
            } while (zzbw() == i2);
            this.pos = i;
            return;
        }
        throw zzhh.zzed();
    }

    public final <T> T zzd(zziy<T> zziy, zzgl zzgl) throws IOException {
        zzy(3);
        return zze(zziy, zzgl);
    }

    public final void zze(List<Double> list) throws IOException {
        int zzbw;
        int i;
        if (list instanceof zzgi) {
            zzgi zzgi = (zzgi) list;
            switch (this.tag & 7) {
                case 1:
                    break;
                case 2:
                    zzbw = zzbw();
                    zzz(zzbw);
                    i = this.pos + zzbw;
                    while (this.pos < i) {
                        zzgi.zzd(Double.longBitsToDouble(zzcc()));
                    }
                    return;
                default:
                    throw zzhh.zzed();
            }
            do {
                zzgi.zzd(readDouble());
                if (!zzbf()) {
                    zzbw = this.pos;
                } else {
                    return;
                }
            } while (zzbw() == this.tag);
            this.pos = zzbw;
            return;
        }
        switch (this.tag & 7) {
            case 1:
                break;
            case 2:
                zzbw = zzbw();
                zzz(zzbw);
                i = this.pos + zzbw;
                while (this.pos < i) {
                    list.add(Double.valueOf(Double.longBitsToDouble(zzcc())));
                }
                return;
            default:
                throw zzhh.zzed();
        }
        do {
            list.add(Double.valueOf(readDouble()));
            if (!zzbf()) {
                zzbw = this.pos;
            } else {
                return;
            }
        } while (zzbw() == this.tag);
        this.pos = zzbw;
    }

    public final void zzf(List<Float> list) throws IOException {
        int i;
        int i2;
        if (list instanceof zzgw) {
            zzgw zzgw = (zzgw) list;
            i = this.tag & 7;
            if (i == 2) {
                i = zzbw();
                zzaa(i);
                i2 = this.pos + i;
                while (this.pos < i2) {
                    zzgw.zzf(Float.intBitsToFloat(zzcb()));
                }
                return;
            } else if (i == 5) {
                do {
                    zzgw.zzf(readFloat());
                    if (!zzbf()) {
                        i = this.pos;
                    } else {
                        return;
                    }
                } while (zzbw() == this.tag);
                this.pos = i;
                return;
            } else {
                throw zzhh.zzed();
            }
        }
        i = this.tag & 7;
        if (i == 2) {
            i = zzbw();
            zzaa(i);
            i2 = this.pos + i;
            while (this.pos < i2) {
                list.add(Float.valueOf(Float.intBitsToFloat(zzcb())));
            }
        } else if (i == 5) {
            do {
                list.add(Float.valueOf(readFloat()));
                if (!zzbf()) {
                    i = this.pos;
                } else {
                    return;
                }
            } while (zzbw() == this.tag);
            this.pos = i;
        } else {
            throw zzhh.zzed();
        }
    }

    public final void zzg(List<Long> list) throws IOException {
        int zzbw;
        if (list instanceof zzhv) {
            zzhv zzhv = (zzhv) list;
            int i = this.tag & 7;
            if (i == 0) {
                do {
                    zzhv.zzp(zzbi());
                    if (!zzbf()) {
                        i = this.pos;
                    } else {
                        return;
                    }
                } while (zzbw() == this.tag);
                this.pos = i;
                return;
            } else if (i == 2) {
                zzbw = this.pos + zzbw();
                while (this.pos < zzbw) {
                    zzhv.zzp(zzbx());
                }
                zzab(zzbw);
                return;
            } else {
                throw zzhh.zzed();
            }
        }
        int i2 = this.tag & 7;
        if (i2 == 0) {
            do {
                list.add(Long.valueOf(zzbi()));
                if (!zzbf()) {
                    i2 = this.pos;
                } else {
                    return;
                }
            } while (zzbw() == this.tag);
            this.pos = i2;
        } else if (i2 == 2) {
            zzbw = this.pos + zzbw();
            while (this.pos < zzbw) {
                list.add(Long.valueOf(zzbx()));
            }
            zzab(zzbw);
        } else {
            throw zzhh.zzed();
        }
    }

    public final void zzh(List<Long> list) throws IOException {
        if (list instanceof zzhv) {
            zzhv zzhv = (zzhv) list;
            int i = this.tag & 7;
            if (i == 0) {
                do {
                    zzhv.zzp(zzbj());
                    if (!zzbf()) {
                        i = this.pos;
                    } else {
                        return;
                    }
                } while (zzbw() == this.tag);
                this.pos = i;
                return;
            } else if (i == 2) {
                int zzbw;
                zzbw = this.pos + zzbw();
                while (this.pos < zzbw) {
                    zzhv.zzp(zzbx());
                }
                zzab(zzbw);
                return;
            } else {
                throw zzhh.zzed();
            }
        }
        int i2 = this.tag & 7;
        if (i2 == 0) {
            do {
                list.add(Long.valueOf(zzbj()));
                if (!zzbf()) {
                    i2 = this.pos;
                } else {
                    return;
                }
            } while (zzbw() == this.tag);
            this.pos = i2;
        } else if (i2 == 2) {
            zzbw = this.pos + zzbw();
            while (this.pos < zzbw) {
                list.add(Long.valueOf(zzbx()));
            }
            zzab(zzbw);
        } else {
            throw zzhh.zzed();
        }
    }

    public final void zzi(List<Integer> list) throws IOException {
        int zzbw;
        if (list instanceof zzha) {
            zzha zzha = (zzha) list;
            int i = this.tag & 7;
            if (i == 0) {
                do {
                    zzha.zzbe(zzbk());
                    if (!zzbf()) {
                        i = this.pos;
                    } else {
                        return;
                    }
                } while (zzbw() == this.tag);
                this.pos = i;
                return;
            } else if (i == 2) {
                zzbw = this.pos + zzbw();
                while (this.pos < zzbw) {
                    zzha.zzbe(zzbw());
                }
                zzab(zzbw);
                return;
            } else {
                throw zzhh.zzed();
            }
        }
        int i2 = this.tag & 7;
        if (i2 == 0) {
            do {
                list.add(Integer.valueOf(zzbk()));
                if (!zzbf()) {
                    i2 = this.pos;
                } else {
                    return;
                }
            } while (zzbw() == this.tag);
            this.pos = i2;
        } else if (i2 == 2) {
            zzbw = this.pos + zzbw();
            while (this.pos < zzbw) {
                list.add(Integer.valueOf(zzbw()));
            }
            zzab(zzbw);
        } else {
            throw zzhh.zzed();
        }
    }

    public final void zzj(List<Long> list) throws IOException {
        int zzbw;
        int i;
        if (list instanceof zzhv) {
            zzhv zzhv = (zzhv) list;
            switch (this.tag & 7) {
                case 1:
                    break;
                case 2:
                    zzbw = zzbw();
                    zzz(zzbw);
                    i = this.pos + zzbw;
                    while (this.pos < i) {
                        zzhv.zzp(zzcc());
                    }
                    return;
                default:
                    throw zzhh.zzed();
            }
            do {
                zzhv.zzp(zzbl());
                if (!zzbf()) {
                    zzbw = this.pos;
                } else {
                    return;
                }
            } while (zzbw() == this.tag);
            this.pos = zzbw;
            return;
        }
        switch (this.tag & 7) {
            case 1:
                break;
            case 2:
                zzbw = zzbw();
                zzz(zzbw);
                i = this.pos + zzbw;
                while (this.pos < i) {
                    list.add(Long.valueOf(zzcc()));
                }
                return;
            default:
                throw zzhh.zzed();
        }
        do {
            list.add(Long.valueOf(zzbl()));
            if (!zzbf()) {
                zzbw = this.pos;
            } else {
                return;
            }
        } while (zzbw() == this.tag);
        this.pos = zzbw;
    }

    public final void zzk(List<Integer> list) throws IOException {
        int i;
        int i2;
        if (list instanceof zzha) {
            zzha zzha = (zzha) list;
            i = this.tag & 7;
            if (i == 2) {
                i = zzbw();
                zzaa(i);
                i2 = this.pos + i;
                while (this.pos < i2) {
                    zzha.zzbe(zzcb());
                }
                return;
            } else if (i == 5) {
                do {
                    zzha.zzbe(zzbm());
                    if (!zzbf()) {
                        i = this.pos;
                    } else {
                        return;
                    }
                } while (zzbw() == this.tag);
                this.pos = i;
                return;
            } else {
                throw zzhh.zzed();
            }
        }
        i = this.tag & 7;
        if (i == 2) {
            i = zzbw();
            zzaa(i);
            i2 = this.pos + i;
            while (this.pos < i2) {
                list.add(Integer.valueOf(zzcb()));
            }
        } else if (i == 5) {
            do {
                list.add(Integer.valueOf(zzbm()));
                if (!zzbf()) {
                    i = this.pos;
                } else {
                    return;
                }
            } while (zzbw() == this.tag);
            this.pos = i;
        } else {
            throw zzhh.zzed();
        }
    }

    public final void zzl(List<Boolean> list) throws IOException {
        if (list instanceof zzfp) {
            zzfp zzfp = (zzfp) list;
            int i = this.tag & 7;
            if (i == 0) {
                do {
                    zzfp.addBoolean(zzbn());
                    if (!zzbf()) {
                        i = this.pos;
                    } else {
                        return;
                    }
                } while (zzbw() == this.tag);
                this.pos = i;
                return;
            } else if (i == 2) {
                int zzbw;
                zzbw = this.pos + zzbw();
                while (this.pos < zzbw) {
                    zzfp.addBoolean(zzbw() != 0);
                }
                zzab(zzbw);
                return;
            } else {
                throw zzhh.zzed();
            }
        }
        int i2 = this.tag & 7;
        if (i2 == 0) {
            do {
                list.add(Boolean.valueOf(zzbn()));
                if (!zzbf()) {
                    i2 = this.pos;
                } else {
                    return;
                }
            } while (zzbw() == this.tag);
            this.pos = i2;
        } else if (i2 == 2) {
            zzbw = this.pos + zzbw();
            while (this.pos < zzbw) {
                list.add(Boolean.valueOf(zzbw() != 0));
            }
            zzab(zzbw);
        } else {
            throw zzhh.zzed();
        }
    }

    public final void zzm(List<String> list) throws IOException {
        zzb((List) list, true);
    }

    public final void zzn(List<zzfr> list) throws IOException {
        if ((this.tag & 7) == 2) {
            int i;
            do {
                list.add(zzbp());
                if (!zzbf()) {
                    i = this.pos;
                } else {
                    return;
                }
            } while (zzbw() == this.tag);
            this.pos = i;
            return;
        }
        throw zzhh.zzed();
    }

    public final void zzo(List<Integer> list) throws IOException {
        int zzbw;
        if (list instanceof zzha) {
            zzha zzha = (zzha) list;
            int i = this.tag & 7;
            if (i == 0) {
                do {
                    zzha.zzbe(zzbq());
                    if (!zzbf()) {
                        i = this.pos;
                    } else {
                        return;
                    }
                } while (zzbw() == this.tag);
                this.pos = i;
                return;
            } else if (i == 2) {
                zzbw = this.pos + zzbw();
                while (this.pos < zzbw) {
                    zzha.zzbe(zzbw());
                }
                return;
            } else {
                throw zzhh.zzed();
            }
        }
        int i2 = this.tag & 7;
        if (i2 == 0) {
            do {
                list.add(Integer.valueOf(zzbq()));
                if (!zzbf()) {
                    i2 = this.pos;
                } else {
                    return;
                }
            } while (zzbw() == this.tag);
            this.pos = i2;
        } else if (i2 == 2) {
            zzbw = this.pos + zzbw();
            while (this.pos < zzbw) {
                list.add(Integer.valueOf(zzbw()));
            }
        } else {
            throw zzhh.zzed();
        }
    }

    public final void zzp(List<Integer> list) throws IOException {
        int zzbw;
        if (list instanceof zzha) {
            zzha zzha = (zzha) list;
            int i = this.tag & 7;
            if (i == 0) {
                do {
                    zzha.zzbe(zzbr());
                    if (!zzbf()) {
                        i = this.pos;
                    } else {
                        return;
                    }
                } while (zzbw() == this.tag);
                this.pos = i;
                return;
            } else if (i == 2) {
                zzbw = this.pos + zzbw();
                while (this.pos < zzbw) {
                    zzha.zzbe(zzbw());
                }
                return;
            } else {
                throw zzhh.zzed();
            }
        }
        int i2 = this.tag & 7;
        if (i2 == 0) {
            do {
                list.add(Integer.valueOf(zzbr()));
                if (!zzbf()) {
                    i2 = this.pos;
                } else {
                    return;
                }
            } while (zzbw() == this.tag);
            this.pos = i2;
        } else if (i2 == 2) {
            zzbw = this.pos + zzbw();
            while (this.pos < zzbw) {
                list.add(Integer.valueOf(zzbw()));
            }
        } else {
            throw zzhh.zzed();
        }
    }

    public final void zzq(List<Integer> list) throws IOException {
        int i;
        int i2;
        if (list instanceof zzha) {
            zzha zzha = (zzha) list;
            i = this.tag & 7;
            if (i == 2) {
                i = zzbw();
                zzaa(i);
                i2 = this.pos + i;
                while (this.pos < i2) {
                    zzha.zzbe(zzcb());
                }
                return;
            } else if (i == 5) {
                do {
                    zzha.zzbe(zzbs());
                    if (!zzbf()) {
                        i = this.pos;
                    } else {
                        return;
                    }
                } while (zzbw() == this.tag);
                this.pos = i;
                return;
            } else {
                throw zzhh.zzed();
            }
        }
        i = this.tag & 7;
        if (i == 2) {
            i = zzbw();
            zzaa(i);
            i2 = this.pos + i;
            while (this.pos < i2) {
                list.add(Integer.valueOf(zzcb()));
            }
        } else if (i == 5) {
            do {
                list.add(Integer.valueOf(zzbs()));
                if (!zzbf()) {
                    i = this.pos;
                } else {
                    return;
                }
            } while (zzbw() == this.tag);
            this.pos = i;
        } else {
            throw zzhh.zzed();
        }
    }

    public final void zzr(List<Long> list) throws IOException {
        int zzbw;
        int i;
        if (list instanceof zzhv) {
            zzhv zzhv = (zzhv) list;
            switch (this.tag & 7) {
                case 1:
                    break;
                case 2:
                    zzbw = zzbw();
                    zzz(zzbw);
                    i = this.pos + zzbw;
                    while (this.pos < i) {
                        zzhv.zzp(zzcc());
                    }
                    return;
                default:
                    throw zzhh.zzed();
            }
            do {
                zzhv.zzp(zzbt());
                if (!zzbf()) {
                    zzbw = this.pos;
                } else {
                    return;
                }
            } while (zzbw() == this.tag);
            this.pos = zzbw;
            return;
        }
        switch (this.tag & 7) {
            case 1:
                break;
            case 2:
                zzbw = zzbw();
                zzz(zzbw);
                i = this.pos + zzbw;
                while (this.pos < i) {
                    list.add(Long.valueOf(zzcc()));
                }
                return;
            default:
                throw zzhh.zzed();
        }
        do {
            list.add(Long.valueOf(zzbt()));
            if (!zzbf()) {
                zzbw = this.pos;
            } else {
                return;
            }
        } while (zzbw() == this.tag);
        this.pos = zzbw;
    }

    public final void zzs(List<Integer> list) throws IOException {
        int zzbw;
        if (list instanceof zzha) {
            zzha zzha = (zzha) list;
            int i = this.tag & 7;
            if (i == 0) {
                do {
                    zzha.zzbe(zzbu());
                    if (!zzbf()) {
                        i = this.pos;
                    } else {
                        return;
                    }
                } while (zzbw() == this.tag);
                this.pos = i;
                return;
            } else if (i == 2) {
                zzbw = this.pos + zzbw();
                while (this.pos < zzbw) {
                    zzha.zzbe(zzga.zzan(zzbw()));
                }
                return;
            } else {
                throw zzhh.zzed();
            }
        }
        int i2 = this.tag & 7;
        if (i2 == 0) {
            do {
                list.add(Integer.valueOf(zzbu()));
                if (!zzbf()) {
                    i2 = this.pos;
                } else {
                    return;
                }
            } while (zzbw() == this.tag);
            this.pos = i2;
        } else if (i2 == 2) {
            zzbw = this.pos + zzbw();
            while (this.pos < zzbw) {
                list.add(Integer.valueOf(zzga.zzan(zzbw())));
            }
        } else {
            throw zzhh.zzed();
        }
    }

    public final void zzt(List<Long> list) throws IOException {
        int zzbw;
        if (list instanceof zzhv) {
            zzhv zzhv = (zzhv) list;
            int i = this.tag & 7;
            if (i == 0) {
                do {
                    zzhv.zzp(zzbv());
                    if (!zzbf()) {
                        i = this.pos;
                    } else {
                        return;
                    }
                } while (zzbw() == this.tag);
                this.pos = i;
                return;
            } else if (i == 2) {
                zzbw = this.pos + zzbw();
                while (this.pos < zzbw) {
                    zzhv.zzp(zzga.zzd(zzbx()));
                }
                return;
            } else {
                throw zzhh.zzed();
            }
        }
        int i2 = this.tag & 7;
        if (i2 == 0) {
            do {
                list.add(Long.valueOf(zzbv()));
                if (!zzbf()) {
                    i2 = this.pos;
                } else {
                    return;
                }
            } while (zzbw() == this.tag);
            this.pos = i2;
        } else if (i2 == 2) {
            zzbw = this.pos + zzbw();
            while (this.pos < zzbw) {
                list.add(Long.valueOf(zzga.zzd(zzbx())));
            }
        } else {
            throw zzhh.zzed();
        }
    }
}
