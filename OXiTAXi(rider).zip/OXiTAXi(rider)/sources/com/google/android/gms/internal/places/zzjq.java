package com.google.android.gms.internal.places;

import java.io.IOException;

abstract class zzjq<T, B> {
    zzjq() {
    }

    abstract void zzb(B b, int i, long j);

    abstract void zzb(B b, int i, zzfr zzfr);

    abstract void zzb(B b, int i, T t);

    abstract void zzb(T t, zzkk zzkk) throws IOException;

    abstract boolean zzb(zzix zzix);

    final boolean zzb(B b, zzix zzix) throws IOException {
        int tag = zzix.getTag();
        int i = tag >>> 3;
        switch (tag & 7) {
            case 0:
                zzb((Object) b, i, zzix.zzbj());
                return true;
            case 1:
                zzc(b, i, zzix.zzbl());
                return true;
            case 2:
                zzb((Object) b, i, zzix.zzbp());
                return true;
            case 3:
                Object zzgo = zzgo();
                int i2 = (i << 3) | 4;
                while (zzix.zzbg() != Integer.MAX_VALUE) {
                    if (!zzb(zzgo, zzix)) {
                        if (i2 != zzix.getTag()) {
                            zzb((Object) b, i, zzk(zzgo));
                            return true;
                        }
                        throw zzhh.zzec();
                    }
                }
                if (i2 != zzix.getTag()) {
                    throw zzhh.zzec();
                }
                zzb((Object) b, i, zzk(zzgo));
                return true;
            case 4:
                return false;
            case 5:
                zzd(b, i, zzix.zzbm());
                return true;
            default:
                throw zzhh.zzed();
        }
    }

    abstract void zzc(B b, int i, long j);

    abstract void zzd(Object obj);

    abstract void zzd(B b, int i, int i2);

    abstract void zzd(T t, zzkk zzkk) throws IOException;

    abstract void zzf(Object obj, T t);

    abstract void zzg(Object obj, B b);

    abstract B zzgo();

    abstract T zzh(T t, T t2);

    abstract T zzk(B b);

    abstract int zzn(T t);

    abstract T zzq(Object obj);

    abstract B zzr(Object obj);

    abstract int zzs(T t);
}
