package com.google.android.gms.internal.places;

import com.google.android.gms.internal.places.zzgz.zze;
import com.google.android.gms.internal.places.zzgz.zzg;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Map.Entry;

final class zzgn extends zzgm<zzf> {
    zzgn() {
    }

    final int zzb(Entry<?, ?> entry) {
        return ((zzf) entry.getKey()).number;
    }

    final zzgq<zzf> zzb(Object obj) {
        return ((zze) obj).zzsm;
    }

    final Object zzb(zzgl zzgl, zzih zzih, int i) {
        return zzgl.zzb(zzih, i);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    final <UT, UB> UB zzb(com.google.android.gms.internal.places.zzix r4, java.lang.Object r5, com.google.android.gms.internal.places.zzgl r6, com.google.android.gms.internal.places.zzgq<com.google.android.gms.internal.places.zzgz.zzf> r7, UB r8, com.google.android.gms.internal.places.zzjq<UT, UB> r9) throws java.io.IOException {
        /*
        r3 = this;
        r5 = (com.google.android.gms.internal.places.zzgz.zzg) r5;
        r0 = r5.zzsu;
        r0 = r0.number;
        r1 = r5.zzsu;
        r1 = r1.zzso;
        r2 = com.google.android.gms.internal.places.zzke.ENUM;
        if (r1 != r2) goto L_0x0027;
    L_0x000e:
        r4 = r4.zzbk();
        r6 = r5.zzsu;
        r6 = r6.zzsn;
        r6 = r6.zzi(r4);
        if (r6 != 0) goto L_0x0021;
    L_0x001c:
        r4 = com.google.android.gms.internal.places.zzja.zzb(r0, r4, r8, r9);
        return r4;
    L_0x0021:
        r4 = java.lang.Integer.valueOf(r4);
        goto L_0x00b3;
    L_0x0027:
        r9 = com.google.android.gms.internal.places.zzgo.zznn;
        r0 = r5.zzsu;
        r0 = r0.zzso;
        r0 = r0.ordinal();
        r9 = r9[r0];
        switch(r9) {
            case 1: goto L_0x00ab;
            case 2: goto L_0x00a2;
            case 3: goto L_0x0099;
            case 4: goto L_0x0094;
            case 5: goto L_0x008f;
            case 6: goto L_0x008a;
            case 7: goto L_0x0085;
            case 8: goto L_0x007c;
            case 9: goto L_0x0077;
            case 10: goto L_0x0072;
            case 11: goto L_0x006d;
            case 12: goto L_0x0068;
            case 13: goto L_0x0063;
            case 14: goto L_0x005b;
            case 15: goto L_0x0056;
            case 16: goto L_0x0051;
            case 17: goto L_0x0045;
            case 18: goto L_0x0039;
            default: goto L_0x0036;
        };
    L_0x0036:
        r4 = 0;
        goto L_0x00b3;
    L_0x0039:
        r9 = r5.zzst;
        r9 = r9.getClass();
        r4 = r4.zzb(r9, r6);
        goto L_0x00b3;
    L_0x0045:
        r9 = r5.zzst;
        r9 = r9.getClass();
        r4 = r4.zzc(r9, r6);
        goto L_0x00b3;
    L_0x0051:
        r4 = r4.readString();
        goto L_0x00b3;
    L_0x0056:
        r4 = r4.zzbp();
        goto L_0x00b3;
    L_0x005b:
        r4 = new java.lang.IllegalStateException;
        r5 = "Shouldn't reach here.";
        r4.<init>(r5);
        throw r4;
    L_0x0063:
        r0 = r4.zzbv();
        goto L_0x009d;
    L_0x0068:
        r4 = r4.zzbu();
        goto L_0x0021;
    L_0x006d:
        r0 = r4.zzbt();
        goto L_0x009d;
    L_0x0072:
        r4 = r4.zzbs();
        goto L_0x0021;
    L_0x0077:
        r4 = r4.zzbq();
        goto L_0x0021;
    L_0x007c:
        r4 = r4.zzbn();
        r4 = java.lang.Boolean.valueOf(r4);
        goto L_0x00b3;
    L_0x0085:
        r4 = r4.zzbm();
        goto L_0x0021;
    L_0x008a:
        r0 = r4.zzbl();
        goto L_0x009d;
    L_0x008f:
        r4 = r4.zzbk();
        goto L_0x0021;
    L_0x0094:
        r0 = r4.zzbi();
        goto L_0x009d;
    L_0x0099:
        r0 = r4.zzbj();
    L_0x009d:
        r4 = java.lang.Long.valueOf(r0);
        goto L_0x00b3;
    L_0x00a2:
        r4 = r4.readFloat();
        r4 = java.lang.Float.valueOf(r4);
        goto L_0x00b3;
    L_0x00ab:
        r0 = r4.readDouble();
        r4 = java.lang.Double.valueOf(r0);
    L_0x00b3:
        r6 = com.google.android.gms.internal.places.zzgo.zznn;
        r9 = r5.zzsu;
        r9 = r9.zzso;
        r9 = r9.ordinal();
        r6 = r6[r9];
        switch(r6) {
            case 17: goto L_0x00c3;
            case 18: goto L_0x00c3;
            default: goto L_0x00c2;
        };
    L_0x00c2:
        goto L_0x00cf;
    L_0x00c3:
        r6 = r5.zzsu;
        r6 = r7.zzb(r6);
        if (r6 == 0) goto L_0x00cf;
    L_0x00cb:
        r4 = com.google.android.gms.internal.places.zzhb.zzb(r6, r4);
    L_0x00cf:
        r5 = r5.zzsu;
        r7.zzb(r5, r4);
        return r8;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.places.zzgn.zzb(com.google.android.gms.internal.places.zzix, java.lang.Object, com.google.android.gms.internal.places.zzgl, com.google.android.gms.internal.places.zzgq, java.lang.Object, com.google.android.gms.internal.places.zzjq):UB");
    }

    final void zzb(zzfr zzfr, Object obj, zzgl zzgl, zzgq<zzf> zzgq) throws IOException {
        byte[] bArr;
        zzg zzg = (zzg) obj;
        Object zzdw = zzg.zzst.zzdr().zzdw();
        int size = zzfr.size();
        if (size == 0) {
            bArr = zzhb.zztl;
        } else {
            byte[] bArr2 = new byte[size];
            zzfr.zzb(bArr2, 0, 0, size);
            bArr = bArr2;
        }
        ByteBuffer wrap = ByteBuffer.wrap(bArr);
        if (wrap.hasArray()) {
            zzix zzfo = new zzfo(wrap, true);
            zzis.zzfc().zzp(zzdw).zzb(zzdw, zzfo, zzgl);
            zzgq.zzb(zzg.zzsu, zzdw);
            if (zzfo.zzbg() != Integer.MAX_VALUE) {
                throw zzhh.zzec();
            }
            return;
        }
        throw new IllegalArgumentException("Direct buffers not yet supported");
    }

    final void zzb(zzix zzix, Object obj, zzgl zzgl, zzgq<zzf> zzgq) throws IOException {
        zzg zzg = (zzg) obj;
        zzgq.zzb(zzg.zzsu, zzix.zzb(zzg.zzst.getClass(), zzgl));
    }

    final void zzb(zzkk zzkk, Entry<?, ?> entry) throws IOException {
        zzf zzf = (zzf) entry.getKey();
        switch (zzgo.zznn[zzf.zzso.ordinal()]) {
            case 1:
                zzkk.zzb(zzf.number, ((Double) entry.getValue()).doubleValue());
                break;
            case 2:
                zzkk.zzc(zzf.number, ((Float) entry.getValue()).floatValue());
                return;
            case 3:
                zzkk.zzj(zzf.number, ((Long) entry.getValue()).longValue());
                return;
            case 4:
                zzkk.zzb(zzf.number, ((Long) entry.getValue()).longValue());
                return;
            case 5:
                zzkk.zze(zzf.number, ((Integer) entry.getValue()).intValue());
                return;
            case 6:
                zzkk.zzd(zzf.number, ((Long) entry.getValue()).longValue());
                return;
            case 7:
                zzkk.zzh(zzf.number, ((Integer) entry.getValue()).intValue());
                return;
            case 8:
                zzkk.zzc(zzf.number, ((Boolean) entry.getValue()).booleanValue());
                return;
            case 9:
                zzkk.zzf(zzf.number, ((Integer) entry.getValue()).intValue());
                return;
            case 10:
                zzkk.zzo(zzf.number, ((Integer) entry.getValue()).intValue());
                return;
            case 11:
                zzkk.zzk(zzf.number, ((Long) entry.getValue()).longValue());
                return;
            case 12:
                zzkk.zzg(zzf.number, ((Integer) entry.getValue()).intValue());
                return;
            case 13:
                zzkk.zzc(zzf.number, ((Long) entry.getValue()).longValue());
                return;
            case 14:
                zzkk.zze(zzf.number, ((Integer) entry.getValue()).intValue());
                return;
            case 15:
                zzkk.zzb(zzf.number, (zzfr) entry.getValue());
                return;
            case 16:
                zzkk.zzb(zzf.number, (String) entry.getValue());
                return;
            case 17:
                zzkk.zzc(zzf.number, entry.getValue(), zzis.zzfc().zzg(entry.getValue().getClass()));
                return;
            case 18:
                zzkk.zzb(zzf.number, entry.getValue(), zzis.zzfc().zzg(entry.getValue().getClass()));
                break;
            default:
                break;
        }
    }

    final void zzb(Object obj, zzgq<zzf> zzgq) {
        ((zze) obj).zzsm = zzgq;
    }

    final zzgq<zzf> zzc(Object obj) {
        zzgq<zzf> zzb = zzb(obj);
        if (!zzb.isImmutable()) {
            return zzb;
        }
        zzgq zzgq = (zzgq) zzb.clone();
        zzb(obj, zzgq);
        return zzgq;
    }

    final void zzd(Object obj) {
        zzb(obj).zzbb();
    }

    final boolean zzf(zzih zzih) {
        return zzih instanceof zze;
    }
}
