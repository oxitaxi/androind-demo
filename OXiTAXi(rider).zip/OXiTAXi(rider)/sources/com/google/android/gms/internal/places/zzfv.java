package com.google.android.gms.internal.places;

interface zzfv {
    byte[] zze(byte[] bArr, int i, int i2);
}
