package com.google.android.gms.internal.places;

public final class zzhi extends zzhh {
    public zzhi(String str) {
        super(str);
    }
}
