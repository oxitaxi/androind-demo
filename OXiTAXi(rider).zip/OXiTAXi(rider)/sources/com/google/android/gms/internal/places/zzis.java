package com.google.android.gms.internal.places;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

final class zzis {
    private static final zzis zzvu = new zzis();
    private final zziz zzvv;
    private final ConcurrentMap<Class<?>, zziy<?>> zzvw = new ConcurrentHashMap();

    private zzis() {
        String[] strArr = new String[]{"com.google.protobuf.AndroidProto3SchemaFactory"};
        zziz zziz = null;
        for (int i = 0; i <= 0; i++) {
            zziz = zzp(strArr[0]);
            if (zziz != null) {
                break;
            }
        }
        if (zziz == null) {
            zziz = new zzhw();
        }
        this.zzvv = zziz;
    }

    public static zzis zzfc() {
        return zzvu;
    }

    private static com.google.android.gms.internal.places.zziz zzp(java.lang.String r2) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/952562199.run(Unknown Source)
*/
        /*
        r2 = java.lang.Class.forName(r2);	 Catch:{ Throwable -> 0x0014 }
        r0 = 0;	 Catch:{ Throwable -> 0x0014 }
        r1 = new java.lang.Class[r0];	 Catch:{ Throwable -> 0x0014 }
        r2 = r2.getConstructor(r1);	 Catch:{ Throwable -> 0x0014 }
        r0 = new java.lang.Object[r0];	 Catch:{ Throwable -> 0x0014 }
        r2 = r2.newInstance(r0);	 Catch:{ Throwable -> 0x0014 }
        r2 = (com.google.android.gms.internal.places.zziz) r2;	 Catch:{ Throwable -> 0x0014 }
        return r2;
    L_0x0014:
        r2 = 0;
        return r2;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.places.zzis.zzp(java.lang.String):com.google.android.gms.internal.places.zziz");
    }

    public final <T> zziy<T> zzg(Class<T> cls) {
        zzhb.zzb((Object) cls, "messageType");
        zziy<T> zziy = (zziy) this.zzvw.get(cls);
        if (zziy != null) {
            return zziy;
        }
        Object zzf = this.zzvv.zzf(cls);
        zzhb.zzb((Object) cls, "messageType");
        zzhb.zzb(zzf, "schema");
        zziy<T> zziy2 = (zziy) this.zzvw.putIfAbsent(cls, zzf);
        return zziy2 != null ? zziy2 : zzf;
    }

    public final <T> zziy<T> zzp(T t) {
        return zzg(t.getClass());
    }
}
