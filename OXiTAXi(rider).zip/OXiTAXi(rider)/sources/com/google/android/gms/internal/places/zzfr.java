package com.google.android.gms.internal.places;

import java.io.IOException;
import java.io.Serializable;
import java.nio.charset.Charset;
import java.util.Iterator;

public abstract class zzfr implements Serializable, Iterable<Byte> {
    public static final zzfr zznt = new zzfy(zzhb.zztl);
    private static final zzfv zznu = (zzfl.zzbd() ? new zzfz() : new zzft());
    private int zznv = 0;

    zzfr() {
    }

    static zzfw zzag(int i) {
        return new zzfw(i);
    }

    static int zzc(int i, int i2, int i3) {
        int i4 = i2 - i;
        if ((((i | i2) | i4) | (i3 - i2)) >= 0) {
            return i4;
        }
        if (i < 0) {
            StringBuilder stringBuilder = new StringBuilder(32);
            stringBuilder.append("Beginning index: ");
            stringBuilder.append(i);
            stringBuilder.append(" < 0");
            throw new IndexOutOfBoundsException(stringBuilder.toString());
        } else if (i2 < i) {
            r1 = new StringBuilder(66);
            r1.append("Beginning index larger than ending index: ");
            r1.append(i);
            r1.append(", ");
            r1.append(i2);
            throw new IndexOutOfBoundsException(r1.toString());
        } else {
            r1 = new StringBuilder(37);
            r1.append("End index: ");
            r1.append(i2);
            r1.append(" >= ");
            r1.append(i3);
            throw new IndexOutOfBoundsException(r1.toString());
        }
    }

    static zzfr zzc(byte[] bArr) {
        return new zzfy(bArr);
    }

    public static zzfr zzc(byte[] bArr, int i, int i2) {
        return new zzfy(zznu.zze(bArr, i, i2));
    }

    static zzfr zzd(byte[] bArr, int i, int i2) {
        return new zzfu(bArr, i, i2);
    }

    public static zzfr zzj(String str) {
        return new zzfy(str.getBytes(zzhb.UTF_8));
    }

    public abstract boolean equals(Object obj);

    public final int hashCode() {
        int i = this.zznv;
        if (i == 0) {
            i = size();
            i = zzb(i, 0, i);
            if (i == 0) {
                i = 1;
            }
            this.zznv = i;
        }
        return i;
    }

    public /* synthetic */ Iterator iterator() {
        return new zzfs(this);
    }

    public abstract int size();

    public final String toString() {
        return String.format("<ByteString@%s size=%d>", new Object[]{Integer.toHexString(System.identityHashCode(this)), Integer.valueOf(size())});
    }

    public abstract byte zzaf(int i);

    protected abstract int zzb(int i, int i2, int i3);

    protected abstract String zzb(Charset charset);

    abstract void zzb(zzfq zzfq) throws IOException;

    protected abstract void zzb(byte[] bArr, int i, int i2, int i3);

    public abstract zzfr zzc(int i, int i2);

    public final String zzcd() {
        return size() == 0 ? "" : zzb(zzhb.UTF_8);
    }

    public abstract boolean zzce();

    protected final int zzcf() {
        return this.zznv;
    }
}
