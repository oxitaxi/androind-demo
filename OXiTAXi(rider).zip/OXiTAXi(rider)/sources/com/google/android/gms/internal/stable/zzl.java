package com.google.android.gms.internal.stable;

abstract class zzl {
    private static final Throwable[] zzahi = new Throwable[0];

    zzl() {
    }

    public abstract void zza(Throwable th, Throwable th2);
}
