package com.google.android.gms.internal.places;

import java.util.List;

abstract class zzhr {
    private static final zzhr zzul = new zzht();
    private static final zzhr zzum = new zzhu();

    private zzhr() {
    }

    static zzhr zzem() {
        return zzul;
    }

    static zzhr zzen() {
        return zzum;
    }

    abstract <L> List<L> zzb(Object obj, long j);

    abstract <L> void zzb(Object obj, Object obj2, long j);

    abstract void zzc(Object obj, long j);
}
