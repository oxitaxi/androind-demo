package com.google.android.gms.internal.places;

import java.io.IOException;

public abstract class zzko<M extends zzko<M>> extends zzku {
    protected zzkq zzaaf;

    public /* synthetic */ Object clone() throws CloneNotSupportedException {
        zzko zzko = (zzko) super.zzhe();
        zzks.zzb(this, zzko);
        return zzko;
    }

    protected int zzal() {
        if (this.zzaaf == null) {
            return 0;
        }
        int i = 0;
        for (int i2 = 0; i2 < this.zzaaf.size(); i2++) {
            i += this.zzaaf.zzbv(i2).zzal();
        }
        return i;
    }

    public void zzb(zzkm zzkm) throws IOException {
        if (this.zzaaf != null) {
            for (int i = 0; i < this.zzaaf.size(); i++) {
                this.zzaaf.zzbv(i).zzb(zzkm);
            }
        }
    }

    protected final boolean zzb(zzkl zzkl, int i) throws IOException {
        int position = zzkl.getPosition();
        if (!zzkl.zzai(i)) {
            return false;
        }
        int i2 = i >>> 3;
        zzkw zzkw = new zzkw(i, zzkl.zzt(position, zzkl.getPosition() - position));
        zzkr zzkr = null;
        if (this.zzaaf == null) {
            this.zzaaf = new zzkq();
        } else {
            zzkr = this.zzaaf.zzbu(i2);
        }
        if (zzkr == null) {
            zzkr = new zzkr();
            this.zzaaf.zzb(i2, zzkr);
        }
        zzkr.zzb(zzkw);
        return true;
    }

    public final /* synthetic */ zzku zzhe() throws CloneNotSupportedException {
        return (zzko) clone();
    }
}
