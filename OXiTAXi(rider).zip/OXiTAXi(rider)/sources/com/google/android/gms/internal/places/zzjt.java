package com.google.android.gms.internal.places;

import java.util.AbstractList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.RandomAccess;

public final class zzjt extends AbstractList<String> implements zzhq, RandomAccess {
    private final zzhq zzxt;

    public zzjt(zzhq zzhq) {
        this.zzxt = zzhq;
    }

    public final /* synthetic */ Object get(int i) {
        return (String) this.zzxt.get(i);
    }

    public final Object getRaw(int i) {
        return this.zzxt.getRaw(i);
    }

    public final Iterator<String> iterator() {
        return new zzjv(this);
    }

    public final ListIterator<String> listIterator(int i) {
        return new zzju(this, i);
    }

    public final int size() {
        return this.zzxt.size();
    }

    public final void zzd(zzfr zzfr) {
        throw new UnsupportedOperationException();
    }

    public final List<?> zzek() {
        return this.zzxt.zzek();
    }

    public final zzhq zzel() {
        return this;
    }
}
