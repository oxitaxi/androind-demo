package com.google.android.gms.internal.places;

import java.util.Iterator;

final class zzjh implements Iterable<Object> {
    zzjh() {
    }

    public final Iterator<Object> iterator() {
        return zzjf.zzxl;
    }
}
