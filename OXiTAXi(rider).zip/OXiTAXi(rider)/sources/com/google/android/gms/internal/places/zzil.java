package com.google.android.gms.internal.places;

import com.google.android.gms.common.util.CrashUtils.ErrorDialogData;
import com.google.android.gms.internal.places.zzgz.zzh;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import sun.misc.Unsafe;

final class zzil<T> implements zziy<T> {
    private static final Unsafe zzuz = zzjw.zzgu();
    private final int[] zzva;
    private final Object[] zzvb;
    private final int zzvc;
    private final int zzvd;
    private final int zzve;
    private final zzih zzvf;
    private final boolean zzvg;
    private final boolean zzvh;
    private final boolean zzvi;
    private final boolean zzvj;
    private final int[] zzvk;
    private final int[] zzvl;
    private final int[] zzvm;
    private final zzio zzvn;
    private final zzhr zzvo;
    private final zzjq<?, ?> zzvp;
    private final zzgm<?> zzvq;
    private final zzic zzvr;

    private zzil(int[] iArr, Object[] objArr, int i, int i2, int i3, zzih zzih, boolean z, boolean z2, int[] iArr2, int[] iArr3, int[] iArr4, zzio zzio, zzhr zzhr, zzjq<?, ?> zzjq, zzgm<?> zzgm, zzic zzic) {
        zzih zzih2 = zzih;
        zzgm<?> zzgm2 = zzgm;
        this.zzva = iArr;
        this.zzvb = objArr;
        this.zzvc = i;
        this.zzvd = i2;
        this.zzve = i3;
        this.zzvh = zzih2 instanceof zzgz;
        this.zzvi = z;
        boolean z3 = zzgm2 != null && zzgm2.zzf(zzih);
        r0.zzvg = z3;
        r0.zzvj = false;
        r0.zzvk = iArr2;
        r0.zzvl = iArr3;
        r0.zzvm = iArr4;
        r0.zzvn = zzio;
        r0.zzvo = zzhr;
        r0.zzvp = zzjq;
        r0.zzvq = zzgm2;
        r0.zzvf = zzih2;
        r0.zzvr = zzic;
    }

    private static <UT, UB> int zzb(zzjq<UT, UB> zzjq, T t) {
        return zzjq.zzn(zzjq.zzq(t));
    }

    static <T> zzil<T> zzb(Class<T> cls, zzif zzif, zzio zzio, zzhr zzhr, zzjq<?, ?> zzjq, zzgm<?> zzgm, zzic zzic) {
        zzif zzif2 = zzif;
        if (zzif2 instanceof zziu) {
            int i;
            int i2;
            int i3;
            int zzfg;
            zziu zziu = (zziu) zzif2;
            boolean z = zziu.zzev() == zzh.zzte;
            if (zziu.getFieldCount() == 0) {
                i = 0;
                i2 = 0;
                i3 = 0;
            } else {
                int zzff = zziu.zzff();
                zzfg = zziu.zzfg();
                i = zziu.zzfk();
                i2 = zzff;
                i3 = zzfg;
            }
            int[] iArr = new int[(i << 2)];
            Object[] objArr = new Object[(i << 1)];
            int[] iArr2 = zziu.zzfh() > 0 ? new int[zziu.zzfh()] : null;
            int[] iArr3 = zziu.zzfi() > 0 ? new int[zziu.zzfi()] : null;
            zziv zzfe = zziu.zzfe();
            if (zzfe.next()) {
                zzfg = zzfe.zzbg();
                i = 0;
                int i4 = 0;
                int i5 = 0;
                while (true) {
                    int zzb;
                    if (zzfg >= zziu.zzfl() || i >= ((zzfg - i2) << 2)) {
                        int zzfv;
                        int i6;
                        if (zzfe.zzfp()) {
                            zzfg = (int) zzjw.zzb(zzfe.zzfq());
                            zzb = (int) zzjw.zzb(zzfe.zzfr());
                        } else {
                            zzfg = (int) zzjw.zzb(zzfe.zzfs());
                            if (zzfe.zzft()) {
                                zzb = (int) zzjw.zzb(zzfe.zzfu());
                                zzfv = zzfe.zzfv();
                                iArr[i] = zzfe.zzbg();
                                i6 = i + 1;
                                iArr[i6] = (((zzfe.zzfx() ? ErrorDialogData.DYNAMITE_CRASH : 0) | (zzfe.zzfw() ? ErrorDialogData.BINDER_CRASH : 0)) | (zzfe.zzfn() << 20)) | zzfg;
                                iArr[i + 2] = zzb | (zzfv << 20);
                                if (zzfe.zzga() != null) {
                                    zzfg = (i / 4) << 1;
                                    objArr[zzfg] = zzfe.zzga();
                                    if (zzfe.zzfy() != null) {
                                        objArr[zzfg + 1] = zzfe.zzfy();
                                    } else if (zzfe.zzfz() != null) {
                                        objArr[zzfg + 1] = zzfe.zzfz();
                                    }
                                } else if (zzfe.zzfy() != null) {
                                    objArr[((i / 4) << 1) + 1] = zzfe.zzfy();
                                } else if (zzfe.zzfz() != null) {
                                    objArr[((i / 4) << 1) + 1] = zzfe.zzfz();
                                }
                                zzfg = zzfe.zzfn();
                                if (zzfg != zzgt.MAP.ordinal()) {
                                    zzfg = i4 + 1;
                                    iArr2[i4] = i;
                                    i4 = zzfg;
                                } else if (zzfg >= 18 && zzfg <= 49) {
                                    zzfg = i5 + 1;
                                    iArr3[i5] = iArr[i6] & 1048575;
                                    i5 = zzfg;
                                }
                                if (zzfe.next()) {
                                    break;
                                }
                                zzfg = zzfe.zzbg();
                            } else {
                                zzb = 0;
                            }
                        }
                        zzfv = 0;
                        iArr[i] = zzfe.zzbg();
                        i6 = i + 1;
                        if (zzfe.zzfx()) {
                        }
                        if (zzfe.zzfw()) {
                        }
                        iArr[i6] = (((zzfe.zzfx() ? ErrorDialogData.DYNAMITE_CRASH : 0) | (zzfe.zzfw() ? ErrorDialogData.BINDER_CRASH : 0)) | (zzfe.zzfn() << 20)) | zzfg;
                        iArr[i + 2] = zzb | (zzfv << 20);
                        if (zzfe.zzga() != null) {
                            zzfg = (i / 4) << 1;
                            objArr[zzfg] = zzfe.zzga();
                            if (zzfe.zzfy() != null) {
                                objArr[zzfg + 1] = zzfe.zzfy();
                            } else if (zzfe.zzfz() != null) {
                                objArr[zzfg + 1] = zzfe.zzfz();
                            }
                        } else if (zzfe.zzfy() != null) {
                            objArr[((i / 4) << 1) + 1] = zzfe.zzfy();
                        } else if (zzfe.zzfz() != null) {
                            objArr[((i / 4) << 1) + 1] = zzfe.zzfz();
                        }
                        zzfg = zzfe.zzfn();
                        if (zzfg != zzgt.MAP.ordinal()) {
                            zzfg = i5 + 1;
                            iArr3[i5] = iArr[i6] & 1048575;
                            i5 = zzfg;
                        } else {
                            zzfg = i4 + 1;
                            iArr2[i4] = i;
                            i4 = zzfg;
                        }
                        if (zzfe.next()) {
                            break;
                        }
                        zzfg = zzfe.zzbg();
                    } else {
                        for (zzb = 0; zzb < 4; zzb++) {
                            iArr[i + zzb] = -1;
                        }
                    }
                    i += 4;
                }
            }
            return new zzil(iArr, objArr, i2, i3, zziu.zzfl(), zziu.zzex(), z, false, zziu.zzfj(), iArr2, iArr3, zzio, zzhr, zzjq, zzgm, zzic);
        }
        ((zzjl) zzif2).zzev();
        throw new NoSuchMethodError();
    }

    private final <K, V, UT, UB> UB zzb(int i, int i2, Map<K, V> map, zzhd<?> zzhd, UB ub, zzjq<UT, UB> zzjq) {
        zzia zzm = this.zzvr.zzm(zzbg(i));
        Iterator it = map.entrySet().iterator();
        while (it.hasNext()) {
            Entry entry = (Entry) it.next();
            if (zzhd.zzi(((Integer) entry.getValue()).intValue()) == null) {
                if (ub == null) {
                    ub = zzjq.zzgo();
                }
                zzfw zzag = zzfr.zzag(zzhz.zzb(zzm, entry.getKey(), entry.getValue()));
                try {
                    zzhz.zzb(zzag.zzci(), zzm, entry.getKey(), entry.getValue());
                    zzjq.zzb((Object) ub, i2, zzag.zzch());
                    it.remove();
                } catch (Throwable e) {
                    throw new RuntimeException(e);
                }
            }
        }
        return ub;
    }

    private final <UT, UB> UB zzb(Object obj, int i, UB ub, zzjq<UT, UB> zzjq) {
        int i2 = this.zzva[i];
        obj = zzjw.zzq(obj, (long) (zzbi(i) & 1048575));
        if (obj == null) {
            return ub;
        }
        zzhd zzbh = zzbh(i);
        if (zzbh == null) {
            return ub;
        }
        return zzb(i, i2, this.zzvr.zzh(obj), zzbh, ub, zzjq);
    }

    private static void zzb(int i, Object obj, zzkk zzkk) throws IOException {
        if (obj instanceof String) {
            zzkk.zzb(i, (String) obj);
        } else {
            zzkk.zzb(i, (zzfr) obj);
        }
    }

    private static <UT, UB> void zzb(zzjq<UT, UB> zzjq, T t, zzkk zzkk) throws IOException {
        zzjq.zzb(zzjq.zzq(t), zzkk);
    }

    private final <K, V> void zzb(zzkk zzkk, int i, Object obj, int i2) throws IOException {
        if (obj != null) {
            zzkk.zzb(i, this.zzvr.zzm(zzbg(i2)), this.zzvr.zzi(obj));
        }
    }

    private final void zzb(Object obj, int i, zzix zzix) throws IOException {
        long j;
        Object zzbo;
        if (zzbk(i)) {
            j = (long) (i & 1048575);
            zzbo = zzix.zzbo();
        } else if (this.zzvh) {
            j = (long) (i & 1048575);
            zzbo = zzix.readString();
        } else {
            j = (long) (i & 1048575);
            zzbo = zzix.zzbp();
        }
        zzjw.zzb(obj, j, zzbo);
    }

    private final void zzb(T t, T t2, int i) {
        long zzbi = (long) (zzbi(i) & 1048575);
        if (zzb((Object) t2, i)) {
            Object zzq = zzjw.zzq(t, zzbi);
            Object zzq2 = zzjw.zzq(t2, zzbi);
            if (zzq == null || zzq2 == null) {
                if (zzq2 != null) {
                    zzjw.zzb((Object) t, zzbi, zzq2);
                    zzc((Object) t, i);
                }
                return;
            }
            zzjw.zzb((Object) t, zzbi, zzhb.zzb(zzq, zzq2));
            zzc((Object) t, i);
        }
    }

    private final boolean zzb(T t, int i) {
        if (this.zzvi) {
            i = zzbi(i);
            long j = (long) (i & 1048575);
            switch ((i & 267386880) >>> 20) {
                case 0:
                    return zzjw.zzp(t, j) != 0.0d;
                case 1:
                    return zzjw.zzo(t, j) != 0.0f;
                case 2:
                    return zzjw.zzm(t, j) != 0;
                case 3:
                    return zzjw.zzm(t, j) != 0;
                case 4:
                    return zzjw.zzl(t, j) != 0;
                case 5:
                    return zzjw.zzm(t, j) != 0;
                case 6:
                    return zzjw.zzl(t, j) != 0;
                case 7:
                    return zzjw.zzn(t, j);
                case 8:
                    Object zzq = zzjw.zzq(t, j);
                    if (zzq instanceof String) {
                        return !((String) zzq).isEmpty();
                    } else {
                        if (zzq instanceof zzfr) {
                            return !zzfr.zznt.equals(zzq);
                        } else {
                            throw new IllegalArgumentException();
                        }
                    }
                case 9:
                    return zzjw.zzq(t, j) != null;
                case 10:
                    return !zzfr.zznt.equals(zzjw.zzq(t, j));
                case 11:
                    return zzjw.zzl(t, j) != 0;
                case 12:
                    return zzjw.zzl(t, j) != 0;
                case 13:
                    return zzjw.zzl(t, j) != 0;
                case 14:
                    return zzjw.zzm(t, j) != 0;
                case 15:
                    return zzjw.zzl(t, j) != 0;
                case 16:
                    return zzjw.zzm(t, j) != 0;
                case 17:
                    return zzjw.zzq(t, j) != null;
                default:
                    throw new IllegalArgumentException();
            }
        }
        i = zzbj(i);
        return (zzjw.zzl(t, (long) (i & 1048575)) & (1 << (i >>> 20))) != 0;
    }

    private final boolean zzb(T t, int i, int i2) {
        return zzjw.zzl(t, (long) (zzbj(i2) & 1048575)) == i;
    }

    private final boolean zzb(T t, int i, int i2, int i3) {
        return this.zzvi ? zzb((Object) t, i) : (i2 & i3) != 0;
    }

    private static boolean zzb(Object obj, int i, zziy zziy) {
        return zziy.zzo(zzjw.zzq(obj, (long) (i & 1048575)));
    }

    private final zziy zzbf(int i) {
        i = (i / 4) << 1;
        zziy zziy = (zziy) this.zzvb[i];
        if (zziy != null) {
            return zziy;
        }
        zziy = zzis.zzfc().zzg((Class) this.zzvb[i + 1]);
        this.zzvb[i] = zziy;
        return zziy;
    }

    private final Object zzbg(int i) {
        return this.zzvb[(i / 4) << 1];
    }

    private final zzhd<?> zzbh(int i) {
        return (zzhd) this.zzvb[((i / 4) << 1) + 1];
    }

    private final int zzbi(int i) {
        return this.zzva[i + 1];
    }

    private final int zzbj(int i) {
        return this.zzva[i + 2];
    }

    private static boolean zzbk(int i) {
        return (i & ErrorDialogData.DYNAMITE_CRASH) != 0;
    }

    private final int zzbl(int i) {
        if (i >= this.zzvc) {
            int i2;
            if (i < this.zzve) {
                i2 = (i - this.zzvc) << 2;
                return this.zzva[i2] == i ? i2 : -1;
            } else if (i <= this.zzvd) {
                i2 = this.zzve - this.zzvc;
                int length = (this.zzva.length / 4) - 1;
                while (i2 <= length) {
                    int i3 = (length + i2) >>> 1;
                    int i4 = i3 << 2;
                    int i5 = this.zzva[i4];
                    if (i == i5) {
                        return i4;
                    }
                    if (i < i5) {
                        length = i3 - 1;
                    } else {
                        i2 = i3 + 1;
                    }
                }
            }
        }
        return -1;
    }

    private final void zzc(T t, int i) {
        if (!this.zzvi) {
            i = zzbj(i);
            long j = (long) (i & 1048575);
            zzjw.zzc((Object) t, j, zzjw.zzl(t, j) | (1 << (i >>> 20)));
        }
    }

    private final void zzc(T t, int i, int i2) {
        zzjw.zzc((Object) t, (long) (zzbj(i2) & 1048575), i);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private final void zzc(T r20, com.google.android.gms.internal.places.zzkk r21) throws java.io.IOException {
        /*
        r19 = this;
        r0 = r19;
        r1 = r20;
        r2 = r21;
        r3 = r0.zzvg;
        if (r3 == 0) goto L_0x0021;
    L_0x000a:
        r3 = r0.zzvq;
        r3 = r3.zzb(r1);
        r5 = r3.isEmpty();
        if (r5 != 0) goto L_0x0021;
    L_0x0016:
        r3 = r3.iterator();
        r5 = r3.next();
        r5 = (java.util.Map.Entry) r5;
        goto L_0x0023;
    L_0x0021:
        r3 = 0;
        r5 = 0;
    L_0x0023:
        r6 = -1;
        r7 = r0.zzva;
        r7 = r7.length;
        r8 = zzuz;
        r10 = r5;
        r5 = 0;
        r11 = 0;
    L_0x002c:
        if (r5 >= r7) goto L_0x04f5;
    L_0x002e:
        r12 = r0.zzbi(r5);
        r13 = r0.zzva;
        r13 = r13[r5];
        r14 = 267386880; // 0xff00000 float:2.3665827E-29 double:1.321066716E-315;
        r14 = r14 & r12;
        r14 = r14 >>> 20;
        r15 = r0.zzvi;
        r16 = 1048575; // 0xfffff float:1.469367E-39 double:5.18065E-318;
        if (r15 != 0) goto L_0x0061;
    L_0x0042:
        r15 = 17;
        if (r14 > r15) goto L_0x0061;
    L_0x0046:
        r15 = r0.zzva;
        r17 = r5 + 2;
        r15 = r15[r17];
        r9 = r15 & r16;
        if (r9 == r6) goto L_0x0059;
    L_0x0050:
        r18 = r5;
        r4 = (long) r9;
        r11 = r8.getInt(r1, r4);
        r6 = r9;
        goto L_0x005b;
    L_0x0059:
        r18 = r5;
    L_0x005b:
        r4 = r15 >>> 20;
        r5 = 1;
        r9 = r5 << r4;
        goto L_0x0064;
    L_0x0061:
        r18 = r5;
        r9 = 0;
    L_0x0064:
        if (r10 == 0) goto L_0x0083;
    L_0x0066:
        r4 = r0.zzvq;
        r4 = r4.zzb(r10);
        if (r4 > r13) goto L_0x0083;
    L_0x006e:
        r4 = r0.zzvq;
        r4.zzb(r2, r10);
        r4 = r3.hasNext();
        if (r4 == 0) goto L_0x0081;
    L_0x0079:
        r4 = r3.next();
        r4 = (java.util.Map.Entry) r4;
        r10 = r4;
        goto L_0x0064;
    L_0x0081:
        r10 = 0;
        goto L_0x0064;
    L_0x0083:
        r4 = r12 & r16;
        r4 = (long) r4;
        switch(r14) {
            case 0: goto L_0x04e4;
            case 1: goto L_0x04d6;
            case 2: goto L_0x04c8;
            case 3: goto L_0x04ba;
            case 4: goto L_0x04ac;
            case 5: goto L_0x049e;
            case 6: goto L_0x0490;
            case 7: goto L_0x0482;
            case 8: goto L_0x0473;
            case 9: goto L_0x0460;
            case 10: goto L_0x044f;
            case 11: goto L_0x0440;
            case 12: goto L_0x0431;
            case 13: goto L_0x0422;
            case 14: goto L_0x0413;
            case 15: goto L_0x0404;
            case 16: goto L_0x03f5;
            case 17: goto L_0x03e2;
            case 18: goto L_0x03d0;
            case 19: goto L_0x03be;
            case 20: goto L_0x03ac;
            case 21: goto L_0x039a;
            case 22: goto L_0x0388;
            case 23: goto L_0x0376;
            case 24: goto L_0x0364;
            case 25: goto L_0x0352;
            case 26: goto L_0x0341;
            case 27: goto L_0x032c;
            case 28: goto L_0x031b;
            case 29: goto L_0x0309;
            case 30: goto L_0x02f7;
            case 31: goto L_0x02e5;
            case 32: goto L_0x02d3;
            case 33: goto L_0x02c1;
            case 34: goto L_0x02af;
            case 35: goto L_0x029d;
            case 36: goto L_0x028b;
            case 37: goto L_0x0279;
            case 38: goto L_0x0267;
            case 39: goto L_0x0255;
            case 40: goto L_0x0243;
            case 41: goto L_0x0231;
            case 42: goto L_0x021f;
            case 43: goto L_0x0216;
            case 44: goto L_0x020d;
            case 45: goto L_0x0204;
            case 46: goto L_0x01fb;
            case 47: goto L_0x01f2;
            case 48: goto L_0x01e3;
            case 49: goto L_0x01ce;
            case 50: goto L_0x01c3;
            case 51: goto L_0x01b2;
            case 52: goto L_0x01a1;
            case 53: goto L_0x0190;
            case 54: goto L_0x017f;
            case 55: goto L_0x016e;
            case 56: goto L_0x015d;
            case 57: goto L_0x014c;
            case 58: goto L_0x013b;
            case 59: goto L_0x012a;
            case 60: goto L_0x0115;
            case 61: goto L_0x0102;
            case 62: goto L_0x00f2;
            case 63: goto L_0x00e2;
            case 64: goto L_0x00d2;
            case 65: goto L_0x00c2;
            case 66: goto L_0x00b2;
            case 67: goto L_0x00a2;
            case 68: goto L_0x008e;
            default: goto L_0x0089;
        };
    L_0x0089:
        r12 = r18;
    L_0x008b:
        r14 = 0;
        goto L_0x04f1;
    L_0x008e:
        r12 = r18;
        r9 = r0.zzb(r1, r13, r12);
        if (r9 == 0) goto L_0x008b;
    L_0x0096:
        r4 = r8.getObject(r1, r4);
        r5 = r0.zzbf(r12);
        r2.zzc(r13, r4, r5);
        goto L_0x008b;
    L_0x00a2:
        r12 = r18;
        r9 = r0.zzb(r1, r13, r12);
        if (r9 == 0) goto L_0x008b;
    L_0x00aa:
        r4 = zzj(r1, r4);
        r2.zzc(r13, r4);
        goto L_0x008b;
    L_0x00b2:
        r12 = r18;
        r9 = r0.zzb(r1, r13, r12);
        if (r9 == 0) goto L_0x008b;
    L_0x00ba:
        r4 = zzi(r1, r4);
        r2.zzg(r13, r4);
        goto L_0x008b;
    L_0x00c2:
        r12 = r18;
        r9 = r0.zzb(r1, r13, r12);
        if (r9 == 0) goto L_0x008b;
    L_0x00ca:
        r4 = zzj(r1, r4);
        r2.zzk(r13, r4);
        goto L_0x008b;
    L_0x00d2:
        r12 = r18;
        r9 = r0.zzb(r1, r13, r12);
        if (r9 == 0) goto L_0x008b;
    L_0x00da:
        r4 = zzi(r1, r4);
        r2.zzo(r13, r4);
        goto L_0x008b;
    L_0x00e2:
        r12 = r18;
        r9 = r0.zzb(r1, r13, r12);
        if (r9 == 0) goto L_0x008b;
    L_0x00ea:
        r4 = zzi(r1, r4);
        r2.zzp(r13, r4);
        goto L_0x008b;
    L_0x00f2:
        r12 = r18;
        r9 = r0.zzb(r1, r13, r12);
        if (r9 == 0) goto L_0x008b;
    L_0x00fa:
        r4 = zzi(r1, r4);
        r2.zzf(r13, r4);
        goto L_0x008b;
    L_0x0102:
        r12 = r18;
        r9 = r0.zzb(r1, r13, r12);
        if (r9 == 0) goto L_0x008b;
    L_0x010a:
        r4 = r8.getObject(r1, r4);
        r4 = (com.google.android.gms.internal.places.zzfr) r4;
        r2.zzb(r13, r4);
        goto L_0x008b;
    L_0x0115:
        r12 = r18;
        r9 = r0.zzb(r1, r13, r12);
        if (r9 == 0) goto L_0x008b;
    L_0x011d:
        r4 = r8.getObject(r1, r4);
        r5 = r0.zzbf(r12);
        r2.zzb(r13, r4, r5);
        goto L_0x008b;
    L_0x012a:
        r12 = r18;
        r9 = r0.zzb(r1, r13, r12);
        if (r9 == 0) goto L_0x008b;
    L_0x0132:
        r4 = r8.getObject(r1, r4);
        zzb(r13, r4, r2);
        goto L_0x008b;
    L_0x013b:
        r12 = r18;
        r9 = r0.zzb(r1, r13, r12);
        if (r9 == 0) goto L_0x008b;
    L_0x0143:
        r4 = zzk(r1, r4);
        r2.zzc(r13, r4);
        goto L_0x008b;
    L_0x014c:
        r12 = r18;
        r9 = r0.zzb(r1, r13, r12);
        if (r9 == 0) goto L_0x008b;
    L_0x0154:
        r4 = zzi(r1, r4);
        r2.zzh(r13, r4);
        goto L_0x008b;
    L_0x015d:
        r12 = r18;
        r9 = r0.zzb(r1, r13, r12);
        if (r9 == 0) goto L_0x008b;
    L_0x0165:
        r4 = zzj(r1, r4);
        r2.zzd(r13, r4);
        goto L_0x008b;
    L_0x016e:
        r12 = r18;
        r9 = r0.zzb(r1, r13, r12);
        if (r9 == 0) goto L_0x008b;
    L_0x0176:
        r4 = zzi(r1, r4);
        r2.zze(r13, r4);
        goto L_0x008b;
    L_0x017f:
        r12 = r18;
        r9 = r0.zzb(r1, r13, r12);
        if (r9 == 0) goto L_0x008b;
    L_0x0187:
        r4 = zzj(r1, r4);
        r2.zzb(r13, r4);
        goto L_0x008b;
    L_0x0190:
        r12 = r18;
        r9 = r0.zzb(r1, r13, r12);
        if (r9 == 0) goto L_0x008b;
    L_0x0198:
        r4 = zzj(r1, r4);
        r2.zzj(r13, r4);
        goto L_0x008b;
    L_0x01a1:
        r12 = r18;
        r9 = r0.zzb(r1, r13, r12);
        if (r9 == 0) goto L_0x008b;
    L_0x01a9:
        r4 = zzh(r1, r4);
        r2.zzc(r13, r4);
        goto L_0x008b;
    L_0x01b2:
        r12 = r18;
        r9 = r0.zzb(r1, r13, r12);
        if (r9 == 0) goto L_0x008b;
    L_0x01ba:
        r4 = zzg(r1, r4);
        r2.zzb(r13, r4);
        goto L_0x008b;
    L_0x01c3:
        r12 = r18;
        r4 = r8.getObject(r1, r4);
        r0.zzb(r2, r13, r4, r12);
        goto L_0x008b;
    L_0x01ce:
        r12 = r18;
        r9 = r0.zzva;
        r9 = r9[r12];
        r4 = r8.getObject(r1, r4);
        r4 = (java.util.List) r4;
        r5 = r0.zzbf(r12);
        com.google.android.gms.internal.places.zzja.zzc(r9, r4, r2, r5);
        goto L_0x008b;
    L_0x01e3:
        r12 = r18;
        r9 = r0.zzva;
        r9 = r9[r12];
        r4 = r8.getObject(r1, r4);
        r4 = (java.util.List) r4;
        r13 = 1;
        goto L_0x02bc;
    L_0x01f2:
        r12 = r18;
        r13 = 1;
        r9 = r0.zzva;
        r9 = r9[r12];
        goto L_0x02c8;
    L_0x01fb:
        r12 = r18;
        r13 = 1;
        r9 = r0.zzva;
        r9 = r9[r12];
        goto L_0x02da;
    L_0x0204:
        r12 = r18;
        r13 = 1;
        r9 = r0.zzva;
        r9 = r9[r12];
        goto L_0x02ec;
    L_0x020d:
        r12 = r18;
        r13 = 1;
        r9 = r0.zzva;
        r9 = r9[r12];
        goto L_0x02fe;
    L_0x0216:
        r12 = r18;
        r13 = 1;
        r9 = r0.zzva;
        r9 = r9[r12];
        goto L_0x0310;
    L_0x021f:
        r12 = r18;
        r13 = 1;
        r9 = r0.zzva;
        r9 = r9[r12];
        r4 = r8.getObject(r1, r4);
        r4 = (java.util.List) r4;
        com.google.android.gms.internal.places.zzja.zzo(r9, r4, r2, r13);
        goto L_0x008b;
    L_0x0231:
        r12 = r18;
        r13 = 1;
        r9 = r0.zzva;
        r9 = r9[r12];
        r4 = r8.getObject(r1, r4);
        r4 = (java.util.List) r4;
        com.google.android.gms.internal.places.zzja.zzl(r9, r4, r2, r13);
        goto L_0x008b;
    L_0x0243:
        r12 = r18;
        r13 = 1;
        r9 = r0.zzva;
        r9 = r9[r12];
        r4 = r8.getObject(r1, r4);
        r4 = (java.util.List) r4;
        com.google.android.gms.internal.places.zzja.zzg(r9, r4, r2, r13);
        goto L_0x008b;
    L_0x0255:
        r12 = r18;
        r13 = 1;
        r9 = r0.zzva;
        r9 = r9[r12];
        r4 = r8.getObject(r1, r4);
        r4 = (java.util.List) r4;
        com.google.android.gms.internal.places.zzja.zzi(r9, r4, r2, r13);
        goto L_0x008b;
    L_0x0267:
        r12 = r18;
        r13 = 1;
        r9 = r0.zzva;
        r9 = r9[r12];
        r4 = r8.getObject(r1, r4);
        r4 = (java.util.List) r4;
        com.google.android.gms.internal.places.zzja.zze(r9, r4, r2, r13);
        goto L_0x008b;
    L_0x0279:
        r12 = r18;
        r13 = 1;
        r9 = r0.zzva;
        r9 = r9[r12];
        r4 = r8.getObject(r1, r4);
        r4 = (java.util.List) r4;
        com.google.android.gms.internal.places.zzja.zzd(r9, r4, r2, r13);
        goto L_0x008b;
    L_0x028b:
        r12 = r18;
        r13 = 1;
        r9 = r0.zzva;
        r9 = r9[r12];
        r4 = r8.getObject(r1, r4);
        r4 = (java.util.List) r4;
        com.google.android.gms.internal.places.zzja.zzc(r9, r4, r2, r13);
        goto L_0x008b;
    L_0x029d:
        r12 = r18;
        r13 = 1;
        r9 = r0.zzva;
        r9 = r9[r12];
        r4 = r8.getObject(r1, r4);
        r4 = (java.util.List) r4;
        com.google.android.gms.internal.places.zzja.zzb(r9, r4, r2, r13);
        goto L_0x008b;
    L_0x02af:
        r12 = r18;
        r9 = r0.zzva;
        r9 = r9[r12];
        r4 = r8.getObject(r1, r4);
        r4 = (java.util.List) r4;
        r13 = 0;
    L_0x02bc:
        com.google.android.gms.internal.places.zzja.zzf(r9, r4, r2, r13);
        goto L_0x008b;
    L_0x02c1:
        r12 = r18;
        r13 = 0;
        r9 = r0.zzva;
        r9 = r9[r12];
    L_0x02c8:
        r4 = r8.getObject(r1, r4);
        r4 = (java.util.List) r4;
        com.google.android.gms.internal.places.zzja.zzk(r9, r4, r2, r13);
        goto L_0x008b;
    L_0x02d3:
        r12 = r18;
        r13 = 0;
        r9 = r0.zzva;
        r9 = r9[r12];
    L_0x02da:
        r4 = r8.getObject(r1, r4);
        r4 = (java.util.List) r4;
        com.google.android.gms.internal.places.zzja.zzh(r9, r4, r2, r13);
        goto L_0x008b;
    L_0x02e5:
        r12 = r18;
        r13 = 0;
        r9 = r0.zzva;
        r9 = r9[r12];
    L_0x02ec:
        r4 = r8.getObject(r1, r4);
        r4 = (java.util.List) r4;
        com.google.android.gms.internal.places.zzja.zzm(r9, r4, r2, r13);
        goto L_0x008b;
    L_0x02f7:
        r12 = r18;
        r13 = 0;
        r9 = r0.zzva;
        r9 = r9[r12];
    L_0x02fe:
        r4 = r8.getObject(r1, r4);
        r4 = (java.util.List) r4;
        com.google.android.gms.internal.places.zzja.zzn(r9, r4, r2, r13);
        goto L_0x008b;
    L_0x0309:
        r12 = r18;
        r13 = 0;
        r9 = r0.zzva;
        r9 = r9[r12];
    L_0x0310:
        r4 = r8.getObject(r1, r4);
        r4 = (java.util.List) r4;
        com.google.android.gms.internal.places.zzja.zzj(r9, r4, r2, r13);
        goto L_0x008b;
    L_0x031b:
        r12 = r18;
        r9 = r0.zzva;
        r9 = r9[r12];
        r4 = r8.getObject(r1, r4);
        r4 = (java.util.List) r4;
        com.google.android.gms.internal.places.zzja.zzc(r9, r4, r2);
        goto L_0x008b;
    L_0x032c:
        r12 = r18;
        r9 = r0.zzva;
        r9 = r9[r12];
        r4 = r8.getObject(r1, r4);
        r4 = (java.util.List) r4;
        r5 = r0.zzbf(r12);
        com.google.android.gms.internal.places.zzja.zzb(r9, r4, r2, r5);
        goto L_0x008b;
    L_0x0341:
        r12 = r18;
        r9 = r0.zzva;
        r9 = r9[r12];
        r4 = r8.getObject(r1, r4);
        r4 = (java.util.List) r4;
        com.google.android.gms.internal.places.zzja.zzb(r9, r4, r2);
        goto L_0x008b;
    L_0x0352:
        r12 = r18;
        r9 = r0.zzva;
        r9 = r9[r12];
        r4 = r8.getObject(r1, r4);
        r4 = (java.util.List) r4;
        r14 = 0;
        com.google.android.gms.internal.places.zzja.zzo(r9, r4, r2, r14);
        goto L_0x04f1;
    L_0x0364:
        r12 = r18;
        r14 = 0;
        r9 = r0.zzva;
        r9 = r9[r12];
        r4 = r8.getObject(r1, r4);
        r4 = (java.util.List) r4;
        com.google.android.gms.internal.places.zzja.zzl(r9, r4, r2, r14);
        goto L_0x04f1;
    L_0x0376:
        r12 = r18;
        r14 = 0;
        r9 = r0.zzva;
        r9 = r9[r12];
        r4 = r8.getObject(r1, r4);
        r4 = (java.util.List) r4;
        com.google.android.gms.internal.places.zzja.zzg(r9, r4, r2, r14);
        goto L_0x04f1;
    L_0x0388:
        r12 = r18;
        r14 = 0;
        r9 = r0.zzva;
        r9 = r9[r12];
        r4 = r8.getObject(r1, r4);
        r4 = (java.util.List) r4;
        com.google.android.gms.internal.places.zzja.zzi(r9, r4, r2, r14);
        goto L_0x04f1;
    L_0x039a:
        r12 = r18;
        r14 = 0;
        r9 = r0.zzva;
        r9 = r9[r12];
        r4 = r8.getObject(r1, r4);
        r4 = (java.util.List) r4;
        com.google.android.gms.internal.places.zzja.zze(r9, r4, r2, r14);
        goto L_0x04f1;
    L_0x03ac:
        r12 = r18;
        r14 = 0;
        r9 = r0.zzva;
        r9 = r9[r12];
        r4 = r8.getObject(r1, r4);
        r4 = (java.util.List) r4;
        com.google.android.gms.internal.places.zzja.zzd(r9, r4, r2, r14);
        goto L_0x04f1;
    L_0x03be:
        r12 = r18;
        r14 = 0;
        r9 = r0.zzva;
        r9 = r9[r12];
        r4 = r8.getObject(r1, r4);
        r4 = (java.util.List) r4;
        com.google.android.gms.internal.places.zzja.zzc(r9, r4, r2, r14);
        goto L_0x04f1;
    L_0x03d0:
        r12 = r18;
        r14 = 0;
        r9 = r0.zzva;
        r9 = r9[r12];
        r4 = r8.getObject(r1, r4);
        r4 = (java.util.List) r4;
        com.google.android.gms.internal.places.zzja.zzb(r9, r4, r2, r14);
        goto L_0x04f1;
    L_0x03e2:
        r12 = r18;
        r14 = 0;
        r9 = r9 & r11;
        if (r9 == 0) goto L_0x04f1;
    L_0x03e8:
        r4 = r8.getObject(r1, r4);
        r5 = r0.zzbf(r12);
        r2.zzc(r13, r4, r5);
        goto L_0x04f1;
    L_0x03f5:
        r12 = r18;
        r14 = 0;
        r9 = r9 & r11;
        if (r9 == 0) goto L_0x04f1;
    L_0x03fb:
        r4 = r8.getLong(r1, r4);
        r2.zzc(r13, r4);
        goto L_0x04f1;
    L_0x0404:
        r12 = r18;
        r14 = 0;
        r9 = r9 & r11;
        if (r9 == 0) goto L_0x04f1;
    L_0x040a:
        r4 = r8.getInt(r1, r4);
        r2.zzg(r13, r4);
        goto L_0x04f1;
    L_0x0413:
        r12 = r18;
        r14 = 0;
        r9 = r9 & r11;
        if (r9 == 0) goto L_0x04f1;
    L_0x0419:
        r4 = r8.getLong(r1, r4);
        r2.zzk(r13, r4);
        goto L_0x04f1;
    L_0x0422:
        r12 = r18;
        r14 = 0;
        r9 = r9 & r11;
        if (r9 == 0) goto L_0x04f1;
    L_0x0428:
        r4 = r8.getInt(r1, r4);
        r2.zzo(r13, r4);
        goto L_0x04f1;
    L_0x0431:
        r12 = r18;
        r14 = 0;
        r9 = r9 & r11;
        if (r9 == 0) goto L_0x04f1;
    L_0x0437:
        r4 = r8.getInt(r1, r4);
        r2.zzp(r13, r4);
        goto L_0x04f1;
    L_0x0440:
        r12 = r18;
        r14 = 0;
        r9 = r9 & r11;
        if (r9 == 0) goto L_0x04f1;
    L_0x0446:
        r4 = r8.getInt(r1, r4);
        r2.zzf(r13, r4);
        goto L_0x04f1;
    L_0x044f:
        r12 = r18;
        r14 = 0;
        r9 = r9 & r11;
        if (r9 == 0) goto L_0x04f1;
    L_0x0455:
        r4 = r8.getObject(r1, r4);
        r4 = (com.google.android.gms.internal.places.zzfr) r4;
        r2.zzb(r13, r4);
        goto L_0x04f1;
    L_0x0460:
        r12 = r18;
        r14 = 0;
        r9 = r9 & r11;
        if (r9 == 0) goto L_0x04f1;
    L_0x0466:
        r4 = r8.getObject(r1, r4);
        r5 = r0.zzbf(r12);
        r2.zzb(r13, r4, r5);
        goto L_0x04f1;
    L_0x0473:
        r12 = r18;
        r14 = 0;
        r9 = r9 & r11;
        if (r9 == 0) goto L_0x04f1;
    L_0x0479:
        r4 = r8.getObject(r1, r4);
        zzb(r13, r4, r2);
        goto L_0x04f1;
    L_0x0482:
        r12 = r18;
        r14 = 0;
        r9 = r9 & r11;
        if (r9 == 0) goto L_0x04f1;
    L_0x0488:
        r4 = com.google.android.gms.internal.places.zzjw.zzn(r1, r4);
        r2.zzc(r13, r4);
        goto L_0x04f1;
    L_0x0490:
        r12 = r18;
        r14 = 0;
        r9 = r9 & r11;
        if (r9 == 0) goto L_0x04f1;
    L_0x0496:
        r4 = r8.getInt(r1, r4);
        r2.zzh(r13, r4);
        goto L_0x04f1;
    L_0x049e:
        r12 = r18;
        r14 = 0;
        r9 = r9 & r11;
        if (r9 == 0) goto L_0x04f1;
    L_0x04a4:
        r4 = r8.getLong(r1, r4);
        r2.zzd(r13, r4);
        goto L_0x04f1;
    L_0x04ac:
        r12 = r18;
        r14 = 0;
        r9 = r9 & r11;
        if (r9 == 0) goto L_0x04f1;
    L_0x04b2:
        r4 = r8.getInt(r1, r4);
        r2.zze(r13, r4);
        goto L_0x04f1;
    L_0x04ba:
        r12 = r18;
        r14 = 0;
        r9 = r9 & r11;
        if (r9 == 0) goto L_0x04f1;
    L_0x04c0:
        r4 = r8.getLong(r1, r4);
        r2.zzb(r13, r4);
        goto L_0x04f1;
    L_0x04c8:
        r12 = r18;
        r14 = 0;
        r9 = r9 & r11;
        if (r9 == 0) goto L_0x04f1;
    L_0x04ce:
        r4 = r8.getLong(r1, r4);
        r2.zzj(r13, r4);
        goto L_0x04f1;
    L_0x04d6:
        r12 = r18;
        r14 = 0;
        r9 = r9 & r11;
        if (r9 == 0) goto L_0x04f1;
    L_0x04dc:
        r4 = com.google.android.gms.internal.places.zzjw.zzo(r1, r4);
        r2.zzc(r13, r4);
        goto L_0x04f1;
    L_0x04e4:
        r12 = r18;
        r14 = 0;
        r9 = r9 & r11;
        if (r9 == 0) goto L_0x04f1;
    L_0x04ea:
        r4 = com.google.android.gms.internal.places.zzjw.zzp(r1, r4);
        r2.zzb(r13, r4);
    L_0x04f1:
        r5 = r12 + 4;
        goto L_0x002c;
    L_0x04f5:
        if (r10 == 0) goto L_0x050c;
    L_0x04f7:
        r4 = r0.zzvq;
        r4.zzb(r2, r10);
        r4 = r3.hasNext();
        if (r4 == 0) goto L_0x050a;
    L_0x0502:
        r4 = r3.next();
        r4 = (java.util.Map.Entry) r4;
        r10 = r4;
        goto L_0x04f5;
    L_0x050a:
        r10 = 0;
        goto L_0x04f5;
    L_0x050c:
        r3 = r0.zzvp;
        zzb(r3, r1, r2);
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.places.zzil.zzc(java.lang.Object, com.google.android.gms.internal.places.zzkk):void");
    }

    private final void zzc(T t, T t2, int i) {
        int zzbi = zzbi(i);
        int i2 = this.zzva[i];
        long j = (long) (zzbi & 1048575);
        if (zzb((Object) t2, i2, i)) {
            Object zzq = zzjw.zzq(t, j);
            Object zzq2 = zzjw.zzq(t2, j);
            if (zzq == null || zzq2 == null) {
                if (zzq2 != null) {
                    zzjw.zzb((Object) t, j, zzq2);
                    zzc((Object) t, i2, i);
                }
                return;
            }
            zzjw.zzb((Object) t, j, zzhb.zzb(zzq, zzq2));
            zzc((Object) t, i2, i);
        }
    }

    private final boolean zzd(T t, T t2, int i) {
        return zzb((Object) t, i) == zzb((Object) t2, i);
    }

    private static <E> List<E> zzf(Object obj, long j) {
        return (List) zzjw.zzq(obj, j);
    }

    private static <T> double zzg(T t, long j) {
        return ((Double) zzjw.zzq(t, j)).doubleValue();
    }

    private static <T> float zzh(T t, long j) {
        return ((Float) zzjw.zzq(t, j)).floatValue();
    }

    private static <T> int zzi(T t, long j) {
        return ((Integer) zzjw.zzq(t, j)).intValue();
    }

    private static <T> long zzj(T t, long j) {
        return ((Long) zzjw.zzq(t, j)).longValue();
    }

    private static <T> boolean zzk(T t, long j) {
        return ((Boolean) zzjw.zzq(t, j)).booleanValue();
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean equals(T r10, T r11) {
        /*
        r9 = this;
        r0 = r9.zzva;
        r0 = r0.length;
        r1 = 0;
        r2 = 0;
    L_0x0005:
        r3 = 1;
        if (r2 >= r0) goto L_0x01aa;
    L_0x0008:
        r4 = r9.zzbi(r2);
        r5 = 1048575; // 0xfffff float:1.469367E-39 double:5.18065E-318;
        r6 = r4 & r5;
        r6 = (long) r6;
        r8 = 267386880; // 0xff00000 float:2.3665827E-29 double:1.321066716E-315;
        r4 = r4 & r8;
        r4 = r4 >>> 20;
        switch(r4) {
            case 0: goto L_0x0190;
            case 1: goto L_0x017f;
            case 2: goto L_0x016c;
            case 3: goto L_0x0159;
            case 4: goto L_0x0148;
            case 5: goto L_0x0135;
            case 6: goto L_0x0124;
            case 7: goto L_0x0112;
            case 8: goto L_0x00fc;
            case 9: goto L_0x00e6;
            case 10: goto L_0x00d0;
            case 11: goto L_0x00be;
            case 12: goto L_0x00ac;
            case 13: goto L_0x009a;
            case 14: goto L_0x0086;
            case 15: goto L_0x0074;
            case 16: goto L_0x0060;
            case 17: goto L_0x004a;
            case 18: goto L_0x003c;
            case 19: goto L_0x003c;
            case 20: goto L_0x003c;
            case 21: goto L_0x003c;
            case 22: goto L_0x003c;
            case 23: goto L_0x003c;
            case 24: goto L_0x003c;
            case 25: goto L_0x003c;
            case 26: goto L_0x003c;
            case 27: goto L_0x003c;
            case 28: goto L_0x003c;
            case 29: goto L_0x003c;
            case 30: goto L_0x003c;
            case 31: goto L_0x003c;
            case 32: goto L_0x003c;
            case 33: goto L_0x003c;
            case 34: goto L_0x003c;
            case 35: goto L_0x003c;
            case 36: goto L_0x003c;
            case 37: goto L_0x003c;
            case 38: goto L_0x003c;
            case 39: goto L_0x003c;
            case 40: goto L_0x003c;
            case 41: goto L_0x003c;
            case 42: goto L_0x003c;
            case 43: goto L_0x003c;
            case 44: goto L_0x003c;
            case 45: goto L_0x003c;
            case 46: goto L_0x003c;
            case 47: goto L_0x003c;
            case 48: goto L_0x003c;
            case 49: goto L_0x003c;
            case 50: goto L_0x003c;
            case 51: goto L_0x001c;
            case 52: goto L_0x001c;
            case 53: goto L_0x001c;
            case 54: goto L_0x001c;
            case 55: goto L_0x001c;
            case 56: goto L_0x001c;
            case 57: goto L_0x001c;
            case 58: goto L_0x001c;
            case 59: goto L_0x001c;
            case 60: goto L_0x001c;
            case 61: goto L_0x001c;
            case 62: goto L_0x001c;
            case 63: goto L_0x001c;
            case 64: goto L_0x001c;
            case 65: goto L_0x001c;
            case 66: goto L_0x001c;
            case 67: goto L_0x001c;
            case 68: goto L_0x001c;
            default: goto L_0x001a;
        };
    L_0x001a:
        goto L_0x01a3;
    L_0x001c:
        r4 = r9.zzbj(r2);
        r4 = r4 & r5;
        r4 = (long) r4;
        r8 = com.google.android.gms.internal.places.zzjw.zzl(r10, r4);
        r4 = com.google.android.gms.internal.places.zzjw.zzl(r11, r4);
        if (r8 != r4) goto L_0x01a2;
    L_0x002c:
        r4 = com.google.android.gms.internal.places.zzjw.zzq(r10, r6);
        r5 = com.google.android.gms.internal.places.zzjw.zzq(r11, r6);
        r4 = com.google.android.gms.internal.places.zzja.zze(r4, r5);
        if (r4 != 0) goto L_0x01a3;
    L_0x003a:
        goto L_0x018f;
    L_0x003c:
        r3 = com.google.android.gms.internal.places.zzjw.zzq(r10, r6);
        r4 = com.google.android.gms.internal.places.zzjw.zzq(r11, r6);
        r3 = com.google.android.gms.internal.places.zzja.zze(r3, r4);
        goto L_0x01a3;
    L_0x004a:
        r4 = r9.zzd(r10, r11, r2);
        if (r4 == 0) goto L_0x01a2;
    L_0x0050:
        r4 = com.google.android.gms.internal.places.zzjw.zzq(r10, r6);
        r5 = com.google.android.gms.internal.places.zzjw.zzq(r11, r6);
        r4 = com.google.android.gms.internal.places.zzja.zze(r4, r5);
        if (r4 != 0) goto L_0x01a3;
    L_0x005e:
        goto L_0x01a2;
    L_0x0060:
        r4 = r9.zzd(r10, r11, r2);
        if (r4 == 0) goto L_0x01a2;
    L_0x0066:
        r4 = com.google.android.gms.internal.places.zzjw.zzm(r10, r6);
        r6 = com.google.android.gms.internal.places.zzjw.zzm(r11, r6);
        r8 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1));
        if (r8 == 0) goto L_0x01a3;
    L_0x0072:
        goto L_0x018f;
    L_0x0074:
        r4 = r9.zzd(r10, r11, r2);
        if (r4 == 0) goto L_0x01a2;
    L_0x007a:
        r4 = com.google.android.gms.internal.places.zzjw.zzl(r10, r6);
        r5 = com.google.android.gms.internal.places.zzjw.zzl(r11, r6);
        if (r4 == r5) goto L_0x01a3;
    L_0x0084:
        goto L_0x01a2;
    L_0x0086:
        r4 = r9.zzd(r10, r11, r2);
        if (r4 == 0) goto L_0x01a2;
    L_0x008c:
        r4 = com.google.android.gms.internal.places.zzjw.zzm(r10, r6);
        r6 = com.google.android.gms.internal.places.zzjw.zzm(r11, r6);
        r8 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1));
        if (r8 == 0) goto L_0x01a3;
    L_0x0098:
        goto L_0x018f;
    L_0x009a:
        r4 = r9.zzd(r10, r11, r2);
        if (r4 == 0) goto L_0x01a2;
    L_0x00a0:
        r4 = com.google.android.gms.internal.places.zzjw.zzl(r10, r6);
        r5 = com.google.android.gms.internal.places.zzjw.zzl(r11, r6);
        if (r4 == r5) goto L_0x01a3;
    L_0x00aa:
        goto L_0x01a2;
    L_0x00ac:
        r4 = r9.zzd(r10, r11, r2);
        if (r4 == 0) goto L_0x01a2;
    L_0x00b2:
        r4 = com.google.android.gms.internal.places.zzjw.zzl(r10, r6);
        r5 = com.google.android.gms.internal.places.zzjw.zzl(r11, r6);
        if (r4 == r5) goto L_0x01a3;
    L_0x00bc:
        goto L_0x018f;
    L_0x00be:
        r4 = r9.zzd(r10, r11, r2);
        if (r4 == 0) goto L_0x01a2;
    L_0x00c4:
        r4 = com.google.android.gms.internal.places.zzjw.zzl(r10, r6);
        r5 = com.google.android.gms.internal.places.zzjw.zzl(r11, r6);
        if (r4 == r5) goto L_0x01a3;
    L_0x00ce:
        goto L_0x01a2;
    L_0x00d0:
        r4 = r9.zzd(r10, r11, r2);
        if (r4 == 0) goto L_0x01a2;
    L_0x00d6:
        r4 = com.google.android.gms.internal.places.zzjw.zzq(r10, r6);
        r5 = com.google.android.gms.internal.places.zzjw.zzq(r11, r6);
        r4 = com.google.android.gms.internal.places.zzja.zze(r4, r5);
        if (r4 != 0) goto L_0x01a3;
    L_0x00e4:
        goto L_0x018f;
    L_0x00e6:
        r4 = r9.zzd(r10, r11, r2);
        if (r4 == 0) goto L_0x01a2;
    L_0x00ec:
        r4 = com.google.android.gms.internal.places.zzjw.zzq(r10, r6);
        r5 = com.google.android.gms.internal.places.zzjw.zzq(r11, r6);
        r4 = com.google.android.gms.internal.places.zzja.zze(r4, r5);
        if (r4 != 0) goto L_0x01a3;
    L_0x00fa:
        goto L_0x01a2;
    L_0x00fc:
        r4 = r9.zzd(r10, r11, r2);
        if (r4 == 0) goto L_0x01a2;
    L_0x0102:
        r4 = com.google.android.gms.internal.places.zzjw.zzq(r10, r6);
        r5 = com.google.android.gms.internal.places.zzjw.zzq(r11, r6);
        r4 = com.google.android.gms.internal.places.zzja.zze(r4, r5);
        if (r4 != 0) goto L_0x01a3;
    L_0x0110:
        goto L_0x018f;
    L_0x0112:
        r4 = r9.zzd(r10, r11, r2);
        if (r4 == 0) goto L_0x01a2;
    L_0x0118:
        r4 = com.google.android.gms.internal.places.zzjw.zzn(r10, r6);
        r5 = com.google.android.gms.internal.places.zzjw.zzn(r11, r6);
        if (r4 == r5) goto L_0x01a3;
    L_0x0122:
        goto L_0x01a2;
    L_0x0124:
        r4 = r9.zzd(r10, r11, r2);
        if (r4 == 0) goto L_0x01a2;
    L_0x012a:
        r4 = com.google.android.gms.internal.places.zzjw.zzl(r10, r6);
        r5 = com.google.android.gms.internal.places.zzjw.zzl(r11, r6);
        if (r4 == r5) goto L_0x01a3;
    L_0x0134:
        goto L_0x018f;
    L_0x0135:
        r4 = r9.zzd(r10, r11, r2);
        if (r4 == 0) goto L_0x01a2;
    L_0x013b:
        r4 = com.google.android.gms.internal.places.zzjw.zzm(r10, r6);
        r6 = com.google.android.gms.internal.places.zzjw.zzm(r11, r6);
        r8 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1));
        if (r8 == 0) goto L_0x01a3;
    L_0x0147:
        goto L_0x01a2;
    L_0x0148:
        r4 = r9.zzd(r10, r11, r2);
        if (r4 == 0) goto L_0x01a2;
    L_0x014e:
        r4 = com.google.android.gms.internal.places.zzjw.zzl(r10, r6);
        r5 = com.google.android.gms.internal.places.zzjw.zzl(r11, r6);
        if (r4 == r5) goto L_0x01a3;
    L_0x0158:
        goto L_0x018f;
    L_0x0159:
        r4 = r9.zzd(r10, r11, r2);
        if (r4 == 0) goto L_0x01a2;
    L_0x015f:
        r4 = com.google.android.gms.internal.places.zzjw.zzm(r10, r6);
        r6 = com.google.android.gms.internal.places.zzjw.zzm(r11, r6);
        r8 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1));
        if (r8 == 0) goto L_0x01a3;
    L_0x016b:
        goto L_0x01a2;
    L_0x016c:
        r4 = r9.zzd(r10, r11, r2);
        if (r4 == 0) goto L_0x01a2;
    L_0x0172:
        r4 = com.google.android.gms.internal.places.zzjw.zzm(r10, r6);
        r6 = com.google.android.gms.internal.places.zzjw.zzm(r11, r6);
        r8 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1));
        if (r8 == 0) goto L_0x01a3;
    L_0x017e:
        goto L_0x018f;
    L_0x017f:
        r4 = r9.zzd(r10, r11, r2);
        if (r4 == 0) goto L_0x01a2;
    L_0x0185:
        r4 = com.google.android.gms.internal.places.zzjw.zzl(r10, r6);
        r5 = com.google.android.gms.internal.places.zzjw.zzl(r11, r6);
        if (r4 == r5) goto L_0x01a3;
    L_0x018f:
        goto L_0x01a2;
    L_0x0190:
        r4 = r9.zzd(r10, r11, r2);
        if (r4 == 0) goto L_0x01a2;
    L_0x0196:
        r4 = com.google.android.gms.internal.places.zzjw.zzm(r10, r6);
        r6 = com.google.android.gms.internal.places.zzjw.zzm(r11, r6);
        r8 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1));
        if (r8 == 0) goto L_0x01a3;
    L_0x01a2:
        r3 = 0;
    L_0x01a3:
        if (r3 != 0) goto L_0x01a6;
    L_0x01a5:
        return r1;
    L_0x01a6:
        r2 = r2 + 4;
        goto L_0x0005;
    L_0x01aa:
        r0 = r9.zzvp;
        r0 = r0.zzq(r10);
        r2 = r9.zzvp;
        r2 = r2.zzq(r11);
        r0 = r0.equals(r2);
        if (r0 != 0) goto L_0x01bd;
    L_0x01bc:
        return r1;
    L_0x01bd:
        r0 = r9.zzvg;
        if (r0 == 0) goto L_0x01d2;
    L_0x01c1:
        r0 = r9.zzvq;
        r10 = r0.zzb(r10);
        r0 = r9.zzvq;
        r11 = r0.zzb(r11);
        r10 = r10.equals(r11);
        return r10;
    L_0x01d2:
        return r3;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.places.zzil.equals(java.lang.Object, java.lang.Object):boolean");
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final int hashCode(T r9) {
        /*
        r8 = this;
        r0 = r8.zzva;
        r0 = r0.length;
        r1 = 0;
        r2 = 0;
    L_0x0005:
        if (r1 >= r0) goto L_0x012e;
    L_0x0007:
        r3 = r8.zzbi(r1);
        r4 = r8.zzva;
        r4 = r4[r1];
        r5 = 1048575; // 0xfffff float:1.469367E-39 double:5.18065E-318;
        r5 = r5 & r3;
        r5 = (long) r5;
        r7 = 267386880; // 0xff00000 float:2.3665827E-29 double:1.321066716E-315;
        r3 = r3 & r7;
        r3 = r3 >>> 20;
        r7 = 37;
        switch(r3) {
            case 0: goto L_0x011b;
            case 1: goto L_0x0110;
            case 2: goto L_0x0109;
            case 3: goto L_0x0109;
            case 4: goto L_0x0102;
            case 5: goto L_0x0109;
            case 6: goto L_0x0102;
            case 7: goto L_0x00f7;
            case 8: goto L_0x00ea;
            case 9: goto L_0x00dc;
            case 10: goto L_0x00d1;
            case 11: goto L_0x0102;
            case 12: goto L_0x0102;
            case 13: goto L_0x0102;
            case 14: goto L_0x0109;
            case 15: goto L_0x0102;
            case 16: goto L_0x0109;
            case 17: goto L_0x00ca;
            case 18: goto L_0x00d1;
            case 19: goto L_0x00d1;
            case 20: goto L_0x00d1;
            case 21: goto L_0x00d1;
            case 22: goto L_0x00d1;
            case 23: goto L_0x00d1;
            case 24: goto L_0x00d1;
            case 25: goto L_0x00d1;
            case 26: goto L_0x00d1;
            case 27: goto L_0x00d1;
            case 28: goto L_0x00d1;
            case 29: goto L_0x00d1;
            case 30: goto L_0x00d1;
            case 31: goto L_0x00d1;
            case 32: goto L_0x00d1;
            case 33: goto L_0x00d1;
            case 34: goto L_0x00d1;
            case 35: goto L_0x00d1;
            case 36: goto L_0x00d1;
            case 37: goto L_0x00d1;
            case 38: goto L_0x00d1;
            case 39: goto L_0x00d1;
            case 40: goto L_0x00d1;
            case 41: goto L_0x00d1;
            case 42: goto L_0x00d1;
            case 43: goto L_0x00d1;
            case 44: goto L_0x00d1;
            case 45: goto L_0x00d1;
            case 46: goto L_0x00d1;
            case 47: goto L_0x00d1;
            case 48: goto L_0x00d1;
            case 49: goto L_0x00d1;
            case 50: goto L_0x00d1;
            case 51: goto L_0x00bd;
            case 52: goto L_0x00b0;
            case 53: goto L_0x00a2;
            case 54: goto L_0x009b;
            case 55: goto L_0x008d;
            case 56: goto L_0x0086;
            case 57: goto L_0x007f;
            case 58: goto L_0x0071;
            case 59: goto L_0x0069;
            case 60: goto L_0x005b;
            case 61: goto L_0x0053;
            case 62: goto L_0x004c;
            case 63: goto L_0x0045;
            case 64: goto L_0x003e;
            case 65: goto L_0x0036;
            case 66: goto L_0x002f;
            case 67: goto L_0x0027;
            case 68: goto L_0x0020;
            default: goto L_0x001e;
        };
    L_0x001e:
        goto L_0x012a;
    L_0x0020:
        r3 = r8.zzb(r9, r4, r1);
        if (r3 == 0) goto L_0x012a;
    L_0x0026:
        goto L_0x0061;
    L_0x0027:
        r3 = r8.zzb(r9, r4, r1);
        if (r3 == 0) goto L_0x012a;
    L_0x002d:
        goto L_0x00a8;
    L_0x002f:
        r3 = r8.zzb(r9, r4, r1);
        if (r3 == 0) goto L_0x012a;
    L_0x0035:
        goto L_0x004b;
    L_0x0036:
        r3 = r8.zzb(r9, r4, r1);
        if (r3 == 0) goto L_0x012a;
    L_0x003c:
        goto L_0x00a8;
    L_0x003e:
        r3 = r8.zzb(r9, r4, r1);
        if (r3 == 0) goto L_0x012a;
    L_0x0044:
        goto L_0x004b;
    L_0x0045:
        r3 = r8.zzb(r9, r4, r1);
        if (r3 == 0) goto L_0x012a;
    L_0x004b:
        goto L_0x0093;
    L_0x004c:
        r3 = r8.zzb(r9, r4, r1);
        if (r3 == 0) goto L_0x012a;
    L_0x0052:
        goto L_0x0093;
    L_0x0053:
        r3 = r8.zzb(r9, r4, r1);
        if (r3 == 0) goto L_0x012a;
    L_0x0059:
        goto L_0x00d1;
    L_0x005b:
        r3 = r8.zzb(r9, r4, r1);
        if (r3 == 0) goto L_0x012a;
    L_0x0061:
        r3 = com.google.android.gms.internal.places.zzjw.zzq(r9, r5);
        r2 = r2 * 53;
        goto L_0x00d7;
    L_0x0069:
        r3 = r8.zzb(r9, r4, r1);
        if (r3 == 0) goto L_0x012a;
    L_0x006f:
        goto L_0x00ea;
    L_0x0071:
        r3 = r8.zzb(r9, r4, r1);
        if (r3 == 0) goto L_0x012a;
    L_0x0077:
        r2 = r2 * 53;
        r3 = zzk(r9, r5);
        goto L_0x00fd;
    L_0x007f:
        r3 = r8.zzb(r9, r4, r1);
        if (r3 == 0) goto L_0x012a;
    L_0x0085:
        goto L_0x0093;
    L_0x0086:
        r3 = r8.zzb(r9, r4, r1);
        if (r3 == 0) goto L_0x012a;
    L_0x008c:
        goto L_0x00a8;
    L_0x008d:
        r3 = r8.zzb(r9, r4, r1);
        if (r3 == 0) goto L_0x012a;
    L_0x0093:
        r2 = r2 * 53;
        r3 = zzi(r9, r5);
        goto L_0x0129;
    L_0x009b:
        r3 = r8.zzb(r9, r4, r1);
        if (r3 == 0) goto L_0x012a;
    L_0x00a1:
        goto L_0x00a8;
    L_0x00a2:
        r3 = r8.zzb(r9, r4, r1);
        if (r3 == 0) goto L_0x012a;
    L_0x00a8:
        r2 = r2 * 53;
        r3 = zzj(r9, r5);
        goto L_0x0125;
    L_0x00b0:
        r3 = r8.zzb(r9, r4, r1);
        if (r3 == 0) goto L_0x012a;
    L_0x00b6:
        r2 = r2 * 53;
        r3 = zzh(r9, r5);
        goto L_0x0116;
    L_0x00bd:
        r3 = r8.zzb(r9, r4, r1);
        if (r3 == 0) goto L_0x012a;
    L_0x00c3:
        r2 = r2 * 53;
        r3 = zzg(r9, r5);
        goto L_0x0121;
    L_0x00ca:
        r3 = com.google.android.gms.internal.places.zzjw.zzq(r9, r5);
        if (r3 == 0) goto L_0x00e6;
    L_0x00d0:
        goto L_0x00e2;
    L_0x00d1:
        r2 = r2 * 53;
        r3 = com.google.android.gms.internal.places.zzjw.zzq(r9, r5);
    L_0x00d7:
        r3 = r3.hashCode();
        goto L_0x0129;
    L_0x00dc:
        r3 = com.google.android.gms.internal.places.zzjw.zzq(r9, r5);
        if (r3 == 0) goto L_0x00e6;
    L_0x00e2:
        r7 = r3.hashCode();
    L_0x00e6:
        r2 = r2 * 53;
        r2 = r2 + r7;
        goto L_0x012a;
    L_0x00ea:
        r2 = r2 * 53;
        r3 = com.google.android.gms.internal.places.zzjw.zzq(r9, r5);
        r3 = (java.lang.String) r3;
        r3 = r3.hashCode();
        goto L_0x0129;
    L_0x00f7:
        r2 = r2 * 53;
        r3 = com.google.android.gms.internal.places.zzjw.zzn(r9, r5);
    L_0x00fd:
        r3 = com.google.android.gms.internal.places.zzhb.zzf(r3);
        goto L_0x0129;
    L_0x0102:
        r2 = r2 * 53;
        r3 = com.google.android.gms.internal.places.zzjw.zzl(r9, r5);
        goto L_0x0129;
    L_0x0109:
        r2 = r2 * 53;
        r3 = com.google.android.gms.internal.places.zzjw.zzm(r9, r5);
        goto L_0x0125;
    L_0x0110:
        r2 = r2 * 53;
        r3 = com.google.android.gms.internal.places.zzjw.zzo(r9, r5);
    L_0x0116:
        r3 = java.lang.Float.floatToIntBits(r3);
        goto L_0x0129;
    L_0x011b:
        r2 = r2 * 53;
        r3 = com.google.android.gms.internal.places.zzjw.zzp(r9, r5);
    L_0x0121:
        r3 = java.lang.Double.doubleToLongBits(r3);
    L_0x0125:
        r3 = com.google.android.gms.internal.places.zzhb.zzo(r3);
    L_0x0129:
        r2 = r2 + r3;
    L_0x012a:
        r1 = r1 + 4;
        goto L_0x0005;
    L_0x012e:
        r2 = r2 * 53;
        r0 = r8.zzvp;
        r0 = r0.zzq(r9);
        r0 = r0.hashCode();
        r2 = r2 + r0;
        r0 = r8.zzvg;
        if (r0 == 0) goto L_0x014c;
    L_0x013f:
        r2 = r2 * 53;
        r0 = r8.zzvq;
        r9 = r0.zzb(r9);
        r9 = r9.hashCode();
        r2 = r2 + r9;
    L_0x014c:
        return r2;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.places.zzil.hashCode(java.lang.Object):int");
    }

    public final T newInstance() {
        return this.zzvn.newInstance(this.zzvf);
    }

    public final void zzb(T r18, com.google.android.gms.internal.places.zzix r19, com.google.android.gms.internal.places.zzgl r20) throws java.io.IOException {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/952562199.run(Unknown Source)
*/
        /*
        r17 = this;
        r1 = r17;
        r2 = r18;
        r0 = r19;
        r10 = r20;
        if (r10 == 0) goto L_0x054b;
    L_0x000a:
        r11 = r1.zzvp;
        r12 = r1.zzvq;
        r13 = 0;
        r3 = r13;
        r14 = r3;
    L_0x0011:
        r15 = 0;
        r4 = r19.zzbg();	 Catch:{ all -> 0x0532 }
        r5 = r1.zzbl(r4);	 Catch:{ all -> 0x0532 }
        if (r5 >= 0) goto L_0x0089;
    L_0x001c:
        r5 = 2147483647; // 0x7fffffff float:NaN double:1.060997895E-314;
        if (r4 != r5) goto L_0x0039;
    L_0x0021:
        r0 = r1.zzvl;
        if (r0 == 0) goto L_0x0033;
    L_0x0025:
        r0 = r1.zzvl;
        r3 = r0.length;
    L_0x0028:
        if (r15 >= r3) goto L_0x0033;
    L_0x002a:
        r4 = r0[r15];
        r14 = r1.zzb(r2, r4, r14, r11);
        r15 = r15 + 1;
        goto L_0x0028;
    L_0x0033:
        if (r14 == 0) goto L_0x0038;
    L_0x0035:
        r11.zzg(r2, r14);
    L_0x0038:
        return;
    L_0x0039:
        r5 = r1.zzvg;	 Catch:{ all -> 0x0532 }
        if (r5 != 0) goto L_0x003f;	 Catch:{ all -> 0x0532 }
    L_0x003d:
        r5 = r13;	 Catch:{ all -> 0x0532 }
        goto L_0x0046;	 Catch:{ all -> 0x0532 }
    L_0x003f:
        r5 = r1.zzvf;	 Catch:{ all -> 0x0532 }
        r4 = r12.zzb(r10, r5, r4);	 Catch:{ all -> 0x0532 }
        r5 = r4;	 Catch:{ all -> 0x0532 }
    L_0x0046:
        if (r5 == 0) goto L_0x0061;	 Catch:{ all -> 0x0532 }
    L_0x0048:
        if (r3 != 0) goto L_0x004e;	 Catch:{ all -> 0x0532 }
    L_0x004a:
        r3 = r12.zzc(r2);	 Catch:{ all -> 0x0532 }
    L_0x004e:
        r16 = r3;	 Catch:{ all -> 0x0532 }
        r3 = r12;	 Catch:{ all -> 0x0532 }
        r4 = r19;	 Catch:{ all -> 0x0532 }
        r6 = r20;	 Catch:{ all -> 0x0532 }
        r7 = r16;	 Catch:{ all -> 0x0532 }
        r8 = r14;	 Catch:{ all -> 0x0532 }
        r9 = r11;	 Catch:{ all -> 0x0532 }
        r3 = r3.zzb(r4, r5, r6, r7, r8, r9);	 Catch:{ all -> 0x0532 }
        r14 = r3;	 Catch:{ all -> 0x0532 }
        r3 = r16;	 Catch:{ all -> 0x0532 }
        goto L_0x0011;	 Catch:{ all -> 0x0532 }
    L_0x0061:
        r11.zzb(r0);	 Catch:{ all -> 0x0532 }
        if (r14 != 0) goto L_0x006b;	 Catch:{ all -> 0x0532 }
    L_0x0066:
        r4 = r11.zzr(r2);	 Catch:{ all -> 0x0532 }
        r14 = r4;	 Catch:{ all -> 0x0532 }
    L_0x006b:
        r4 = r11.zzb(r14, r0);	 Catch:{ all -> 0x0532 }
        if (r4 != 0) goto L_0x0011;
    L_0x0071:
        r0 = r1.zzvl;
        if (r0 == 0) goto L_0x0083;
    L_0x0075:
        r0 = r1.zzvl;
        r3 = r0.length;
    L_0x0078:
        if (r15 >= r3) goto L_0x0083;
    L_0x007a:
        r4 = r0[r15];
        r14 = r1.zzb(r2, r4, r14, r11);
        r15 = r15 + 1;
        goto L_0x0078;
    L_0x0083:
        if (r14 == 0) goto L_0x0088;
    L_0x0085:
        r11.zzg(r2, r14);
    L_0x0088:
        return;
    L_0x0089:
        r6 = r1.zzbi(r5);	 Catch:{ all -> 0x0532 }
        r7 = 267386880; // 0xff00000 float:2.3665827E-29 double:1.321066716E-315;
        r7 = r7 & r6;
        r7 = r7 >>> 20;
        r8 = 1048575; // 0xfffff float:1.469367E-39 double:5.18065E-318;
        switch(r7) {
            case 0: goto L_0x04df;
            case 1: goto L_0x04d3;
            case 2: goto L_0x04c7;
            case 3: goto L_0x04bb;
            case 4: goto L_0x04af;
            case 5: goto L_0x04a3;
            case 6: goto L_0x0497;
            case 7: goto L_0x048b;
            case 8: goto L_0x0486;
            case 9: goto L_0x045b;
            case 10: goto L_0x0450;
            case 11: goto L_0x0445;
            case 12: goto L_0x042e;
            case 13: goto L_0x0423;
            case 14: goto L_0x0418;
            case 15: goto L_0x040d;
            case 16: goto L_0x0402;
            case 17: goto L_0x03d1;
            case 18: goto L_0x03c6;
            case 19: goto L_0x03bb;
            case 20: goto L_0x03b0;
            case 21: goto L_0x03a5;
            case 22: goto L_0x039a;
            case 23: goto L_0x038f;
            case 24: goto L_0x0384;
            case 25: goto L_0x0379;
            case 26: goto L_0x0357;
            case 27: goto L_0x0345;
            case 28: goto L_0x0337;
            case 29: goto L_0x032c;
            case 30: goto L_0x0316;
            case 31: goto L_0x030b;
            case 32: goto L_0x0300;
            case 33: goto L_0x02f5;
            case 34: goto L_0x02ea;
            case 35: goto L_0x02dc;
            case 36: goto L_0x02ce;
            case 37: goto L_0x02c0;
            case 38: goto L_0x02b2;
            case 39: goto L_0x02a4;
            case 40: goto L_0x0296;
            case 41: goto L_0x0288;
            case 42: goto L_0x027a;
            case 43: goto L_0x026c;
            case 44: goto L_0x025b;
            case 45: goto L_0x024d;
            case 46: goto L_0x023f;
            case 47: goto L_0x0231;
            case 48: goto L_0x0223;
            case 49: goto L_0x0211;
            case 50: goto L_0x01cf;
            case 51: goto L_0x01c0;
            case 52: goto L_0x01b1;
            case 53: goto L_0x01a2;
            case 54: goto L_0x0193;
            case 55: goto L_0x0184;
            case 56: goto L_0x0175;
            case 57: goto L_0x0166;
            case 58: goto L_0x0157;
            case 59: goto L_0x0152;
            case 60: goto L_0x0123;
            case 61: goto L_0x0119;
            case 62: goto L_0x010b;
            case 63: goto L_0x00ea;
            case 64: goto L_0x00dc;
            case 65: goto L_0x00ce;
            case 66: goto L_0x00c0;
            case 67: goto L_0x00b2;
            case 68: goto L_0x00a0;
            default: goto L_0x0098;
        };
    L_0x0098:
        if (r14 != 0) goto L_0x04ec;
    L_0x009a:
        r4 = r11.zzgo();	 Catch:{ zzhi -> 0x050a }
        goto L_0x04eb;	 Catch:{ zzhi -> 0x050a }
    L_0x00a0:
        r6 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r6 = (long) r6;	 Catch:{ zzhi -> 0x050a }
        r8 = r1.zzbf(r5);	 Catch:{ zzhi -> 0x050a }
        r8 = r0.zzd(r8, r10);	 Catch:{ zzhi -> 0x050a }
        com.google.android.gms.internal.places.zzjw.zzb(r2, r6, r8);	 Catch:{ zzhi -> 0x050a }
    L_0x00ad:
        r1.zzc(r2, r4, r5);	 Catch:{ zzhi -> 0x050a }
        goto L_0x0011;	 Catch:{ zzhi -> 0x050a }
    L_0x00b2:
        r6 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r6 = (long) r6;	 Catch:{ zzhi -> 0x050a }
        r8 = r19.zzbv();	 Catch:{ zzhi -> 0x050a }
        r8 = java.lang.Long.valueOf(r8);	 Catch:{ zzhi -> 0x050a }
        com.google.android.gms.internal.places.zzjw.zzb(r2, r6, r8);	 Catch:{ zzhi -> 0x050a }
        goto L_0x00ad;	 Catch:{ zzhi -> 0x050a }
    L_0x00c0:
        r6 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r6 = (long) r6;	 Catch:{ zzhi -> 0x050a }
        r8 = r19.zzbu();	 Catch:{ zzhi -> 0x050a }
        r8 = java.lang.Integer.valueOf(r8);	 Catch:{ zzhi -> 0x050a }
        com.google.android.gms.internal.places.zzjw.zzb(r2, r6, r8);	 Catch:{ zzhi -> 0x050a }
        goto L_0x00ad;	 Catch:{ zzhi -> 0x050a }
    L_0x00ce:
        r6 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r6 = (long) r6;	 Catch:{ zzhi -> 0x050a }
        r8 = r19.zzbt();	 Catch:{ zzhi -> 0x050a }
        r8 = java.lang.Long.valueOf(r8);	 Catch:{ zzhi -> 0x050a }
        com.google.android.gms.internal.places.zzjw.zzb(r2, r6, r8);	 Catch:{ zzhi -> 0x050a }
        goto L_0x00ad;	 Catch:{ zzhi -> 0x050a }
    L_0x00dc:
        r6 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r6 = (long) r6;	 Catch:{ zzhi -> 0x050a }
        r8 = r19.zzbs();	 Catch:{ zzhi -> 0x050a }
        r8 = java.lang.Integer.valueOf(r8);	 Catch:{ zzhi -> 0x050a }
        com.google.android.gms.internal.places.zzjw.zzb(r2, r6, r8);	 Catch:{ zzhi -> 0x050a }
        goto L_0x00ad;	 Catch:{ zzhi -> 0x050a }
    L_0x00ea:
        r7 = r19.zzbr();	 Catch:{ zzhi -> 0x050a }
        r9 = r1.zzbh(r5);	 Catch:{ zzhi -> 0x050a }
        if (r9 == 0) goto L_0x0101;	 Catch:{ zzhi -> 0x050a }
    L_0x00f4:
        r9 = r9.zzi(r7);	 Catch:{ zzhi -> 0x050a }
        if (r9 == 0) goto L_0x00fb;	 Catch:{ zzhi -> 0x050a }
    L_0x00fa:
        goto L_0x0101;	 Catch:{ zzhi -> 0x050a }
    L_0x00fb:
        r4 = com.google.android.gms.internal.places.zzja.zzb(r4, r7, r14, r11);	 Catch:{ zzhi -> 0x050a }
        goto L_0x0329;	 Catch:{ zzhi -> 0x050a }
    L_0x0101:
        r6 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r8 = (long) r6;	 Catch:{ zzhi -> 0x050a }
        r6 = java.lang.Integer.valueOf(r7);	 Catch:{ zzhi -> 0x050a }
        com.google.android.gms.internal.places.zzjw.zzb(r2, r8, r6);	 Catch:{ zzhi -> 0x050a }
        goto L_0x00ad;	 Catch:{ zzhi -> 0x050a }
    L_0x010b:
        r6 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r6 = (long) r6;	 Catch:{ zzhi -> 0x050a }
        r8 = r19.zzbq();	 Catch:{ zzhi -> 0x050a }
        r8 = java.lang.Integer.valueOf(r8);	 Catch:{ zzhi -> 0x050a }
        com.google.android.gms.internal.places.zzjw.zzb(r2, r6, r8);	 Catch:{ zzhi -> 0x050a }
        goto L_0x00ad;	 Catch:{ zzhi -> 0x050a }
    L_0x0119:
        r6 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r6 = (long) r6;	 Catch:{ zzhi -> 0x050a }
        r8 = r19.zzbp();	 Catch:{ zzhi -> 0x050a }
        com.google.android.gms.internal.places.zzjw.zzb(r2, r6, r8);	 Catch:{ zzhi -> 0x050a }
        goto L_0x00ad;	 Catch:{ zzhi -> 0x050a }
    L_0x0123:
        r7 = r1.zzb(r2, r4, r5);	 Catch:{ zzhi -> 0x050a }
        if (r7 == 0) goto L_0x0140;	 Catch:{ zzhi -> 0x050a }
    L_0x0129:
        r6 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r6 = (long) r6;	 Catch:{ zzhi -> 0x050a }
        r8 = com.google.android.gms.internal.places.zzjw.zzq(r2, r6);	 Catch:{ zzhi -> 0x050a }
        r9 = r1.zzbf(r5);	 Catch:{ zzhi -> 0x050a }
        r9 = r0.zzb(r9, r10);	 Catch:{ zzhi -> 0x050a }
        r8 = com.google.android.gms.internal.places.zzhb.zzb(r8, r9);	 Catch:{ zzhi -> 0x050a }
        com.google.android.gms.internal.places.zzjw.zzb(r2, r6, r8);	 Catch:{ zzhi -> 0x050a }
        goto L_0x00ad;	 Catch:{ zzhi -> 0x050a }
    L_0x0140:
        r6 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r6 = (long) r6;	 Catch:{ zzhi -> 0x050a }
        r8 = r1.zzbf(r5);	 Catch:{ zzhi -> 0x050a }
        r8 = r0.zzb(r8, r10);	 Catch:{ zzhi -> 0x050a }
        com.google.android.gms.internal.places.zzjw.zzb(r2, r6, r8);	 Catch:{ zzhi -> 0x050a }
        r1.zzc(r2, r5);	 Catch:{ zzhi -> 0x050a }
        goto L_0x00ad;	 Catch:{ zzhi -> 0x050a }
    L_0x0152:
        r1.zzb(r2, r6, r0);	 Catch:{ zzhi -> 0x050a }
        goto L_0x00ad;	 Catch:{ zzhi -> 0x050a }
    L_0x0157:
        r6 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r6 = (long) r6;	 Catch:{ zzhi -> 0x050a }
        r8 = r19.zzbn();	 Catch:{ zzhi -> 0x050a }
        r8 = java.lang.Boolean.valueOf(r8);	 Catch:{ zzhi -> 0x050a }
        com.google.android.gms.internal.places.zzjw.zzb(r2, r6, r8);	 Catch:{ zzhi -> 0x050a }
        goto L_0x00ad;	 Catch:{ zzhi -> 0x050a }
    L_0x0166:
        r6 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r6 = (long) r6;	 Catch:{ zzhi -> 0x050a }
        r8 = r19.zzbm();	 Catch:{ zzhi -> 0x050a }
        r8 = java.lang.Integer.valueOf(r8);	 Catch:{ zzhi -> 0x050a }
        com.google.android.gms.internal.places.zzjw.zzb(r2, r6, r8);	 Catch:{ zzhi -> 0x050a }
        goto L_0x00ad;	 Catch:{ zzhi -> 0x050a }
    L_0x0175:
        r6 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r6 = (long) r6;	 Catch:{ zzhi -> 0x050a }
        r8 = r19.zzbl();	 Catch:{ zzhi -> 0x050a }
        r8 = java.lang.Long.valueOf(r8);	 Catch:{ zzhi -> 0x050a }
        com.google.android.gms.internal.places.zzjw.zzb(r2, r6, r8);	 Catch:{ zzhi -> 0x050a }
        goto L_0x00ad;	 Catch:{ zzhi -> 0x050a }
    L_0x0184:
        r6 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r6 = (long) r6;	 Catch:{ zzhi -> 0x050a }
        r8 = r19.zzbk();	 Catch:{ zzhi -> 0x050a }
        r8 = java.lang.Integer.valueOf(r8);	 Catch:{ zzhi -> 0x050a }
        com.google.android.gms.internal.places.zzjw.zzb(r2, r6, r8);	 Catch:{ zzhi -> 0x050a }
        goto L_0x00ad;	 Catch:{ zzhi -> 0x050a }
    L_0x0193:
        r6 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r6 = (long) r6;	 Catch:{ zzhi -> 0x050a }
        r8 = r19.zzbi();	 Catch:{ zzhi -> 0x050a }
        r8 = java.lang.Long.valueOf(r8);	 Catch:{ zzhi -> 0x050a }
        com.google.android.gms.internal.places.zzjw.zzb(r2, r6, r8);	 Catch:{ zzhi -> 0x050a }
        goto L_0x00ad;	 Catch:{ zzhi -> 0x050a }
    L_0x01a2:
        r6 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r6 = (long) r6;	 Catch:{ zzhi -> 0x050a }
        r8 = r19.zzbj();	 Catch:{ zzhi -> 0x050a }
        r8 = java.lang.Long.valueOf(r8);	 Catch:{ zzhi -> 0x050a }
        com.google.android.gms.internal.places.zzjw.zzb(r2, r6, r8);	 Catch:{ zzhi -> 0x050a }
        goto L_0x00ad;	 Catch:{ zzhi -> 0x050a }
    L_0x01b1:
        r6 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r6 = (long) r6;	 Catch:{ zzhi -> 0x050a }
        r8 = r19.readFloat();	 Catch:{ zzhi -> 0x050a }
        r8 = java.lang.Float.valueOf(r8);	 Catch:{ zzhi -> 0x050a }
        com.google.android.gms.internal.places.zzjw.zzb(r2, r6, r8);	 Catch:{ zzhi -> 0x050a }
        goto L_0x00ad;	 Catch:{ zzhi -> 0x050a }
    L_0x01c0:
        r6 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r6 = (long) r6;	 Catch:{ zzhi -> 0x050a }
        r8 = r19.readDouble();	 Catch:{ zzhi -> 0x050a }
        r8 = java.lang.Double.valueOf(r8);	 Catch:{ zzhi -> 0x050a }
        com.google.android.gms.internal.places.zzjw.zzb(r2, r6, r8);	 Catch:{ zzhi -> 0x050a }
        goto L_0x00ad;	 Catch:{ zzhi -> 0x050a }
    L_0x01cf:
        r4 = r1.zzbg(r5);	 Catch:{ zzhi -> 0x050a }
        r5 = r1.zzbi(r5);	 Catch:{ zzhi -> 0x050a }
        r5 = r5 & r8;	 Catch:{ zzhi -> 0x050a }
        r5 = (long) r5;	 Catch:{ zzhi -> 0x050a }
        r7 = com.google.android.gms.internal.places.zzjw.zzq(r2, r5);	 Catch:{ zzhi -> 0x050a }
        if (r7 != 0) goto L_0x01e9;	 Catch:{ zzhi -> 0x050a }
    L_0x01df:
        r7 = r1.zzvr;	 Catch:{ zzhi -> 0x050a }
        r7 = r7.zzl(r4);	 Catch:{ zzhi -> 0x050a }
        com.google.android.gms.internal.places.zzjw.zzb(r2, r5, r7);	 Catch:{ zzhi -> 0x050a }
        goto L_0x0200;	 Catch:{ zzhi -> 0x050a }
    L_0x01e9:
        r8 = r1.zzvr;	 Catch:{ zzhi -> 0x050a }
        r8 = r8.zzj(r7);	 Catch:{ zzhi -> 0x050a }
        if (r8 == 0) goto L_0x0200;	 Catch:{ zzhi -> 0x050a }
    L_0x01f1:
        r8 = r1.zzvr;	 Catch:{ zzhi -> 0x050a }
        r8 = r8.zzl(r4);	 Catch:{ zzhi -> 0x050a }
        r9 = r1.zzvr;	 Catch:{ zzhi -> 0x050a }
        r9.zzc(r8, r7);	 Catch:{ zzhi -> 0x050a }
        com.google.android.gms.internal.places.zzjw.zzb(r2, r5, r8);	 Catch:{ zzhi -> 0x050a }
        r7 = r8;	 Catch:{ zzhi -> 0x050a }
    L_0x0200:
        r5 = r1.zzvr;	 Catch:{ zzhi -> 0x050a }
        r5 = r5.zzh(r7);	 Catch:{ zzhi -> 0x050a }
        r6 = r1.zzvr;	 Catch:{ zzhi -> 0x050a }
        r4 = r6.zzm(r4);	 Catch:{ zzhi -> 0x050a }
        r0.zzb(r5, r4, r10);	 Catch:{ zzhi -> 0x050a }
        goto L_0x0011;	 Catch:{ zzhi -> 0x050a }
    L_0x0211:
        r4 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r6 = (long) r4;	 Catch:{ zzhi -> 0x050a }
        r4 = r1.zzbf(r5);	 Catch:{ zzhi -> 0x050a }
        r5 = r1.zzvo;	 Catch:{ zzhi -> 0x050a }
        r5 = r5.zzb(r2, r6);	 Catch:{ zzhi -> 0x050a }
        r0.zzc(r5, r4, r10);	 Catch:{ zzhi -> 0x050a }
        goto L_0x0011;	 Catch:{ zzhi -> 0x050a }
    L_0x0223:
        r4 = r1.zzvo;	 Catch:{ zzhi -> 0x050a }
        r5 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r5 = (long) r5;	 Catch:{ zzhi -> 0x050a }
        r4 = r4.zzb(r2, r5);	 Catch:{ zzhi -> 0x050a }
    L_0x022c:
        r0.zzt(r4);	 Catch:{ zzhi -> 0x050a }
        goto L_0x0011;	 Catch:{ zzhi -> 0x050a }
    L_0x0231:
        r4 = r1.zzvo;	 Catch:{ zzhi -> 0x050a }
        r5 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r5 = (long) r5;	 Catch:{ zzhi -> 0x050a }
        r4 = r4.zzb(r2, r5);	 Catch:{ zzhi -> 0x050a }
    L_0x023a:
        r0.zzs(r4);	 Catch:{ zzhi -> 0x050a }
        goto L_0x0011;	 Catch:{ zzhi -> 0x050a }
    L_0x023f:
        r4 = r1.zzvo;	 Catch:{ zzhi -> 0x050a }
        r5 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r5 = (long) r5;	 Catch:{ zzhi -> 0x050a }
        r4 = r4.zzb(r2, r5);	 Catch:{ zzhi -> 0x050a }
    L_0x0248:
        r0.zzr(r4);	 Catch:{ zzhi -> 0x050a }
        goto L_0x0011;	 Catch:{ zzhi -> 0x050a }
    L_0x024d:
        r4 = r1.zzvo;	 Catch:{ zzhi -> 0x050a }
        r5 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r5 = (long) r5;	 Catch:{ zzhi -> 0x050a }
        r4 = r4.zzb(r2, r5);	 Catch:{ zzhi -> 0x050a }
    L_0x0256:
        r0.zzq(r4);	 Catch:{ zzhi -> 0x050a }
        goto L_0x0011;	 Catch:{ zzhi -> 0x050a }
    L_0x025b:
        r7 = r1.zzvo;	 Catch:{ zzhi -> 0x050a }
        r6 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r8 = (long) r6;	 Catch:{ zzhi -> 0x050a }
        r6 = r7.zzb(r2, r8);	 Catch:{ zzhi -> 0x050a }
        r0.zzp(r6);	 Catch:{ zzhi -> 0x050a }
        r5 = r1.zzbh(r5);	 Catch:{ zzhi -> 0x050a }
        goto L_0x0325;	 Catch:{ zzhi -> 0x050a }
    L_0x026c:
        r4 = r1.zzvo;	 Catch:{ zzhi -> 0x050a }
        r5 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r5 = (long) r5;	 Catch:{ zzhi -> 0x050a }
        r4 = r4.zzb(r2, r5);	 Catch:{ zzhi -> 0x050a }
    L_0x0275:
        r0.zzo(r4);	 Catch:{ zzhi -> 0x050a }
        goto L_0x0011;	 Catch:{ zzhi -> 0x050a }
    L_0x027a:
        r4 = r1.zzvo;	 Catch:{ zzhi -> 0x050a }
        r5 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r5 = (long) r5;	 Catch:{ zzhi -> 0x050a }
        r4 = r4.zzb(r2, r5);	 Catch:{ zzhi -> 0x050a }
    L_0x0283:
        r0.zzl(r4);	 Catch:{ zzhi -> 0x050a }
        goto L_0x0011;	 Catch:{ zzhi -> 0x050a }
    L_0x0288:
        r4 = r1.zzvo;	 Catch:{ zzhi -> 0x050a }
        r5 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r5 = (long) r5;	 Catch:{ zzhi -> 0x050a }
        r4 = r4.zzb(r2, r5);	 Catch:{ zzhi -> 0x050a }
    L_0x0291:
        r0.zzk(r4);	 Catch:{ zzhi -> 0x050a }
        goto L_0x0011;	 Catch:{ zzhi -> 0x050a }
    L_0x0296:
        r4 = r1.zzvo;	 Catch:{ zzhi -> 0x050a }
        r5 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r5 = (long) r5;	 Catch:{ zzhi -> 0x050a }
        r4 = r4.zzb(r2, r5);	 Catch:{ zzhi -> 0x050a }
    L_0x029f:
        r0.zzj(r4);	 Catch:{ zzhi -> 0x050a }
        goto L_0x0011;	 Catch:{ zzhi -> 0x050a }
    L_0x02a4:
        r4 = r1.zzvo;	 Catch:{ zzhi -> 0x050a }
        r5 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r5 = (long) r5;	 Catch:{ zzhi -> 0x050a }
        r4 = r4.zzb(r2, r5);	 Catch:{ zzhi -> 0x050a }
    L_0x02ad:
        r0.zzi(r4);	 Catch:{ zzhi -> 0x050a }
        goto L_0x0011;	 Catch:{ zzhi -> 0x050a }
    L_0x02b2:
        r4 = r1.zzvo;	 Catch:{ zzhi -> 0x050a }
        r5 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r5 = (long) r5;	 Catch:{ zzhi -> 0x050a }
        r4 = r4.zzb(r2, r5);	 Catch:{ zzhi -> 0x050a }
    L_0x02bb:
        r0.zzg(r4);	 Catch:{ zzhi -> 0x050a }
        goto L_0x0011;	 Catch:{ zzhi -> 0x050a }
    L_0x02c0:
        r4 = r1.zzvo;	 Catch:{ zzhi -> 0x050a }
        r5 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r5 = (long) r5;	 Catch:{ zzhi -> 0x050a }
        r4 = r4.zzb(r2, r5);	 Catch:{ zzhi -> 0x050a }
    L_0x02c9:
        r0.zzh(r4);	 Catch:{ zzhi -> 0x050a }
        goto L_0x0011;	 Catch:{ zzhi -> 0x050a }
    L_0x02ce:
        r4 = r1.zzvo;	 Catch:{ zzhi -> 0x050a }
        r5 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r5 = (long) r5;	 Catch:{ zzhi -> 0x050a }
        r4 = r4.zzb(r2, r5);	 Catch:{ zzhi -> 0x050a }
    L_0x02d7:
        r0.zzf(r4);	 Catch:{ zzhi -> 0x050a }
        goto L_0x0011;	 Catch:{ zzhi -> 0x050a }
    L_0x02dc:
        r4 = r1.zzvo;	 Catch:{ zzhi -> 0x050a }
        r5 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r5 = (long) r5;	 Catch:{ zzhi -> 0x050a }
        r4 = r4.zzb(r2, r5);	 Catch:{ zzhi -> 0x050a }
    L_0x02e5:
        r0.zze(r4);	 Catch:{ zzhi -> 0x050a }
        goto L_0x0011;	 Catch:{ zzhi -> 0x050a }
    L_0x02ea:
        r4 = r1.zzvo;	 Catch:{ zzhi -> 0x050a }
        r5 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r5 = (long) r5;	 Catch:{ zzhi -> 0x050a }
        r4 = r4.zzb(r2, r5);	 Catch:{ zzhi -> 0x050a }
        goto L_0x022c;	 Catch:{ zzhi -> 0x050a }
    L_0x02f5:
        r4 = r1.zzvo;	 Catch:{ zzhi -> 0x050a }
        r5 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r5 = (long) r5;	 Catch:{ zzhi -> 0x050a }
        r4 = r4.zzb(r2, r5);	 Catch:{ zzhi -> 0x050a }
        goto L_0x023a;	 Catch:{ zzhi -> 0x050a }
    L_0x0300:
        r4 = r1.zzvo;	 Catch:{ zzhi -> 0x050a }
        r5 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r5 = (long) r5;	 Catch:{ zzhi -> 0x050a }
        r4 = r4.zzb(r2, r5);	 Catch:{ zzhi -> 0x050a }
        goto L_0x0248;	 Catch:{ zzhi -> 0x050a }
    L_0x030b:
        r4 = r1.zzvo;	 Catch:{ zzhi -> 0x050a }
        r5 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r5 = (long) r5;	 Catch:{ zzhi -> 0x050a }
        r4 = r4.zzb(r2, r5);	 Catch:{ zzhi -> 0x050a }
        goto L_0x0256;	 Catch:{ zzhi -> 0x050a }
    L_0x0316:
        r7 = r1.zzvo;	 Catch:{ zzhi -> 0x050a }
        r6 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r8 = (long) r6;	 Catch:{ zzhi -> 0x050a }
        r6 = r7.zzb(r2, r8);	 Catch:{ zzhi -> 0x050a }
        r0.zzp(r6);	 Catch:{ zzhi -> 0x050a }
        r5 = r1.zzbh(r5);	 Catch:{ zzhi -> 0x050a }
    L_0x0325:
        r4 = com.google.android.gms.internal.places.zzja.zzb(r4, r6, r5, r14, r11);	 Catch:{ zzhi -> 0x050a }
    L_0x0329:
        r14 = r4;	 Catch:{ zzhi -> 0x050a }
        goto L_0x0011;	 Catch:{ zzhi -> 0x050a }
    L_0x032c:
        r4 = r1.zzvo;	 Catch:{ zzhi -> 0x050a }
        r5 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r5 = (long) r5;	 Catch:{ zzhi -> 0x050a }
        r4 = r4.zzb(r2, r5);	 Catch:{ zzhi -> 0x050a }
        goto L_0x0275;	 Catch:{ zzhi -> 0x050a }
    L_0x0337:
        r4 = r1.zzvo;	 Catch:{ zzhi -> 0x050a }
        r5 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r5 = (long) r5;	 Catch:{ zzhi -> 0x050a }
        r4 = r4.zzb(r2, r5);	 Catch:{ zzhi -> 0x050a }
        r0.zzn(r4);	 Catch:{ zzhi -> 0x050a }
        goto L_0x0011;	 Catch:{ zzhi -> 0x050a }
    L_0x0345:
        r4 = r1.zzbf(r5);	 Catch:{ zzhi -> 0x050a }
        r5 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r5 = (long) r5;	 Catch:{ zzhi -> 0x050a }
        r7 = r1.zzvo;	 Catch:{ zzhi -> 0x050a }
        r5 = r7.zzb(r2, r5);	 Catch:{ zzhi -> 0x050a }
        r0.zzb(r5, r4, r10);	 Catch:{ zzhi -> 0x050a }
        goto L_0x0011;	 Catch:{ zzhi -> 0x050a }
    L_0x0357:
        r4 = zzbk(r6);	 Catch:{ zzhi -> 0x050a }
        if (r4 == 0) goto L_0x036b;	 Catch:{ zzhi -> 0x050a }
    L_0x035d:
        r4 = r1.zzvo;	 Catch:{ zzhi -> 0x050a }
        r5 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r5 = (long) r5;	 Catch:{ zzhi -> 0x050a }
        r4 = r4.zzb(r2, r5);	 Catch:{ zzhi -> 0x050a }
        r0.zzm(r4);	 Catch:{ zzhi -> 0x050a }
        goto L_0x0011;	 Catch:{ zzhi -> 0x050a }
    L_0x036b:
        r4 = r1.zzvo;	 Catch:{ zzhi -> 0x050a }
        r5 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r5 = (long) r5;	 Catch:{ zzhi -> 0x050a }
        r4 = r4.zzb(r2, r5);	 Catch:{ zzhi -> 0x050a }
        r0.readStringList(r4);	 Catch:{ zzhi -> 0x050a }
        goto L_0x0011;	 Catch:{ zzhi -> 0x050a }
    L_0x0379:
        r4 = r1.zzvo;	 Catch:{ zzhi -> 0x050a }
        r5 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r5 = (long) r5;	 Catch:{ zzhi -> 0x050a }
        r4 = r4.zzb(r2, r5);	 Catch:{ zzhi -> 0x050a }
        goto L_0x0283;	 Catch:{ zzhi -> 0x050a }
    L_0x0384:
        r4 = r1.zzvo;	 Catch:{ zzhi -> 0x050a }
        r5 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r5 = (long) r5;	 Catch:{ zzhi -> 0x050a }
        r4 = r4.zzb(r2, r5);	 Catch:{ zzhi -> 0x050a }
        goto L_0x0291;	 Catch:{ zzhi -> 0x050a }
    L_0x038f:
        r4 = r1.zzvo;	 Catch:{ zzhi -> 0x050a }
        r5 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r5 = (long) r5;	 Catch:{ zzhi -> 0x050a }
        r4 = r4.zzb(r2, r5);	 Catch:{ zzhi -> 0x050a }
        goto L_0x029f;	 Catch:{ zzhi -> 0x050a }
    L_0x039a:
        r4 = r1.zzvo;	 Catch:{ zzhi -> 0x050a }
        r5 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r5 = (long) r5;	 Catch:{ zzhi -> 0x050a }
        r4 = r4.zzb(r2, r5);	 Catch:{ zzhi -> 0x050a }
        goto L_0x02ad;	 Catch:{ zzhi -> 0x050a }
    L_0x03a5:
        r4 = r1.zzvo;	 Catch:{ zzhi -> 0x050a }
        r5 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r5 = (long) r5;	 Catch:{ zzhi -> 0x050a }
        r4 = r4.zzb(r2, r5);	 Catch:{ zzhi -> 0x050a }
        goto L_0x02bb;	 Catch:{ zzhi -> 0x050a }
    L_0x03b0:
        r4 = r1.zzvo;	 Catch:{ zzhi -> 0x050a }
        r5 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r5 = (long) r5;	 Catch:{ zzhi -> 0x050a }
        r4 = r4.zzb(r2, r5);	 Catch:{ zzhi -> 0x050a }
        goto L_0x02c9;	 Catch:{ zzhi -> 0x050a }
    L_0x03bb:
        r4 = r1.zzvo;	 Catch:{ zzhi -> 0x050a }
        r5 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r5 = (long) r5;	 Catch:{ zzhi -> 0x050a }
        r4 = r4.zzb(r2, r5);	 Catch:{ zzhi -> 0x050a }
        goto L_0x02d7;	 Catch:{ zzhi -> 0x050a }
    L_0x03c6:
        r4 = r1.zzvo;	 Catch:{ zzhi -> 0x050a }
        r5 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r5 = (long) r5;	 Catch:{ zzhi -> 0x050a }
        r4 = r4.zzb(r2, r5);	 Catch:{ zzhi -> 0x050a }
        goto L_0x02e5;	 Catch:{ zzhi -> 0x050a }
    L_0x03d1:
        r4 = r1.zzb(r2, r5);	 Catch:{ zzhi -> 0x050a }
        if (r4 == 0) goto L_0x03ef;	 Catch:{ zzhi -> 0x050a }
    L_0x03d7:
        r4 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r6 = (long) r4;	 Catch:{ zzhi -> 0x050a }
        r4 = com.google.android.gms.internal.places.zzjw.zzq(r2, r6);	 Catch:{ zzhi -> 0x050a }
        r5 = r1.zzbf(r5);	 Catch:{ zzhi -> 0x050a }
        r5 = r0.zzd(r5, r10);	 Catch:{ zzhi -> 0x050a }
        r4 = com.google.android.gms.internal.places.zzhb.zzb(r4, r5);	 Catch:{ zzhi -> 0x050a }
    L_0x03ea:
        com.google.android.gms.internal.places.zzjw.zzb(r2, r6, r4);	 Catch:{ zzhi -> 0x050a }
        goto L_0x0011;	 Catch:{ zzhi -> 0x050a }
    L_0x03ef:
        r4 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r6 = (long) r4;	 Catch:{ zzhi -> 0x050a }
        r4 = r1.zzbf(r5);	 Catch:{ zzhi -> 0x050a }
        r4 = r0.zzd(r4, r10);	 Catch:{ zzhi -> 0x050a }
        com.google.android.gms.internal.places.zzjw.zzb(r2, r6, r4);	 Catch:{ zzhi -> 0x050a }
    L_0x03fd:
        r1.zzc(r2, r5);	 Catch:{ zzhi -> 0x050a }
        goto L_0x0011;	 Catch:{ zzhi -> 0x050a }
    L_0x0402:
        r4 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r6 = (long) r4;	 Catch:{ zzhi -> 0x050a }
        r8 = r19.zzbv();	 Catch:{ zzhi -> 0x050a }
        com.google.android.gms.internal.places.zzjw.zzb(r2, r6, r8);	 Catch:{ zzhi -> 0x050a }
        goto L_0x03fd;	 Catch:{ zzhi -> 0x050a }
    L_0x040d:
        r4 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r6 = (long) r4;	 Catch:{ zzhi -> 0x050a }
        r4 = r19.zzbu();	 Catch:{ zzhi -> 0x050a }
        com.google.android.gms.internal.places.zzjw.zzc(r2, r6, r4);	 Catch:{ zzhi -> 0x050a }
        goto L_0x03fd;	 Catch:{ zzhi -> 0x050a }
    L_0x0418:
        r4 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r6 = (long) r4;	 Catch:{ zzhi -> 0x050a }
        r8 = r19.zzbt();	 Catch:{ zzhi -> 0x050a }
        com.google.android.gms.internal.places.zzjw.zzb(r2, r6, r8);	 Catch:{ zzhi -> 0x050a }
        goto L_0x03fd;	 Catch:{ zzhi -> 0x050a }
    L_0x0423:
        r4 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r6 = (long) r4;	 Catch:{ zzhi -> 0x050a }
        r4 = r19.zzbs();	 Catch:{ zzhi -> 0x050a }
        com.google.android.gms.internal.places.zzjw.zzc(r2, r6, r4);	 Catch:{ zzhi -> 0x050a }
        goto L_0x03fd;	 Catch:{ zzhi -> 0x050a }
    L_0x042e:
        r7 = r19.zzbr();	 Catch:{ zzhi -> 0x050a }
        r9 = r1.zzbh(r5);	 Catch:{ zzhi -> 0x050a }
        if (r9 == 0) goto L_0x043e;	 Catch:{ zzhi -> 0x050a }
    L_0x0438:
        r9 = r9.zzi(r7);	 Catch:{ zzhi -> 0x050a }
        if (r9 == 0) goto L_0x00fb;	 Catch:{ zzhi -> 0x050a }
    L_0x043e:
        r4 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r8 = (long) r4;	 Catch:{ zzhi -> 0x050a }
        com.google.android.gms.internal.places.zzjw.zzc(r2, r8, r7);	 Catch:{ zzhi -> 0x050a }
        goto L_0x03fd;	 Catch:{ zzhi -> 0x050a }
    L_0x0445:
        r4 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r6 = (long) r4;	 Catch:{ zzhi -> 0x050a }
        r4 = r19.zzbq();	 Catch:{ zzhi -> 0x050a }
        com.google.android.gms.internal.places.zzjw.zzc(r2, r6, r4);	 Catch:{ zzhi -> 0x050a }
        goto L_0x03fd;	 Catch:{ zzhi -> 0x050a }
    L_0x0450:
        r4 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r6 = (long) r4;	 Catch:{ zzhi -> 0x050a }
        r4 = r19.zzbp();	 Catch:{ zzhi -> 0x050a }
        com.google.android.gms.internal.places.zzjw.zzb(r2, r6, r4);	 Catch:{ zzhi -> 0x050a }
        goto L_0x03fd;	 Catch:{ zzhi -> 0x050a }
    L_0x045b:
        r4 = r1.zzb(r2, r5);	 Catch:{ zzhi -> 0x050a }
        if (r4 == 0) goto L_0x0476;	 Catch:{ zzhi -> 0x050a }
    L_0x0461:
        r4 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r6 = (long) r4;	 Catch:{ zzhi -> 0x050a }
        r4 = com.google.android.gms.internal.places.zzjw.zzq(r2, r6);	 Catch:{ zzhi -> 0x050a }
        r5 = r1.zzbf(r5);	 Catch:{ zzhi -> 0x050a }
        r5 = r0.zzb(r5, r10);	 Catch:{ zzhi -> 0x050a }
        r4 = com.google.android.gms.internal.places.zzhb.zzb(r4, r5);	 Catch:{ zzhi -> 0x050a }
        goto L_0x03ea;	 Catch:{ zzhi -> 0x050a }
    L_0x0476:
        r4 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r6 = (long) r4;	 Catch:{ zzhi -> 0x050a }
        r4 = r1.zzbf(r5);	 Catch:{ zzhi -> 0x050a }
        r4 = r0.zzb(r4, r10);	 Catch:{ zzhi -> 0x050a }
        com.google.android.gms.internal.places.zzjw.zzb(r2, r6, r4);	 Catch:{ zzhi -> 0x050a }
        goto L_0x03fd;	 Catch:{ zzhi -> 0x050a }
    L_0x0486:
        r1.zzb(r2, r6, r0);	 Catch:{ zzhi -> 0x050a }
        goto L_0x03fd;	 Catch:{ zzhi -> 0x050a }
    L_0x048b:
        r4 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r6 = (long) r4;	 Catch:{ zzhi -> 0x050a }
        r4 = r19.zzbn();	 Catch:{ zzhi -> 0x050a }
        com.google.android.gms.internal.places.zzjw.zzb(r2, r6, r4);	 Catch:{ zzhi -> 0x050a }
        goto L_0x03fd;	 Catch:{ zzhi -> 0x050a }
    L_0x0497:
        r4 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r6 = (long) r4;	 Catch:{ zzhi -> 0x050a }
        r4 = r19.zzbm();	 Catch:{ zzhi -> 0x050a }
        com.google.android.gms.internal.places.zzjw.zzc(r2, r6, r4);	 Catch:{ zzhi -> 0x050a }
        goto L_0x03fd;	 Catch:{ zzhi -> 0x050a }
    L_0x04a3:
        r4 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r6 = (long) r4;	 Catch:{ zzhi -> 0x050a }
        r8 = r19.zzbl();	 Catch:{ zzhi -> 0x050a }
        com.google.android.gms.internal.places.zzjw.zzb(r2, r6, r8);	 Catch:{ zzhi -> 0x050a }
        goto L_0x03fd;	 Catch:{ zzhi -> 0x050a }
    L_0x04af:
        r4 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r6 = (long) r4;	 Catch:{ zzhi -> 0x050a }
        r4 = r19.zzbk();	 Catch:{ zzhi -> 0x050a }
        com.google.android.gms.internal.places.zzjw.zzc(r2, r6, r4);	 Catch:{ zzhi -> 0x050a }
        goto L_0x03fd;	 Catch:{ zzhi -> 0x050a }
    L_0x04bb:
        r4 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r6 = (long) r4;	 Catch:{ zzhi -> 0x050a }
        r8 = r19.zzbi();	 Catch:{ zzhi -> 0x050a }
        com.google.android.gms.internal.places.zzjw.zzb(r2, r6, r8);	 Catch:{ zzhi -> 0x050a }
        goto L_0x03fd;	 Catch:{ zzhi -> 0x050a }
    L_0x04c7:
        r4 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r6 = (long) r4;	 Catch:{ zzhi -> 0x050a }
        r8 = r19.zzbj();	 Catch:{ zzhi -> 0x050a }
        com.google.android.gms.internal.places.zzjw.zzb(r2, r6, r8);	 Catch:{ zzhi -> 0x050a }
        goto L_0x03fd;	 Catch:{ zzhi -> 0x050a }
    L_0x04d3:
        r4 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r6 = (long) r4;	 Catch:{ zzhi -> 0x050a }
        r4 = r19.readFloat();	 Catch:{ zzhi -> 0x050a }
        com.google.android.gms.internal.places.zzjw.zzb(r2, r6, r4);	 Catch:{ zzhi -> 0x050a }
        goto L_0x03fd;	 Catch:{ zzhi -> 0x050a }
    L_0x04df:
        r4 = r6 & r8;	 Catch:{ zzhi -> 0x050a }
        r6 = (long) r4;	 Catch:{ zzhi -> 0x050a }
        r8 = r19.readDouble();	 Catch:{ zzhi -> 0x050a }
        com.google.android.gms.internal.places.zzjw.zzb(r2, r6, r8);	 Catch:{ zzhi -> 0x050a }
        goto L_0x03fd;	 Catch:{ zzhi -> 0x050a }
    L_0x04eb:
        r14 = r4;	 Catch:{ zzhi -> 0x050a }
    L_0x04ec:
        r4 = r11.zzb(r14, r0);	 Catch:{ zzhi -> 0x050a }
        if (r4 != 0) goto L_0x0011;
    L_0x04f2:
        r0 = r1.zzvl;
        if (r0 == 0) goto L_0x0504;
    L_0x04f6:
        r0 = r1.zzvl;
        r3 = r0.length;
    L_0x04f9:
        if (r15 >= r3) goto L_0x0504;
    L_0x04fb:
        r4 = r0[r15];
        r14 = r1.zzb(r2, r4, r14, r11);
        r15 = r15 + 1;
        goto L_0x04f9;
    L_0x0504:
        if (r14 == 0) goto L_0x0509;
    L_0x0506:
        r11.zzg(r2, r14);
    L_0x0509:
        return;
    L_0x050a:
        r11.zzb(r0);	 Catch:{ all -> 0x0532 }
        if (r14 != 0) goto L_0x0514;	 Catch:{ all -> 0x0532 }
    L_0x050f:
        r4 = r11.zzr(r2);	 Catch:{ all -> 0x0532 }
        r14 = r4;	 Catch:{ all -> 0x0532 }
    L_0x0514:
        r4 = r11.zzb(r14, r0);	 Catch:{ all -> 0x0532 }
        if (r4 != 0) goto L_0x0011;
    L_0x051a:
        r0 = r1.zzvl;
        if (r0 == 0) goto L_0x052c;
    L_0x051e:
        r0 = r1.zzvl;
        r3 = r0.length;
    L_0x0521:
        if (r15 >= r3) goto L_0x052c;
    L_0x0523:
        r4 = r0[r15];
        r14 = r1.zzb(r2, r4, r14, r11);
        r15 = r15 + 1;
        goto L_0x0521;
    L_0x052c:
        if (r14 == 0) goto L_0x0531;
    L_0x052e:
        r11.zzg(r2, r14);
    L_0x0531:
        return;
    L_0x0532:
        r0 = move-exception;
        r3 = r1.zzvl;
        if (r3 == 0) goto L_0x0545;
    L_0x0537:
        r3 = r1.zzvl;
        r4 = r3.length;
    L_0x053a:
        if (r15 >= r4) goto L_0x0545;
    L_0x053c:
        r5 = r3[r15];
        r14 = r1.zzb(r2, r5, r14, r11);
        r15 = r15 + 1;
        goto L_0x053a;
    L_0x0545:
        if (r14 == 0) goto L_0x054a;
    L_0x0547:
        r11.zzg(r2, r14);
    L_0x054a:
        throw r0;
    L_0x054b:
        r0 = new java.lang.NullPointerException;
        r0.<init>();
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.places.zzil.zzb(java.lang.Object, com.google.android.gms.internal.places.zzix, com.google.android.gms.internal.places.zzgl):void");
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void zzb(T r14, com.google.android.gms.internal.places.zzkk r15) throws java.io.IOException {
        /*
        r13 = this;
        r0 = r15.zzcv();
        r1 = com.google.android.gms.internal.places.zzgz.zzh.zzth;
        r2 = 267386880; // 0xff00000 float:2.3665827E-29 double:1.321066716E-315;
        r3 = 0;
        r4 = 1;
        r5 = 0;
        r6 = 1048575; // 0xfffff float:1.469367E-39 double:5.18065E-318;
        if (r0 != r1) goto L_0x04cf;
    L_0x0010:
        r0 = r13.zzvp;
        zzb(r0, r14, r15);
        r0 = r13.zzvg;
        if (r0 == 0) goto L_0x0030;
    L_0x0019:
        r0 = r13.zzvq;
        r0 = r0.zzb(r14);
        r1 = r0.isEmpty();
        if (r1 != 0) goto L_0x0030;
    L_0x0025:
        r0 = r0.descendingIterator();
        r1 = r0.next();
        r1 = (java.util.Map.Entry) r1;
        goto L_0x0032;
    L_0x0030:
        r0 = r3;
        r1 = r0;
    L_0x0032:
        r7 = r13.zzva;
        r7 = r7.length;
        r7 = r7 + -4;
    L_0x0037:
        if (r7 < 0) goto L_0x04b7;
    L_0x0039:
        r8 = r13.zzbi(r7);
        r9 = r13.zzva;
        r9 = r9[r7];
    L_0x0041:
        if (r1 == 0) goto L_0x005f;
    L_0x0043:
        r10 = r13.zzvq;
        r10 = r10.zzb(r1);
        if (r10 <= r9) goto L_0x005f;
    L_0x004b:
        r10 = r13.zzvq;
        r10.zzb(r15, r1);
        r1 = r0.hasNext();
        if (r1 == 0) goto L_0x005d;
    L_0x0056:
        r1 = r0.next();
        r1 = (java.util.Map.Entry) r1;
        goto L_0x0041;
    L_0x005d:
        r1 = r3;
        goto L_0x0041;
    L_0x005f:
        r10 = r8 & r2;
        r10 = r10 >>> 20;
        switch(r10) {
            case 0: goto L_0x04a4;
            case 1: goto L_0x0494;
            case 2: goto L_0x0484;
            case 3: goto L_0x0474;
            case 4: goto L_0x0464;
            case 5: goto L_0x0454;
            case 6: goto L_0x0444;
            case 7: goto L_0x0433;
            case 8: goto L_0x0422;
            case 9: goto L_0x040d;
            case 10: goto L_0x03fa;
            case 11: goto L_0x03e9;
            case 12: goto L_0x03d8;
            case 13: goto L_0x03c7;
            case 14: goto L_0x03b6;
            case 15: goto L_0x03a5;
            case 16: goto L_0x0394;
            case 17: goto L_0x037f;
            case 18: goto L_0x036e;
            case 19: goto L_0x035d;
            case 20: goto L_0x034c;
            case 21: goto L_0x033b;
            case 22: goto L_0x032a;
            case 23: goto L_0x0319;
            case 24: goto L_0x0308;
            case 25: goto L_0x02f7;
            case 26: goto L_0x02e6;
            case 27: goto L_0x02d1;
            case 28: goto L_0x02c0;
            case 29: goto L_0x02af;
            case 30: goto L_0x029e;
            case 31: goto L_0x028d;
            case 32: goto L_0x027c;
            case 33: goto L_0x026b;
            case 34: goto L_0x025a;
            case 35: goto L_0x0249;
            case 36: goto L_0x0238;
            case 37: goto L_0x0227;
            case 38: goto L_0x0216;
            case 39: goto L_0x0205;
            case 40: goto L_0x01f4;
            case 41: goto L_0x01e3;
            case 42: goto L_0x01d2;
            case 43: goto L_0x01c1;
            case 44: goto L_0x01b0;
            case 45: goto L_0x019f;
            case 46: goto L_0x018e;
            case 47: goto L_0x017d;
            case 48: goto L_0x016c;
            case 49: goto L_0x0157;
            case 50: goto L_0x014c;
            case 51: goto L_0x013e;
            case 52: goto L_0x0130;
            case 53: goto L_0x0122;
            case 54: goto L_0x0114;
            case 55: goto L_0x0106;
            case 56: goto L_0x00f8;
            case 57: goto L_0x00ea;
            case 58: goto L_0x00dc;
            case 59: goto L_0x00d4;
            case 60: goto L_0x00cc;
            case 61: goto L_0x00c4;
            case 62: goto L_0x00b6;
            case 63: goto L_0x00a8;
            case 64: goto L_0x009a;
            case 65: goto L_0x008c;
            case 66: goto L_0x007e;
            case 67: goto L_0x0070;
            case 68: goto L_0x0068;
            default: goto L_0x0066;
        };
    L_0x0066:
        goto L_0x04b3;
    L_0x0068:
        r10 = r13.zzb(r14, r9, r7);
        if (r10 == 0) goto L_0x04b3;
    L_0x006e:
        goto L_0x0385;
    L_0x0070:
        r10 = r13.zzb(r14, r9, r7);
        if (r10 == 0) goto L_0x04b3;
    L_0x0076:
        r8 = r8 & r6;
        r10 = (long) r8;
        r10 = zzj(r14, r10);
        goto L_0x03a0;
    L_0x007e:
        r10 = r13.zzb(r14, r9, r7);
        if (r10 == 0) goto L_0x04b3;
    L_0x0084:
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = zzi(r14, r10);
        goto L_0x03b1;
    L_0x008c:
        r10 = r13.zzb(r14, r9, r7);
        if (r10 == 0) goto L_0x04b3;
    L_0x0092:
        r8 = r8 & r6;
        r10 = (long) r8;
        r10 = zzj(r14, r10);
        goto L_0x03c2;
    L_0x009a:
        r10 = r13.zzb(r14, r9, r7);
        if (r10 == 0) goto L_0x04b3;
    L_0x00a0:
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = zzi(r14, r10);
        goto L_0x03d3;
    L_0x00a8:
        r10 = r13.zzb(r14, r9, r7);
        if (r10 == 0) goto L_0x04b3;
    L_0x00ae:
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = zzi(r14, r10);
        goto L_0x03e4;
    L_0x00b6:
        r10 = r13.zzb(r14, r9, r7);
        if (r10 == 0) goto L_0x04b3;
    L_0x00bc:
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = zzi(r14, r10);
        goto L_0x03f5;
    L_0x00c4:
        r10 = r13.zzb(r14, r9, r7);
        if (r10 == 0) goto L_0x04b3;
    L_0x00ca:
        goto L_0x0400;
    L_0x00cc:
        r10 = r13.zzb(r14, r9, r7);
        if (r10 == 0) goto L_0x04b3;
    L_0x00d2:
        goto L_0x0413;
    L_0x00d4:
        r10 = r13.zzb(r14, r9, r7);
        if (r10 == 0) goto L_0x04b3;
    L_0x00da:
        goto L_0x0428;
    L_0x00dc:
        r10 = r13.zzb(r14, r9, r7);
        if (r10 == 0) goto L_0x04b3;
    L_0x00e2:
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = zzk(r14, r10);
        goto L_0x043f;
    L_0x00ea:
        r10 = r13.zzb(r14, r9, r7);
        if (r10 == 0) goto L_0x04b3;
    L_0x00f0:
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = zzi(r14, r10);
        goto L_0x0450;
    L_0x00f8:
        r10 = r13.zzb(r14, r9, r7);
        if (r10 == 0) goto L_0x04b3;
    L_0x00fe:
        r8 = r8 & r6;
        r10 = (long) r8;
        r10 = zzj(r14, r10);
        goto L_0x0460;
    L_0x0106:
        r10 = r13.zzb(r14, r9, r7);
        if (r10 == 0) goto L_0x04b3;
    L_0x010c:
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = zzi(r14, r10);
        goto L_0x0470;
    L_0x0114:
        r10 = r13.zzb(r14, r9, r7);
        if (r10 == 0) goto L_0x04b3;
    L_0x011a:
        r8 = r8 & r6;
        r10 = (long) r8;
        r10 = zzj(r14, r10);
        goto L_0x0480;
    L_0x0122:
        r10 = r13.zzb(r14, r9, r7);
        if (r10 == 0) goto L_0x04b3;
    L_0x0128:
        r8 = r8 & r6;
        r10 = (long) r8;
        r10 = zzj(r14, r10);
        goto L_0x0490;
    L_0x0130:
        r10 = r13.zzb(r14, r9, r7);
        if (r10 == 0) goto L_0x04b3;
    L_0x0136:
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = zzh(r14, r10);
        goto L_0x04a0;
    L_0x013e:
        r10 = r13.zzb(r14, r9, r7);
        if (r10 == 0) goto L_0x04b3;
    L_0x0144:
        r8 = r8 & r6;
        r10 = (long) r8;
        r10 = zzg(r14, r10);
        goto L_0x04b0;
    L_0x014c:
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzq(r14, r10);
        r13.zzb(r15, r9, r8, r7);
        goto L_0x04b3;
    L_0x0157:
        r9 = r13.zzva;
        r9 = r9[r7];
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzq(r14, r10);
        r8 = (java.util.List) r8;
        r10 = r13.zzbf(r7);
        com.google.android.gms.internal.places.zzja.zzc(r9, r8, r15, r10);
        goto L_0x04b3;
    L_0x016c:
        r9 = r13.zzva;
        r9 = r9[r7];
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzq(r14, r10);
        r8 = (java.util.List) r8;
        com.google.android.gms.internal.places.zzja.zzf(r9, r8, r15, r4);
        goto L_0x04b3;
    L_0x017d:
        r9 = r13.zzva;
        r9 = r9[r7];
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzq(r14, r10);
        r8 = (java.util.List) r8;
        com.google.android.gms.internal.places.zzja.zzk(r9, r8, r15, r4);
        goto L_0x04b3;
    L_0x018e:
        r9 = r13.zzva;
        r9 = r9[r7];
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzq(r14, r10);
        r8 = (java.util.List) r8;
        com.google.android.gms.internal.places.zzja.zzh(r9, r8, r15, r4);
        goto L_0x04b3;
    L_0x019f:
        r9 = r13.zzva;
        r9 = r9[r7];
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzq(r14, r10);
        r8 = (java.util.List) r8;
        com.google.android.gms.internal.places.zzja.zzm(r9, r8, r15, r4);
        goto L_0x04b3;
    L_0x01b0:
        r9 = r13.zzva;
        r9 = r9[r7];
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzq(r14, r10);
        r8 = (java.util.List) r8;
        com.google.android.gms.internal.places.zzja.zzn(r9, r8, r15, r4);
        goto L_0x04b3;
    L_0x01c1:
        r9 = r13.zzva;
        r9 = r9[r7];
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzq(r14, r10);
        r8 = (java.util.List) r8;
        com.google.android.gms.internal.places.zzja.zzj(r9, r8, r15, r4);
        goto L_0x04b3;
    L_0x01d2:
        r9 = r13.zzva;
        r9 = r9[r7];
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzq(r14, r10);
        r8 = (java.util.List) r8;
        com.google.android.gms.internal.places.zzja.zzo(r9, r8, r15, r4);
        goto L_0x04b3;
    L_0x01e3:
        r9 = r13.zzva;
        r9 = r9[r7];
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzq(r14, r10);
        r8 = (java.util.List) r8;
        com.google.android.gms.internal.places.zzja.zzl(r9, r8, r15, r4);
        goto L_0x04b3;
    L_0x01f4:
        r9 = r13.zzva;
        r9 = r9[r7];
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzq(r14, r10);
        r8 = (java.util.List) r8;
        com.google.android.gms.internal.places.zzja.zzg(r9, r8, r15, r4);
        goto L_0x04b3;
    L_0x0205:
        r9 = r13.zzva;
        r9 = r9[r7];
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzq(r14, r10);
        r8 = (java.util.List) r8;
        com.google.android.gms.internal.places.zzja.zzi(r9, r8, r15, r4);
        goto L_0x04b3;
    L_0x0216:
        r9 = r13.zzva;
        r9 = r9[r7];
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzq(r14, r10);
        r8 = (java.util.List) r8;
        com.google.android.gms.internal.places.zzja.zze(r9, r8, r15, r4);
        goto L_0x04b3;
    L_0x0227:
        r9 = r13.zzva;
        r9 = r9[r7];
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzq(r14, r10);
        r8 = (java.util.List) r8;
        com.google.android.gms.internal.places.zzja.zzd(r9, r8, r15, r4);
        goto L_0x04b3;
    L_0x0238:
        r9 = r13.zzva;
        r9 = r9[r7];
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzq(r14, r10);
        r8 = (java.util.List) r8;
        com.google.android.gms.internal.places.zzja.zzc(r9, r8, r15, r4);
        goto L_0x04b3;
    L_0x0249:
        r9 = r13.zzva;
        r9 = r9[r7];
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzq(r14, r10);
        r8 = (java.util.List) r8;
        com.google.android.gms.internal.places.zzja.zzb(r9, r8, r15, r4);
        goto L_0x04b3;
    L_0x025a:
        r9 = r13.zzva;
        r9 = r9[r7];
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzq(r14, r10);
        r8 = (java.util.List) r8;
        com.google.android.gms.internal.places.zzja.zzf(r9, r8, r15, r5);
        goto L_0x04b3;
    L_0x026b:
        r9 = r13.zzva;
        r9 = r9[r7];
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzq(r14, r10);
        r8 = (java.util.List) r8;
        com.google.android.gms.internal.places.zzja.zzk(r9, r8, r15, r5);
        goto L_0x04b3;
    L_0x027c:
        r9 = r13.zzva;
        r9 = r9[r7];
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzq(r14, r10);
        r8 = (java.util.List) r8;
        com.google.android.gms.internal.places.zzja.zzh(r9, r8, r15, r5);
        goto L_0x04b3;
    L_0x028d:
        r9 = r13.zzva;
        r9 = r9[r7];
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzq(r14, r10);
        r8 = (java.util.List) r8;
        com.google.android.gms.internal.places.zzja.zzm(r9, r8, r15, r5);
        goto L_0x04b3;
    L_0x029e:
        r9 = r13.zzva;
        r9 = r9[r7];
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzq(r14, r10);
        r8 = (java.util.List) r8;
        com.google.android.gms.internal.places.zzja.zzn(r9, r8, r15, r5);
        goto L_0x04b3;
    L_0x02af:
        r9 = r13.zzva;
        r9 = r9[r7];
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzq(r14, r10);
        r8 = (java.util.List) r8;
        com.google.android.gms.internal.places.zzja.zzj(r9, r8, r15, r5);
        goto L_0x04b3;
    L_0x02c0:
        r9 = r13.zzva;
        r9 = r9[r7];
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzq(r14, r10);
        r8 = (java.util.List) r8;
        com.google.android.gms.internal.places.zzja.zzc(r9, r8, r15);
        goto L_0x04b3;
    L_0x02d1:
        r9 = r13.zzva;
        r9 = r9[r7];
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzq(r14, r10);
        r8 = (java.util.List) r8;
        r10 = r13.zzbf(r7);
        com.google.android.gms.internal.places.zzja.zzb(r9, r8, r15, r10);
        goto L_0x04b3;
    L_0x02e6:
        r9 = r13.zzva;
        r9 = r9[r7];
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzq(r14, r10);
        r8 = (java.util.List) r8;
        com.google.android.gms.internal.places.zzja.zzb(r9, r8, r15);
        goto L_0x04b3;
    L_0x02f7:
        r9 = r13.zzva;
        r9 = r9[r7];
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzq(r14, r10);
        r8 = (java.util.List) r8;
        com.google.android.gms.internal.places.zzja.zzo(r9, r8, r15, r5);
        goto L_0x04b3;
    L_0x0308:
        r9 = r13.zzva;
        r9 = r9[r7];
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzq(r14, r10);
        r8 = (java.util.List) r8;
        com.google.android.gms.internal.places.zzja.zzl(r9, r8, r15, r5);
        goto L_0x04b3;
    L_0x0319:
        r9 = r13.zzva;
        r9 = r9[r7];
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzq(r14, r10);
        r8 = (java.util.List) r8;
        com.google.android.gms.internal.places.zzja.zzg(r9, r8, r15, r5);
        goto L_0x04b3;
    L_0x032a:
        r9 = r13.zzva;
        r9 = r9[r7];
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzq(r14, r10);
        r8 = (java.util.List) r8;
        com.google.android.gms.internal.places.zzja.zzi(r9, r8, r15, r5);
        goto L_0x04b3;
    L_0x033b:
        r9 = r13.zzva;
        r9 = r9[r7];
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzq(r14, r10);
        r8 = (java.util.List) r8;
        com.google.android.gms.internal.places.zzja.zze(r9, r8, r15, r5);
        goto L_0x04b3;
    L_0x034c:
        r9 = r13.zzva;
        r9 = r9[r7];
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzq(r14, r10);
        r8 = (java.util.List) r8;
        com.google.android.gms.internal.places.zzja.zzd(r9, r8, r15, r5);
        goto L_0x04b3;
    L_0x035d:
        r9 = r13.zzva;
        r9 = r9[r7];
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzq(r14, r10);
        r8 = (java.util.List) r8;
        com.google.android.gms.internal.places.zzja.zzc(r9, r8, r15, r5);
        goto L_0x04b3;
    L_0x036e:
        r9 = r13.zzva;
        r9 = r9[r7];
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzq(r14, r10);
        r8 = (java.util.List) r8;
        com.google.android.gms.internal.places.zzja.zzb(r9, r8, r15, r5);
        goto L_0x04b3;
    L_0x037f:
        r10 = r13.zzb(r14, r7);
        if (r10 == 0) goto L_0x04b3;
    L_0x0385:
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzq(r14, r10);
        r10 = r13.zzbf(r7);
        r15.zzc(r9, r8, r10);
        goto L_0x04b3;
    L_0x0394:
        r10 = r13.zzb(r14, r7);
        if (r10 == 0) goto L_0x04b3;
    L_0x039a:
        r8 = r8 & r6;
        r10 = (long) r8;
        r10 = com.google.android.gms.internal.places.zzjw.zzm(r14, r10);
    L_0x03a0:
        r15.zzc(r9, r10);
        goto L_0x04b3;
    L_0x03a5:
        r10 = r13.zzb(r14, r7);
        if (r10 == 0) goto L_0x04b3;
    L_0x03ab:
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzl(r14, r10);
    L_0x03b1:
        r15.zzg(r9, r8);
        goto L_0x04b3;
    L_0x03b6:
        r10 = r13.zzb(r14, r7);
        if (r10 == 0) goto L_0x04b3;
    L_0x03bc:
        r8 = r8 & r6;
        r10 = (long) r8;
        r10 = com.google.android.gms.internal.places.zzjw.zzm(r14, r10);
    L_0x03c2:
        r15.zzk(r9, r10);
        goto L_0x04b3;
    L_0x03c7:
        r10 = r13.zzb(r14, r7);
        if (r10 == 0) goto L_0x04b3;
    L_0x03cd:
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzl(r14, r10);
    L_0x03d3:
        r15.zzo(r9, r8);
        goto L_0x04b3;
    L_0x03d8:
        r10 = r13.zzb(r14, r7);
        if (r10 == 0) goto L_0x04b3;
    L_0x03de:
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzl(r14, r10);
    L_0x03e4:
        r15.zzp(r9, r8);
        goto L_0x04b3;
    L_0x03e9:
        r10 = r13.zzb(r14, r7);
        if (r10 == 0) goto L_0x04b3;
    L_0x03ef:
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzl(r14, r10);
    L_0x03f5:
        r15.zzf(r9, r8);
        goto L_0x04b3;
    L_0x03fa:
        r10 = r13.zzb(r14, r7);
        if (r10 == 0) goto L_0x04b3;
    L_0x0400:
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzq(r14, r10);
        r8 = (com.google.android.gms.internal.places.zzfr) r8;
        r15.zzb(r9, r8);
        goto L_0x04b3;
    L_0x040d:
        r10 = r13.zzb(r14, r7);
        if (r10 == 0) goto L_0x04b3;
    L_0x0413:
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzq(r14, r10);
        r10 = r13.zzbf(r7);
        r15.zzb(r9, r8, r10);
        goto L_0x04b3;
    L_0x0422:
        r10 = r13.zzb(r14, r7);
        if (r10 == 0) goto L_0x04b3;
    L_0x0428:
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzq(r14, r10);
        zzb(r9, r8, r15);
        goto L_0x04b3;
    L_0x0433:
        r10 = r13.zzb(r14, r7);
        if (r10 == 0) goto L_0x04b3;
    L_0x0439:
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzn(r14, r10);
    L_0x043f:
        r15.zzc(r9, r8);
        goto L_0x04b3;
    L_0x0444:
        r10 = r13.zzb(r14, r7);
        if (r10 == 0) goto L_0x04b3;
    L_0x044a:
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzl(r14, r10);
    L_0x0450:
        r15.zzh(r9, r8);
        goto L_0x04b3;
    L_0x0454:
        r10 = r13.zzb(r14, r7);
        if (r10 == 0) goto L_0x04b3;
    L_0x045a:
        r8 = r8 & r6;
        r10 = (long) r8;
        r10 = com.google.android.gms.internal.places.zzjw.zzm(r14, r10);
    L_0x0460:
        r15.zzd(r9, r10);
        goto L_0x04b3;
    L_0x0464:
        r10 = r13.zzb(r14, r7);
        if (r10 == 0) goto L_0x04b3;
    L_0x046a:
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzl(r14, r10);
    L_0x0470:
        r15.zze(r9, r8);
        goto L_0x04b3;
    L_0x0474:
        r10 = r13.zzb(r14, r7);
        if (r10 == 0) goto L_0x04b3;
    L_0x047a:
        r8 = r8 & r6;
        r10 = (long) r8;
        r10 = com.google.android.gms.internal.places.zzjw.zzm(r14, r10);
    L_0x0480:
        r15.zzb(r9, r10);
        goto L_0x04b3;
    L_0x0484:
        r10 = r13.zzb(r14, r7);
        if (r10 == 0) goto L_0x04b3;
    L_0x048a:
        r8 = r8 & r6;
        r10 = (long) r8;
        r10 = com.google.android.gms.internal.places.zzjw.zzm(r14, r10);
    L_0x0490:
        r15.zzj(r9, r10);
        goto L_0x04b3;
    L_0x0494:
        r10 = r13.zzb(r14, r7);
        if (r10 == 0) goto L_0x04b3;
    L_0x049a:
        r8 = r8 & r6;
        r10 = (long) r8;
        r8 = com.google.android.gms.internal.places.zzjw.zzo(r14, r10);
    L_0x04a0:
        r15.zzc(r9, r8);
        goto L_0x04b3;
    L_0x04a4:
        r10 = r13.zzb(r14, r7);
        if (r10 == 0) goto L_0x04b3;
    L_0x04aa:
        r8 = r8 & r6;
        r10 = (long) r8;
        r10 = com.google.android.gms.internal.places.zzjw.zzp(r14, r10);
    L_0x04b0:
        r15.zzb(r9, r10);
    L_0x04b3:
        r7 = r7 + -4;
        goto L_0x0037;
    L_0x04b7:
        if (r1 == 0) goto L_0x04ce;
    L_0x04b9:
        r14 = r13.zzvq;
        r14.zzb(r15, r1);
        r14 = r0.hasNext();
        if (r14 == 0) goto L_0x04cc;
    L_0x04c4:
        r14 = r0.next();
        r14 = (java.util.Map.Entry) r14;
        r1 = r14;
        goto L_0x04b7;
    L_0x04cc:
        r1 = r3;
        goto L_0x04b7;
    L_0x04ce:
        return;
    L_0x04cf:
        r0 = r13.zzvi;
        if (r0 == 0) goto L_0x0992;
    L_0x04d3:
        r0 = r13.zzvg;
        if (r0 == 0) goto L_0x04ee;
    L_0x04d7:
        r0 = r13.zzvq;
        r0 = r0.zzb(r14);
        r1 = r0.isEmpty();
        if (r1 != 0) goto L_0x04ee;
    L_0x04e3:
        r0 = r0.iterator();
        r1 = r0.next();
        r1 = (java.util.Map.Entry) r1;
        goto L_0x04f0;
    L_0x04ee:
        r0 = r3;
        r1 = r0;
    L_0x04f0:
        r7 = r13.zzva;
        r7 = r7.length;
        r8 = r1;
        r1 = 0;
    L_0x04f5:
        if (r1 >= r7) goto L_0x0975;
    L_0x04f7:
        r9 = r13.zzbi(r1);
        r10 = r13.zzva;
        r10 = r10[r1];
    L_0x04ff:
        if (r8 == 0) goto L_0x051d;
    L_0x0501:
        r11 = r13.zzvq;
        r11 = r11.zzb(r8);
        if (r11 > r10) goto L_0x051d;
    L_0x0509:
        r11 = r13.zzvq;
        r11.zzb(r15, r8);
        r8 = r0.hasNext();
        if (r8 == 0) goto L_0x051b;
    L_0x0514:
        r8 = r0.next();
        r8 = (java.util.Map.Entry) r8;
        goto L_0x04ff;
    L_0x051b:
        r8 = r3;
        goto L_0x04ff;
    L_0x051d:
        r11 = r9 & r2;
        r11 = r11 >>> 20;
        switch(r11) {
            case 0: goto L_0x0962;
            case 1: goto L_0x0952;
            case 2: goto L_0x0942;
            case 3: goto L_0x0932;
            case 4: goto L_0x0922;
            case 5: goto L_0x0912;
            case 6: goto L_0x0902;
            case 7: goto L_0x08f1;
            case 8: goto L_0x08e0;
            case 9: goto L_0x08cb;
            case 10: goto L_0x08b8;
            case 11: goto L_0x08a7;
            case 12: goto L_0x0896;
            case 13: goto L_0x0885;
            case 14: goto L_0x0874;
            case 15: goto L_0x0863;
            case 16: goto L_0x0852;
            case 17: goto L_0x083d;
            case 18: goto L_0x082c;
            case 19: goto L_0x081b;
            case 20: goto L_0x080a;
            case 21: goto L_0x07f9;
            case 22: goto L_0x07e8;
            case 23: goto L_0x07d7;
            case 24: goto L_0x07c6;
            case 25: goto L_0x07b5;
            case 26: goto L_0x07a4;
            case 27: goto L_0x078f;
            case 28: goto L_0x077e;
            case 29: goto L_0x076d;
            case 30: goto L_0x075c;
            case 31: goto L_0x074b;
            case 32: goto L_0x073a;
            case 33: goto L_0x0729;
            case 34: goto L_0x0718;
            case 35: goto L_0x0707;
            case 36: goto L_0x06f6;
            case 37: goto L_0x06e5;
            case 38: goto L_0x06d4;
            case 39: goto L_0x06c3;
            case 40: goto L_0x06b2;
            case 41: goto L_0x06a1;
            case 42: goto L_0x0690;
            case 43: goto L_0x067f;
            case 44: goto L_0x066e;
            case 45: goto L_0x065d;
            case 46: goto L_0x064c;
            case 47: goto L_0x063b;
            case 48: goto L_0x062a;
            case 49: goto L_0x0615;
            case 50: goto L_0x060a;
            case 51: goto L_0x05fc;
            case 52: goto L_0x05ee;
            case 53: goto L_0x05e0;
            case 54: goto L_0x05d2;
            case 55: goto L_0x05c4;
            case 56: goto L_0x05b6;
            case 57: goto L_0x05a8;
            case 58: goto L_0x059a;
            case 59: goto L_0x0592;
            case 60: goto L_0x058a;
            case 61: goto L_0x0582;
            case 62: goto L_0x0574;
            case 63: goto L_0x0566;
            case 64: goto L_0x0558;
            case 65: goto L_0x054a;
            case 66: goto L_0x053c;
            case 67: goto L_0x052e;
            case 68: goto L_0x0526;
            default: goto L_0x0524;
        };
    L_0x0524:
        goto L_0x0971;
    L_0x0526:
        r11 = r13.zzb(r14, r10, r1);
        if (r11 == 0) goto L_0x0971;
    L_0x052c:
        goto L_0x0843;
    L_0x052e:
        r11 = r13.zzb(r14, r10, r1);
        if (r11 == 0) goto L_0x0971;
    L_0x0534:
        r9 = r9 & r6;
        r11 = (long) r9;
        r11 = zzj(r14, r11);
        goto L_0x085e;
    L_0x053c:
        r11 = r13.zzb(r14, r10, r1);
        if (r11 == 0) goto L_0x0971;
    L_0x0542:
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = zzi(r14, r11);
        goto L_0x086f;
    L_0x054a:
        r11 = r13.zzb(r14, r10, r1);
        if (r11 == 0) goto L_0x0971;
    L_0x0550:
        r9 = r9 & r6;
        r11 = (long) r9;
        r11 = zzj(r14, r11);
        goto L_0x0880;
    L_0x0558:
        r11 = r13.zzb(r14, r10, r1);
        if (r11 == 0) goto L_0x0971;
    L_0x055e:
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = zzi(r14, r11);
        goto L_0x0891;
    L_0x0566:
        r11 = r13.zzb(r14, r10, r1);
        if (r11 == 0) goto L_0x0971;
    L_0x056c:
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = zzi(r14, r11);
        goto L_0x08a2;
    L_0x0574:
        r11 = r13.zzb(r14, r10, r1);
        if (r11 == 0) goto L_0x0971;
    L_0x057a:
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = zzi(r14, r11);
        goto L_0x08b3;
    L_0x0582:
        r11 = r13.zzb(r14, r10, r1);
        if (r11 == 0) goto L_0x0971;
    L_0x0588:
        goto L_0x08be;
    L_0x058a:
        r11 = r13.zzb(r14, r10, r1);
        if (r11 == 0) goto L_0x0971;
    L_0x0590:
        goto L_0x08d1;
    L_0x0592:
        r11 = r13.zzb(r14, r10, r1);
        if (r11 == 0) goto L_0x0971;
    L_0x0598:
        goto L_0x08e6;
    L_0x059a:
        r11 = r13.zzb(r14, r10, r1);
        if (r11 == 0) goto L_0x0971;
    L_0x05a0:
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = zzk(r14, r11);
        goto L_0x08fd;
    L_0x05a8:
        r11 = r13.zzb(r14, r10, r1);
        if (r11 == 0) goto L_0x0971;
    L_0x05ae:
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = zzi(r14, r11);
        goto L_0x090e;
    L_0x05b6:
        r11 = r13.zzb(r14, r10, r1);
        if (r11 == 0) goto L_0x0971;
    L_0x05bc:
        r9 = r9 & r6;
        r11 = (long) r9;
        r11 = zzj(r14, r11);
        goto L_0x091e;
    L_0x05c4:
        r11 = r13.zzb(r14, r10, r1);
        if (r11 == 0) goto L_0x0971;
    L_0x05ca:
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = zzi(r14, r11);
        goto L_0x092e;
    L_0x05d2:
        r11 = r13.zzb(r14, r10, r1);
        if (r11 == 0) goto L_0x0971;
    L_0x05d8:
        r9 = r9 & r6;
        r11 = (long) r9;
        r11 = zzj(r14, r11);
        goto L_0x093e;
    L_0x05e0:
        r11 = r13.zzb(r14, r10, r1);
        if (r11 == 0) goto L_0x0971;
    L_0x05e6:
        r9 = r9 & r6;
        r11 = (long) r9;
        r11 = zzj(r14, r11);
        goto L_0x094e;
    L_0x05ee:
        r11 = r13.zzb(r14, r10, r1);
        if (r11 == 0) goto L_0x0971;
    L_0x05f4:
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = zzh(r14, r11);
        goto L_0x095e;
    L_0x05fc:
        r11 = r13.zzb(r14, r10, r1);
        if (r11 == 0) goto L_0x0971;
    L_0x0602:
        r9 = r9 & r6;
        r11 = (long) r9;
        r11 = zzg(r14, r11);
        goto L_0x096e;
    L_0x060a:
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzq(r14, r11);
        r13.zzb(r15, r10, r9, r1);
        goto L_0x0971;
    L_0x0615:
        r10 = r13.zzva;
        r10 = r10[r1];
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzq(r14, r11);
        r9 = (java.util.List) r9;
        r11 = r13.zzbf(r1);
        com.google.android.gms.internal.places.zzja.zzc(r10, r9, r15, r11);
        goto L_0x0971;
    L_0x062a:
        r10 = r13.zzva;
        r10 = r10[r1];
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzq(r14, r11);
        r9 = (java.util.List) r9;
        com.google.android.gms.internal.places.zzja.zzf(r10, r9, r15, r4);
        goto L_0x0971;
    L_0x063b:
        r10 = r13.zzva;
        r10 = r10[r1];
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzq(r14, r11);
        r9 = (java.util.List) r9;
        com.google.android.gms.internal.places.zzja.zzk(r10, r9, r15, r4);
        goto L_0x0971;
    L_0x064c:
        r10 = r13.zzva;
        r10 = r10[r1];
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzq(r14, r11);
        r9 = (java.util.List) r9;
        com.google.android.gms.internal.places.zzja.zzh(r10, r9, r15, r4);
        goto L_0x0971;
    L_0x065d:
        r10 = r13.zzva;
        r10 = r10[r1];
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzq(r14, r11);
        r9 = (java.util.List) r9;
        com.google.android.gms.internal.places.zzja.zzm(r10, r9, r15, r4);
        goto L_0x0971;
    L_0x066e:
        r10 = r13.zzva;
        r10 = r10[r1];
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzq(r14, r11);
        r9 = (java.util.List) r9;
        com.google.android.gms.internal.places.zzja.zzn(r10, r9, r15, r4);
        goto L_0x0971;
    L_0x067f:
        r10 = r13.zzva;
        r10 = r10[r1];
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzq(r14, r11);
        r9 = (java.util.List) r9;
        com.google.android.gms.internal.places.zzja.zzj(r10, r9, r15, r4);
        goto L_0x0971;
    L_0x0690:
        r10 = r13.zzva;
        r10 = r10[r1];
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzq(r14, r11);
        r9 = (java.util.List) r9;
        com.google.android.gms.internal.places.zzja.zzo(r10, r9, r15, r4);
        goto L_0x0971;
    L_0x06a1:
        r10 = r13.zzva;
        r10 = r10[r1];
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzq(r14, r11);
        r9 = (java.util.List) r9;
        com.google.android.gms.internal.places.zzja.zzl(r10, r9, r15, r4);
        goto L_0x0971;
    L_0x06b2:
        r10 = r13.zzva;
        r10 = r10[r1];
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzq(r14, r11);
        r9 = (java.util.List) r9;
        com.google.android.gms.internal.places.zzja.zzg(r10, r9, r15, r4);
        goto L_0x0971;
    L_0x06c3:
        r10 = r13.zzva;
        r10 = r10[r1];
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzq(r14, r11);
        r9 = (java.util.List) r9;
        com.google.android.gms.internal.places.zzja.zzi(r10, r9, r15, r4);
        goto L_0x0971;
    L_0x06d4:
        r10 = r13.zzva;
        r10 = r10[r1];
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzq(r14, r11);
        r9 = (java.util.List) r9;
        com.google.android.gms.internal.places.zzja.zze(r10, r9, r15, r4);
        goto L_0x0971;
    L_0x06e5:
        r10 = r13.zzva;
        r10 = r10[r1];
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzq(r14, r11);
        r9 = (java.util.List) r9;
        com.google.android.gms.internal.places.zzja.zzd(r10, r9, r15, r4);
        goto L_0x0971;
    L_0x06f6:
        r10 = r13.zzva;
        r10 = r10[r1];
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzq(r14, r11);
        r9 = (java.util.List) r9;
        com.google.android.gms.internal.places.zzja.zzc(r10, r9, r15, r4);
        goto L_0x0971;
    L_0x0707:
        r10 = r13.zzva;
        r10 = r10[r1];
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzq(r14, r11);
        r9 = (java.util.List) r9;
        com.google.android.gms.internal.places.zzja.zzb(r10, r9, r15, r4);
        goto L_0x0971;
    L_0x0718:
        r10 = r13.zzva;
        r10 = r10[r1];
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzq(r14, r11);
        r9 = (java.util.List) r9;
        com.google.android.gms.internal.places.zzja.zzf(r10, r9, r15, r5);
        goto L_0x0971;
    L_0x0729:
        r10 = r13.zzva;
        r10 = r10[r1];
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzq(r14, r11);
        r9 = (java.util.List) r9;
        com.google.android.gms.internal.places.zzja.zzk(r10, r9, r15, r5);
        goto L_0x0971;
    L_0x073a:
        r10 = r13.zzva;
        r10 = r10[r1];
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzq(r14, r11);
        r9 = (java.util.List) r9;
        com.google.android.gms.internal.places.zzja.zzh(r10, r9, r15, r5);
        goto L_0x0971;
    L_0x074b:
        r10 = r13.zzva;
        r10 = r10[r1];
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzq(r14, r11);
        r9 = (java.util.List) r9;
        com.google.android.gms.internal.places.zzja.zzm(r10, r9, r15, r5);
        goto L_0x0971;
    L_0x075c:
        r10 = r13.zzva;
        r10 = r10[r1];
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzq(r14, r11);
        r9 = (java.util.List) r9;
        com.google.android.gms.internal.places.zzja.zzn(r10, r9, r15, r5);
        goto L_0x0971;
    L_0x076d:
        r10 = r13.zzva;
        r10 = r10[r1];
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzq(r14, r11);
        r9 = (java.util.List) r9;
        com.google.android.gms.internal.places.zzja.zzj(r10, r9, r15, r5);
        goto L_0x0971;
    L_0x077e:
        r10 = r13.zzva;
        r10 = r10[r1];
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzq(r14, r11);
        r9 = (java.util.List) r9;
        com.google.android.gms.internal.places.zzja.zzc(r10, r9, r15);
        goto L_0x0971;
    L_0x078f:
        r10 = r13.zzva;
        r10 = r10[r1];
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzq(r14, r11);
        r9 = (java.util.List) r9;
        r11 = r13.zzbf(r1);
        com.google.android.gms.internal.places.zzja.zzb(r10, r9, r15, r11);
        goto L_0x0971;
    L_0x07a4:
        r10 = r13.zzva;
        r10 = r10[r1];
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzq(r14, r11);
        r9 = (java.util.List) r9;
        com.google.android.gms.internal.places.zzja.zzb(r10, r9, r15);
        goto L_0x0971;
    L_0x07b5:
        r10 = r13.zzva;
        r10 = r10[r1];
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzq(r14, r11);
        r9 = (java.util.List) r9;
        com.google.android.gms.internal.places.zzja.zzo(r10, r9, r15, r5);
        goto L_0x0971;
    L_0x07c6:
        r10 = r13.zzva;
        r10 = r10[r1];
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzq(r14, r11);
        r9 = (java.util.List) r9;
        com.google.android.gms.internal.places.zzja.zzl(r10, r9, r15, r5);
        goto L_0x0971;
    L_0x07d7:
        r10 = r13.zzva;
        r10 = r10[r1];
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzq(r14, r11);
        r9 = (java.util.List) r9;
        com.google.android.gms.internal.places.zzja.zzg(r10, r9, r15, r5);
        goto L_0x0971;
    L_0x07e8:
        r10 = r13.zzva;
        r10 = r10[r1];
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzq(r14, r11);
        r9 = (java.util.List) r9;
        com.google.android.gms.internal.places.zzja.zzi(r10, r9, r15, r5);
        goto L_0x0971;
    L_0x07f9:
        r10 = r13.zzva;
        r10 = r10[r1];
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzq(r14, r11);
        r9 = (java.util.List) r9;
        com.google.android.gms.internal.places.zzja.zze(r10, r9, r15, r5);
        goto L_0x0971;
    L_0x080a:
        r10 = r13.zzva;
        r10 = r10[r1];
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzq(r14, r11);
        r9 = (java.util.List) r9;
        com.google.android.gms.internal.places.zzja.zzd(r10, r9, r15, r5);
        goto L_0x0971;
    L_0x081b:
        r10 = r13.zzva;
        r10 = r10[r1];
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzq(r14, r11);
        r9 = (java.util.List) r9;
        com.google.android.gms.internal.places.zzja.zzc(r10, r9, r15, r5);
        goto L_0x0971;
    L_0x082c:
        r10 = r13.zzva;
        r10 = r10[r1];
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzq(r14, r11);
        r9 = (java.util.List) r9;
        com.google.android.gms.internal.places.zzja.zzb(r10, r9, r15, r5);
        goto L_0x0971;
    L_0x083d:
        r11 = r13.zzb(r14, r1);
        if (r11 == 0) goto L_0x0971;
    L_0x0843:
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzq(r14, r11);
        r11 = r13.zzbf(r1);
        r15.zzc(r10, r9, r11);
        goto L_0x0971;
    L_0x0852:
        r11 = r13.zzb(r14, r1);
        if (r11 == 0) goto L_0x0971;
    L_0x0858:
        r9 = r9 & r6;
        r11 = (long) r9;
        r11 = com.google.android.gms.internal.places.zzjw.zzm(r14, r11);
    L_0x085e:
        r15.zzc(r10, r11);
        goto L_0x0971;
    L_0x0863:
        r11 = r13.zzb(r14, r1);
        if (r11 == 0) goto L_0x0971;
    L_0x0869:
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzl(r14, r11);
    L_0x086f:
        r15.zzg(r10, r9);
        goto L_0x0971;
    L_0x0874:
        r11 = r13.zzb(r14, r1);
        if (r11 == 0) goto L_0x0971;
    L_0x087a:
        r9 = r9 & r6;
        r11 = (long) r9;
        r11 = com.google.android.gms.internal.places.zzjw.zzm(r14, r11);
    L_0x0880:
        r15.zzk(r10, r11);
        goto L_0x0971;
    L_0x0885:
        r11 = r13.zzb(r14, r1);
        if (r11 == 0) goto L_0x0971;
    L_0x088b:
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzl(r14, r11);
    L_0x0891:
        r15.zzo(r10, r9);
        goto L_0x0971;
    L_0x0896:
        r11 = r13.zzb(r14, r1);
        if (r11 == 0) goto L_0x0971;
    L_0x089c:
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzl(r14, r11);
    L_0x08a2:
        r15.zzp(r10, r9);
        goto L_0x0971;
    L_0x08a7:
        r11 = r13.zzb(r14, r1);
        if (r11 == 0) goto L_0x0971;
    L_0x08ad:
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzl(r14, r11);
    L_0x08b3:
        r15.zzf(r10, r9);
        goto L_0x0971;
    L_0x08b8:
        r11 = r13.zzb(r14, r1);
        if (r11 == 0) goto L_0x0971;
    L_0x08be:
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzq(r14, r11);
        r9 = (com.google.android.gms.internal.places.zzfr) r9;
        r15.zzb(r10, r9);
        goto L_0x0971;
    L_0x08cb:
        r11 = r13.zzb(r14, r1);
        if (r11 == 0) goto L_0x0971;
    L_0x08d1:
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzq(r14, r11);
        r11 = r13.zzbf(r1);
        r15.zzb(r10, r9, r11);
        goto L_0x0971;
    L_0x08e0:
        r11 = r13.zzb(r14, r1);
        if (r11 == 0) goto L_0x0971;
    L_0x08e6:
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzq(r14, r11);
        zzb(r10, r9, r15);
        goto L_0x0971;
    L_0x08f1:
        r11 = r13.zzb(r14, r1);
        if (r11 == 0) goto L_0x0971;
    L_0x08f7:
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzn(r14, r11);
    L_0x08fd:
        r15.zzc(r10, r9);
        goto L_0x0971;
    L_0x0902:
        r11 = r13.zzb(r14, r1);
        if (r11 == 0) goto L_0x0971;
    L_0x0908:
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzl(r14, r11);
    L_0x090e:
        r15.zzh(r10, r9);
        goto L_0x0971;
    L_0x0912:
        r11 = r13.zzb(r14, r1);
        if (r11 == 0) goto L_0x0971;
    L_0x0918:
        r9 = r9 & r6;
        r11 = (long) r9;
        r11 = com.google.android.gms.internal.places.zzjw.zzm(r14, r11);
    L_0x091e:
        r15.zzd(r10, r11);
        goto L_0x0971;
    L_0x0922:
        r11 = r13.zzb(r14, r1);
        if (r11 == 0) goto L_0x0971;
    L_0x0928:
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzl(r14, r11);
    L_0x092e:
        r15.zze(r10, r9);
        goto L_0x0971;
    L_0x0932:
        r11 = r13.zzb(r14, r1);
        if (r11 == 0) goto L_0x0971;
    L_0x0938:
        r9 = r9 & r6;
        r11 = (long) r9;
        r11 = com.google.android.gms.internal.places.zzjw.zzm(r14, r11);
    L_0x093e:
        r15.zzb(r10, r11);
        goto L_0x0971;
    L_0x0942:
        r11 = r13.zzb(r14, r1);
        if (r11 == 0) goto L_0x0971;
    L_0x0948:
        r9 = r9 & r6;
        r11 = (long) r9;
        r11 = com.google.android.gms.internal.places.zzjw.zzm(r14, r11);
    L_0x094e:
        r15.zzj(r10, r11);
        goto L_0x0971;
    L_0x0952:
        r11 = r13.zzb(r14, r1);
        if (r11 == 0) goto L_0x0971;
    L_0x0958:
        r9 = r9 & r6;
        r11 = (long) r9;
        r9 = com.google.android.gms.internal.places.zzjw.zzo(r14, r11);
    L_0x095e:
        r15.zzc(r10, r9);
        goto L_0x0971;
    L_0x0962:
        r11 = r13.zzb(r14, r1);
        if (r11 == 0) goto L_0x0971;
    L_0x0968:
        r9 = r9 & r6;
        r11 = (long) r9;
        r11 = com.google.android.gms.internal.places.zzjw.zzp(r14, r11);
    L_0x096e:
        r15.zzb(r10, r11);
    L_0x0971:
        r1 = r1 + 4;
        goto L_0x04f5;
    L_0x0975:
        if (r8 == 0) goto L_0x098c;
    L_0x0977:
        r1 = r13.zzvq;
        r1.zzb(r15, r8);
        r1 = r0.hasNext();
        if (r1 == 0) goto L_0x098a;
    L_0x0982:
        r1 = r0.next();
        r1 = (java.util.Map.Entry) r1;
        r8 = r1;
        goto L_0x0975;
    L_0x098a:
        r8 = r3;
        goto L_0x0975;
    L_0x098c:
        r0 = r13.zzvp;
        zzb(r0, r14, r15);
        return;
    L_0x0992:
        r13.zzc(r14, r15);
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.places.zzil.zzb(java.lang.Object, com.google.android.gms.internal.places.zzkk):void");
    }

    public final void zzd(T t) {
        if (this.zzvl != null) {
            for (int zzbi : this.zzvl) {
                long zzbi2 = (long) (zzbi(zzbi) & 1048575);
                Object zzq = zzjw.zzq(t, zzbi2);
                if (zzq != null) {
                    zzjw.zzb((Object) t, zzbi2, this.zzvr.zzk(zzq));
                }
            }
        }
        if (this.zzvm != null) {
            for (int i : this.zzvm) {
                this.zzvo.zzc(t, (long) i);
            }
        }
        this.zzvp.zzd(t);
        if (this.zzvg) {
            this.zzvq.zzd(t);
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void zzd(T r7, T r8) {
        /*
        r6 = this;
        if (r8 == 0) goto L_0x0105;
    L_0x0002:
        r0 = 0;
    L_0x0003:
        r1 = r6.zzva;
        r1 = r1.length;
        if (r0 >= r1) goto L_0x00f2;
    L_0x0008:
        r1 = r6.zzbi(r0);
        r2 = 1048575; // 0xfffff float:1.469367E-39 double:5.18065E-318;
        r2 = r2 & r1;
        r2 = (long) r2;
        r4 = r6.zzva;
        r4 = r4[r0];
        r5 = 267386880; // 0xff00000 float:2.3665827E-29 double:1.321066716E-315;
        r1 = r1 & r5;
        r1 = r1 >>> 20;
        switch(r1) {
            case 0: goto L_0x00de;
            case 1: goto L_0x00d0;
            case 2: goto L_0x00c2;
            case 3: goto L_0x00bb;
            case 4: goto L_0x00ad;
            case 5: goto L_0x00a6;
            case 6: goto L_0x009f;
            case 7: goto L_0x0091;
            case 8: goto L_0x0083;
            case 9: goto L_0x007e;
            case 10: goto L_0x0077;
            case 11: goto L_0x0070;
            case 12: goto L_0x0069;
            case 13: goto L_0x0062;
            case 14: goto L_0x005a;
            case 15: goto L_0x0053;
            case 16: goto L_0x004b;
            case 17: goto L_0x007e;
            case 18: goto L_0x0044;
            case 19: goto L_0x0044;
            case 20: goto L_0x0044;
            case 21: goto L_0x0044;
            case 22: goto L_0x0044;
            case 23: goto L_0x0044;
            case 24: goto L_0x0044;
            case 25: goto L_0x0044;
            case 26: goto L_0x0044;
            case 27: goto L_0x0044;
            case 28: goto L_0x0044;
            case 29: goto L_0x0044;
            case 30: goto L_0x0044;
            case 31: goto L_0x0044;
            case 32: goto L_0x0044;
            case 33: goto L_0x0044;
            case 34: goto L_0x0044;
            case 35: goto L_0x0044;
            case 36: goto L_0x0044;
            case 37: goto L_0x0044;
            case 38: goto L_0x0044;
            case 39: goto L_0x0044;
            case 40: goto L_0x0044;
            case 41: goto L_0x0044;
            case 42: goto L_0x0044;
            case 43: goto L_0x0044;
            case 44: goto L_0x0044;
            case 45: goto L_0x0044;
            case 46: goto L_0x0044;
            case 47: goto L_0x0044;
            case 48: goto L_0x0044;
            case 49: goto L_0x0044;
            case 50: goto L_0x003d;
            case 51: goto L_0x002b;
            case 52: goto L_0x002b;
            case 53: goto L_0x002b;
            case 54: goto L_0x002b;
            case 55: goto L_0x002b;
            case 56: goto L_0x002b;
            case 57: goto L_0x002b;
            case 58: goto L_0x002b;
            case 59: goto L_0x002b;
            case 60: goto L_0x0026;
            case 61: goto L_0x001f;
            case 62: goto L_0x001f;
            case 63: goto L_0x001f;
            case 64: goto L_0x001f;
            case 65: goto L_0x001f;
            case 66: goto L_0x001f;
            case 67: goto L_0x001f;
            case 68: goto L_0x0026;
            default: goto L_0x001d;
        };
    L_0x001d:
        goto L_0x00ee;
    L_0x001f:
        r1 = r6.zzb(r8, r4, r0);
        if (r1 == 0) goto L_0x00ee;
    L_0x0025:
        goto L_0x0031;
    L_0x0026:
        r6.zzc(r7, r8, r0);
        goto L_0x00ee;
    L_0x002b:
        r1 = r6.zzb(r8, r4, r0);
        if (r1 == 0) goto L_0x00ee;
    L_0x0031:
        r1 = com.google.android.gms.internal.places.zzjw.zzq(r8, r2);
        com.google.android.gms.internal.places.zzjw.zzb(r7, r2, r1);
        r6.zzc(r7, r4, r0);
        goto L_0x00ee;
    L_0x003d:
        r1 = r6.zzvr;
        com.google.android.gms.internal.places.zzja.zzb(r1, r7, r8, r2);
        goto L_0x00ee;
    L_0x0044:
        r1 = r6.zzvo;
        r1.zzb(r7, r8, r2);
        goto L_0x00ee;
    L_0x004b:
        r1 = r6.zzb(r8, r0);
        if (r1 == 0) goto L_0x00ee;
    L_0x0051:
        goto L_0x00c8;
    L_0x0053:
        r1 = r6.zzb(r8, r0);
        if (r1 == 0) goto L_0x00ee;
    L_0x0059:
        goto L_0x006f;
    L_0x005a:
        r1 = r6.zzb(r8, r0);
        if (r1 == 0) goto L_0x00ee;
    L_0x0060:
        goto L_0x00c8;
    L_0x0062:
        r1 = r6.zzb(r8, r0);
        if (r1 == 0) goto L_0x00ee;
    L_0x0068:
        goto L_0x006f;
    L_0x0069:
        r1 = r6.zzb(r8, r0);
        if (r1 == 0) goto L_0x00ee;
    L_0x006f:
        goto L_0x00b3;
    L_0x0070:
        r1 = r6.zzb(r8, r0);
        if (r1 == 0) goto L_0x00ee;
    L_0x0076:
        goto L_0x00b3;
    L_0x0077:
        r1 = r6.zzb(r8, r0);
        if (r1 == 0) goto L_0x00ee;
    L_0x007d:
        goto L_0x0089;
    L_0x007e:
        r6.zzb(r7, r8, r0);
        goto L_0x00ee;
    L_0x0083:
        r1 = r6.zzb(r8, r0);
        if (r1 == 0) goto L_0x00ee;
    L_0x0089:
        r1 = com.google.android.gms.internal.places.zzjw.zzq(r8, r2);
        com.google.android.gms.internal.places.zzjw.zzb(r7, r2, r1);
        goto L_0x00eb;
    L_0x0091:
        r1 = r6.zzb(r8, r0);
        if (r1 == 0) goto L_0x00ee;
    L_0x0097:
        r1 = com.google.android.gms.internal.places.zzjw.zzn(r8, r2);
        com.google.android.gms.internal.places.zzjw.zzb(r7, r2, r1);
        goto L_0x00eb;
    L_0x009f:
        r1 = r6.zzb(r8, r0);
        if (r1 == 0) goto L_0x00ee;
    L_0x00a5:
        goto L_0x00b3;
    L_0x00a6:
        r1 = r6.zzb(r8, r0);
        if (r1 == 0) goto L_0x00ee;
    L_0x00ac:
        goto L_0x00c8;
    L_0x00ad:
        r1 = r6.zzb(r8, r0);
        if (r1 == 0) goto L_0x00ee;
    L_0x00b3:
        r1 = com.google.android.gms.internal.places.zzjw.zzl(r8, r2);
        com.google.android.gms.internal.places.zzjw.zzc(r7, r2, r1);
        goto L_0x00eb;
    L_0x00bb:
        r1 = r6.zzb(r8, r0);
        if (r1 == 0) goto L_0x00ee;
    L_0x00c1:
        goto L_0x00c8;
    L_0x00c2:
        r1 = r6.zzb(r8, r0);
        if (r1 == 0) goto L_0x00ee;
    L_0x00c8:
        r4 = com.google.android.gms.internal.places.zzjw.zzm(r8, r2);
        com.google.android.gms.internal.places.zzjw.zzb(r7, r2, r4);
        goto L_0x00eb;
    L_0x00d0:
        r1 = r6.zzb(r8, r0);
        if (r1 == 0) goto L_0x00ee;
    L_0x00d6:
        r1 = com.google.android.gms.internal.places.zzjw.zzo(r8, r2);
        com.google.android.gms.internal.places.zzjw.zzb(r7, r2, r1);
        goto L_0x00eb;
    L_0x00de:
        r1 = r6.zzb(r8, r0);
        if (r1 == 0) goto L_0x00ee;
    L_0x00e4:
        r4 = com.google.android.gms.internal.places.zzjw.zzp(r8, r2);
        com.google.android.gms.internal.places.zzjw.zzb(r7, r2, r4);
    L_0x00eb:
        r6.zzc(r7, r0);
    L_0x00ee:
        r0 = r0 + 4;
        goto L_0x0003;
    L_0x00f2:
        r0 = r6.zzvi;
        if (r0 != 0) goto L_0x0104;
    L_0x00f6:
        r0 = r6.zzvp;
        com.google.android.gms.internal.places.zzja.zzb(r0, r7, r8);
        r0 = r6.zzvg;
        if (r0 == 0) goto L_0x0104;
    L_0x00ff:
        r0 = r6.zzvq;
        com.google.android.gms.internal.places.zzja.zzb(r0, r7, r8);
    L_0x0104:
        return;
    L_0x0105:
        r7 = new java.lang.NullPointerException;
        r7.<init>();
        throw r7;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.places.zzil.zzd(java.lang.Object, java.lang.Object):void");
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final int zzn(T r21) {
        /*
        r20 = this;
        r0 = r20;
        r1 = r21;
        r2 = r0.zzvi;
        r3 = 267386880; // 0xff00000 float:2.3665827E-29 double:1.321066716E-315;
        r4 = 0;
        r7 = 1;
        r8 = 1048575; // 0xfffff float:1.469367E-39 double:5.18065E-318;
        r9 = 0;
        r11 = 0;
        if (r2 == 0) goto L_0x03b8;
    L_0x0012:
        r2 = zzuz;
        r12 = 0;
        r13 = 0;
    L_0x0016:
        r14 = r0.zzva;
        r14 = r14.length;
        if (r12 >= r14) goto L_0x03b0;
    L_0x001b:
        r14 = r0.zzbi(r12);
        r15 = r14 & r3;
        r15 = r15 >>> 20;
        r3 = r0.zzva;
        r3 = r3[r12];
        r14 = r14 & r8;
        r5 = (long) r14;
        r14 = com.google.android.gms.internal.places.zzgt.DOUBLE_LIST_PACKED;
        r14 = r14.id();
        if (r15 < r14) goto L_0x0041;
    L_0x0031:
        r14 = com.google.android.gms.internal.places.zzgt.SINT64_LIST_PACKED;
        r14 = r14.id();
        if (r15 > r14) goto L_0x0041;
    L_0x0039:
        r14 = r0.zzva;
        r17 = r12 + 2;
        r14 = r14[r17];
        r14 = r14 & r8;
        goto L_0x0042;
    L_0x0041:
        r14 = 0;
    L_0x0042:
        switch(r15) {
            case 0: goto L_0x039c;
            case 1: goto L_0x0390;
            case 2: goto L_0x0380;
            case 3: goto L_0x0370;
            case 4: goto L_0x0360;
            case 5: goto L_0x0354;
            case 6: goto L_0x0348;
            case 7: goto L_0x033c;
            case 8: goto L_0x0325;
            case 9: goto L_0x0311;
            case 10: goto L_0x0300;
            case 11: goto L_0x02f1;
            case 12: goto L_0x02e2;
            case 13: goto L_0x02d7;
            case 14: goto L_0x02cc;
            case 15: goto L_0x02bd;
            case 16: goto L_0x02ae;
            case 17: goto L_0x0299;
            case 18: goto L_0x028e;
            case 19: goto L_0x0285;
            case 20: goto L_0x027c;
            case 21: goto L_0x0273;
            case 22: goto L_0x026a;
            case 23: goto L_0x028e;
            case 24: goto L_0x0285;
            case 25: goto L_0x0261;
            case 26: goto L_0x0258;
            case 27: goto L_0x024b;
            case 28: goto L_0x0242;
            case 29: goto L_0x0239;
            case 30: goto L_0x0230;
            case 31: goto L_0x0285;
            case 32: goto L_0x028e;
            case 33: goto L_0x0227;
            case 34: goto L_0x021d;
            case 35: goto L_0x01fd;
            case 36: goto L_0x01ec;
            case 37: goto L_0x01db;
            case 38: goto L_0x01ca;
            case 39: goto L_0x01b9;
            case 40: goto L_0x01a8;
            case 41: goto L_0x0197;
            case 42: goto L_0x0185;
            case 43: goto L_0x0173;
            case 44: goto L_0x0161;
            case 45: goto L_0x014f;
            case 46: goto L_0x013d;
            case 47: goto L_0x012b;
            case 48: goto L_0x0119;
            case 49: goto L_0x010b;
            case 50: goto L_0x00fb;
            case 51: goto L_0x00f3;
            case 52: goto L_0x00eb;
            case 53: goto L_0x00df;
            case 54: goto L_0x00d3;
            case 55: goto L_0x00c7;
            case 56: goto L_0x00bf;
            case 57: goto L_0x00b7;
            case 58: goto L_0x00af;
            case 59: goto L_0x009f;
            case 60: goto L_0x0097;
            case 61: goto L_0x008f;
            case 62: goto L_0x0083;
            case 63: goto L_0x0077;
            case 64: goto L_0x006f;
            case 65: goto L_0x0067;
            case 66: goto L_0x005b;
            case 67: goto L_0x004f;
            case 68: goto L_0x0047;
            default: goto L_0x0045;
        };
    L_0x0045:
        goto L_0x03aa;
    L_0x0047:
        r14 = r0.zzb(r1, r3, r12);
        if (r14 == 0) goto L_0x03aa;
    L_0x004d:
        goto L_0x029f;
    L_0x004f:
        r14 = r0.zzb(r1, r3, r12);
        if (r14 == 0) goto L_0x03aa;
    L_0x0055:
        r5 = zzj(r1, r5);
        goto L_0x02b8;
    L_0x005b:
        r14 = r0.zzb(r1, r3, r12);
        if (r14 == 0) goto L_0x03aa;
    L_0x0061:
        r5 = zzi(r1, r5);
        goto L_0x02c7;
    L_0x0067:
        r5 = r0.zzb(r1, r3, r12);
        if (r5 == 0) goto L_0x03aa;
    L_0x006d:
        goto L_0x02d2;
    L_0x006f:
        r5 = r0.zzb(r1, r3, r12);
        if (r5 == 0) goto L_0x03aa;
    L_0x0075:
        goto L_0x02dd;
    L_0x0077:
        r14 = r0.zzb(r1, r3, r12);
        if (r14 == 0) goto L_0x03aa;
    L_0x007d:
        r5 = zzi(r1, r5);
        goto L_0x02ec;
    L_0x0083:
        r14 = r0.zzb(r1, r3, r12);
        if (r14 == 0) goto L_0x03aa;
    L_0x0089:
        r5 = zzi(r1, r5);
        goto L_0x02fb;
    L_0x008f:
        r14 = r0.zzb(r1, r3, r12);
        if (r14 == 0) goto L_0x03aa;
    L_0x0095:
        goto L_0x0306;
    L_0x0097:
        r14 = r0.zzb(r1, r3, r12);
        if (r14 == 0) goto L_0x03aa;
    L_0x009d:
        goto L_0x0317;
    L_0x009f:
        r14 = r0.zzb(r1, r3, r12);
        if (r14 == 0) goto L_0x03aa;
    L_0x00a5:
        r5 = com.google.android.gms.internal.places.zzjw.zzq(r1, r5);
        r6 = r5 instanceof com.google.android.gms.internal.places.zzfr;
        if (r6 == 0) goto L_0x0334;
    L_0x00ad:
        goto L_0x0333;
    L_0x00af:
        r5 = r0.zzb(r1, r3, r12);
        if (r5 == 0) goto L_0x03aa;
    L_0x00b5:
        goto L_0x0342;
    L_0x00b7:
        r5 = r0.zzb(r1, r3, r12);
        if (r5 == 0) goto L_0x03aa;
    L_0x00bd:
        goto L_0x034e;
    L_0x00bf:
        r5 = r0.zzb(r1, r3, r12);
        if (r5 == 0) goto L_0x03aa;
    L_0x00c5:
        goto L_0x035a;
    L_0x00c7:
        r14 = r0.zzb(r1, r3, r12);
        if (r14 == 0) goto L_0x03aa;
    L_0x00cd:
        r5 = zzi(r1, r5);
        goto L_0x036a;
    L_0x00d3:
        r14 = r0.zzb(r1, r3, r12);
        if (r14 == 0) goto L_0x03aa;
    L_0x00d9:
        r5 = zzj(r1, r5);
        goto L_0x037a;
    L_0x00df:
        r14 = r0.zzb(r1, r3, r12);
        if (r14 == 0) goto L_0x03aa;
    L_0x00e5:
        r5 = zzj(r1, r5);
        goto L_0x038a;
    L_0x00eb:
        r5 = r0.zzb(r1, r3, r12);
        if (r5 == 0) goto L_0x03aa;
    L_0x00f1:
        goto L_0x0396;
    L_0x00f3:
        r5 = r0.zzb(r1, r3, r12);
        if (r5 == 0) goto L_0x03aa;
    L_0x00f9:
        goto L_0x03a2;
    L_0x00fb:
        r14 = r0.zzvr;
        r5 = com.google.android.gms.internal.places.zzjw.zzq(r1, r5);
        r6 = r0.zzbg(r12);
        r3 = r14.zzc(r3, r5, r6);
        goto L_0x0296;
    L_0x010b:
        r5 = zzf(r1, r5);
        r6 = r0.zzbf(r12);
        r3 = com.google.android.gms.internal.places.zzja.zze(r3, r5, r6);
        goto L_0x0296;
    L_0x0119:
        r5 = r2.getObject(r1, r5);
        r5 = (java.util.List) r5;
        r5 = com.google.android.gms.internal.places.zzja.zzw(r5);
        if (r5 <= 0) goto L_0x03aa;
    L_0x0125:
        r6 = r0.zzvj;
        if (r6 == 0) goto L_0x0211;
    L_0x0129:
        goto L_0x020d;
    L_0x012b:
        r5 = r2.getObject(r1, r5);
        r5 = (java.util.List) r5;
        r5 = com.google.android.gms.internal.places.zzja.zzaa(r5);
        if (r5 <= 0) goto L_0x03aa;
    L_0x0137:
        r6 = r0.zzvj;
        if (r6 == 0) goto L_0x0211;
    L_0x013b:
        goto L_0x020d;
    L_0x013d:
        r5 = r2.getObject(r1, r5);
        r5 = (java.util.List) r5;
        r5 = com.google.android.gms.internal.places.zzja.zzac(r5);
        if (r5 <= 0) goto L_0x03aa;
    L_0x0149:
        r6 = r0.zzvj;
        if (r6 == 0) goto L_0x0211;
    L_0x014d:
        goto L_0x020d;
    L_0x014f:
        r5 = r2.getObject(r1, r5);
        r5 = (java.util.List) r5;
        r5 = com.google.android.gms.internal.places.zzja.zzab(r5);
        if (r5 <= 0) goto L_0x03aa;
    L_0x015b:
        r6 = r0.zzvj;
        if (r6 == 0) goto L_0x0211;
    L_0x015f:
        goto L_0x020d;
    L_0x0161:
        r5 = r2.getObject(r1, r5);
        r5 = (java.util.List) r5;
        r5 = com.google.android.gms.internal.places.zzja.zzx(r5);
        if (r5 <= 0) goto L_0x03aa;
    L_0x016d:
        r6 = r0.zzvj;
        if (r6 == 0) goto L_0x0211;
    L_0x0171:
        goto L_0x020d;
    L_0x0173:
        r5 = r2.getObject(r1, r5);
        r5 = (java.util.List) r5;
        r5 = com.google.android.gms.internal.places.zzja.zzz(r5);
        if (r5 <= 0) goto L_0x03aa;
    L_0x017f:
        r6 = r0.zzvj;
        if (r6 == 0) goto L_0x0211;
    L_0x0183:
        goto L_0x020d;
    L_0x0185:
        r5 = r2.getObject(r1, r5);
        r5 = (java.util.List) r5;
        r5 = com.google.android.gms.internal.places.zzja.zzad(r5);
        if (r5 <= 0) goto L_0x03aa;
    L_0x0191:
        r6 = r0.zzvj;
        if (r6 == 0) goto L_0x0211;
    L_0x0195:
        goto L_0x020d;
    L_0x0197:
        r5 = r2.getObject(r1, r5);
        r5 = (java.util.List) r5;
        r5 = com.google.android.gms.internal.places.zzja.zzab(r5);
        if (r5 <= 0) goto L_0x03aa;
    L_0x01a3:
        r6 = r0.zzvj;
        if (r6 == 0) goto L_0x0211;
    L_0x01a7:
        goto L_0x020d;
    L_0x01a8:
        r5 = r2.getObject(r1, r5);
        r5 = (java.util.List) r5;
        r5 = com.google.android.gms.internal.places.zzja.zzac(r5);
        if (r5 <= 0) goto L_0x03aa;
    L_0x01b4:
        r6 = r0.zzvj;
        if (r6 == 0) goto L_0x0211;
    L_0x01b8:
        goto L_0x020d;
    L_0x01b9:
        r5 = r2.getObject(r1, r5);
        r5 = (java.util.List) r5;
        r5 = com.google.android.gms.internal.places.zzja.zzy(r5);
        if (r5 <= 0) goto L_0x03aa;
    L_0x01c5:
        r6 = r0.zzvj;
        if (r6 == 0) goto L_0x0211;
    L_0x01c9:
        goto L_0x020d;
    L_0x01ca:
        r5 = r2.getObject(r1, r5);
        r5 = (java.util.List) r5;
        r5 = com.google.android.gms.internal.places.zzja.zzv(r5);
        if (r5 <= 0) goto L_0x03aa;
    L_0x01d6:
        r6 = r0.zzvj;
        if (r6 == 0) goto L_0x0211;
    L_0x01da:
        goto L_0x020d;
    L_0x01db:
        r5 = r2.getObject(r1, r5);
        r5 = (java.util.List) r5;
        r5 = com.google.android.gms.internal.places.zzja.zzu(r5);
        if (r5 <= 0) goto L_0x03aa;
    L_0x01e7:
        r6 = r0.zzvj;
        if (r6 == 0) goto L_0x0211;
    L_0x01eb:
        goto L_0x020d;
    L_0x01ec:
        r5 = r2.getObject(r1, r5);
        r5 = (java.util.List) r5;
        r5 = com.google.android.gms.internal.places.zzja.zzab(r5);
        if (r5 <= 0) goto L_0x03aa;
    L_0x01f8:
        r6 = r0.zzvj;
        if (r6 == 0) goto L_0x0211;
    L_0x01fc:
        goto L_0x020d;
    L_0x01fd:
        r5 = r2.getObject(r1, r5);
        r5 = (java.util.List) r5;
        r5 = com.google.android.gms.internal.places.zzja.zzac(r5);
        if (r5 <= 0) goto L_0x03aa;
    L_0x0209:
        r6 = r0.zzvj;
        if (r6 == 0) goto L_0x0211;
    L_0x020d:
        r14 = (long) r14;
        r2.putInt(r1, r14, r5);
    L_0x0211:
        r3 = com.google.android.gms.internal.places.zzgf.zzas(r3);
        r6 = com.google.android.gms.internal.places.zzgf.zzau(r5);
        r3 = r3 + r6;
        r3 = r3 + r5;
        goto L_0x0296;
    L_0x021d:
        r5 = zzf(r1, r5);
        r3 = com.google.android.gms.internal.places.zzja.zzr(r3, r5, r11);
        goto L_0x0296;
    L_0x0227:
        r5 = zzf(r1, r5);
        r3 = com.google.android.gms.internal.places.zzja.zzv(r3, r5, r11);
        goto L_0x0296;
    L_0x0230:
        r5 = zzf(r1, r5);
        r3 = com.google.android.gms.internal.places.zzja.zzs(r3, r5, r11);
        goto L_0x0296;
    L_0x0239:
        r5 = zzf(r1, r5);
        r3 = com.google.android.gms.internal.places.zzja.zzu(r3, r5, r11);
        goto L_0x0296;
    L_0x0242:
        r5 = zzf(r1, r5);
        r3 = com.google.android.gms.internal.places.zzja.zzf(r3, r5);
        goto L_0x0296;
    L_0x024b:
        r5 = zzf(r1, r5);
        r6 = r0.zzbf(r12);
        r3 = com.google.android.gms.internal.places.zzja.zzd(r3, r5, r6);
        goto L_0x0296;
    L_0x0258:
        r5 = zzf(r1, r5);
        r3 = com.google.android.gms.internal.places.zzja.zze(r3, r5);
        goto L_0x0296;
    L_0x0261:
        r5 = zzf(r1, r5);
        r3 = com.google.android.gms.internal.places.zzja.zzy(r3, r5, r11);
        goto L_0x0296;
    L_0x026a:
        r5 = zzf(r1, r5);
        r3 = com.google.android.gms.internal.places.zzja.zzt(r3, r5, r11);
        goto L_0x0296;
    L_0x0273:
        r5 = zzf(r1, r5);
        r3 = com.google.android.gms.internal.places.zzja.zzq(r3, r5, r11);
        goto L_0x0296;
    L_0x027c:
        r5 = zzf(r1, r5);
        r3 = com.google.android.gms.internal.places.zzja.zzp(r3, r5, r11);
        goto L_0x0296;
    L_0x0285:
        r5 = zzf(r1, r5);
        r3 = com.google.android.gms.internal.places.zzja.zzw(r3, r5, r11);
        goto L_0x0296;
    L_0x028e:
        r5 = zzf(r1, r5);
        r3 = com.google.android.gms.internal.places.zzja.zzx(r3, r5, r11);
    L_0x0296:
        r13 = r13 + r3;
        goto L_0x03aa;
    L_0x0299:
        r14 = r0.zzb(r1, r12);
        if (r14 == 0) goto L_0x03aa;
    L_0x029f:
        r5 = com.google.android.gms.internal.places.zzjw.zzq(r1, r5);
        r5 = (com.google.android.gms.internal.places.zzih) r5;
        r6 = r0.zzbf(r12);
        r3 = com.google.android.gms.internal.places.zzgf.zzd(r3, r5, r6);
        goto L_0x0296;
    L_0x02ae:
        r14 = r0.zzb(r1, r12);
        if (r14 == 0) goto L_0x03aa;
    L_0x02b4:
        r5 = com.google.android.gms.internal.places.zzjw.zzm(r1, r5);
    L_0x02b8:
        r3 = com.google.android.gms.internal.places.zzgf.zzg(r3, r5);
        goto L_0x0296;
    L_0x02bd:
        r14 = r0.zzb(r1, r12);
        if (r14 == 0) goto L_0x03aa;
    L_0x02c3:
        r5 = com.google.android.gms.internal.places.zzjw.zzl(r1, r5);
    L_0x02c7:
        r3 = com.google.android.gms.internal.places.zzgf.zzk(r3, r5);
        goto L_0x0296;
    L_0x02cc:
        r5 = r0.zzb(r1, r12);
        if (r5 == 0) goto L_0x03aa;
    L_0x02d2:
        r3 = com.google.android.gms.internal.places.zzgf.zzi(r3, r9);
        goto L_0x0296;
    L_0x02d7:
        r5 = r0.zzb(r1, r12);
        if (r5 == 0) goto L_0x03aa;
    L_0x02dd:
        r3 = com.google.android.gms.internal.places.zzgf.zzm(r3, r11);
        goto L_0x0296;
    L_0x02e2:
        r14 = r0.zzb(r1, r12);
        if (r14 == 0) goto L_0x03aa;
    L_0x02e8:
        r5 = com.google.android.gms.internal.places.zzjw.zzl(r1, r5);
    L_0x02ec:
        r3 = com.google.android.gms.internal.places.zzgf.zzn(r3, r5);
        goto L_0x0296;
    L_0x02f1:
        r14 = r0.zzb(r1, r12);
        if (r14 == 0) goto L_0x03aa;
    L_0x02f7:
        r5 = com.google.android.gms.internal.places.zzjw.zzl(r1, r5);
    L_0x02fb:
        r3 = com.google.android.gms.internal.places.zzgf.zzj(r3, r5);
        goto L_0x0296;
    L_0x0300:
        r14 = r0.zzb(r1, r12);
        if (r14 == 0) goto L_0x03aa;
    L_0x0306:
        r5 = com.google.android.gms.internal.places.zzjw.zzq(r1, r5);
    L_0x030a:
        r5 = (com.google.android.gms.internal.places.zzfr) r5;
        r3 = com.google.android.gms.internal.places.zzgf.zzd(r3, r5);
        goto L_0x0296;
    L_0x0311:
        r14 = r0.zzb(r1, r12);
        if (r14 == 0) goto L_0x03aa;
    L_0x0317:
        r5 = com.google.android.gms.internal.places.zzjw.zzq(r1, r5);
        r6 = r0.zzbf(r12);
        r3 = com.google.android.gms.internal.places.zzja.zzd(r3, r5, r6);
        goto L_0x0296;
    L_0x0325:
        r14 = r0.zzb(r1, r12);
        if (r14 == 0) goto L_0x03aa;
    L_0x032b:
        r5 = com.google.android.gms.internal.places.zzjw.zzq(r1, r5);
        r6 = r5 instanceof com.google.android.gms.internal.places.zzfr;
        if (r6 == 0) goto L_0x0334;
    L_0x0333:
        goto L_0x030a;
    L_0x0334:
        r5 = (java.lang.String) r5;
        r3 = com.google.android.gms.internal.places.zzgf.zzc(r3, r5);
        goto L_0x0296;
    L_0x033c:
        r5 = r0.zzb(r1, r12);
        if (r5 == 0) goto L_0x03aa;
    L_0x0342:
        r3 = com.google.android.gms.internal.places.zzgf.zzd(r3, r7);
        goto L_0x0296;
    L_0x0348:
        r5 = r0.zzb(r1, r12);
        if (r5 == 0) goto L_0x03aa;
    L_0x034e:
        r3 = com.google.android.gms.internal.places.zzgf.zzl(r3, r11);
        goto L_0x0296;
    L_0x0354:
        r5 = r0.zzb(r1, r12);
        if (r5 == 0) goto L_0x03aa;
    L_0x035a:
        r3 = com.google.android.gms.internal.places.zzgf.zzh(r3, r9);
        goto L_0x0296;
    L_0x0360:
        r14 = r0.zzb(r1, r12);
        if (r14 == 0) goto L_0x03aa;
    L_0x0366:
        r5 = com.google.android.gms.internal.places.zzjw.zzl(r1, r5);
    L_0x036a:
        r3 = com.google.android.gms.internal.places.zzgf.zzi(r3, r5);
        goto L_0x0296;
    L_0x0370:
        r14 = r0.zzb(r1, r12);
        if (r14 == 0) goto L_0x03aa;
    L_0x0376:
        r5 = com.google.android.gms.internal.places.zzjw.zzm(r1, r5);
    L_0x037a:
        r3 = com.google.android.gms.internal.places.zzgf.zzf(r3, r5);
        goto L_0x0296;
    L_0x0380:
        r14 = r0.zzb(r1, r12);
        if (r14 == 0) goto L_0x03aa;
    L_0x0386:
        r5 = com.google.android.gms.internal.places.zzjw.zzm(r1, r5);
    L_0x038a:
        r3 = com.google.android.gms.internal.places.zzgf.zze(r3, r5);
        goto L_0x0296;
    L_0x0390:
        r5 = r0.zzb(r1, r12);
        if (r5 == 0) goto L_0x03aa;
    L_0x0396:
        r3 = com.google.android.gms.internal.places.zzgf.zzd(r3, r4);
        goto L_0x0296;
    L_0x039c:
        r5 = r0.zzb(r1, r12);
        if (r5 == 0) goto L_0x03aa;
    L_0x03a2:
        r5 = 0;
        r3 = com.google.android.gms.internal.places.zzgf.zzc(r3, r5);
        goto L_0x0296;
    L_0x03aa:
        r12 = r12 + 4;
        r3 = 267386880; // 0xff00000 float:2.3665827E-29 double:1.321066716E-315;
        goto L_0x0016;
    L_0x03b0:
        r2 = r0.zzvp;
        r1 = zzb(r2, r1);
        r13 = r13 + r1;
        return r13;
    L_0x03b8:
        r2 = zzuz;
        r3 = -1;
        r3 = 0;
        r5 = 0;
        r6 = -1;
        r12 = 0;
    L_0x03bf:
        r13 = r0.zzva;
        r13 = r13.length;
        if (r3 >= r13) goto L_0x07c7;
    L_0x03c4:
        r13 = r0.zzbi(r3);
        r14 = r0.zzva;
        r14 = r14[r3];
        r15 = 267386880; // 0xff00000 float:2.3665827E-29 double:1.321066716E-315;
        r16 = r13 & r15;
        r15 = r16 >>> 20;
        r4 = 17;
        if (r15 > r4) goto L_0x03eb;
    L_0x03d6:
        r4 = r0.zzva;
        r16 = r3 + 2;
        r4 = r4[r16];
        r11 = r4 & r8;
        r16 = r4 >>> 20;
        r16 = r7 << r16;
        if (r11 == r6) goto L_0x040c;
    L_0x03e4:
        r9 = (long) r11;
        r12 = r2.getInt(r1, r9);
        r6 = r11;
        goto L_0x040c;
    L_0x03eb:
        r4 = r0.zzvj;
        if (r4 == 0) goto L_0x0409;
    L_0x03ef:
        r4 = com.google.android.gms.internal.places.zzgt.DOUBLE_LIST_PACKED;
        r4 = r4.id();
        if (r15 < r4) goto L_0x0409;
    L_0x03f7:
        r4 = com.google.android.gms.internal.places.zzgt.SINT64_LIST_PACKED;
        r4 = r4.id();
        if (r15 > r4) goto L_0x0409;
    L_0x03ff:
        r4 = r0.zzva;
        r9 = r3 + 2;
        r4 = r4[r9];
        r11 = r4 & r8;
        r4 = r11;
        goto L_0x040a;
    L_0x0409:
        r4 = 0;
    L_0x040a:
        r16 = 0;
    L_0x040c:
        r9 = r13 & r8;
        r9 = (long) r9;
        switch(r15) {
            case 0: goto L_0x07b0;
            case 1: goto L_0x07a0;
            case 2: goto L_0x078e;
            case 3: goto L_0x077e;
            case 4: goto L_0x076e;
            case 5: goto L_0x075f;
            case 6: goto L_0x0753;
            case 7: goto L_0x0749;
            case 8: goto L_0x0734;
            case 9: goto L_0x0722;
            case 10: goto L_0x0713;
            case 11: goto L_0x0706;
            case 12: goto L_0x06f9;
            case 13: goto L_0x06ee;
            case 14: goto L_0x06e3;
            case 15: goto L_0x06d6;
            case 16: goto L_0x06c9;
            case 17: goto L_0x06b6;
            case 18: goto L_0x06a2;
            case 19: goto L_0x0696;
            case 20: goto L_0x068a;
            case 21: goto L_0x067e;
            case 22: goto L_0x0672;
            case 23: goto L_0x06a2;
            case 24: goto L_0x0696;
            case 25: goto L_0x0666;
            case 26: goto L_0x065b;
            case 27: goto L_0x064c;
            case 28: goto L_0x0641;
            case 29: goto L_0x0635;
            case 30: goto L_0x0628;
            case 31: goto L_0x0696;
            case 32: goto L_0x06a2;
            case 33: goto L_0x061b;
            case 34: goto L_0x060e;
            case 35: goto L_0x05ee;
            case 36: goto L_0x05dd;
            case 37: goto L_0x05cc;
            case 38: goto L_0x05bb;
            case 39: goto L_0x05aa;
            case 40: goto L_0x0599;
            case 41: goto L_0x0588;
            case 42: goto L_0x0576;
            case 43: goto L_0x0564;
            case 44: goto L_0x0552;
            case 45: goto L_0x0540;
            case 46: goto L_0x052e;
            case 47: goto L_0x051c;
            case 48: goto L_0x050a;
            case 49: goto L_0x04fa;
            case 50: goto L_0x04ea;
            case 51: goto L_0x04dc;
            case 52: goto L_0x04cf;
            case 53: goto L_0x04bf;
            case 54: goto L_0x04af;
            case 55: goto L_0x049f;
            case 56: goto L_0x0491;
            case 57: goto L_0x0484;
            case 58: goto L_0x047c;
            case 59: goto L_0x046c;
            case 60: goto L_0x0464;
            case 61: goto L_0x045c;
            case 62: goto L_0x0450;
            case 63: goto L_0x0444;
            case 64: goto L_0x043c;
            case 65: goto L_0x0434;
            case 66: goto L_0x0428;
            case 67: goto L_0x041c;
            case 68: goto L_0x0414;
            default: goto L_0x0412;
        };
    L_0x0412:
        goto L_0x06ae;
    L_0x0414:
        r4 = r0.zzb(r1, r14, r3);
        if (r4 == 0) goto L_0x06ae;
    L_0x041a:
        goto L_0x06ba;
    L_0x041c:
        r4 = r0.zzb(r1, r14, r3);
        if (r4 == 0) goto L_0x06ae;
    L_0x0422:
        r9 = zzj(r1, r9);
        goto L_0x06d1;
    L_0x0428:
        r4 = r0.zzb(r1, r14, r3);
        if (r4 == 0) goto L_0x06ae;
    L_0x042e:
        r4 = zzi(r1, r9);
        goto L_0x06de;
    L_0x0434:
        r4 = r0.zzb(r1, r14, r3);
        if (r4 == 0) goto L_0x06ae;
    L_0x043a:
        goto L_0x06e7;
    L_0x043c:
        r4 = r0.zzb(r1, r14, r3);
        if (r4 == 0) goto L_0x06ae;
    L_0x0442:
        goto L_0x06f2;
    L_0x0444:
        r4 = r0.zzb(r1, r14, r3);
        if (r4 == 0) goto L_0x06ae;
    L_0x044a:
        r4 = zzi(r1, r9);
        goto L_0x0701;
    L_0x0450:
        r4 = r0.zzb(r1, r14, r3);
        if (r4 == 0) goto L_0x06ae;
    L_0x0456:
        r4 = zzi(r1, r9);
        goto L_0x070e;
    L_0x045c:
        r4 = r0.zzb(r1, r14, r3);
        if (r4 == 0) goto L_0x06ae;
    L_0x0462:
        goto L_0x0717;
    L_0x0464:
        r4 = r0.zzb(r1, r14, r3);
        if (r4 == 0) goto L_0x06ae;
    L_0x046a:
        goto L_0x0726;
    L_0x046c:
        r4 = r0.zzb(r1, r14, r3);
        if (r4 == 0) goto L_0x06ae;
    L_0x0472:
        r4 = r2.getObject(r1, r9);
        r9 = r4 instanceof com.google.android.gms.internal.places.zzfr;
        if (r9 == 0) goto L_0x0741;
    L_0x047a:
        goto L_0x0740;
    L_0x047c:
        r4 = r0.zzb(r1, r14, r3);
        if (r4 == 0) goto L_0x06ae;
    L_0x0482:
        goto L_0x074d;
    L_0x0484:
        r4 = r0.zzb(r1, r14, r3);
        if (r4 == 0) goto L_0x06ae;
    L_0x048a:
        r4 = 0;
        r9 = com.google.android.gms.internal.places.zzgf.zzl(r14, r4);
        goto L_0x06f7;
    L_0x0491:
        r4 = r0.zzb(r1, r14, r3);
        if (r4 == 0) goto L_0x06ae;
    L_0x0497:
        r9 = 0;
        r4 = com.google.android.gms.internal.places.zzgf.zzh(r14, r9);
        goto L_0x06ad;
    L_0x049f:
        r4 = r0.zzb(r1, r14, r3);
        if (r4 == 0) goto L_0x06ae;
    L_0x04a5:
        r4 = zzi(r1, r9);
        r4 = com.google.android.gms.internal.places.zzgf.zzi(r14, r4);
        goto L_0x06ad;
    L_0x04af:
        r4 = r0.zzb(r1, r14, r3);
        if (r4 == 0) goto L_0x06ae;
    L_0x04b5:
        r9 = zzj(r1, r9);
        r4 = com.google.android.gms.internal.places.zzgf.zzf(r14, r9);
        goto L_0x06ad;
    L_0x04bf:
        r4 = r0.zzb(r1, r14, r3);
        if (r4 == 0) goto L_0x06ae;
    L_0x04c5:
        r9 = zzj(r1, r9);
        r4 = com.google.android.gms.internal.places.zzgf.zze(r14, r9);
        goto L_0x06ad;
    L_0x04cf:
        r4 = r0.zzb(r1, r14, r3);
        if (r4 == 0) goto L_0x06ae;
    L_0x04d5:
        r4 = 0;
        r9 = com.google.android.gms.internal.places.zzgf.zzd(r14, r4);
        goto L_0x06f7;
    L_0x04dc:
        r4 = r0.zzb(r1, r14, r3);
        if (r4 == 0) goto L_0x06ae;
    L_0x04e2:
        r9 = 0;
        r4 = com.google.android.gms.internal.places.zzgf.zzc(r14, r9);
        goto L_0x06ad;
    L_0x04ea:
        r4 = r0.zzvr;
        r9 = r2.getObject(r1, r9);
        r10 = r0.zzbg(r3);
        r4 = r4.zzc(r14, r9, r10);
        goto L_0x06ad;
    L_0x04fa:
        r4 = r2.getObject(r1, r9);
        r4 = (java.util.List) r4;
        r9 = r0.zzbf(r3);
        r4 = com.google.android.gms.internal.places.zzja.zze(r14, r4, r9);
        goto L_0x06ad;
    L_0x050a:
        r9 = r2.getObject(r1, r9);
        r9 = (java.util.List) r9;
        r9 = com.google.android.gms.internal.places.zzja.zzw(r9);
        if (r9 <= 0) goto L_0x06ae;
    L_0x0516:
        r10 = r0.zzvj;
        if (r10 == 0) goto L_0x0602;
    L_0x051a:
        goto L_0x05fe;
    L_0x051c:
        r9 = r2.getObject(r1, r9);
        r9 = (java.util.List) r9;
        r9 = com.google.android.gms.internal.places.zzja.zzaa(r9);
        if (r9 <= 0) goto L_0x06ae;
    L_0x0528:
        r10 = r0.zzvj;
        if (r10 == 0) goto L_0x0602;
    L_0x052c:
        goto L_0x05fe;
    L_0x052e:
        r9 = r2.getObject(r1, r9);
        r9 = (java.util.List) r9;
        r9 = com.google.android.gms.internal.places.zzja.zzac(r9);
        if (r9 <= 0) goto L_0x06ae;
    L_0x053a:
        r10 = r0.zzvj;
        if (r10 == 0) goto L_0x0602;
    L_0x053e:
        goto L_0x05fe;
    L_0x0540:
        r9 = r2.getObject(r1, r9);
        r9 = (java.util.List) r9;
        r9 = com.google.android.gms.internal.places.zzja.zzab(r9);
        if (r9 <= 0) goto L_0x06ae;
    L_0x054c:
        r10 = r0.zzvj;
        if (r10 == 0) goto L_0x0602;
    L_0x0550:
        goto L_0x05fe;
    L_0x0552:
        r9 = r2.getObject(r1, r9);
        r9 = (java.util.List) r9;
        r9 = com.google.android.gms.internal.places.zzja.zzx(r9);
        if (r9 <= 0) goto L_0x06ae;
    L_0x055e:
        r10 = r0.zzvj;
        if (r10 == 0) goto L_0x0602;
    L_0x0562:
        goto L_0x05fe;
    L_0x0564:
        r9 = r2.getObject(r1, r9);
        r9 = (java.util.List) r9;
        r9 = com.google.android.gms.internal.places.zzja.zzz(r9);
        if (r9 <= 0) goto L_0x06ae;
    L_0x0570:
        r10 = r0.zzvj;
        if (r10 == 0) goto L_0x0602;
    L_0x0574:
        goto L_0x05fe;
    L_0x0576:
        r9 = r2.getObject(r1, r9);
        r9 = (java.util.List) r9;
        r9 = com.google.android.gms.internal.places.zzja.zzad(r9);
        if (r9 <= 0) goto L_0x06ae;
    L_0x0582:
        r10 = r0.zzvj;
        if (r10 == 0) goto L_0x0602;
    L_0x0586:
        goto L_0x05fe;
    L_0x0588:
        r9 = r2.getObject(r1, r9);
        r9 = (java.util.List) r9;
        r9 = com.google.android.gms.internal.places.zzja.zzab(r9);
        if (r9 <= 0) goto L_0x06ae;
    L_0x0594:
        r10 = r0.zzvj;
        if (r10 == 0) goto L_0x0602;
    L_0x0598:
        goto L_0x05fe;
    L_0x0599:
        r9 = r2.getObject(r1, r9);
        r9 = (java.util.List) r9;
        r9 = com.google.android.gms.internal.places.zzja.zzac(r9);
        if (r9 <= 0) goto L_0x06ae;
    L_0x05a5:
        r10 = r0.zzvj;
        if (r10 == 0) goto L_0x0602;
    L_0x05a9:
        goto L_0x05fe;
    L_0x05aa:
        r9 = r2.getObject(r1, r9);
        r9 = (java.util.List) r9;
        r9 = com.google.android.gms.internal.places.zzja.zzy(r9);
        if (r9 <= 0) goto L_0x06ae;
    L_0x05b6:
        r10 = r0.zzvj;
        if (r10 == 0) goto L_0x0602;
    L_0x05ba:
        goto L_0x05fe;
    L_0x05bb:
        r9 = r2.getObject(r1, r9);
        r9 = (java.util.List) r9;
        r9 = com.google.android.gms.internal.places.zzja.zzv(r9);
        if (r9 <= 0) goto L_0x06ae;
    L_0x05c7:
        r10 = r0.zzvj;
        if (r10 == 0) goto L_0x0602;
    L_0x05cb:
        goto L_0x05fe;
    L_0x05cc:
        r9 = r2.getObject(r1, r9);
        r9 = (java.util.List) r9;
        r9 = com.google.android.gms.internal.places.zzja.zzu(r9);
        if (r9 <= 0) goto L_0x06ae;
    L_0x05d8:
        r10 = r0.zzvj;
        if (r10 == 0) goto L_0x0602;
    L_0x05dc:
        goto L_0x05fe;
    L_0x05dd:
        r9 = r2.getObject(r1, r9);
        r9 = (java.util.List) r9;
        r9 = com.google.android.gms.internal.places.zzja.zzab(r9);
        if (r9 <= 0) goto L_0x06ae;
    L_0x05e9:
        r10 = r0.zzvj;
        if (r10 == 0) goto L_0x0602;
    L_0x05ed:
        goto L_0x05fe;
    L_0x05ee:
        r9 = r2.getObject(r1, r9);
        r9 = (java.util.List) r9;
        r9 = com.google.android.gms.internal.places.zzja.zzac(r9);
        if (r9 <= 0) goto L_0x06ae;
    L_0x05fa:
        r10 = r0.zzvj;
        if (r10 == 0) goto L_0x0602;
    L_0x05fe:
        r10 = (long) r4;
        r2.putInt(r1, r10, r9);
    L_0x0602:
        r4 = com.google.android.gms.internal.places.zzgf.zzas(r14);
        r10 = com.google.android.gms.internal.places.zzgf.zzau(r9);
        r4 = r4 + r10;
        r4 = r4 + r9;
        goto L_0x06ad;
    L_0x060e:
        r4 = r2.getObject(r1, r9);
        r4 = (java.util.List) r4;
        r11 = 0;
        r4 = com.google.android.gms.internal.places.zzja.zzr(r14, r4, r11);
        goto L_0x06ad;
    L_0x061b:
        r11 = 0;
        r4 = r2.getObject(r1, r9);
        r4 = (java.util.List) r4;
        r4 = com.google.android.gms.internal.places.zzja.zzv(r14, r4, r11);
        goto L_0x06ad;
    L_0x0628:
        r11 = 0;
        r4 = r2.getObject(r1, r9);
        r4 = (java.util.List) r4;
        r4 = com.google.android.gms.internal.places.zzja.zzs(r14, r4, r11);
        goto L_0x06ad;
    L_0x0635:
        r11 = 0;
        r4 = r2.getObject(r1, r9);
        r4 = (java.util.List) r4;
        r4 = com.google.android.gms.internal.places.zzja.zzu(r14, r4, r11);
        goto L_0x06ad;
    L_0x0641:
        r4 = r2.getObject(r1, r9);
        r4 = (java.util.List) r4;
        r4 = com.google.android.gms.internal.places.zzja.zzf(r14, r4);
        goto L_0x06ad;
    L_0x064c:
        r4 = r2.getObject(r1, r9);
        r4 = (java.util.List) r4;
        r9 = r0.zzbf(r3);
        r4 = com.google.android.gms.internal.places.zzja.zzd(r14, r4, r9);
        goto L_0x06ad;
    L_0x065b:
        r4 = r2.getObject(r1, r9);
        r4 = (java.util.List) r4;
        r4 = com.google.android.gms.internal.places.zzja.zze(r14, r4);
        goto L_0x06ad;
    L_0x0666:
        r4 = r2.getObject(r1, r9);
        r4 = (java.util.List) r4;
        r11 = 0;
        r4 = com.google.android.gms.internal.places.zzja.zzy(r14, r4, r11);
        goto L_0x06ad;
    L_0x0672:
        r11 = 0;
        r4 = r2.getObject(r1, r9);
        r4 = (java.util.List) r4;
        r4 = com.google.android.gms.internal.places.zzja.zzt(r14, r4, r11);
        goto L_0x06ad;
    L_0x067e:
        r11 = 0;
        r4 = r2.getObject(r1, r9);
        r4 = (java.util.List) r4;
        r4 = com.google.android.gms.internal.places.zzja.zzq(r14, r4, r11);
        goto L_0x06ad;
    L_0x068a:
        r11 = 0;
        r4 = r2.getObject(r1, r9);
        r4 = (java.util.List) r4;
        r4 = com.google.android.gms.internal.places.zzja.zzp(r14, r4, r11);
        goto L_0x06ad;
    L_0x0696:
        r11 = 0;
        r4 = r2.getObject(r1, r9);
        r4 = (java.util.List) r4;
        r4 = com.google.android.gms.internal.places.zzja.zzw(r14, r4, r11);
        goto L_0x06ad;
    L_0x06a2:
        r11 = 0;
        r4 = r2.getObject(r1, r9);
        r4 = (java.util.List) r4;
        r4 = com.google.android.gms.internal.places.zzja.zzx(r14, r4, r11);
    L_0x06ad:
        r5 = r5 + r4;
    L_0x06ae:
        r4 = 0;
    L_0x06af:
        r9 = 0;
        r10 = 0;
        r18 = 0;
        goto L_0x07bf;
    L_0x06b6:
        r4 = r12 & r16;
        if (r4 == 0) goto L_0x06ae;
    L_0x06ba:
        r4 = r2.getObject(r1, r9);
        r4 = (com.google.android.gms.internal.places.zzih) r4;
        r9 = r0.zzbf(r3);
        r4 = com.google.android.gms.internal.places.zzgf.zzd(r14, r4, r9);
        goto L_0x06ad;
    L_0x06c9:
        r4 = r12 & r16;
        if (r4 == 0) goto L_0x06ae;
    L_0x06cd:
        r9 = r2.getLong(r1, r9);
    L_0x06d1:
        r4 = com.google.android.gms.internal.places.zzgf.zzg(r14, r9);
        goto L_0x06ad;
    L_0x06d6:
        r4 = r12 & r16;
        if (r4 == 0) goto L_0x06ae;
    L_0x06da:
        r4 = r2.getInt(r1, r9);
    L_0x06de:
        r4 = com.google.android.gms.internal.places.zzgf.zzk(r14, r4);
        goto L_0x06ad;
    L_0x06e3:
        r4 = r12 & r16;
        if (r4 == 0) goto L_0x06ae;
    L_0x06e7:
        r9 = 0;
        r4 = com.google.android.gms.internal.places.zzgf.zzi(r14, r9);
        goto L_0x06ad;
    L_0x06ee:
        r4 = r12 & r16;
        if (r4 == 0) goto L_0x06ae;
    L_0x06f2:
        r4 = 0;
        r9 = com.google.android.gms.internal.places.zzgf.zzm(r14, r4);
    L_0x06f7:
        r5 = r5 + r9;
        goto L_0x06ae;
    L_0x06f9:
        r4 = r12 & r16;
        if (r4 == 0) goto L_0x06ae;
    L_0x06fd:
        r4 = r2.getInt(r1, r9);
    L_0x0701:
        r4 = com.google.android.gms.internal.places.zzgf.zzn(r14, r4);
        goto L_0x06ad;
    L_0x0706:
        r4 = r12 & r16;
        if (r4 == 0) goto L_0x06ae;
    L_0x070a:
        r4 = r2.getInt(r1, r9);
    L_0x070e:
        r4 = com.google.android.gms.internal.places.zzgf.zzj(r14, r4);
        goto L_0x06ad;
    L_0x0713:
        r4 = r12 & r16;
        if (r4 == 0) goto L_0x06ae;
    L_0x0717:
        r4 = r2.getObject(r1, r9);
    L_0x071b:
        r4 = (com.google.android.gms.internal.places.zzfr) r4;
        r4 = com.google.android.gms.internal.places.zzgf.zzd(r14, r4);
        goto L_0x06ad;
    L_0x0722:
        r4 = r12 & r16;
        if (r4 == 0) goto L_0x06ae;
    L_0x0726:
        r4 = r2.getObject(r1, r9);
        r9 = r0.zzbf(r3);
        r4 = com.google.android.gms.internal.places.zzja.zzd(r14, r4, r9);
        goto L_0x06ad;
    L_0x0734:
        r4 = r12 & r16;
        if (r4 == 0) goto L_0x06ae;
    L_0x0738:
        r4 = r2.getObject(r1, r9);
        r9 = r4 instanceof com.google.android.gms.internal.places.zzfr;
        if (r9 == 0) goto L_0x0741;
    L_0x0740:
        goto L_0x071b;
    L_0x0741:
        r4 = (java.lang.String) r4;
        r4 = com.google.android.gms.internal.places.zzgf.zzc(r14, r4);
        goto L_0x06ad;
    L_0x0749:
        r4 = r12 & r16;
        if (r4 == 0) goto L_0x06ae;
    L_0x074d:
        r4 = com.google.android.gms.internal.places.zzgf.zzd(r14, r7);
        goto L_0x06ad;
    L_0x0753:
        r4 = r12 & r16;
        if (r4 == 0) goto L_0x06ae;
    L_0x0757:
        r4 = 0;
        r9 = com.google.android.gms.internal.places.zzgf.zzl(r14, r4);
        r5 = r5 + r9;
        goto L_0x06af;
    L_0x075f:
        r4 = 0;
        r9 = r12 & r16;
        if (r9 == 0) goto L_0x06af;
    L_0x0764:
        r9 = 0;
        r11 = com.google.android.gms.internal.places.zzgf.zzh(r14, r9);
        r5 = r5 + r11;
        r18 = r9;
        goto L_0x079e;
    L_0x076e:
        r4 = 0;
        r18 = 0;
        r11 = r12 & r16;
        if (r11 == 0) goto L_0x079e;
    L_0x0775:
        r9 = r2.getInt(r1, r9);
        r9 = com.google.android.gms.internal.places.zzgf.zzi(r14, r9);
        goto L_0x079d;
    L_0x077e:
        r4 = 0;
        r18 = 0;
        r11 = r12 & r16;
        if (r11 == 0) goto L_0x079e;
    L_0x0785:
        r9 = r2.getLong(r1, r9);
        r9 = com.google.android.gms.internal.places.zzgf.zzf(r14, r9);
        goto L_0x079d;
    L_0x078e:
        r4 = 0;
        r18 = 0;
        r11 = r12 & r16;
        if (r11 == 0) goto L_0x079e;
    L_0x0795:
        r9 = r2.getLong(r1, r9);
        r9 = com.google.android.gms.internal.places.zzgf.zze(r14, r9);
    L_0x079d:
        r5 = r5 + r9;
    L_0x079e:
        r9 = 0;
        goto L_0x07ad;
    L_0x07a0:
        r4 = 0;
        r18 = 0;
        r9 = r12 & r16;
        if (r9 == 0) goto L_0x079e;
    L_0x07a7:
        r9 = 0;
        r10 = com.google.android.gms.internal.places.zzgf.zzd(r14, r9);
        r5 = r5 + r10;
    L_0x07ad:
        r10 = 0;
        goto L_0x07bf;
    L_0x07b0:
        r4 = 0;
        r9 = 0;
        r18 = 0;
        r10 = r12 & r16;
        if (r10 == 0) goto L_0x07ad;
    L_0x07b8:
        r10 = 0;
        r13 = com.google.android.gms.internal.places.zzgf.zzc(r14, r10);
        r5 = r5 + r13;
    L_0x07bf:
        r3 = r3 + 4;
        r9 = r18;
        r4 = 0;
        r11 = 0;
        goto L_0x03bf;
    L_0x07c7:
        r2 = r0.zzvp;
        r2 = zzb(r2, r1);
        r5 = r5 + r2;
        r2 = r0.zzvg;
        if (r2 == 0) goto L_0x07dd;
    L_0x07d2:
        r2 = r0.zzvq;
        r1 = r2.zzb(r1);
        r1 = r1.zzdg();
        r5 = r5 + r1;
    L_0x07dd:
        return r5;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.places.zzil.zzn(java.lang.Object):int");
    }

    public final boolean zzo(T t) {
        Object obj = t;
        int i = 1;
        if (this.zzvk != null) {
            if (r0.zzvk.length != 0) {
                int[] iArr = r0.zzvk;
                int length = iArr.length;
                int i2 = 0;
                int i3 = -1;
                int i4 = 0;
                while (i2 < length) {
                    int[] iArr2;
                    int i5;
                    int i6 = iArr[i2];
                    int zzbl = zzbl(i6);
                    int zzbi = zzbi(zzbl);
                    if (r0.zzvi) {
                        iArr2 = iArr;
                        i5 = 0;
                    } else {
                        i5 = r0.zzva[zzbl + 2];
                        int i7 = i5 & 1048575;
                        i5 = i << (i5 >>> 20);
                        if (i7 != i3) {
                            iArr2 = iArr;
                            i4 = zzuz.getInt(obj, (long) i7);
                            i3 = i7;
                        } else {
                            iArr2 = iArr;
                        }
                    }
                    if (((ErrorDialogData.BINDER_CRASH & zzbi) != 0 ? 1 : null) != null && !zzb(obj, zzbl, i4, i5)) {
                        return false;
                    }
                    i = (267386880 & zzbi) >>> 20;
                    if (i != 9 && i != 17) {
                        zziy zziy;
                        Object obj2;
                        if (i != 27) {
                            if (i != 60 && i != 68) {
                                switch (i) {
                                    case 49:
                                        break;
                                    case 50:
                                        Map zzi = r0.zzvr.zzi(zzjw.zzq(obj, (long) (zzbi & 1048575)));
                                        if (!zzi.isEmpty()) {
                                            if (r0.zzvr.zzm(zzbg(zzbl)).zzuv.zzgz() == zzkj.MESSAGE) {
                                                zziy = null;
                                                for (Object next : zzi.values()) {
                                                    if (zziy == null) {
                                                        zziy = zzis.zzfc().zzg(next.getClass());
                                                    }
                                                    if (!zziy.zzo(next)) {
                                                        obj2 = null;
                                                        if (obj2 == null) {
                                                            return false;
                                                        }
                                                        continue;
                                                    }
                                                }
                                            }
                                        }
                                        obj2 = 1;
                                        if (obj2 == null) {
                                            return false;
                                        }
                                        continue;
                                    default:
                                        continue;
                                }
                            } else if (zzb(obj, i6, zzbl) && !zzb(obj, zzbi, zzbf(zzbl))) {
                                return false;
                            }
                        }
                        List list = (List) zzjw.zzq(obj, (long) (zzbi & 1048575));
                        if (!list.isEmpty()) {
                            zziy = zzbf(zzbl);
                            i6 = 0;
                            while (i6 < list.size()) {
                                if (zziy.zzo(list.get(i6))) {
                                    i6++;
                                } else {
                                    obj2 = null;
                                    if (obj2 == null) {
                                        return false;
                                    }
                                }
                            }
                        }
                        obj2 = 1;
                        if (obj2 == null) {
                            return false;
                        }
                    } else if (zzb(obj, zzbl, i4, i5) && !zzb(obj, zzbi, zzbf(zzbl))) {
                        return false;
                    }
                    i2++;
                    iArr = iArr2;
                    i = 1;
                }
                return !r0.zzvg || r0.zzvq.zzb(obj).isInitialized();
            }
        }
        return true;
    }
}
