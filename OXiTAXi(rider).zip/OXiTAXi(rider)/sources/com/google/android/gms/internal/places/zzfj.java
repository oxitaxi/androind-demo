package com.google.android.gms.internal.places;

public abstract class zzfj<MessageType extends zzih> implements zzir<MessageType> {
    private static final zzgl zznj = zzgl.zzda();
}
