package com.google.android.gms.internal.places;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.logging.Level;
import java.util.logging.Logger;

public abstract class zzgf extends zzfq {
    private static final Logger logger = Logger.getLogger(zzgf.class.getName());
    private static final boolean zzoo = zzjw.zzgs();
    zzgh zzop = this;

    public static class zzd extends IOException {
        zzd() {
            super("CodedOutputStream was writing to a flat byte array and ran out of space.");
        }

        zzd(String str) {
            String valueOf = String.valueOf("CodedOutputStream was writing to a flat byte array and ran out of space.: ");
            str = String.valueOf(str);
            super(str.length() != 0 ? valueOf.concat(str) : new String(valueOf));
        }

        zzd(String str, Throwable th) {
            String valueOf = String.valueOf("CodedOutputStream was writing to a flat byte array and ran out of space.: ");
            str = String.valueOf(str);
            super(str.length() != 0 ? valueOf.concat(str) : new String(valueOf), th);
        }

        zzd(Throwable th) {
            super("CodedOutputStream was writing to a flat byte array and ran out of space.", th);
        }
    }

    static class zzb extends zzgf {
        private final byte[] buffer;
        private final int limit;
        private final int offset;
        private int position;

        zzb(byte[] bArr, int i, int i2) {
            super();
            if (bArr != null) {
                int i3 = i + i2;
                if (((i | i2) | (bArr.length - i3)) >= 0) {
                    this.buffer = bArr;
                    this.offset = i;
                    this.position = i;
                    this.limit = i3;
                    return;
                }
                throw new IllegalArgumentException(String.format("Array range is invalid. Buffer.length=%d, offset=%d, length=%d", new Object[]{Integer.valueOf(bArr.length), Integer.valueOf(i), Integer.valueOf(i2)}));
            }
            throw new NullPointerException("buffer");
        }

        public void flush() {
        }

        public final void write(byte[] bArr, int i, int i2) throws IOException {
            try {
                System.arraycopy(bArr, i, this.buffer, this.position, i2);
                this.position += i2;
            } catch (Throwable e) {
                throw new zzd(String.format("Pos: %d, limit: %d, len: %d", new Object[]{Integer.valueOf(this.position), Integer.valueOf(this.limit), Integer.valueOf(i2)}), e);
            }
        }

        public final void zzao(int i) throws IOException {
            if (i >= 0) {
                zzap(i);
            } else {
                zze((long) i);
            }
        }

        public final void zzap(int i) throws IOException {
            byte[] bArr;
            int i2;
            if (!zzgf.zzoo || zzcs() < 10) {
                while ((i & -128) != 0) {
                    bArr = this.buffer;
                    i2 = this.position;
                    this.position = i2 + 1;
                    bArr[i2] = (byte) ((i & 127) | 128);
                    i >>>= 7;
                }
                try {
                    bArr = this.buffer;
                    i2 = this.position;
                    this.position = i2 + 1;
                    bArr[i2] = (byte) i;
                    return;
                } catch (Throwable e) {
                    throw new zzd(String.format("Pos: %d, limit: %d, len: %d", new Object[]{Integer.valueOf(this.position), Integer.valueOf(this.limit), Integer.valueOf(1)}), e);
                }
            }
            while ((i & -128) != 0) {
                bArr = this.buffer;
                i2 = this.position;
                this.position = i2 + 1;
                zzjw.zzb(bArr, (long) i2, (byte) ((i & 127) | 128));
                i >>>= 7;
            }
            bArr = this.buffer;
            i2 = this.position;
            this.position = i2 + 1;
            zzjw.zzb(bArr, (long) i2, (byte) i);
        }

        public final void zzar(int i) throws IOException {
            try {
                byte[] bArr = this.buffer;
                int i2 = this.position;
                this.position = i2 + 1;
                bArr[i2] = (byte) i;
                bArr = this.buffer;
                i2 = this.position;
                this.position = i2 + 1;
                bArr[i2] = (byte) (i >> 8);
                bArr = this.buffer;
                i2 = this.position;
                this.position = i2 + 1;
                bArr[i2] = (byte) (i >> 16);
                bArr = this.buffer;
                i2 = this.position;
                this.position = i2 + 1;
                bArr[i2] = i >> 24;
            } catch (Throwable e) {
                throw new zzd(String.format("Pos: %d, limit: %d, len: %d", new Object[]{Integer.valueOf(this.position), Integer.valueOf(this.limit), Integer.valueOf(1)}), e);
            }
        }

        public final void zzb(byte b) throws IOException {
            try {
                byte[] bArr = this.buffer;
                int i = this.position;
                this.position = i + 1;
                bArr[i] = b;
            } catch (Throwable e) {
                throw new zzd(String.format("Pos: %d, limit: %d, len: %d", new Object[]{Integer.valueOf(this.position), Integer.valueOf(this.limit), Integer.valueOf(1)}), e);
            }
        }

        public final void zzb(int i, long j) throws IOException {
            zzd(i, 0);
            zze(j);
        }

        public final void zzb(int i, zzfr zzfr) throws IOException {
            zzd(i, 2);
            zzb(zzfr);
        }

        public final void zzb(int i, zzih zzih) throws IOException {
            zzd(i, 2);
            zzc(zzih);
        }

        final void zzb(int i, zzih zzih, zziy zziy) throws IOException {
            zzd(i, 2);
            zzfh zzfh = (zzfh) zzih;
            int zzay = zzfh.zzay();
            if (zzay == -1) {
                zzay = zziy.zzn(zzfh);
                zzfh.zzv(zzay);
            }
            zzap(zzay);
            zziy.zzb(zzih, this.zzop);
        }

        public final void zzb(int i, String str) throws IOException {
            zzd(i, 2);
            zzk(str);
        }

        public final void zzb(zzfr zzfr) throws IOException {
            zzap(zzfr.size());
            zzfr.zzb((zzfq) this);
        }

        final void zzb(zzih zzih, zziy zziy) throws IOException {
            zzfh zzfh = (zzfh) zzih;
            int zzay = zzfh.zzay();
            if (zzay == -1) {
                zzay = zziy.zzn(zzfh);
                zzfh.zzv(zzay);
            }
            zzap(zzay);
            zziy.zzb(zzih, this.zzop);
        }

        public final void zzb(byte[] bArr, int i, int i2) throws IOException {
            write(bArr, i, i2);
        }

        public final void zzc(int i, zzfr zzfr) throws IOException {
            zzd(1, 3);
            zzf(2, i);
            zzb(3, zzfr);
            zzd(1, 4);
        }

        public final void zzc(int i, zzih zzih) throws IOException {
            zzd(1, 3);
            zzf(2, i);
            zzb(3, zzih);
            zzd(1, 4);
        }

        public final void zzc(int i, boolean z) throws IOException {
            zzd(i, 0);
            zzb((byte) z);
        }

        public final void zzc(zzih zzih) throws IOException {
            zzap(zzih.zzdg());
            zzih.zzc(this);
        }

        public final int zzcs() {
            return this.limit - this.position;
        }

        public final int zzcu() {
            return this.position - this.offset;
        }

        public final void zzd(int i, int i2) throws IOException {
            zzap((i << 3) | i2);
        }

        public final void zzd(int i, long j) throws IOException {
            zzd(i, 1);
            zzg(j);
        }

        public final void zze(int i, int i2) throws IOException {
            zzd(i, 0);
            zzao(i2);
        }

        public final void zze(long j) throws IOException {
            byte[] bArr;
            if (!zzgf.zzoo || zzcs() < 10) {
                while ((j & -128) != 0) {
                    bArr = this.buffer;
                    int i = this.position;
                    this.position = i + 1;
                    bArr[i] = (byte) ((((int) j) & 127) | 128);
                    j >>>= 7;
                }
                try {
                    bArr = this.buffer;
                    int i2 = this.position;
                    this.position = i2 + 1;
                    bArr[i2] = (byte) ((int) j);
                    return;
                } catch (Throwable e) {
                    throw new zzd(String.format("Pos: %d, limit: %d, len: %d", new Object[]{Integer.valueOf(this.position), Integer.valueOf(this.limit), Integer.valueOf(1)}), e);
                }
            }
            while ((j & -128) != 0) {
                bArr = this.buffer;
                i = this.position;
                this.position = i + 1;
                zzjw.zzb(bArr, (long) i, (byte) ((((int) j) & 127) | 128));
                j >>>= 7;
            }
            bArr = this.buffer;
            i2 = this.position;
            this.position = i2 + 1;
            zzjw.zzb(bArr, (long) i2, (byte) ((int) j));
        }

        public final void zzf(int i, int i2) throws IOException {
            zzd(i, 0);
            zzap(i2);
        }

        public final void zzg(long j) throws IOException {
            try {
                byte[] bArr = this.buffer;
                int i = this.position;
                this.position = i + 1;
                bArr[i] = (byte) ((int) j);
                bArr = this.buffer;
                i = this.position;
                this.position = i + 1;
                bArr[i] = (byte) ((int) (j >> 8));
                bArr = this.buffer;
                i = this.position;
                this.position = i + 1;
                bArr[i] = (byte) ((int) (j >> 16));
                bArr = this.buffer;
                i = this.position;
                this.position = i + 1;
                bArr[i] = (byte) ((int) (j >> 24));
                bArr = this.buffer;
                i = this.position;
                this.position = i + 1;
                bArr[i] = (byte) ((int) (j >> 32));
                bArr = this.buffer;
                i = this.position;
                this.position = i + 1;
                bArr[i] = (byte) ((int) (j >> 40));
                bArr = this.buffer;
                i = this.position;
                this.position = i + 1;
                bArr[i] = (byte) ((int) (j >> 48));
                bArr = this.buffer;
                i = this.position;
                this.position = i + 1;
                bArr[i] = (byte) ((int) (j >> 56));
            } catch (Throwable e) {
                throw new zzd(String.format("Pos: %d, limit: %d, len: %d", new Object[]{Integer.valueOf(this.position), Integer.valueOf(this.limit), Integer.valueOf(1)}), e);
            }
        }

        public final void zzg(byte[] bArr, int i, int i2) throws IOException {
            zzap(i2);
            write(bArr, 0, i2);
        }

        public final void zzh(int i, int i2) throws IOException {
            zzd(i, 5);
            zzar(i2);
        }

        public final void zzk(String str) throws IOException {
            int i = this.position;
            try {
                int zzau = zzgf.zzau(str.length() * 3);
                int zzau2 = zzgf.zzau(str.length());
                if (zzau2 == zzau) {
                    this.position = i + zzau2;
                    zzau = zzjy.zzb(str, this.buffer, this.position, zzcs());
                    this.position = i;
                    zzap((zzau - i) - zzau2);
                    this.position = zzau;
                    return;
                }
                zzap(zzjy.zzb(str));
                this.position = zzjy.zzb(str, this.buffer, this.position, zzcs());
            } catch (zzkb e) {
                this.position = i;
                zzb(str, e);
            } catch (Throwable e2) {
                throw new zzd(e2);
            }
        }
    }

    static final class zze extends zzgf {
        private final int zzor;
        private final ByteBuffer zzos;
        private final ByteBuffer zzot;

        zze(ByteBuffer byteBuffer) {
            super();
            this.zzos = byteBuffer;
            this.zzot = byteBuffer.duplicate().order(ByteOrder.LITTLE_ENDIAN);
            this.zzor = byteBuffer.position();
        }

        private final void zzm(String str) throws IOException {
            try {
                zzjy.zzb(str, this.zzot);
            } catch (Throwable e) {
                throw new zzd(e);
            }
        }

        public final void flush() {
            this.zzos.position(this.zzot.position());
        }

        public final void write(byte[] bArr, int i, int i2) throws IOException {
            try {
                this.zzot.put(bArr, i, i2);
            } catch (Throwable e) {
                throw new zzd(e);
            } catch (Throwable e2) {
                throw new zzd(e2);
            }
        }

        public final void zzao(int i) throws IOException {
            if (i >= 0) {
                zzap(i);
            } else {
                zze((long) i);
            }
        }

        public final void zzap(int i) throws IOException {
            while ((i & -128) != 0) {
                this.zzot.put((byte) ((i & 127) | 128));
                i >>>= 7;
            }
            try {
                this.zzot.put((byte) i);
            } catch (Throwable e) {
                throw new zzd(e);
            }
        }

        public final void zzar(int i) throws IOException {
            try {
                this.zzot.putInt(i);
            } catch (Throwable e) {
                throw new zzd(e);
            }
        }

        public final void zzb(byte b) throws IOException {
            try {
                this.zzot.put(b);
            } catch (Throwable e) {
                throw new zzd(e);
            }
        }

        public final void zzb(int i, long j) throws IOException {
            zzd(i, 0);
            zze(j);
        }

        public final void zzb(int i, zzfr zzfr) throws IOException {
            zzd(i, 2);
            zzb(zzfr);
        }

        public final void zzb(int i, zzih zzih) throws IOException {
            zzd(i, 2);
            zzc(zzih);
        }

        final void zzb(int i, zzih zzih, zziy zziy) throws IOException {
            zzd(i, 2);
            zzb(zzih, zziy);
        }

        public final void zzb(int i, String str) throws IOException {
            zzd(i, 2);
            zzk(str);
        }

        public final void zzb(zzfr zzfr) throws IOException {
            zzap(zzfr.size());
            zzfr.zzb((zzfq) this);
        }

        final void zzb(zzih zzih, zziy zziy) throws IOException {
            zzfh zzfh = (zzfh) zzih;
            int zzay = zzfh.zzay();
            if (zzay == -1) {
                zzay = zziy.zzn(zzfh);
                zzfh.zzv(zzay);
            }
            zzap(zzay);
            zziy.zzb(zzih, this.zzop);
        }

        public final void zzb(byte[] bArr, int i, int i2) throws IOException {
            write(bArr, i, i2);
        }

        public final void zzc(int i, zzfr zzfr) throws IOException {
            zzd(1, 3);
            zzf(2, i);
            zzb(3, zzfr);
            zzd(1, 4);
        }

        public final void zzc(int i, zzih zzih) throws IOException {
            zzd(1, 3);
            zzf(2, i);
            zzb(3, zzih);
            zzd(1, 4);
        }

        public final void zzc(int i, boolean z) throws IOException {
            zzd(i, 0);
            zzb((byte) z);
        }

        public final void zzc(zzih zzih) throws IOException {
            zzap(zzih.zzdg());
            zzih.zzc(this);
        }

        public final int zzcs() {
            return this.zzot.remaining();
        }

        public final void zzd(int i, int i2) throws IOException {
            zzap((i << 3) | i2);
        }

        public final void zzd(int i, long j) throws IOException {
            zzd(i, 1);
            zzg(j);
        }

        public final void zze(int i, int i2) throws IOException {
            zzd(i, 0);
            zzao(i2);
        }

        public final void zze(long j) throws IOException {
            while ((-128 & j) != 0) {
                this.zzot.put((byte) ((((int) j) & 127) | 128));
                j >>>= 7;
            }
            try {
                this.zzot.put((byte) ((int) j));
            } catch (Throwable e) {
                throw new zzd(e);
            }
        }

        public final void zzf(int i, int i2) throws IOException {
            zzd(i, 0);
            zzap(i2);
        }

        public final void zzg(long j) throws IOException {
            try {
                this.zzot.putLong(j);
            } catch (Throwable e) {
                throw new zzd(e);
            }
        }

        public final void zzg(byte[] bArr, int i, int i2) throws IOException {
            zzap(i2);
            write(bArr, 0, i2);
        }

        public final void zzh(int i, int i2) throws IOException {
            zzd(i, 5);
            zzar(i2);
        }

        public final void zzk(String str) throws IOException {
            int position = this.zzot.position();
            try {
                int zzau = zzgf.zzau(str.length() * 3);
                int zzau2 = zzgf.zzau(str.length());
                if (zzau2 == zzau) {
                    zzau = this.zzot.position() + zzau2;
                    this.zzot.position(zzau);
                    zzm(str);
                    zzau2 = this.zzot.position();
                    this.zzot.position(position);
                    zzap(zzau2 - zzau);
                    this.zzot.position(zzau2);
                    return;
                }
                zzap(zzjy.zzb(str));
                zzm(str);
            } catch (zzkb e) {
                this.zzot.position(position);
                zzb(str, e);
            } catch (Throwable e2) {
                throw new zzd(e2);
            }
        }
    }

    static final class zzf extends zzgf {
        private final ByteBuffer zzos;
        private final ByteBuffer zzot;
        private final long zzou;
        private final long zzov;
        private final long zzow;
        private final long zzox = (this.zzow - 10);
        private long zzoy = this.zzov;

        zzf(ByteBuffer byteBuffer) {
            super();
            this.zzos = byteBuffer;
            this.zzot = byteBuffer.duplicate().order(ByteOrder.LITTLE_ENDIAN);
            this.zzou = zzjw.zzc(byteBuffer);
            this.zzov = this.zzou + ((long) byteBuffer.position());
            this.zzow = this.zzou + ((long) byteBuffer.limit());
        }

        private final void zzn(long j) {
            this.zzot.position((int) (j - this.zzou));
        }

        public final void flush() {
            this.zzos.position((int) (this.zzoy - this.zzou));
        }

        public final void write(byte[] bArr, int i, int i2) throws IOException {
            if (bArr != null && i >= 0 && i2 >= 0 && bArr.length - i2 >= i) {
                long j = (long) i2;
                if (this.zzow - j >= this.zzoy) {
                    zzjw.zzb(bArr, (long) i, this.zzoy, j);
                    this.zzoy += j;
                    return;
                }
            }
            if (bArr == null) {
                throw new NullPointerException("value");
            }
            throw new zzd(String.format("Pos: %d, limit: %d, len: %d", new Object[]{Long.valueOf(this.zzoy), Long.valueOf(this.zzow), Integer.valueOf(i2)}));
        }

        public final void zzao(int i) throws IOException {
            if (i >= 0) {
                zzap(i);
            } else {
                zze((long) i);
            }
        }

        public final void zzap(int i) throws IOException {
            long j;
            if (this.zzoy <= this.zzox) {
                while ((i & -128) != 0) {
                    j = this.zzoy;
                    this.zzoy = j + 1;
                    zzjw.zzb(j, (byte) ((i & 127) | 128));
                    i >>>= 7;
                }
            } else {
                while (this.zzoy < this.zzow) {
                    if ((i & -128) != 0) {
                        j = this.zzoy;
                        this.zzoy = j + 1;
                        zzjw.zzb(j, (byte) ((i & 127) | 128));
                        i >>>= 7;
                    }
                }
                throw new zzd(String.format("Pos: %d, limit: %d, len: %d", new Object[]{Long.valueOf(this.zzoy), Long.valueOf(this.zzow), Integer.valueOf(1)}));
            }
            j = this.zzoy;
            this.zzoy = 1 + j;
            zzjw.zzb(j, (byte) i);
        }

        public final void zzar(int i) throws IOException {
            this.zzot.putInt((int) (this.zzoy - this.zzou), i);
            this.zzoy += 4;
        }

        public final void zzb(byte b) throws IOException {
            if (this.zzoy < this.zzow) {
                long j = this.zzoy;
                this.zzoy = 1 + j;
                zzjw.zzb(j, b);
                return;
            }
            throw new zzd(String.format("Pos: %d, limit: %d, len: %d", new Object[]{Long.valueOf(this.zzoy), Long.valueOf(this.zzow), Integer.valueOf(1)}));
        }

        public final void zzb(int i, long j) throws IOException {
            zzd(i, 0);
            zze(j);
        }

        public final void zzb(int i, zzfr zzfr) throws IOException {
            zzd(i, 2);
            zzb(zzfr);
        }

        public final void zzb(int i, zzih zzih) throws IOException {
            zzd(i, 2);
            zzc(zzih);
        }

        final void zzb(int i, zzih zzih, zziy zziy) throws IOException {
            zzd(i, 2);
            zzb(zzih, zziy);
        }

        public final void zzb(int i, String str) throws IOException {
            zzd(i, 2);
            zzk(str);
        }

        public final void zzb(zzfr zzfr) throws IOException {
            zzap(zzfr.size());
            zzfr.zzb((zzfq) this);
        }

        final void zzb(zzih zzih, zziy zziy) throws IOException {
            zzfh zzfh = (zzfh) zzih;
            int zzay = zzfh.zzay();
            if (zzay == -1) {
                zzay = zziy.zzn(zzfh);
                zzfh.zzv(zzay);
            }
            zzap(zzay);
            zziy.zzb(zzih, this.zzop);
        }

        public final void zzb(byte[] bArr, int i, int i2) throws IOException {
            write(bArr, i, i2);
        }

        public final void zzc(int i, zzfr zzfr) throws IOException {
            zzd(1, 3);
            zzf(2, i);
            zzb(3, zzfr);
            zzd(1, 4);
        }

        public final void zzc(int i, zzih zzih) throws IOException {
            zzd(1, 3);
            zzf(2, i);
            zzb(3, zzih);
            zzd(1, 4);
        }

        public final void zzc(int i, boolean z) throws IOException {
            zzd(i, 0);
            zzb((byte) z);
        }

        public final void zzc(zzih zzih) throws IOException {
            zzap(zzih.zzdg());
            zzih.zzc(this);
        }

        public final int zzcs() {
            return (int) (this.zzow - this.zzoy);
        }

        public final void zzd(int i, int i2) throws IOException {
            zzap((i << 3) | i2);
        }

        public final void zzd(int i, long j) throws IOException {
            zzd(i, 1);
            zzg(j);
        }

        public final void zze(int i, int i2) throws IOException {
            zzd(i, 0);
            zzao(i2);
        }

        public final void zze(long j) throws IOException {
            long j2;
            if (this.zzoy <= this.zzox) {
                while ((j & -128) != 0) {
                    j2 = this.zzoy;
                    this.zzoy = j2 + 1;
                    zzjw.zzb(j2, (byte) ((((int) j) & 127) | 128));
                    j >>>= 7;
                }
            } else {
                while (this.zzoy < this.zzow) {
                    if ((j & -128) != 0) {
                        j2 = this.zzoy;
                        this.zzoy = j2 + 1;
                        zzjw.zzb(j2, (byte) ((((int) j) & 127) | 128));
                        j >>>= 7;
                    }
                }
                throw new zzd(String.format("Pos: %d, limit: %d, len: %d", new Object[]{Long.valueOf(this.zzoy), Long.valueOf(this.zzow), Integer.valueOf(1)}));
            }
            j2 = this.zzoy;
            this.zzoy = 1 + j2;
            zzjw.zzb(j2, (byte) ((int) j));
        }

        public final void zzf(int i, int i2) throws IOException {
            zzd(i, 0);
            zzap(i2);
        }

        public final void zzg(long j) throws IOException {
            this.zzot.putLong((int) (this.zzoy - this.zzou), j);
            this.zzoy += 8;
        }

        public final void zzg(byte[] bArr, int i, int i2) throws IOException {
            zzap(i2);
            write(bArr, 0, i2);
        }

        public final void zzh(int i, int i2) throws IOException {
            zzd(i, 5);
            zzar(i2);
        }

        public final void zzk(String str) throws IOException {
            long j = this.zzoy;
            try {
                int zzau = zzgf.zzau(str.length() * 3);
                int zzau2 = zzgf.zzau(str.length());
                if (zzau2 == zzau) {
                    zzau = ((int) (this.zzoy - this.zzou)) + zzau2;
                    this.zzot.position(zzau);
                    zzjy.zzb(str, this.zzot);
                    zzau2 = this.zzot.position() - zzau;
                    zzap(zzau2);
                    this.zzoy += (long) zzau2;
                    return;
                }
                zzau = zzjy.zzb(str);
                zzap(zzau);
                zzn(this.zzoy);
                zzjy.zzb(str, this.zzot);
                this.zzoy += (long) zzau;
            } catch (zzkb e) {
                this.zzoy = j;
                zzn(this.zzoy);
                zzb(str, e);
            } catch (Throwable e2) {
                throw new zzd(e2);
            } catch (Throwable e22) {
                throw new zzd(e22);
            }
        }
    }

    static final class zzc extends zzb {
        private final ByteBuffer zzoq;
        private int zzor;

        zzc(ByteBuffer byteBuffer) {
            super(byteBuffer.array(), byteBuffer.arrayOffset() + byteBuffer.position(), byteBuffer.remaining());
            this.zzoq = byteBuffer;
            this.zzor = byteBuffer.position();
        }

        public final void flush() {
            this.zzoq.position(this.zzor + zzcu());
        }
    }

    private zzgf() {
    }

    public static int zzas(int i) {
        return zzau(i << 3);
    }

    public static int zzat(int i) {
        return i >= 0 ? zzau(i) : 10;
    }

    public static int zzau(int i) {
        return (i & -128) == 0 ? 1 : (i & -16384) == 0 ? 2 : (-2097152 & i) == 0 ? 3 : (i & -268435456) == 0 ? 4 : 5;
    }

    public static int zzav(int i) {
        return zzau(zzaz(i));
    }

    public static int zzaw(int i) {
        return 4;
    }

    public static int zzax(int i) {
        return 4;
    }

    public static int zzay(int i) {
        return zzat(i);
    }

    private static int zzaz(int i) {
        return (i >> 31) ^ (i << 1);
    }

    public static int zzb(int i, zzho zzho) {
        i = zzas(i);
        int zzdg = zzho.zzdg();
        return i + (zzau(zzdg) + zzdg);
    }

    public static int zzb(zzho zzho) {
        int zzdg = zzho.zzdg();
        return zzau(zzdg) + zzdg;
    }

    public static zzgf zzb(ByteBuffer byteBuffer) {
        if (byteBuffer.hasArray()) {
            return new zzc(byteBuffer);
        }
        if (byteBuffer.isDirect() && !byteBuffer.isReadOnly()) {
            return zzjw.zzgt() ? new zzf(byteBuffer) : new zze(byteBuffer);
        } else {
            throw new IllegalArgumentException("ByteBuffer is read-only");
        }
    }

    @Deprecated
    public static int zzba(int i) {
        return zzau(i);
    }

    public static int zzc(double d) {
        return 8;
    }

    public static int zzc(int i, double d) {
        return zzas(i) + 8;
    }

    public static int zzc(int i, zzho zzho) {
        return ((zzas(1) << 1) + zzj(2, i)) + zzb(3, zzho);
    }

    static int zzc(int i, zzih zzih, zziy zziy) {
        return zzas(i) + zzc(zzih, zziy);
    }

    public static int zzc(int i, String str) {
        return zzas(i) + zzl(str);
    }

    public static int zzc(zzfr zzfr) {
        int size = zzfr.size();
        return zzau(size) + size;
    }

    static int zzc(zzih zzih, zziy zziy) {
        zzfh zzfh = (zzfh) zzih;
        int zzay = zzfh.zzay();
        if (zzay == -1) {
            zzay = zziy.zzn(zzfh);
            zzfh.zzv(zzay);
        }
        return zzau(zzay) + zzay;
    }

    public static int zzd(int i, float f) {
        return zzas(i) + 4;
    }

    public static int zzd(int i, zzfr zzfr) {
        i = zzas(i);
        int size = zzfr.size();
        return i + (zzau(size) + size);
    }

    public static int zzd(int i, zzih zzih) {
        return zzas(i) + zzd(zzih);
    }

    @Deprecated
    static int zzd(int i, zzih zzih, zziy zziy) {
        i = zzas(i) << 1;
        zzfh zzfh = (zzfh) zzih;
        int zzay = zzfh.zzay();
        if (zzay == -1) {
            zzay = zziy.zzn(zzfh);
            zzfh.zzv(zzay);
        }
        return i + zzay;
    }

    public static int zzd(int i, boolean z) {
        return zzas(i) + 1;
    }

    public static int zzd(zzih zzih) {
        int zzdg = zzih.zzdg();
        return zzau(zzdg) + zzdg;
    }

    public static zzgf zzd(byte[] bArr) {
        return new zzb(bArr, 0, bArr.length);
    }

    public static int zze(float f) {
        return 4;
    }

    public static int zze(int i, long j) {
        return zzas(i) + zzi(j);
    }

    public static int zze(int i, zzfr zzfr) {
        return ((zzas(1) << 1) + zzj(2, i)) + zzd(3, zzfr);
    }

    public static int zze(int i, zzih zzih) {
        return ((zzas(1) << 1) + zzj(2, i)) + zzd(3, zzih);
    }

    @Deprecated
    public static int zze(zzih zzih) {
        return zzih.zzdg();
    }

    public static int zze(boolean z) {
        return 1;
    }

    public static int zze(byte[] bArr) {
        int length = bArr.length;
        return zzau(length) + length;
    }

    public static int zzf(int i, long j) {
        return zzas(i) + zzi(j);
    }

    public static int zzg(int i, long j) {
        return zzas(i) + zzi(zzm(j));
    }

    public static int zzh(int i, long j) {
        return zzas(i) + 8;
    }

    public static int zzh(long j) {
        return zzi(j);
    }

    public static int zzi(int i, int i2) {
        return zzas(i) + zzat(i2);
    }

    public static int zzi(int i, long j) {
        return zzas(i) + 8;
    }

    public static int zzi(long j) {
        if ((-128 & j) == 0) {
            return 1;
        }
        if (j < 0) {
            return 10;
        }
        int i;
        if ((-34359738368L & j) != 0) {
            i = 6;
            j >>>= 28;
        } else {
            i = 2;
        }
        if ((-2097152 & j) != 0) {
            i += 2;
            j >>>= 14;
        }
        if ((j & -16384) != 0) {
            i++;
        }
        return i;
    }

    public static int zzj(int i, int i2) {
        return zzas(i) + zzau(i2);
    }

    public static int zzj(long j) {
        return zzi(zzm(j));
    }

    public static int zzk(int i, int i2) {
        return zzas(i) + zzau(zzaz(i2));
    }

    public static int zzk(long j) {
        return 8;
    }

    public static int zzl(int i, int i2) {
        return zzas(i) + 4;
    }

    public static int zzl(long j) {
        return 8;
    }

    public static int zzl(java.lang.String r1) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/952562199.run(Unknown Source)
*/
        /*
        r0 = com.google.android.gms.internal.places.zzjy.zzb(r1);	 Catch:{ zzkb -> 0x0005 }
        goto L_0x000c;
    L_0x0005:
        r0 = com.google.android.gms.internal.places.zzhb.UTF_8;
        r1 = r1.getBytes(r0);
        r0 = r1.length;
    L_0x000c:
        r1 = zzau(r0);
        r1 = r1 + r0;
        return r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.places.zzgf.zzl(java.lang.String):int");
    }

    public static int zzm(int i, int i2) {
        return zzas(i) + 4;
    }

    private static long zzm(long j) {
        return (j >> 63) ^ (j << 1);
    }

    public static int zzn(int i, int i2) {
        return zzas(i) + zzat(i2);
    }

    public abstract void flush() throws IOException;

    public abstract void write(byte[] bArr, int i, int i2) throws IOException;

    public abstract void zzao(int i) throws IOException;

    public abstract void zzap(int i) throws IOException;

    public final void zzaq(int i) throws IOException {
        zzap(zzaz(i));
    }

    public abstract void zzar(int i) throws IOException;

    public abstract void zzb(byte b) throws IOException;

    public final void zzb(double d) throws IOException {
        zzg(Double.doubleToRawLongBits(d));
    }

    public final void zzb(int i, double d) throws IOException {
        zzd(i, Double.doubleToRawLongBits(d));
    }

    public abstract void zzb(int i, long j) throws IOException;

    public abstract void zzb(int i, zzfr zzfr) throws IOException;

    public abstract void zzb(int i, zzih zzih) throws IOException;

    abstract void zzb(int i, zzih zzih, zziy zziy) throws IOException;

    public abstract void zzb(int i, String str) throws IOException;

    public abstract void zzb(zzfr zzfr) throws IOException;

    abstract void zzb(zzih zzih, zziy zziy) throws IOException;

    final void zzb(String str, zzkb zzkb) throws IOException {
        logger.logp(Level.WARNING, "com.google.protobuf.CodedOutputStream", "inefficientWriteStringNoTag", "Converting ill-formed UTF-16. Your Protocol Buffer will not round trip correctly!", zzkb);
        byte[] bytes = str.getBytes(zzhb.UTF_8);
        try {
            zzap(bytes.length);
            zzb(bytes, 0, bytes.length);
        } catch (Throwable e) {
            throw new zzd(e);
        } catch (zzd e2) {
            throw e2;
        }
    }

    public final void zzc(int i, float f) throws IOException {
        zzh(i, Float.floatToRawIntBits(f));
    }

    public final void zzc(int i, long j) throws IOException {
        zzb(i, zzm(j));
    }

    public abstract void zzc(int i, zzfr zzfr) throws IOException;

    public abstract void zzc(int i, zzih zzih) throws IOException;

    public abstract void zzc(int i, boolean z) throws IOException;

    public abstract void zzc(zzih zzih) throws IOException;

    public abstract int zzcs();

    public final void zzd(float f) throws IOException {
        zzar(Float.floatToRawIntBits(f));
    }

    public abstract void zzd(int i, int i2) throws IOException;

    public abstract void zzd(int i, long j) throws IOException;

    public final void zzd(boolean z) throws IOException {
        zzb((byte) z);
    }

    public abstract void zze(int i, int i2) throws IOException;

    public abstract void zze(long j) throws IOException;

    public abstract void zzf(int i, int i2) throws IOException;

    public final void zzf(long j) throws IOException {
        zze(zzm(j));
    }

    public final void zzg(int i, int i2) throws IOException {
        zzf(i, zzaz(i2));
    }

    public abstract void zzg(long j) throws IOException;

    abstract void zzg(byte[] bArr, int i, int i2) throws IOException;

    public abstract void zzh(int i, int i2) throws IOException;

    public abstract void zzk(String str) throws IOException;
}
