package com.google.android.gms.internal.places;

import java.util.Arrays;
import java.util.Collection;
import java.util.RandomAccess;

final class zzfp extends zzfk<Boolean> implements zzhg<Boolean>, RandomAccess {
    private static final zzfp zznr;
    private int size;
    private boolean[] zzns;

    static {
        zzfk zzfp = new zzfp();
        zznr = zzfp;
        zzfp.zzbb();
    }

    zzfp() {
        this(new boolean[10], 0);
    }

    private zzfp(boolean[] zArr, int i) {
        this.zzns = zArr;
        this.size = i;
    }

    private final void zzac(int i) {
        if (i < 0 || i >= this.size) {
            throw new IndexOutOfBoundsException(zzad(i));
        }
    }

    private final String zzad(int i) {
        int i2 = this.size;
        StringBuilder stringBuilder = new StringBuilder(35);
        stringBuilder.append("Index:");
        stringBuilder.append(i);
        stringBuilder.append(", Size:");
        stringBuilder.append(i2);
        return stringBuilder.toString();
    }

    private final void zzb(int i, boolean z) {
        zzbc();
        if (i < 0 || i > this.size) {
            throw new IndexOutOfBoundsException(zzad(i));
        }
        if (this.size < this.zzns.length) {
            System.arraycopy(this.zzns, i, this.zzns, i + 1, this.size - i);
        } else {
            Object obj = new boolean[(((this.size * 3) / 2) + 1)];
            System.arraycopy(this.zzns, 0, obj, 0, i);
            System.arraycopy(this.zzns, i, obj, i + 1, this.size - i);
            this.zzns = obj;
        }
        this.zzns[i] = z;
        this.size++;
        this.modCount++;
    }

    public final /* synthetic */ void add(int i, Object obj) {
        zzb(i, ((Boolean) obj).booleanValue());
    }

    public final boolean addAll(Collection<? extends Boolean> collection) {
        zzbc();
        zzhb.checkNotNull(collection);
        if (!(collection instanceof zzfp)) {
            return super.addAll(collection);
        }
        zzfp zzfp = (zzfp) collection;
        if (zzfp.size == 0) {
            return false;
        }
        if (Integer.MAX_VALUE - this.size >= zzfp.size) {
            int i = this.size + zzfp.size;
            if (i > this.zzns.length) {
                this.zzns = Arrays.copyOf(this.zzns, i);
            }
            System.arraycopy(zzfp.zzns, 0, this.zzns, this.size, zzfp.size);
            this.size = i;
            this.modCount++;
            return true;
        }
        throw new OutOfMemoryError();
    }

    public final void addBoolean(boolean z) {
        zzb(this.size, z);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof zzfp)) {
            return super.equals(obj);
        }
        zzfp zzfp = (zzfp) obj;
        if (this.size != zzfp.size) {
            return false;
        }
        boolean[] zArr = zzfp.zzns;
        for (int i = 0; i < this.size; i++) {
            if (this.zzns[i] != zArr[i]) {
                return false;
            }
        }
        return true;
    }

    public final /* synthetic */ Object get(int i) {
        zzac(i);
        return Boolean.valueOf(this.zzns[i]);
    }

    public final int hashCode() {
        int i = 1;
        for (int i2 = 0; i2 < this.size; i2++) {
            i = (i * 31) + zzhb.zzf(this.zzns[i2]);
        }
        return i;
    }

    public final /* synthetic */ Object remove(int i) {
        zzbc();
        zzac(i);
        boolean z = this.zzns[i];
        if (i < this.size - 1) {
            System.arraycopy(this.zzns, i + 1, this.zzns, i, this.size - i);
        }
        this.size--;
        this.modCount++;
        return Boolean.valueOf(z);
    }

    public final boolean remove(Object obj) {
        zzbc();
        for (int i = 0; i < this.size; i++) {
            if (obj.equals(Boolean.valueOf(this.zzns[i]))) {
                System.arraycopy(this.zzns, i + 1, this.zzns, i, this.size - i);
                this.size--;
                this.modCount++;
                return true;
            }
        }
        return false;
    }

    protected final void removeRange(int i, int i2) {
        zzbc();
        if (i2 >= i) {
            System.arraycopy(this.zzns, i2, this.zzns, i, this.size - i2);
            this.size -= i2 - i;
            this.modCount++;
            return;
        }
        throw new IndexOutOfBoundsException("toIndex < fromIndex");
    }

    public final /* synthetic */ Object set(int i, Object obj) {
        boolean booleanValue = ((Boolean) obj).booleanValue();
        zzbc();
        zzac(i);
        boolean z = this.zzns[i];
        this.zzns[i] = booleanValue;
        return Boolean.valueOf(z);
    }

    public final int size() {
        return this.size;
    }

    public final /* synthetic */ zzhg zzae(int i) {
        if (i >= this.size) {
            return new zzfp(Arrays.copyOf(this.zzns, i), this.size);
        }
        throw new IllegalArgumentException();
    }
}
