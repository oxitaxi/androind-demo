package com.google.android.gms.internal.places;

import com.google.android.gms.internal.places.zzgz.zzh;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

final class zzgh implements zzkk {
    private final zzgf zznz;

    private zzgh(zzgf zzgf) {
        this.zznz = (zzgf) zzhb.zzb((Object) zzgf, "output");
    }

    public static zzgh zzb(zzgf zzgf) {
        return zzgf.zzop != null ? zzgf.zzop : new zzgh(zzgf);
    }

    public final void zzb(int i, double d) throws IOException {
        this.zznz.zzb(i, d);
    }

    public final void zzb(int i, long j) throws IOException {
        this.zznz.zzb(i, j);
    }

    public final void zzb(int i, zzfr zzfr) throws IOException {
        this.zznz.zzb(i, zzfr);
    }

    public final <K, V> void zzb(int i, zzia<K, V> zzia, Map<K, V> map) throws IOException {
        for (Entry entry : map.entrySet()) {
            this.zznz.zzd(i, 2);
            this.zznz.zzap(zzhz.zzb(zzia, entry.getKey(), entry.getValue()));
            zzhz.zzb(this.zznz, zzia, entry.getKey(), entry.getValue());
        }
    }

    public final void zzb(int i, Object obj) throws IOException {
        if (obj instanceof zzfr) {
            this.zznz.zzc(i, (zzfr) obj);
        } else {
            this.zznz.zzc(i, (zzih) obj);
        }
    }

    public final void zzb(int i, Object obj, zziy zziy) throws IOException {
        this.zznz.zzb(i, (zzih) obj, zziy);
    }

    public final void zzb(int i, String str) throws IOException {
        this.zznz.zzb(i, str);
    }

    public final void zzb(int i, List<?> list, zziy zziy) throws IOException {
        for (int i2 = 0; i2 < list.size(); i2++) {
            zzb(i, list.get(i2), zziy);
        }
    }

    public final void zzb(int i, List<Integer> list, boolean z) throws IOException {
        int i2 = 0;
        if (z) {
            this.zznz.zzd(i, 2);
            int i3 = 0;
            for (i = 0; i < list.size(); i++) {
                i3 += zzgf.zzat(((Integer) list.get(i)).intValue());
            }
            this.zznz.zzap(i3);
            while (i2 < list.size()) {
                this.zznz.zzao(((Integer) list.get(i2)).intValue());
                i2++;
            }
            return;
        }
        while (i2 < list.size()) {
            this.zznz.zze(i, ((Integer) list.get(i2)).intValue());
            i2++;
        }
    }

    public final void zzbb(int i) throws IOException {
        this.zznz.zzd(i, 3);
    }

    public final void zzbc(int i) throws IOException {
        this.zznz.zzd(i, 4);
    }

    public final void zzc(int i, float f) throws IOException {
        this.zznz.zzc(i, f);
    }

    public final void zzc(int i, long j) throws IOException {
        this.zznz.zzc(i, j);
    }

    public final void zzc(int i, Object obj, zziy zziy) throws IOException {
        zzgf zzgf = this.zznz;
        zzih zzih = (zzih) obj;
        zzgf.zzd(i, 3);
        zziy.zzb(zzih, zzgf.zzop);
        zzgf.zzd(i, 4);
    }

    public final void zzc(int i, List<String> list) throws IOException {
        int i2 = 0;
        if (list instanceof zzhq) {
            zzhq zzhq = (zzhq) list;
            while (i2 < list.size()) {
                Object raw = zzhq.getRaw(i2);
                if (raw instanceof String) {
                    this.zznz.zzb(i, (String) raw);
                } else {
                    this.zznz.zzb(i, (zzfr) raw);
                }
                i2++;
            }
            return;
        }
        while (i2 < list.size()) {
            this.zznz.zzb(i, (String) list.get(i2));
            i2++;
        }
    }

    public final void zzc(int i, List<?> list, zziy zziy) throws IOException {
        for (int i2 = 0; i2 < list.size(); i2++) {
            zzc(i, list.get(i2), zziy);
        }
    }

    public final void zzc(int i, List<Integer> list, boolean z) throws IOException {
        int i2 = 0;
        if (z) {
            this.zznz.zzd(i, 2);
            int i3 = 0;
            for (i = 0; i < list.size(); i++) {
                i3 += zzgf.zzaw(((Integer) list.get(i)).intValue());
            }
            this.zznz.zzap(i3);
            while (i2 < list.size()) {
                this.zznz.zzar(((Integer) list.get(i2)).intValue());
                i2++;
            }
            return;
        }
        while (i2 < list.size()) {
            this.zznz.zzh(i, ((Integer) list.get(i2)).intValue());
            i2++;
        }
    }

    public final void zzc(int i, boolean z) throws IOException {
        this.zznz.zzc(i, z);
    }

    public final int zzcv() {
        return zzh.zztg;
    }

    public final void zzd(int i, long j) throws IOException {
        this.zznz.zzd(i, j);
    }

    public final void zzd(int i, List<zzfr> list) throws IOException {
        for (int i2 = 0; i2 < list.size(); i2++) {
            this.zznz.zzb(i, (zzfr) list.get(i2));
        }
    }

    public final void zzd(int i, List<Long> list, boolean z) throws IOException {
        int i2 = 0;
        if (z) {
            this.zznz.zzd(i, 2);
            int i3 = 0;
            for (i = 0; i < list.size(); i++) {
                i3 += zzgf.zzh(((Long) list.get(i)).longValue());
            }
            this.zznz.zzap(i3);
            while (i2 < list.size()) {
                this.zznz.zze(((Long) list.get(i2)).longValue());
                i2++;
            }
            return;
        }
        while (i2 < list.size()) {
            this.zznz.zzb(i, ((Long) list.get(i2)).longValue());
            i2++;
        }
    }

    public final void zze(int i, int i2) throws IOException {
        this.zznz.zze(i, i2);
    }

    public final void zze(int i, List<Long> list, boolean z) throws IOException {
        int i2 = 0;
        if (z) {
            this.zznz.zzd(i, 2);
            int i3 = 0;
            for (i = 0; i < list.size(); i++) {
                i3 += zzgf.zzi(((Long) list.get(i)).longValue());
            }
            this.zznz.zzap(i3);
            while (i2 < list.size()) {
                this.zznz.zze(((Long) list.get(i2)).longValue());
                i2++;
            }
            return;
        }
        while (i2 < list.size()) {
            this.zznz.zzb(i, ((Long) list.get(i2)).longValue());
            i2++;
        }
    }

    public final void zzf(int i, int i2) throws IOException {
        this.zznz.zzf(i, i2);
    }

    public final void zzf(int i, List<Long> list, boolean z) throws IOException {
        int i2 = 0;
        if (z) {
            this.zznz.zzd(i, 2);
            int i3 = 0;
            for (i = 0; i < list.size(); i++) {
                i3 += zzgf.zzk(((Long) list.get(i)).longValue());
            }
            this.zznz.zzap(i3);
            while (i2 < list.size()) {
                this.zznz.zzg(((Long) list.get(i2)).longValue());
                i2++;
            }
            return;
        }
        while (i2 < list.size()) {
            this.zznz.zzd(i, ((Long) list.get(i2)).longValue());
            i2++;
        }
    }

    public final void zzg(int i, int i2) throws IOException {
        this.zznz.zzg(i, i2);
    }

    public final void zzg(int i, List<Float> list, boolean z) throws IOException {
        int i2 = 0;
        if (z) {
            this.zznz.zzd(i, 2);
            int i3 = 0;
            for (i = 0; i < list.size(); i++) {
                i3 += zzgf.zze(((Float) list.get(i)).floatValue());
            }
            this.zznz.zzap(i3);
            while (i2 < list.size()) {
                this.zznz.zzd(((Float) list.get(i2)).floatValue());
                i2++;
            }
            return;
        }
        while (i2 < list.size()) {
            this.zznz.zzc(i, ((Float) list.get(i2)).floatValue());
            i2++;
        }
    }

    public final void zzh(int i, int i2) throws IOException {
        this.zznz.zzh(i, i2);
    }

    public final void zzh(int i, List<Double> list, boolean z) throws IOException {
        int i2 = 0;
        if (z) {
            this.zznz.zzd(i, 2);
            int i3 = 0;
            for (i = 0; i < list.size(); i++) {
                i3 += zzgf.zzc(((Double) list.get(i)).doubleValue());
            }
            this.zznz.zzap(i3);
            while (i2 < list.size()) {
                this.zznz.zzb(((Double) list.get(i2)).doubleValue());
                i2++;
            }
            return;
        }
        while (i2 < list.size()) {
            this.zznz.zzb(i, ((Double) list.get(i2)).doubleValue());
            i2++;
        }
    }

    public final void zzi(int i, List<Integer> list, boolean z) throws IOException {
        int i2 = 0;
        if (z) {
            this.zznz.zzd(i, 2);
            int i3 = 0;
            for (i = 0; i < list.size(); i++) {
                i3 += zzgf.zzay(((Integer) list.get(i)).intValue());
            }
            this.zznz.zzap(i3);
            while (i2 < list.size()) {
                this.zznz.zzao(((Integer) list.get(i2)).intValue());
                i2++;
            }
            return;
        }
        while (i2 < list.size()) {
            this.zznz.zze(i, ((Integer) list.get(i2)).intValue());
            i2++;
        }
    }

    public final void zzj(int i, long j) throws IOException {
        this.zznz.zzb(i, j);
    }

    public final void zzj(int i, List<Boolean> list, boolean z) throws IOException {
        int i2 = 0;
        if (z) {
            this.zznz.zzd(i, 2);
            int i3 = 0;
            for (i = 0; i < list.size(); i++) {
                i3 += zzgf.zze(((Boolean) list.get(i)).booleanValue());
            }
            this.zznz.zzap(i3);
            while (i2 < list.size()) {
                this.zznz.zzd(((Boolean) list.get(i2)).booleanValue());
                i2++;
            }
            return;
        }
        while (i2 < list.size()) {
            this.zznz.zzc(i, ((Boolean) list.get(i2)).booleanValue());
            i2++;
        }
    }

    public final void zzk(int i, long j) throws IOException {
        this.zznz.zzd(i, j);
    }

    public final void zzk(int i, List<Integer> list, boolean z) throws IOException {
        int i2 = 0;
        if (z) {
            this.zznz.zzd(i, 2);
            int i3 = 0;
            for (i = 0; i < list.size(); i++) {
                i3 += zzgf.zzau(((Integer) list.get(i)).intValue());
            }
            this.zznz.zzap(i3);
            while (i2 < list.size()) {
                this.zznz.zzap(((Integer) list.get(i2)).intValue());
                i2++;
            }
            return;
        }
        while (i2 < list.size()) {
            this.zznz.zzf(i, ((Integer) list.get(i2)).intValue());
            i2++;
        }
    }

    public final void zzl(int i, List<Integer> list, boolean z) throws IOException {
        int i2 = 0;
        if (z) {
            this.zznz.zzd(i, 2);
            int i3 = 0;
            for (i = 0; i < list.size(); i++) {
                i3 += zzgf.zzax(((Integer) list.get(i)).intValue());
            }
            this.zznz.zzap(i3);
            while (i2 < list.size()) {
                this.zznz.zzar(((Integer) list.get(i2)).intValue());
                i2++;
            }
            return;
        }
        while (i2 < list.size()) {
            this.zznz.zzh(i, ((Integer) list.get(i2)).intValue());
            i2++;
        }
    }

    public final void zzm(int i, List<Long> list, boolean z) throws IOException {
        int i2 = 0;
        if (z) {
            this.zznz.zzd(i, 2);
            int i3 = 0;
            for (i = 0; i < list.size(); i++) {
                i3 += zzgf.zzl(((Long) list.get(i)).longValue());
            }
            this.zznz.zzap(i3);
            while (i2 < list.size()) {
                this.zznz.zzg(((Long) list.get(i2)).longValue());
                i2++;
            }
            return;
        }
        while (i2 < list.size()) {
            this.zznz.zzd(i, ((Long) list.get(i2)).longValue());
            i2++;
        }
    }

    public final void zzn(int i, List<Integer> list, boolean z) throws IOException {
        int i2 = 0;
        if (z) {
            this.zznz.zzd(i, 2);
            int i3 = 0;
            for (i = 0; i < list.size(); i++) {
                i3 += zzgf.zzav(((Integer) list.get(i)).intValue());
            }
            this.zznz.zzap(i3);
            while (i2 < list.size()) {
                this.zznz.zzaq(((Integer) list.get(i2)).intValue());
                i2++;
            }
            return;
        }
        while (i2 < list.size()) {
            this.zznz.zzg(i, ((Integer) list.get(i2)).intValue());
            i2++;
        }
    }

    public final void zzo(int i, int i2) throws IOException {
        this.zznz.zzh(i, i2);
    }

    public final void zzo(int i, List<Long> list, boolean z) throws IOException {
        int i2 = 0;
        if (z) {
            this.zznz.zzd(i, 2);
            int i3 = 0;
            for (i = 0; i < list.size(); i++) {
                i3 += zzgf.zzj(((Long) list.get(i)).longValue());
            }
            this.zznz.zzap(i3);
            while (i2 < list.size()) {
                this.zznz.zzf(((Long) list.get(i2)).longValue());
                i2++;
            }
            return;
        }
        while (i2 < list.size()) {
            this.zznz.zzc(i, ((Long) list.get(i2)).longValue());
            i2++;
        }
    }

    public final void zzp(int i, int i2) throws IOException {
        this.zznz.zze(i, i2);
    }
}
