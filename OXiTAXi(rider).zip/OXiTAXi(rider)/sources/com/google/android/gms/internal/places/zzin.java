package com.google.android.gms.internal.places;

public interface zzin extends zzih, Cloneable {
    zzin zzey();
}
