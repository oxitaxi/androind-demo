package com.google.android.gms.internal.places;

final class zzjn implements zzjo {
    private final /* synthetic */ zzfr zzxp;

    zzjn(zzfr zzfr) {
        this.zzxp = zzfr;
    }

    public final int size() {
        return this.zzxp.size();
    }

    public final byte zzaf(int i) {
        return this.zzxp.zzaf(i);
    }
}
