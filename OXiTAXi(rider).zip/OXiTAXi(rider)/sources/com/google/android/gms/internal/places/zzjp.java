package com.google.android.gms.internal.places;

import java.util.List;

public final class zzjp extends RuntimeException {
    private final List<String> zzxq = null;

    public zzjp(zzih zzih) {
        super("Message was missing required fields.  (Lite runtime could not determine which fields were missing).");
    }
}
