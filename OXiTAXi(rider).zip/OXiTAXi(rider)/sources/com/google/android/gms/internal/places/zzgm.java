package com.google.android.gms.internal.places;

import java.io.IOException;
import java.util.Map.Entry;

abstract class zzgm<T extends zzgs<T>> {
    zzgm() {
    }

    abstract int zzb(Entry<?, ?> entry);

    abstract zzgq<T> zzb(Object obj);

    abstract Object zzb(zzgl zzgl, zzih zzih, int i);

    abstract <UT, UB> UB zzb(zzix zzix, Object obj, zzgl zzgl, zzgq<T> zzgq, UB ub, zzjq<UT, UB> zzjq) throws IOException;

    abstract void zzb(zzfr zzfr, Object obj, zzgl zzgl, zzgq<T> zzgq) throws IOException;

    abstract void zzb(zzix zzix, Object obj, zzgl zzgl, zzgq<T> zzgq) throws IOException;

    abstract void zzb(zzkk zzkk, Entry<?, ?> entry) throws IOException;

    abstract void zzb(Object obj, zzgq<T> zzgq);

    abstract zzgq<T> zzc(Object obj);

    abstract void zzd(Object obj);

    abstract boolean zzf(zzih zzih);
}
