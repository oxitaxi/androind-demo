package com.google.android.gms.internal.places;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public final class zzkp<M extends zzko<M>, T> {
    private final int tag;
    private final int type;
    protected final Class<T> zzaag;
    protected final boolean zzaah;
    private final zzgz<?, ?> zzsj;

    private zzkp(int i, Class<T> cls, int i2, boolean z) {
        this(11, cls, null, i2, false);
    }

    private zzkp(int i, Class<T> cls, zzgz<?, ?> zzgz, int i2, boolean z) {
        this.type = i;
        this.zzaag = cls;
        this.tag = i2;
        this.zzaah = false;
        this.zzsj = null;
    }

    private final Object zzab(zzkl zzkl) {
        StringBuilder stringBuilder;
        String valueOf;
        Class componentType = this.zzaah ? this.zzaag.getComponentType() : this.zzaag;
        try {
            zzku zzku;
            switch (this.type) {
                case 10:
                    zzku = (zzku) componentType.newInstance();
                    zzkl.zzb(zzku, this.tag >>> 3);
                    return zzku;
                case 11:
                    zzku = (zzku) componentType.newInstance();
                    zzkl.zzb(zzku);
                    return zzku;
                default:
                    int i = this.type;
                    stringBuilder = new StringBuilder(24);
                    stringBuilder.append("Unknown type ");
                    stringBuilder.append(i);
                    throw new IllegalArgumentException(stringBuilder.toString());
            }
        } catch (Throwable e) {
            valueOf = String.valueOf(componentType);
            stringBuilder = new StringBuilder(String.valueOf(valueOf).length() + 33);
            stringBuilder.append("Error creating instance of class ");
            stringBuilder.append(valueOf);
            throw new IllegalArgumentException(stringBuilder.toString(), e);
        } catch (Throwable e2) {
            valueOf = String.valueOf(componentType);
            stringBuilder = new StringBuilder(String.valueOf(valueOf).length() + 33);
            stringBuilder.append("Error creating instance of class ");
            stringBuilder.append(valueOf);
            throw new IllegalArgumentException(stringBuilder.toString(), e2);
        } catch (Throwable e22) {
            throw new IllegalArgumentException("Error reading extension field", e22);
        }
    }

    public static <M extends zzko<M>, T extends zzku> zzkp<M, T> zzb(int i, Class<T> cls, long j) {
        return new zzkp(11, cls, (int) j, false);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof zzkp)) {
            return false;
        }
        zzkp zzkp = (zzkp) obj;
        return this.type == zzkp.type && this.zzaag == zzkp.zzaag && this.tag == zzkp.tag && this.zzaah == zzkp.zzaah;
    }

    public final int hashCode() {
        return ((((((this.type + 1147) * 31) + this.zzaag.hashCode()) * 31) + this.tag) * 31) + this.zzaah;
    }

    final T zzae(List<zzkw> list) {
        if (list == null) {
            return null;
        }
        if (this.zzaah) {
            List arrayList = new ArrayList();
            for (int i = 0; i < list.size(); i++) {
                zzkw zzkw = (zzkw) list.get(i);
                if (zzkw.zzoa.length != 0) {
                    arrayList.add(zzab(zzkl.zzh(zzkw.zzoa)));
                }
            }
            int size = arrayList.size();
            if (size == 0) {
                return null;
            }
            T cast = this.zzaag.cast(Array.newInstance(this.zzaag.getComponentType(), size));
            for (int i2 = 0; i2 < size; i2++) {
                Array.set(cast, i2, arrayList.get(i2));
            }
            return cast;
        } else if (list.isEmpty()) {
            return null;
        } else {
            return this.zzaag.cast(zzab(zzkl.zzh(((zzkw) list.get(list.size() - 1)).zzoa)));
        }
    }

    protected final void zzb(Object obj, zzkm zzkm) {
        try {
            zzkm.zzbt(this.tag);
            switch (this.type) {
                case 10:
                    int i = this.tag >>> 3;
                    ((zzku) obj).zzb(zzkm);
                    zzkm.zzd(i, 4);
                    return;
                case 11:
                    zzkm.zzc((zzku) obj);
                    return;
                default:
                    int i2 = this.type;
                    StringBuilder stringBuilder = new StringBuilder(24);
                    stringBuilder.append("Unknown type ");
                    stringBuilder.append(i2);
                    throw new IllegalArgumentException(stringBuilder.toString());
            }
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    protected final int zzt(Object obj) {
        int i = this.tag >>> 3;
        switch (this.type) {
            case 10:
                return (zzkm.zzas(i) << 1) + ((zzku) obj).zzdg();
            case 11:
                return zzkm.zzc(i, (zzku) obj);
            default:
                i = this.type;
                StringBuilder stringBuilder = new StringBuilder(24);
                stringBuilder.append("Unknown type ");
                stringBuilder.append(i);
                throw new IllegalArgumentException(stringBuilder.toString());
        }
    }
}
