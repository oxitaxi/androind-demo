package com.google.android.gms.internal.places;

import java.io.IOException;
import java.nio.charset.Charset;

class zzfy extends zzfx {
    protected final byte[] zzoa;

    zzfy(byte[] bArr) {
        this.zzoa = bArr;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof zzfr) || size() != ((zzfr) obj).size()) {
            return false;
        }
        if (size() == 0) {
            return true;
        }
        if (!(obj instanceof zzfy)) {
            return obj.equals(this);
        }
        zzfy zzfy = (zzfy) obj;
        int zzcf = zzcf();
        int zzcf2 = zzfy.zzcf();
        return (zzcf == 0 || zzcf2 == 0 || zzcf == zzcf2) ? zzb(zzfy, 0, size()) : false;
    }

    public int size() {
        return this.zzoa.length;
    }

    public byte zzaf(int i) {
        return this.zzoa[i];
    }

    protected final int zzb(int i, int i2, int i3) {
        return zzhb.zzb(i, this.zzoa, zzcg(), i3);
    }

    protected final String zzb(Charset charset) {
        return new String(this.zzoa, zzcg(), size(), charset);
    }

    final void zzb(zzfq zzfq) throws IOException {
        zzfq.zzb(this.zzoa, zzcg(), size());
    }

    protected void zzb(byte[] bArr, int i, int i2, int i3) {
        System.arraycopy(this.zzoa, 0, bArr, 0, i3);
    }

    final boolean zzb(zzfr zzfr, int i, int i2) {
        StringBuilder stringBuilder;
        if (i2 > zzfr.size()) {
            i = size();
            stringBuilder = new StringBuilder(40);
            stringBuilder.append("Length too large: ");
            stringBuilder.append(i2);
            stringBuilder.append(i);
            throw new IllegalArgumentException(stringBuilder.toString());
        } else if (i2 > zzfr.size()) {
            r6 = zzfr.size();
            stringBuilder = new StringBuilder(59);
            stringBuilder.append("Ran off end of other: 0, ");
            stringBuilder.append(i2);
            stringBuilder.append(", ");
            stringBuilder.append(r6);
            throw new IllegalArgumentException(stringBuilder.toString());
        } else if (!(zzfr instanceof zzfy)) {
            return zzfr.zzc(0, i2).equals(zzc(0, i2));
        } else {
            zzfy zzfy = (zzfy) zzfr;
            byte[] bArr = this.zzoa;
            byte[] bArr2 = zzfy.zzoa;
            int zzcg = zzcg() + i2;
            i2 = zzcg();
            r6 = zzfy.zzcg();
            while (i2 < zzcg) {
                if (bArr[i2] != bArr2[r6]) {
                    return false;
                }
                i2++;
                r6++;
            }
            return true;
        }
    }

    public final zzfr zzc(int i, int i2) {
        i = zzfr.zzc(0, i2, size());
        return i == 0 ? zzfr.zznt : new zzfu(this.zzoa, zzcg(), i);
    }

    public final boolean zzce() {
        int zzcg = zzcg();
        return zzjy.zzh(this.zzoa, zzcg, size() + zzcg);
    }

    protected int zzcg() {
        return 0;
    }
}
