package com.google.android.gms.internal.places;

import java.io.IOException;

public interface zzih extends zzij {
    zzfr zzax();

    void zzc(zzgf zzgf) throws IOException;

    int zzdg();

    zzii zzdq();

    zzii zzdr();
}
