package com.google.android.gms.internal.places;

enum zzgv {
    SCALAR(false),
    VECTOR(true),
    PACKED_VECTOR(true),
    MAP(false);
    
    private final boolean zzsa;

    private zzgv(boolean z) {
        this.zzsa = z;
    }
}
