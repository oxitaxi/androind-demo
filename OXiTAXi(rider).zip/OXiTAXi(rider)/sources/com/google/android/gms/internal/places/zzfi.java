package com.google.android.gms.internal.places;

public abstract class zzfi<MessageType extends zzfh<MessageType, BuilderType>, BuilderType extends zzfi<MessageType, BuilderType>> implements zzii {
    public /* synthetic */ Object clone() throws CloneNotSupportedException {
        return zzaz();
    }

    public abstract BuilderType zzaz();

    protected abstract BuilderType zzb(MessageType messageType);

    public final /* synthetic */ zzii zzb(zzih zzih) {
        if (zzds().getClass().isInstance(zzih)) {
            return zzb((zzfh) zzih);
        }
        throw new IllegalArgumentException("mergeFrom(MessageLite) can only merge messages of the same type.");
    }
}
