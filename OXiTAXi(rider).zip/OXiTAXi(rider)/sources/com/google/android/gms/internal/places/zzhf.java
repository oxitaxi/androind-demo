package com.google.android.gms.internal.places;

public interface zzhf<F, T> {
}
