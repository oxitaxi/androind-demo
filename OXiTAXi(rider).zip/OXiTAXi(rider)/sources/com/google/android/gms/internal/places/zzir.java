package com.google.android.gms.internal.places;

public interface zzir<MessageType> {
    MessageType zzb(zzga zzga, zzgl zzgl) throws zzhh;
}
