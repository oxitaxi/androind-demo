package com.google.android.gms.internal.places;

import java.util.List;

public interface zzhq extends List {
    Object getRaw(int i);

    void zzd(zzfr zzfr);

    List<?> zzek();

    zzhq zzel();
}
