package com.google.android.gms.internal.places;

final class zzjl implements zzif {
    public final int zzev() {
        throw new NoSuchMethodError();
    }

    public final boolean zzew() {
        throw new NoSuchMethodError();
    }

    public final zzih zzex() {
        throw new NoSuchMethodError();
    }
}
