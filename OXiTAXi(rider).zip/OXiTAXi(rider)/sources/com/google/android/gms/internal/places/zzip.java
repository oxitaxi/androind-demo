package com.google.android.gms.internal.places;

import com.google.android.gms.internal.places.zzgz.zzh;

final class zzip implements zzio {
    zzip() {
    }

    public final Object newInstance(Object obj) {
        return ((zzgz) obj).zzb(zzh.zzsy, null, null);
    }
}
