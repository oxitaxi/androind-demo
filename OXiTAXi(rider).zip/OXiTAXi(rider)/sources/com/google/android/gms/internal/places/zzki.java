package com.google.android.gms.internal.places;

enum zzki extends zzke {
    zzki(String str, int i, zzkj zzkj, int i2) {
        super(str, 11, zzkj, 2);
    }
}
