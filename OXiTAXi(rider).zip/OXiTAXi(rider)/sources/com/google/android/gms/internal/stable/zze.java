package com.google.android.gms.internal.stable;

import android.content.ContentResolver;
import android.net.Uri;
import android.provider.BaseColumns;
import java.util.HashMap;

public final class zze {

    public static class zza implements BaseColumns {
        private static HashMap<Uri, zzh> zzagq = new HashMap();

        private static zzh zza(ContentResolver contentResolver, Uri uri) {
            zzh zzh = (zzh) zzagq.get(uri);
            if (zzh == null) {
                zzh = new zzh();
                zzagq.put(uri, zzh);
                contentResolver.registerContentObserver(uri, true, new zzf(null, zzh));
                return zzh;
            } else if (!zzh.zzagu.getAndSet(false)) {
                return zzh;
            } else {
                synchronized (zzh) {
                    zzh.zzags.clear();
                    zzh.zzagt = new Object();
                }
                return zzh;
            }
        }

        /* JADX WARNING: inconsistent code. */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        protected static java.lang.String zza(android.content.ContentResolver r11, android.net.Uri r12, java.lang.String r13) {
            /*
            r0 = com.google.android.gms.internal.stable.zze.zza.class;
            monitor-enter(r0);
            r1 = zza(r11, r12);	 Catch:{ all -> 0x008a }
            monitor-exit(r0);	 Catch:{ all -> 0x008a }
            monitor-enter(r1);
            r0 = r1.zzagt;	 Catch:{ all -> 0x0087 }
            r2 = r1.zzags;	 Catch:{ all -> 0x0087 }
            r2 = r2.containsKey(r13);	 Catch:{ all -> 0x0087 }
            if (r2 == 0) goto L_0x001d;
        L_0x0013:
            r11 = r1.zzags;	 Catch:{ all -> 0x0087 }
            r11 = r11.get(r13);	 Catch:{ all -> 0x0087 }
            r11 = (java.lang.String) r11;	 Catch:{ all -> 0x0087 }
            monitor-exit(r1);	 Catch:{ all -> 0x0087 }
            return r11;
        L_0x001d:
            monitor-exit(r1);	 Catch:{ all -> 0x0087 }
            r2 = 1;
            r3 = 0;
            r6 = new java.lang.String[r2];	 Catch:{ SQLException -> 0x005e }
            r4 = "value";
            r10 = 0;
            r6[r10] = r4;	 Catch:{ SQLException -> 0x005e }
            r7 = "name=?";
            r8 = new java.lang.String[r2];	 Catch:{ SQLException -> 0x005e }
            r8[r10] = r13;	 Catch:{ SQLException -> 0x005e }
            r9 = 0;
            r4 = r11;
            r5 = r12;
            r11 = r4.query(r5, r6, r7, r8, r9);	 Catch:{ SQLException -> 0x005e }
            if (r11 == 0) goto L_0x0053;
        L_0x0036:
            r2 = r11.moveToFirst();	 Catch:{ SQLException -> 0x004f, all -> 0x004c }
            if (r2 != 0) goto L_0x003d;
        L_0x003c:
            goto L_0x0053;
        L_0x003d:
            r2 = r11.getString(r10);	 Catch:{ SQLException -> 0x004f, all -> 0x004c }
            zza(r1, r0, r13, r2);	 Catch:{ SQLException -> 0x004a, all -> 0x004c }
            if (r11 == 0) goto L_0x0080;
        L_0x0046:
            r11.close();
            goto L_0x0080;
        L_0x004a:
            r0 = move-exception;
            goto L_0x0051;
        L_0x004c:
            r12 = move-exception;
            r3 = r11;
            goto L_0x0081;
        L_0x004f:
            r0 = move-exception;
            r2 = r3;
        L_0x0051:
            r3 = r11;
            goto L_0x0060;
        L_0x0053:
            zza(r1, r0, r13, r3);	 Catch:{ SQLException -> 0x004f, all -> 0x004c }
            if (r11 == 0) goto L_0x005b;
        L_0x0058:
            r11.close();
        L_0x005b:
            return r3;
        L_0x005c:
            r12 = move-exception;
            goto L_0x0081;
        L_0x005e:
            r0 = move-exception;
            r2 = r3;
        L_0x0060:
            r11 = "GoogleSettings";
            r1 = new java.lang.StringBuilder;	 Catch:{ all -> 0x005c }
            r4 = "Can't get key ";
            r1.<init>(r4);	 Catch:{ all -> 0x005c }
            r1.append(r13);	 Catch:{ all -> 0x005c }
            r13 = " from ";
            r1.append(r13);	 Catch:{ all -> 0x005c }
            r1.append(r12);	 Catch:{ all -> 0x005c }
            r12 = r1.toString();	 Catch:{ all -> 0x005c }
            android.util.Log.e(r11, r12, r0);	 Catch:{ all -> 0x005c }
            if (r3 == 0) goto L_0x0080;
        L_0x007d:
            r3.close();
        L_0x0080:
            return r2;
        L_0x0081:
            if (r3 == 0) goto L_0x0086;
        L_0x0083:
            r3.close();
        L_0x0086:
            throw r12;
        L_0x0087:
            r11 = move-exception;
            monitor-exit(r1);	 Catch:{ all -> 0x0087 }
            throw r11;
        L_0x008a:
            r11 = move-exception;
            monitor-exit(r0);	 Catch:{ all -> 0x008a }
            throw r11;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.stable.zze.zza.zza(android.content.ContentResolver, android.net.Uri, java.lang.String):java.lang.String");
        }

        private static void zza(zzh zzh, Object obj, String str, String str2) {
            synchronized (zzh) {
                if (obj == zzh.zzagt) {
                    zzh.zzags.put(str, str2);
                }
            }
        }
    }
}
