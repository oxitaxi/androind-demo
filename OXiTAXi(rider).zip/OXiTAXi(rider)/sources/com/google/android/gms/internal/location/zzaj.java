package com.google.android.gms.internal.location;

import android.os.IInterface;
import android.os.RemoteException;

public interface zzaj extends IInterface {
    void zza(zzad zzad) throws RemoteException;
}
