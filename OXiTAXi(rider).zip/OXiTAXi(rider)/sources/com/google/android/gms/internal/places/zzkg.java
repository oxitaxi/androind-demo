package com.google.android.gms.internal.places;

enum zzkg extends zzke {
    zzkg(String str, int i, zzkj zzkj, int i2) {
        super(str, 9, zzkj, 3);
    }
}
