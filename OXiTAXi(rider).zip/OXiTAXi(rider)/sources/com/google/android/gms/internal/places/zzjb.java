package com.google.android.gms.internal.places;

import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

class zzjb<K extends Comparable<K>, V> extends AbstractMap<K, V> {
    private boolean zzpk;
    private final int zzxd;
    private List<zzji> zzxe;
    private Map<K, V> zzxf;
    private volatile zzjk zzxg;
    private Map<K, V> zzxh;
    private volatile zzje zzxi;

    private zzjb(int i) {
        this.zzxd = i;
        this.zzxe = Collections.emptyList();
        this.zzxf = Collections.emptyMap();
        this.zzxh = Collections.emptyMap();
    }

    private final int zzb(K k) {
        int compareTo;
        int size = this.zzxe.size() - 1;
        if (size >= 0) {
            compareTo = k.compareTo((Comparable) ((zzji) this.zzxe.get(size)).getKey());
            if (compareTo > 0) {
                return -(size + 2);
            }
            if (compareTo == 0) {
                return size;
            }
        }
        compareTo = 0;
        while (compareTo <= size) {
            int i = (compareTo + size) / 2;
            int compareTo2 = k.compareTo((Comparable) ((zzji) this.zzxe.get(i)).getKey());
            if (compareTo2 < 0) {
                size = i - 1;
            } else if (compareTo2 <= 0) {
                return i;
            } else {
                compareTo = i + 1;
            }
        }
        return -(compareTo + 1);
    }

    static <FieldDescriptorType extends zzgs<FieldDescriptorType>> zzjb<FieldDescriptorType, Object> zzbm(int i) {
        return new zzjc(i);
    }

    private final V zzbo(int i) {
        zzgj();
        V value = ((zzji) this.zzxe.remove(i)).getValue();
        if (!this.zzxf.isEmpty()) {
            Iterator it = zzgk().entrySet().iterator();
            this.zzxe.add(new zzji(this, (Entry) it.next()));
            it.remove();
        }
        return value;
    }

    private final void zzgj() {
        if (this.zzpk) {
            throw new UnsupportedOperationException();
        }
    }

    private final SortedMap<K, V> zzgk() {
        zzgj();
        if (this.zzxf.isEmpty() && !(this.zzxf instanceof TreeMap)) {
            this.zzxf = new TreeMap();
            this.zzxh = ((TreeMap) this.zzxf).descendingMap();
        }
        return (SortedMap) this.zzxf;
    }

    public void clear() {
        zzgj();
        if (!this.zzxe.isEmpty()) {
            this.zzxe.clear();
        }
        if (!this.zzxf.isEmpty()) {
            this.zzxf.clear();
        }
    }

    public boolean containsKey(Object obj) {
        Comparable comparable = (Comparable) obj;
        if (zzb(comparable) < 0) {
            if (!this.zzxf.containsKey(comparable)) {
                return false;
            }
        }
        return true;
    }

    public Set<Entry<K, V>> entrySet() {
        if (this.zzxg == null) {
            this.zzxg = new zzjk();
        }
        return this.zzxg;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof zzjb)) {
            return super.equals(obj);
        }
        zzjb zzjb = (zzjb) obj;
        int size = size();
        if (size != zzjb.size()) {
            return false;
        }
        int zzgg = zzgg();
        if (zzgg != zzjb.zzgg()) {
            return entrySet().equals(zzjb.entrySet());
        }
        for (int i = 0; i < zzgg; i++) {
            if (!zzbn(i).equals(zzjb.zzbn(i))) {
                return false;
            }
        }
        return zzgg != size ? this.zzxf.equals(zzjb.zzxf) : true;
    }

    public V get(Object obj) {
        Comparable comparable = (Comparable) obj;
        int zzb = zzb(comparable);
        return zzb >= 0 ? ((zzji) this.zzxe.get(zzb)).getValue() : this.zzxf.get(comparable);
    }

    public int hashCode() {
        int i = 0;
        for (int i2 = 0; i2 < zzgg(); i2++) {
            i += ((zzji) this.zzxe.get(i2)).hashCode();
        }
        return this.zzxf.size() > 0 ? i + this.zzxf.hashCode() : i;
    }

    public final boolean isImmutable() {
        return this.zzpk;
    }

    public /* synthetic */ Object put(Object obj, Object obj2) {
        return zzb((Comparable) obj, obj2);
    }

    public V remove(Object obj) {
        zzgj();
        Comparable comparable = (Comparable) obj;
        int zzb = zzb(comparable);
        return zzb >= 0 ? zzbo(zzb) : this.zzxf.isEmpty() ? null : this.zzxf.remove(comparable);
    }

    public int size() {
        return this.zzxe.size() + this.zzxf.size();
    }

    public final V zzb(K k, V v) {
        zzgj();
        int zzb = zzb((Comparable) k);
        if (zzb >= 0) {
            return ((zzji) this.zzxe.get(zzb)).setValue(v);
        }
        zzgj();
        if (this.zzxe.isEmpty() && !(this.zzxe instanceof ArrayList)) {
            this.zzxe = new ArrayList(this.zzxd);
        }
        zzb = -(zzb + 1);
        if (zzb >= this.zzxd) {
            return zzgk().put(k, v);
        }
        if (this.zzxe.size() == this.zzxd) {
            zzji zzji = (zzji) this.zzxe.remove(this.zzxd - 1);
            zzgk().put((Comparable) zzji.getKey(), zzji.getValue());
        }
        this.zzxe.add(zzb, new zzji(this, k, v));
        return null;
    }

    public void zzbb() {
        if (!this.zzpk) {
            this.zzxf = this.zzxf.isEmpty() ? Collections.emptyMap() : Collections.unmodifiableMap(this.zzxf);
            this.zzxh = this.zzxh.isEmpty() ? Collections.emptyMap() : Collections.unmodifiableMap(this.zzxh);
            this.zzpk = true;
        }
    }

    public final Entry<K, V> zzbn(int i) {
        return (Entry) this.zzxe.get(i);
    }

    public final int zzgg() {
        return this.zzxe.size();
    }

    public final Iterable<Entry<K, V>> zzgh() {
        return this.zzxf.isEmpty() ? zzjf.zzgm() : this.zzxf.entrySet();
    }

    final Set<Entry<K, V>> zzgi() {
        if (this.zzxi == null) {
            this.zzxi = new zzje();
        }
        return this.zzxi;
    }
}
