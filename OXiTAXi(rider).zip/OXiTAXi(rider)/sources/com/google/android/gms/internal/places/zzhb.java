package com.google.android.gms.internal.places;

import java.nio.ByteBuffer;
import java.nio.charset.Charset;

public final class zzhb {
    private static final Charset ISO_8859_1 = Charset.forName("ISO-8859-1");
    static final Charset UTF_8 = Charset.forName("UTF-8");
    public static final byte[] zztl;
    private static final ByteBuffer zztm;
    private static final zzga zztn;

    static {
        byte[] bArr = new byte[0];
        zztl = bArr;
        zztm = ByteBuffer.wrap(bArr);
        bArr = zztl;
        zztn = zzga.zzb(bArr, 0, bArr.length, false);
    }

    static <T> T checkNotNull(T t) {
        if (t != null) {
            return t;
        }
        throw new NullPointerException();
    }

    public static int hashCode(byte[] bArr) {
        int length = bArr.length;
        int zzb = zzb(length, bArr, 0, length);
        return zzb == 0 ? 1 : zzb;
    }

    static int zzb(int i, byte[] bArr, int i2, int i3) {
        int i4 = i;
        for (i = i2; i < i2 + i3; i++) {
            i4 = (i4 * 31) + bArr[i];
        }
        return i4;
    }

    static Object zzb(Object obj, Object obj2) {
        return ((zzih) obj).zzdq().zzb((zzih) obj2).zzdw();
    }

    static <T> T zzb(T t, String str) {
        if (t != null) {
            return t;
        }
        throw new NullPointerException(str);
    }

    public static int zzf(boolean z) {
        return z ? 1231 : 1237;
    }

    public static boolean zzf(byte[] bArr) {
        return zzjy.zzf(bArr);
    }

    public static String zzg(byte[] bArr) {
        return new String(bArr, UTF_8);
    }

    static boolean zzg(zzih zzih) {
        return false;
    }

    public static int zzo(long j) {
        return (int) (j ^ (j >>> 32));
    }
}
