package com.google.android.gms.internal.places;

interface zziz {
    <T> zziy<T> zzf(Class<T> cls);
}
