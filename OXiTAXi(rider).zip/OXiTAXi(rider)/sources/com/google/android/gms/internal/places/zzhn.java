package com.google.android.gms.internal.places;

import java.util.Iterator;
import java.util.Map.Entry;

final class zzhn<K> implements Iterator<Entry<K, Object>> {
    private Iterator<Entry<K, Object>> zzue;

    public zzhn(Iterator<Entry<K, Object>> it) {
        this.zzue = it;
    }

    public final boolean hasNext() {
        return this.zzue.hasNext();
    }

    public final /* synthetic */ Object next() {
        Entry entry = (Entry) this.zzue.next();
        return entry.getValue() instanceof zzhk ? new zzhm(entry) : entry;
    }

    public final void remove() {
        this.zzue.remove();
    }
}
