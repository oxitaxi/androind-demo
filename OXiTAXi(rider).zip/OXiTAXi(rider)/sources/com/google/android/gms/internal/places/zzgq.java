package com.google.android.gms.internal.places;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

final class zzgq<FieldDescriptorType extends zzgs<FieldDescriptorType>> {
    private static final zzgq zzpm = new zzgq(true);
    private final zzjb<FieldDescriptorType, Object> zzpj = zzjb.zzbm(16);
    private boolean zzpk;
    private boolean zzpl = false;

    private zzgq() {
    }

    private zzgq(boolean z) {
        zzbb();
    }

    static int zzb(zzke zzke, int i, Object obj) {
        i = zzgf.zzas(i);
        if (zzke == zzke.GROUP) {
            zzhb.zzg((zzih) obj);
            i <<= 1;
        }
        return i + zzc(zzke, obj);
    }

    static void zzb(zzgf zzgf, zzke zzke, int i, Object obj) throws IOException {
        if (zzke == zzke.GROUP) {
            zzih zzih = (zzih) obj;
            zzhb.zzg(zzih);
            zzgf.zzd(i, 3);
            zzih.zzc(zzgf);
            zzgf.zzd(i, 4);
            return;
        }
        zzgf.zzd(i, zzke.zzha());
        switch (zzgr.zznn[zzke.ordinal()]) {
            case 1:
                zzgf.zzb(((Double) obj).doubleValue());
                break;
            case 2:
                zzgf.zzd(((Float) obj).floatValue());
                return;
            case 3:
                zzgf.zze(((Long) obj).longValue());
                return;
            case 4:
                zzgf.zze(((Long) obj).longValue());
                return;
            case 5:
                zzgf.zzao(((Integer) obj).intValue());
                return;
            case 6:
                zzgf.zzg(((Long) obj).longValue());
                return;
            case 7:
                zzgf.zzar(((Integer) obj).intValue());
                return;
            case 8:
                zzgf.zzd(((Boolean) obj).booleanValue());
                return;
            case 9:
                ((zzih) obj).zzc(zzgf);
                return;
            case 10:
                zzgf.zzc((zzih) obj);
                return;
            case 11:
                if (obj instanceof zzfr) {
                    zzgf.zzb((zzfr) obj);
                    return;
                } else {
                    zzgf.zzk((String) obj);
                    return;
                }
            case 12:
                if (obj instanceof zzfr) {
                    zzgf.zzb((zzfr) obj);
                    return;
                }
                byte[] bArr = (byte[]) obj;
                zzgf.zzg(bArr, 0, bArr.length);
                return;
            case 13:
                zzgf.zzap(((Integer) obj).intValue());
                return;
            case 14:
                zzgf.zzar(((Integer) obj).intValue());
                return;
            case 15:
                zzgf.zzg(((Long) obj).longValue());
                return;
            case 16:
                zzgf.zzaq(((Integer) obj).intValue());
                return;
            case 17:
                zzgf.zzf(((Long) obj).longValue());
                return;
            case 18:
                if (!(obj instanceof zzhc)) {
                    zzgf.zzao(((Integer) obj).intValue());
                    break;
                } else {
                    zzgf.zzao(((zzhc) obj).zzap());
                    return;
                }
            default:
                break;
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static void zzb(com.google.android.gms.internal.places.zzke r2, java.lang.Object r3) {
        /*
        com.google.android.gms.internal.places.zzhb.checkNotNull(r3);
        r0 = com.google.android.gms.internal.places.zzgr.zzpn;
        r2 = r2.zzgz();
        r2 = r2.ordinal();
        r2 = r0[r2];
        r0 = 1;
        r1 = 0;
        switch(r2) {
            case 1: goto L_0x0040;
            case 2: goto L_0x003d;
            case 3: goto L_0x003a;
            case 4: goto L_0x0037;
            case 5: goto L_0x0034;
            case 6: goto L_0x0031;
            case 7: goto L_0x0028;
            case 8: goto L_0x001e;
            case 9: goto L_0x0015;
            default: goto L_0x0014;
        };
    L_0x0014:
        goto L_0x0043;
    L_0x0015:
        r2 = r3 instanceof com.google.android.gms.internal.places.zzih;
        if (r2 != 0) goto L_0x0026;
    L_0x0019:
        r2 = r3 instanceof com.google.android.gms.internal.places.zzhk;
        if (r2 == 0) goto L_0x0043;
    L_0x001d:
        goto L_0x0026;
    L_0x001e:
        r2 = r3 instanceof java.lang.Integer;
        if (r2 != 0) goto L_0x0026;
    L_0x0022:
        r2 = r3 instanceof com.google.android.gms.internal.places.zzhc;
        if (r2 == 0) goto L_0x0043;
    L_0x0026:
        r1 = 1;
        goto L_0x0043;
    L_0x0028:
        r2 = r3 instanceof com.google.android.gms.internal.places.zzfr;
        if (r2 != 0) goto L_0x0026;
    L_0x002c:
        r2 = r3 instanceof byte[];
        if (r2 == 0) goto L_0x0043;
    L_0x0030:
        goto L_0x0026;
    L_0x0031:
        r0 = r3 instanceof java.lang.String;
        goto L_0x0042;
    L_0x0034:
        r0 = r3 instanceof java.lang.Boolean;
        goto L_0x0042;
    L_0x0037:
        r0 = r3 instanceof java.lang.Double;
        goto L_0x0042;
    L_0x003a:
        r0 = r3 instanceof java.lang.Float;
        goto L_0x0042;
    L_0x003d:
        r0 = r3 instanceof java.lang.Long;
        goto L_0x0042;
    L_0x0040:
        r0 = r3 instanceof java.lang.Integer;
    L_0x0042:
        r1 = r0;
    L_0x0043:
        if (r1 == 0) goto L_0x0046;
    L_0x0045:
        return;
    L_0x0046:
        r2 = new java.lang.IllegalArgumentException;
        r3 = "Wrong object type used with protocol message reflection.";
        r2.<init>(r3);
        throw r2;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.places.zzgq.zzb(com.google.android.gms.internal.places.zzke, java.lang.Object):void");
    }

    private static int zzc(zzgs<?> zzgs, Object obj) {
        zzke zzdi = zzgs.zzdi();
        int zzap = zzgs.zzap();
        if (!zzgs.zzdk()) {
            return zzb(zzdi, zzap, obj);
        }
        int i = 0;
        if (zzgs.zzdl()) {
            for (Object obj2 : (List) obj2) {
                i += zzc(zzdi, obj2);
            }
            return (zzgf.zzas(zzap) + i) + zzgf.zzba(i);
        }
        for (Object obj22 : (List) obj22) {
            i += zzb(zzdi, zzap, obj22);
        }
        return i;
    }

    private static int zzc(zzke zzke, Object obj) {
        switch (zzgr.zznn[zzke.ordinal()]) {
            case 1:
                return zzgf.zzc(((Double) obj).doubleValue());
            case 2:
                return zzgf.zze(((Float) obj).floatValue());
            case 3:
                return zzgf.zzh(((Long) obj).longValue());
            case 4:
                return zzgf.zzi(((Long) obj).longValue());
            case 5:
                return zzgf.zzat(((Integer) obj).intValue());
            case 6:
                return zzgf.zzk(((Long) obj).longValue());
            case 7:
                return zzgf.zzaw(((Integer) obj).intValue());
            case 8:
                return zzgf.zze(((Boolean) obj).booleanValue());
            case 9:
                return zzgf.zze((zzih) obj);
            case 10:
                return obj instanceof zzhk ? zzgf.zzb((zzhk) obj) : zzgf.zzd((zzih) obj);
            case 11:
                return obj instanceof zzfr ? zzgf.zzc((zzfr) obj) : zzgf.zzl((String) obj);
            case 12:
                return obj instanceof zzfr ? zzgf.zzc((zzfr) obj) : zzgf.zze((byte[]) obj);
            case 13:
                return zzgf.zzau(((Integer) obj).intValue());
            case 14:
                return zzgf.zzax(((Integer) obj).intValue());
            case 15:
                return zzgf.zzl(((Long) obj).longValue());
            case 16:
                return zzgf.zzav(((Integer) obj).intValue());
            case 17:
                return zzgf.zzj(((Long) obj).longValue());
            case 18:
                return obj instanceof zzhc ? zzgf.zzay(((zzhc) obj).zzap()) : zzgf.zzay(((Integer) obj).intValue());
            default:
                throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
        }
    }

    private static boolean zzc(Entry<FieldDescriptorType, Object> entry) {
        zzgs zzgs = (zzgs) entry.getKey();
        if (zzgs.zzdj() == zzkj.MESSAGE) {
            if (zzgs.zzdk()) {
                for (zzih isInitialized : (List) entry.getValue()) {
                    if (!isInitialized.isInitialized()) {
                        return false;
                    }
                }
            }
            Object value = entry.getValue();
            if (value instanceof zzih) {
                if (!((zzih) value).isInitialized()) {
                    return false;
                }
            } else if (value instanceof zzhk) {
                return true;
            } else {
                throw new IllegalArgumentException("Wrong object type used with protocol message reflection.");
            }
        }
        return true;
    }

    private final void zzd(Entry<FieldDescriptorType, Object> entry) {
        Comparable comparable = (zzgs) entry.getKey();
        Object value = entry.getValue();
        if (value instanceof zzhk) {
            value = zzhk.zzei();
        }
        Object zzb;
        if (comparable.zzdk()) {
            zzb = zzb((zzgs) comparable);
            if (zzb == null) {
                zzb = new ArrayList();
            }
            for (Object zze : (List) value) {
                ((List) zzb).add(zze(zze));
            }
            this.zzpj.zzb(comparable, zzb);
        } else if (comparable.zzdj() == zzkj.MESSAGE) {
            zzb = zzb((zzgs) comparable);
            if (zzb == null) {
                this.zzpj.zzb(comparable, zze(value));
            } else {
                this.zzpj.zzb(comparable, zzb instanceof zzin ? comparable.zzb((zzin) zzb, (zzin) value) : comparable.zzb(((zzih) zzb).zzdq(), (zzih) value).zzdx());
            }
        } else {
            this.zzpj.zzb(comparable, zze(value));
        }
    }

    public static <T extends zzgs<T>> zzgq<T> zzdf() {
        return zzpm;
    }

    private static int zze(Entry<FieldDescriptorType, Object> entry) {
        zzgs zzgs = (zzgs) entry.getKey();
        Object value = entry.getValue();
        return (zzgs.zzdj() != zzkj.MESSAGE || zzgs.zzdk() || zzgs.zzdl()) ? zzc(zzgs, value) : value instanceof zzhk ? zzgf.zzc(((zzgs) entry.getKey()).zzap(), (zzhk) value) : zzgf.zze(((zzgs) entry.getKey()).zzap(), (zzih) value);
    }

    private static Object zze(Object obj) {
        if (obj instanceof zzin) {
            return ((zzin) obj).zzey();
        }
        if (!(obj instanceof byte[])) {
            return obj;
        }
        byte[] bArr = (byte[]) obj;
        Object obj2 = new byte[bArr.length];
        System.arraycopy(bArr, 0, obj2, 0, bArr.length);
        return obj2;
    }

    public final /* synthetic */ Object clone() throws CloneNotSupportedException {
        zzgq zzgq = new zzgq();
        for (int i = 0; i < this.zzpj.zzgg(); i++) {
            Entry zzbn = this.zzpj.zzbn(i);
            zzgq.zzb((zzgs) zzbn.getKey(), zzbn.getValue());
        }
        for (Entry zzbn2 : this.zzpj.zzgh()) {
            zzgq.zzb((zzgs) zzbn2.getKey(), zzbn2.getValue());
        }
        zzgq.zzpl = this.zzpl;
        return zzgq;
    }

    final Iterator<Entry<FieldDescriptorType, Object>> descendingIterator() {
        return this.zzpl ? new zzhn(this.zzpj.zzgi().iterator()) : this.zzpj.zzgi().iterator();
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof zzgq)) {
            return false;
        }
        return this.zzpj.equals(((zzgq) obj).zzpj);
    }

    public final int hashCode() {
        return this.zzpj.hashCode();
    }

    final boolean isEmpty() {
        return this.zzpj.isEmpty();
    }

    public final boolean isImmutable() {
        return this.zzpk;
    }

    public final boolean isInitialized() {
        for (int i = 0; i < this.zzpj.zzgg(); i++) {
            if (!zzc(this.zzpj.zzbn(i))) {
                return false;
            }
        }
        for (Entry zzc : this.zzpj.zzgh()) {
            if (!zzc(zzc)) {
                return false;
            }
        }
        return true;
    }

    public final Iterator<Entry<FieldDescriptorType, Object>> iterator() {
        return this.zzpl ? new zzhn(this.zzpj.entrySet().iterator()) : this.zzpj.entrySet().iterator();
    }

    public final Object zzb(FieldDescriptorType fieldDescriptorType) {
        Object obj = this.zzpj.get(fieldDescriptorType);
        return obj instanceof zzhk ? zzhk.zzei() : obj;
    }

    public final void zzb(zzgq<FieldDescriptorType> zzgq) {
        for (int i = 0; i < zzgq.zzpj.zzgg(); i++) {
            zzd(zzgq.zzpj.zzbn(i));
        }
        for (Entry zzd : zzgq.zzpj.zzgh()) {
            zzd(zzd);
        }
    }

    public final void zzb(FieldDescriptorType fieldDescriptorType, Object obj) {
        if (!fieldDescriptorType.zzdk()) {
            zzb(fieldDescriptorType.zzdi(), obj);
        } else if (obj instanceof List) {
            List arrayList = new ArrayList();
            arrayList.addAll((List) obj);
            ArrayList arrayList2 = (ArrayList) arrayList;
            int size = arrayList2.size();
            int i = 0;
            while (i < size) {
                Object obj2 = arrayList2.get(i);
                i++;
                zzb(fieldDescriptorType.zzdi(), obj2);
            }
            obj = arrayList;
        } else {
            throw new IllegalArgumentException("Wrong object type used with protocol message reflection.");
        }
        if (obj instanceof zzhk) {
            this.zzpl = true;
        }
        this.zzpj.zzb((Comparable) fieldDescriptorType, obj);
    }

    public final void zzbb() {
        if (!this.zzpk) {
            this.zzpj.zzbb();
            this.zzpk = true;
        }
    }

    public final int zzdg() {
        int i = 0;
        for (int i2 = 0; i2 < this.zzpj.zzgg(); i2++) {
            Entry zzbn = this.zzpj.zzbn(i2);
            i += zzc((zzgs) zzbn.getKey(), zzbn.getValue());
        }
        for (Entry zzbn2 : this.zzpj.zzgh()) {
            i += zzc((zzgs) zzbn2.getKey(), zzbn2.getValue());
        }
        return i;
    }

    public final int zzdh() {
        int i = 0;
        for (int i2 = 0; i2 < this.zzpj.zzgg(); i2++) {
            i += zze(this.zzpj.zzbn(i2));
        }
        for (Entry zze : this.zzpj.zzgh()) {
            i += zze(zze);
        }
        return i;
    }
}
