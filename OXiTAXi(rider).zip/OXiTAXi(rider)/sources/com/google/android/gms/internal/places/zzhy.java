package com.google.android.gms.internal.places;

final class zzhy implements zzig {
    private zzig[] zzus;

    zzhy(zzig... zzigArr) {
        this.zzus = zzigArr;
    }

    public final boolean zzc(Class<?> cls) {
        for (zzig zzc : this.zzus) {
            if (zzc.zzc(cls)) {
                return true;
            }
        }
        return false;
    }

    public final zzif zzd(Class<?> cls) {
        for (zzig zzig : this.zzus) {
            if (zzig.zzc(cls)) {
                return zzig.zzd(cls);
            }
        }
        String str = "No factory is available for message type: ";
        String valueOf = String.valueOf(cls.getName());
        throw new UnsupportedOperationException(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
    }
}
