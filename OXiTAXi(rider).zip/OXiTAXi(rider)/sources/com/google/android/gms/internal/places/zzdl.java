package com.google.android.gms.internal.places;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.Objects;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelWriter;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable.Class;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable.Constructor;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable.Field;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable.Param;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable.Reserved;

@Class(creator = "PlaceAliasCreator")
@Reserved({1000})
@Deprecated
public final class zzdl extends AbstractSafeParcelable {
    public static final Creator<zzdl> CREATOR = new zzdm();
    private static final zzdl zzhj = new zzdl("Home");
    private static final zzdl zzhk = new zzdl("Work");
    @Field(getter = "getAlias", id = 1)
    private final String zzhl;

    @Constructor
    zzdl(@Param(id = 1) String str) {
        this.zzhl = str;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof zzdl)) {
            return false;
        }
        return Objects.equal(this.zzhl, ((zzdl) obj).zzhl);
    }

    public final int hashCode() {
        return Objects.hashCode(this.zzhl);
    }

    public final String toString() {
        return Objects.toStringHelper(this).add("alias", this.zzhl).toString();
    }

    public final void writeToParcel(Parcel parcel, int i) {
        i = SafeParcelWriter.beginObjectHeader(parcel);
        SafeParcelWriter.writeString(parcel, 1, this.zzhl, false);
        SafeParcelWriter.finishObjectHeader(parcel, i);
    }
}
