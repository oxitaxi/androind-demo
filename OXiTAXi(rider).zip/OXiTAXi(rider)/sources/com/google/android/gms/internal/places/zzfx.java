package com.google.android.gms.internal.places;

abstract class zzfx extends zzfr {
    zzfx() {
    }

    abstract boolean zzb(zzfr zzfr, int i, int i2);
}
