package com.google.android.gms.internal.places;

import java.util.Iterator;
import java.util.NoSuchElementException;

final class zzfs implements Iterator {
    private final int limit = this.zznw.size();
    private int position = 0;
    private final /* synthetic */ zzfr zznw;

    zzfs(zzfr zzfr) {
        this.zznw = zzfr;
    }

    private final byte nextByte() {
        try {
            zzfr zzfr = this.zznw;
            int i = this.position;
            this.position = i + 1;
            return zzfr.zzaf(i);
        } catch (IndexOutOfBoundsException e) {
            throw new NoSuchElementException(e.getMessage());
        }
    }

    public final boolean hasNext() {
        return this.position < this.limit;
    }

    public final /* synthetic */ Object next() {
        return Byte.valueOf(nextByte());
    }

    public final void remove() {
        throw new UnsupportedOperationException();
    }
}
