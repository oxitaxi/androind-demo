package com.google.android.gms.internal.places;

import java.lang.reflect.Field;

final class zziv {
    private final int flags;
    private final Object[] zzvb;
    private final int zzvc;
    private final int zzvd;
    private final int zzve;
    private final int[] zzvk;
    private final zziw zzvz;
    private Class<?> zzwa;
    private final int zzwb;
    private final int zzwc;
    private final int zzwd;
    private final int zzwe;
    private final int zzwf;
    private final int zzwg;
    private int zzwh;
    private int zzwi;
    private int zzwj = Integer.MAX_VALUE;
    private int zzwk = Integer.MIN_VALUE;
    private int zzwl = 0;
    private int zzwm = 0;
    private int zzwn = 0;
    private int zzwo = 0;
    private int zzwp = 0;
    private int zzwq;
    private int zzwr;
    private int zzws;
    private int zzwt;
    private int zzwu;
    private Field zzwv;
    private Object zzww;
    private Object zzwx;
    private Object zzwy;

    zziv(Class<?> cls, String str, Object[] objArr) {
        this.zzwa = cls;
        this.zzvz = new zziw(str);
        this.zzvb = objArr;
        this.flags = this.zzvz.next();
        this.zzwb = this.zzvz.next();
        int[] iArr = null;
        if (this.zzwb == 0) {
            this.zzwc = 0;
            this.zzwd = 0;
            this.zzvc = 0;
            this.zzvd = 0;
            this.zzwe = 0;
            this.zzwf = 0;
            this.zzve = 0;
            this.zzwg = 0;
            this.zzvk = null;
            return;
        }
        this.zzwc = this.zzvz.next();
        this.zzwd = this.zzvz.next();
        this.zzvc = this.zzvz.next();
        this.zzvd = this.zzvz.next();
        this.zzwf = this.zzvz.next();
        this.zzve = this.zzvz.next();
        this.zzwe = this.zzvz.next();
        this.zzwg = this.zzvz.next();
        int next = this.zzvz.next();
        if (next != 0) {
            iArr = new int[next];
        }
        this.zzvk = iArr;
        this.zzwh = (this.zzwc << 1) + this.zzwd;
    }

    private static java.lang.reflect.Field zzb(java.lang.Class<?> r5, java.lang.String r6) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/952562199.run(Unknown Source)
*/
        /*
        r0 = r5.getDeclaredField(r6);	 Catch:{ NoSuchFieldException -> 0x0005 }
        return r0;
    L_0x0005:
        r0 = r5.getDeclaredFields();
        r1 = r0.length;
        r2 = 0;
    L_0x000b:
        if (r2 >= r1) goto L_0x001d;
    L_0x000d:
        r3 = r0[r2];
        r4 = r3.getName();
        r4 = r6.equals(r4);
        if (r4 == 0) goto L_0x001a;
    L_0x0019:
        return r3;
    L_0x001a:
        r2 = r2 + 1;
        goto L_0x000b;
    L_0x001d:
        r1 = new java.lang.RuntimeException;
        r5 = r5.getName();
        r0 = java.util.Arrays.toString(r0);
        r2 = java.lang.String.valueOf(r6);
        r2 = r2.length();
        r2 = r2 + 40;
        r3 = java.lang.String.valueOf(r5);
        r3 = r3.length();
        r2 = r2 + r3;
        r3 = java.lang.String.valueOf(r0);
        r3 = r3.length();
        r2 = r2 + r3;
        r3 = new java.lang.StringBuilder;
        r3.<init>(r2);
        r2 = "Field ";
        r3.append(r2);
        r3.append(r6);
        r6 = " for ";
        r3.append(r6);
        r3.append(r5);
        r5 = " not found. Known fields are ";
        r3.append(r5);
        r3.append(r0);
        r5 = r3.toString();
        r1.<init>(r5);
        throw r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.places.zziv.zzb(java.lang.Class, java.lang.String):java.lang.reflect.Field");
    }

    private final Object zzfm() {
        Object[] objArr = this.zzvb;
        int i = this.zzwh;
        this.zzwh = i + 1;
        return objArr[i];
    }

    private final boolean zzfo() {
        return (this.flags & 1) == 1;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    final boolean next() {
        /*
        r5 = this;
        r0 = r5.zzvz;
        r0 = r0.hasNext();
        r1 = 0;
        if (r0 != 0) goto L_0x000a;
    L_0x0009:
        return r1;
    L_0x000a:
        r0 = r5.zzvz;
        r0 = r0.next();
        r5.zzwq = r0;
        r0 = r5.zzvz;
        r0 = r0.next();
        r5.zzwr = r0;
        r0 = r5.zzwr;
        r0 = r0 & 255;
        r5.zzws = r0;
        r0 = r5.zzwq;
        r2 = r5.zzwj;
        if (r0 >= r2) goto L_0x002a;
    L_0x0026:
        r0 = r5.zzwq;
        r5.zzwj = r0;
    L_0x002a:
        r0 = r5.zzwq;
        r2 = r5.zzwk;
        if (r0 <= r2) goto L_0x0034;
    L_0x0030:
        r0 = r5.zzwq;
        r5.zzwk = r0;
    L_0x0034:
        r0 = r5.zzws;
        r2 = com.google.android.gms.internal.places.zzgt.MAP;
        r2 = r2.id();
        r3 = 1;
        if (r0 != r2) goto L_0x0045;
    L_0x003f:
        r0 = r5.zzwl;
        r0 = r0 + r3;
        r5.zzwl = r0;
        goto L_0x005e;
    L_0x0045:
        r0 = r5.zzws;
        r2 = com.google.android.gms.internal.places.zzgt.DOUBLE_LIST;
        r2 = r2.id();
        if (r0 < r2) goto L_0x005e;
    L_0x004f:
        r0 = r5.zzws;
        r2 = com.google.android.gms.internal.places.zzgt.GROUP_LIST;
        r2 = r2.id();
        if (r0 > r2) goto L_0x005e;
    L_0x0059:
        r0 = r5.zzwm;
        r0 = r0 + r3;
        r5.zzwm = r0;
    L_0x005e:
        r0 = r5.zzwp;
        r0 = r0 + r3;
        r5.zzwp = r0;
        r0 = r5.zzwj;
        r2 = r5.zzwq;
        r4 = r5.zzwp;
        r0 = com.google.android.gms.internal.places.zzja.zzd(r0, r2, r4);
        if (r0 == 0) goto L_0x007c;
    L_0x006f:
        r0 = r5.zzwq;
        r0 = r0 + r3;
        r5.zzwo = r0;
        r0 = r5.zzwo;
        r2 = r5.zzwj;
        r0 = r0 - r2;
    L_0x0079:
        r5.zzwn = r0;
        goto L_0x0080;
    L_0x007c:
        r0 = r5.zzwn;
        r0 = r0 + r3;
        goto L_0x0079;
    L_0x0080:
        r0 = r5.zzwr;
        r0 = r0 & 1024;
        if (r0 == 0) goto L_0x0088;
    L_0x0086:
        r0 = 1;
        goto L_0x0089;
    L_0x0088:
        r0 = 0;
    L_0x0089:
        if (r0 == 0) goto L_0x0097;
    L_0x008b:
        r0 = r5.zzvk;
        r2 = r5.zzwi;
        r4 = r2 + 1;
        r5.zzwi = r4;
        r4 = r5.zzwq;
        r0[r2] = r4;
    L_0x0097:
        r0 = 0;
        r5.zzww = r0;
        r5.zzwx = r0;
        r5.zzwy = r0;
        r0 = r5.zzfp();
        if (r0 == 0) goto L_0x00e7;
    L_0x00a4:
        r0 = r5.zzvz;
        r0 = r0.next();
        r5.zzwt = r0;
        r0 = r5.zzws;
        r1 = com.google.android.gms.internal.places.zzgt.MESSAGE;
        r1 = r1.id();
        r1 = r1 + 51;
        if (r0 == r1) goto L_0x00df;
    L_0x00b8:
        r0 = r5.zzws;
        r1 = com.google.android.gms.internal.places.zzgt.GROUP;
        r1 = r1.id();
        r1 = r1 + 51;
        if (r0 != r1) goto L_0x00c5;
    L_0x00c4:
        goto L_0x00df;
    L_0x00c5:
        r0 = r5.zzws;
        r1 = com.google.android.gms.internal.places.zzgt.ENUM;
        r1 = r1.id();
        r1 = r1 + 51;
        if (r0 != r1) goto L_0x0177;
    L_0x00d1:
        r0 = r5.zzfo();
        if (r0 == 0) goto L_0x0177;
    L_0x00d7:
        r0 = r5.zzfm();
        r5.zzwx = r0;
        goto L_0x0177;
    L_0x00df:
        r0 = r5.zzfm();
    L_0x00e3:
        r5.zzww = r0;
        goto L_0x0177;
    L_0x00e7:
        r0 = r5.zzwa;
        r2 = r5.zzfm();
        r2 = (java.lang.String) r2;
        r0 = zzb(r0, r2);
        r5.zzwv = r0;
        r0 = r5.zzft();
        if (r0 == 0) goto L_0x0103;
    L_0x00fb:
        r0 = r5.zzvz;
        r0 = r0.next();
        r5.zzwu = r0;
    L_0x0103:
        r0 = r5.zzws;
        r2 = com.google.android.gms.internal.places.zzgt.MESSAGE;
        r2 = r2.id();
        if (r0 == r2) goto L_0x016f;
    L_0x010d:
        r0 = r5.zzws;
        r2 = com.google.android.gms.internal.places.zzgt.GROUP;
        r2 = r2.id();
        if (r0 != r2) goto L_0x0118;
    L_0x0117:
        goto L_0x016f;
    L_0x0118:
        r0 = r5.zzws;
        r2 = com.google.android.gms.internal.places.zzgt.MESSAGE_LIST;
        r2 = r2.id();
        if (r0 == r2) goto L_0x00df;
    L_0x0122:
        r0 = r5.zzws;
        r2 = com.google.android.gms.internal.places.zzgt.GROUP_LIST;
        r2 = r2.id();
        if (r0 != r2) goto L_0x012d;
    L_0x012c:
        goto L_0x00df;
    L_0x012d:
        r0 = r5.zzws;
        r2 = com.google.android.gms.internal.places.zzgt.ENUM;
        r2 = r2.id();
        if (r0 == r2) goto L_0x0167;
    L_0x0137:
        r0 = r5.zzws;
        r2 = com.google.android.gms.internal.places.zzgt.ENUM_LIST;
        r2 = r2.id();
        if (r0 == r2) goto L_0x0167;
    L_0x0141:
        r0 = r5.zzws;
        r2 = com.google.android.gms.internal.places.zzgt.ENUM_LIST_PACKED;
        r2 = r2.id();
        if (r0 != r2) goto L_0x014c;
    L_0x014b:
        goto L_0x0167;
    L_0x014c:
        r0 = r5.zzws;
        r2 = com.google.android.gms.internal.places.zzgt.MAP;
        r2 = r2.id();
        if (r0 != r2) goto L_0x0177;
    L_0x0156:
        r0 = r5.zzfm();
        r5.zzwy = r0;
        r0 = r5.zzwr;
        r0 = r0 & 2048;
        if (r0 == 0) goto L_0x0163;
    L_0x0162:
        r1 = 1;
    L_0x0163:
        if (r1 == 0) goto L_0x0177;
    L_0x0165:
        goto L_0x00d7;
    L_0x0167:
        r0 = r5.zzfo();
        if (r0 == 0) goto L_0x0177;
    L_0x016d:
        goto L_0x00d7;
    L_0x016f:
        r0 = r5.zzwv;
        r0 = r0.getType();
        goto L_0x00e3;
    L_0x0177:
        return r3;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.places.zziv.next():boolean");
    }

    final int zzbg() {
        return this.zzwq;
    }

    final int zzfn() {
        return this.zzws;
    }

    final boolean zzfp() {
        return this.zzws > zzgt.MAP.id();
    }

    final Field zzfq() {
        int i = this.zzwt << 1;
        Object obj = this.zzvb[i];
        if (obj instanceof Field) {
            return (Field) obj;
        }
        Field zzb = zzb(this.zzwa, (String) obj);
        this.zzvb[i] = zzb;
        return zzb;
    }

    final Field zzfr() {
        int i = (this.zzwt << 1) + 1;
        Object obj = this.zzvb[i];
        if (obj instanceof Field) {
            return (Field) obj;
        }
        Field zzb = zzb(this.zzwa, (String) obj);
        this.zzvb[i] = zzb;
        return zzb;
    }

    final Field zzfs() {
        return this.zzwv;
    }

    final boolean zzft() {
        return zzfo() && this.zzws <= zzgt.GROUP.id();
    }

    final Field zzfu() {
        int i = (this.zzwc << 1) + (this.zzwu / 32);
        Object obj = this.zzvb[i];
        if (obj instanceof Field) {
            return (Field) obj;
        }
        Field zzb = zzb(this.zzwa, (String) obj);
        this.zzvb[i] = zzb;
        return zzb;
    }

    final int zzfv() {
        return this.zzwu % 32;
    }

    final boolean zzfw() {
        return (this.zzwr & 256) != 0;
    }

    final boolean zzfx() {
        return (this.zzwr & 512) != 0;
    }

    final Object zzfy() {
        return this.zzww;
    }

    final Object zzfz() {
        return this.zzwx;
    }

    final Object zzga() {
        return this.zzwy;
    }
}
