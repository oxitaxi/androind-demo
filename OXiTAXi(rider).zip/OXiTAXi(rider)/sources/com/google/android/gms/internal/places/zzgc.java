package com.google.android.gms.internal.places;

import java.io.IOException;
import java.util.Arrays;

final class zzgc extends zzga {
    private final byte[] buffer;
    private int limit;
    private int pos;
    private final boolean zzoh;
    private int zzoi;
    private int zzoj;
    private int zzok;
    private int zzol;

    private zzgc(byte[] bArr, int i, int i2, boolean z) {
        super();
        this.zzol = Integer.MAX_VALUE;
        this.buffer = bArr;
        this.limit = i2 + i;
        this.pos = i;
        this.zzoj = this.pos;
        this.zzoh = z;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private final int zzcm() throws java.io.IOException {
        /*
        r5 = this;
        r0 = r5.pos;
        r1 = r5.limit;
        if (r1 == r0) goto L_0x006d;
    L_0x0006:
        r1 = r5.buffer;
        r2 = r0 + 1;
        r0 = r1[r0];
        if (r0 < 0) goto L_0x0011;
    L_0x000e:
        r5.pos = r2;
        return r0;
    L_0x0011:
        r3 = r5.limit;
        r3 = r3 - r2;
        r4 = 9;
        if (r3 < r4) goto L_0x006d;
    L_0x0018:
        r3 = r2 + 1;
        r2 = r1[r2];
        r2 = r2 << 7;
        r0 = r0 ^ r2;
        if (r0 >= 0) goto L_0x0024;
    L_0x0021:
        r0 = r0 ^ -128;
        goto L_0x006a;
    L_0x0024:
        r2 = r3 + 1;
        r3 = r1[r3];
        r3 = r3 << 14;
        r0 = r0 ^ r3;
        if (r0 < 0) goto L_0x0031;
    L_0x002d:
        r0 = r0 ^ 16256;
    L_0x002f:
        r3 = r2;
        goto L_0x006a;
    L_0x0031:
        r3 = r2 + 1;
        r2 = r1[r2];
        r2 = r2 << 21;
        r0 = r0 ^ r2;
        if (r0 >= 0) goto L_0x003f;
    L_0x003a:
        r1 = -2080896; // 0xffffffffffe03f80 float:NaN double:NaN;
        r0 = r0 ^ r1;
        goto L_0x006a;
    L_0x003f:
        r2 = r3 + 1;
        r3 = r1[r3];
        r4 = r3 << 28;
        r0 = r0 ^ r4;
        r4 = 266354560; // 0xfe03f80 float:2.2112565E-29 double:1.315966377E-315;
        r0 = r0 ^ r4;
        if (r3 >= 0) goto L_0x002f;
    L_0x004c:
        r3 = r2 + 1;
        r2 = r1[r2];
        if (r2 >= 0) goto L_0x006a;
    L_0x0052:
        r2 = r3 + 1;
        r3 = r1[r3];
        if (r3 >= 0) goto L_0x002f;
    L_0x0058:
        r3 = r2 + 1;
        r2 = r1[r2];
        if (r2 >= 0) goto L_0x006a;
    L_0x005e:
        r2 = r3 + 1;
        r3 = r1[r3];
        if (r3 >= 0) goto L_0x002f;
    L_0x0064:
        r3 = r2 + 1;
        r1 = r1[r2];
        if (r1 < 0) goto L_0x006d;
    L_0x006a:
        r5.pos = r3;
        return r0;
    L_0x006d:
        r0 = r5.zzck();
        r0 = (int) r0;
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.places.zzgc.zzcm():int");
    }

    private final long zzcn() throws IOException {
        int i = this.pos;
        if (this.limit != i) {
            byte[] bArr = this.buffer;
            int i2 = i + 1;
            byte b = bArr[i];
            if (b >= (byte) 0) {
                this.pos = i2;
                return (long) b;
            } else if (this.limit - i2 >= 9) {
                long j;
                long j2;
                int i3 = i2 + 1;
                i = b ^ (bArr[i2] << 7);
                if (i < 0) {
                    i ^= -128;
                } else {
                    i2 = i3 + 1;
                    i ^= bArr[i3] << 14;
                    if (i >= 0) {
                        j = (long) (i ^ 16256);
                        i = i2;
                        j2 = j;
                        this.pos = i;
                        return j2;
                    }
                    i3 = i2 + 1;
                    i ^= bArr[i2] << 21;
                    if (i < 0) {
                        i ^= -2080896;
                    } else {
                        long j3 = (long) i;
                        i = i3 + 1;
                        j2 = (((long) bArr[i3]) << 28) ^ j3;
                        if (j2 >= 0) {
                            j3 = 266354560;
                        } else {
                            long j4;
                            int i4 = i + 1;
                            j2 ^= ((long) bArr[i]) << 35;
                            if (j2 < 0) {
                                j4 = -34093383808L;
                            } else {
                                i = i4 + 1;
                                j2 ^= ((long) bArr[i4]) << 42;
                                if (j2 >= 0) {
                                    j3 = 4363953127296L;
                                } else {
                                    i4 = i + 1;
                                    j2 ^= ((long) bArr[i]) << 49;
                                    if (j2 < 0) {
                                        j4 = -558586000294016L;
                                    } else {
                                        i = i4 + 1;
                                        j2 = (j2 ^ (((long) bArr[i4]) << 56)) ^ 71499008037633920L;
                                        if (j2 < 0) {
                                            i4 = i + 1;
                                            if (((long) bArr[i]) >= 0) {
                                                i = i4;
                                            }
                                        }
                                        this.pos = i;
                                        return j2;
                                    }
                                }
                            }
                            j2 = j4 ^ j2;
                            i = i4;
                            this.pos = i;
                            return j2;
                        }
                        j2 ^= j3;
                        this.pos = i;
                        return j2;
                    }
                }
                j = (long) i;
                i = i3;
                j2 = j;
                this.pos = i;
                return j2;
            }
        }
        return zzck();
    }

    private final int zzco() throws IOException {
        int i = this.pos;
        if (this.limit - i >= 4) {
            byte[] bArr = this.buffer;
            this.pos = i + 4;
            return ((bArr[i + 3] & 255) << 24) | (((bArr[i] & 255) | ((bArr[i + 1] & 255) << 8)) | ((bArr[i + 2] & 255) << 16));
        }
        throw zzhh.zzdz();
    }

    private final long zzcp() throws IOException {
        int i = this.pos;
        if (this.limit - i >= 8) {
            byte[] bArr = this.buffer;
            this.pos = i + 8;
            return ((((long) bArr[i + 7]) & 255) << 56) | (((((((((long) bArr[i]) & 255) | ((((long) bArr[i + 1]) & 255) << 8)) | ((((long) bArr[i + 2]) & 255) << 16)) | ((((long) bArr[i + 3]) & 255) << 24)) | ((((long) bArr[i + 4]) & 255) << 32)) | ((((long) bArr[i + 5]) & 255) << 40)) | ((((long) bArr[i + 6]) & 255) << 48));
        }
        throw zzhh.zzdz();
    }

    private final void zzcq() {
        this.limit += this.zzoi;
        int i = this.limit - this.zzoj;
        if (i > this.zzol) {
            this.zzoi = i - this.zzol;
            this.limit -= this.zzoi;
            return;
        }
        this.zzoi = 0;
    }

    private final byte zzcr() throws IOException {
        if (this.pos != this.limit) {
            byte[] bArr = this.buffer;
            int i = this.pos;
            this.pos = i + 1;
            return bArr[i];
        }
        throw zzhh.zzdz();
    }

    public final double readDouble() throws IOException {
        return Double.longBitsToDouble(zzcp());
    }

    public final float readFloat() throws IOException {
        return Float.intBitsToFloat(zzco());
    }

    public final String readString() throws IOException {
        int zzcm = zzcm();
        if (zzcm > 0 && zzcm <= this.limit - this.pos) {
            String str = new String(this.buffer, this.pos, zzcm, zzhb.UTF_8);
            this.pos += zzcm;
            return str;
        } else if (zzcm == 0) {
            return "";
        } else {
            if (zzcm < 0) {
                throw zzhh.zzea();
            }
            throw zzhh.zzdz();
        }
    }

    public final void zzah(int i) throws zzhh {
        if (this.zzok != i) {
            throw zzhh.zzec();
        }
    }

    public final boolean zzai(int i) throws IOException {
        int i2 = 0;
        switch (i & 7) {
            case 0:
                if (this.limit - this.pos >= 10) {
                    while (i2 < 10) {
                        byte[] bArr = this.buffer;
                        int i3 = this.pos;
                        this.pos = i3 + 1;
                        if (bArr[i3] < (byte) 0) {
                            i2++;
                        }
                    }
                    throw zzhh.zzeb();
                }
                while (i2 < 10) {
                    if (zzcr() < (byte) 0) {
                        i2++;
                    }
                }
                throw zzhh.zzeb();
                return true;
            case 1:
                zzam(8);
                return true;
            case 2:
                zzam(zzcm());
                return true;
            case 3:
                break;
            case 4:
                return false;
            case 5:
                zzam(4);
                return true;
            default:
                throw zzhh.zzed();
        }
        int zzcj;
        do {
            zzcj = zzcj();
            if (zzcj != 0) {
            }
            zzah(((i >>> 3) << 3) | 4);
            return true;
        } while (zzai(zzcj));
        zzah(((i >>> 3) << 3) | 4);
        return true;
    }

    public final int zzak(int i) throws zzhh {
        if (i >= 0) {
            i += zzcl();
            int i2 = this.zzol;
            if (i <= i2) {
                this.zzol = i;
                zzcq();
                return i2;
            }
            throw zzhh.zzdz();
        }
        throw zzhh.zzea();
    }

    public final void zzal(int i) {
        this.zzol = i;
        zzcq();
    }

    public final void zzam(int i) throws IOException {
        if (i >= 0 && i <= this.limit - this.pos) {
            this.pos += i;
        } else if (i < 0) {
            throw zzhh.zzea();
        } else {
            throw zzhh.zzdz();
        }
    }

    public final <T extends zzih> T zzb(zzir<T> zzir, zzgl zzgl) throws IOException {
        int zzcm = zzcm();
        if (this.zzob < this.zzoc) {
            zzcm = zzak(zzcm);
            this.zzob++;
            zzih zzih = (zzih) zzir.zzb(this, zzgl);
            zzah(0);
            this.zzob--;
            zzal(zzcm);
            return zzih;
        }
        throw zzhh.zzee();
    }

    public final boolean zzbf() throws IOException {
        return this.pos == this.limit;
    }

    public final long zzbi() throws IOException {
        return zzcn();
    }

    public final long zzbj() throws IOException {
        return zzcn();
    }

    public final int zzbk() throws IOException {
        return zzcm();
    }

    public final long zzbl() throws IOException {
        return zzcp();
    }

    public final int zzbm() throws IOException {
        return zzco();
    }

    public final boolean zzbn() throws IOException {
        return zzcn() != 0;
    }

    public final String zzbo() throws IOException {
        int zzcm = zzcm();
        if (zzcm <= 0 || zzcm > this.limit - this.pos) {
            if (zzcm == 0) {
                return "";
            }
            if (zzcm <= 0) {
                throw zzhh.zzea();
            }
            throw zzhh.zzdz();
        } else if (zzjy.zzh(this.buffer, this.pos, this.pos + zzcm)) {
            int i = this.pos;
            this.pos += zzcm;
            return new String(this.buffer, i, zzcm, zzhb.UTF_8);
        } else {
            throw zzhh.zzeg();
        }
    }

    public final zzfr zzbp() throws IOException {
        int zzcm = zzcm();
        if (zzcm > 0 && zzcm <= this.limit - this.pos) {
            zzfr zzc = zzfr.zzc(this.buffer, this.pos, zzcm);
            this.pos += zzcm;
            return zzc;
        } else if (zzcm == 0) {
            return zzfr.zznt;
        } else {
            byte[] copyOfRange;
            if (zzcm > 0 && zzcm <= this.limit - this.pos) {
                int i = this.pos;
                this.pos += zzcm;
                copyOfRange = Arrays.copyOfRange(this.buffer, i, this.pos);
            } else if (zzcm > 0) {
                throw zzhh.zzdz();
            } else if (zzcm == 0) {
                copyOfRange = zzhb.zztl;
            } else {
                throw zzhh.zzea();
            }
            return zzfr.zzc(copyOfRange);
        }
    }

    public final int zzbq() throws IOException {
        return zzcm();
    }

    public final int zzbr() throws IOException {
        return zzcm();
    }

    public final int zzbs() throws IOException {
        return zzco();
    }

    public final long zzbt() throws IOException {
        return zzcp();
    }

    public final int zzbu() throws IOException {
        return zzga.zzan(zzcm());
    }

    public final long zzbv() throws IOException {
        return zzga.zzd(zzcn());
    }

    public final int zzcj() throws IOException {
        if (zzbf()) {
            this.zzok = 0;
            return 0;
        }
        this.zzok = zzcm();
        if ((this.zzok >>> 3) != 0) {
            return this.zzok;
        }
        throw new zzhh("Protocol message contained an invalid tag (zero).");
    }

    final long zzck() throws IOException {
        long j = 0;
        for (int i = 0; i < 64; i += 7) {
            byte zzcr = zzcr();
            j |= ((long) (zzcr & 127)) << i;
            if ((zzcr & 128) == 0) {
                return j;
            }
        }
        throw zzhh.zzeb();
    }

    public final int zzcl() {
        return this.pos - this.zzoj;
    }
}
