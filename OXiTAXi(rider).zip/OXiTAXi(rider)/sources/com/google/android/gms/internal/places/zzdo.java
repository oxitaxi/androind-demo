package com.google.android.gms.internal.places;

import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.data.DataBufferSafeParcelable;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.internal.Preconditions;
import com.google.android.gms.location.places.PlacesStatusCodes;

@Deprecated
public final class zzdo extends DataBufferSafeParcelable<zzdn> implements Result {
    private final Status zzdz;

    public zzdo(DataHolder dataHolder) {
        this(dataHolder, PlacesStatusCodes.zze(dataHolder.getStatusCode()));
    }

    private zzdo(DataHolder dataHolder, Status status) {
        boolean z;
        super(dataHolder, zzdn.CREATOR);
        if (dataHolder != null) {
            if (dataHolder.getStatusCode() != status.getStatusCode()) {
                z = false;
                Preconditions.checkArgument(z);
                this.zzdz = status;
            }
        }
        z = true;
        Preconditions.checkArgument(z);
        this.zzdz = status;
    }

    public final Status getStatus() {
        return this.zzdz;
    }
}
