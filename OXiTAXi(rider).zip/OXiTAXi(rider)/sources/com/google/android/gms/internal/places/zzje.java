package com.google.android.gms.internal.places;

import java.util.Iterator;
import java.util.Map.Entry;

final class zzje extends zzjk {
    private final /* synthetic */ zzjb zzxk;

    private zzje(zzjb zzjb) {
        this.zzxk = zzjb;
        super(zzjb);
    }

    public final Iterator<Entry<K, V>> iterator() {
        return new zzjd(this.zzxk);
    }
}
