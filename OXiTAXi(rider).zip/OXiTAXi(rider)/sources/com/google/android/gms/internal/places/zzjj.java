package com.google.android.gms.internal.places;

import java.util.Iterator;
import java.util.Map.Entry;

final class zzjj implements Iterator<Entry<K, V>> {
    private int pos;
    private Iterator<Entry<K, V>> zzxj;
    private final /* synthetic */ zzjb zzxk;
    private boolean zzxo;

    private zzjj(zzjb zzjb) {
        this.zzxk = zzjb;
        this.pos = -1;
    }

    private final Iterator<Entry<K, V>> zzgl() {
        if (this.zzxj == null) {
            this.zzxj = this.zzxk.zzxf.entrySet().iterator();
        }
        return this.zzxj;
    }

    public final boolean hasNext() {
        if (this.pos + 1 >= this.zzxk.zzxe.size()) {
            if (this.zzxk.zzxf.isEmpty() || !zzgl().hasNext()) {
                return false;
            }
        }
        return true;
    }

    public final /* synthetic */ Object next() {
        this.zzxo = true;
        int i = this.pos + 1;
        this.pos = i;
        return (Entry) (i < this.zzxk.zzxe.size() ? this.zzxk.zzxe.get(this.pos) : zzgl().next());
    }

    public final void remove() {
        if (this.zzxo) {
            this.zzxo = false;
            this.zzxk.zzgj();
            if (this.pos < this.zzxk.zzxe.size()) {
                zzjb zzjb = this.zzxk;
                int i = this.pos;
                this.pos = i - 1;
                zzjb.zzbo(i);
                return;
            }
            zzgl().remove();
            return;
        }
        throw new IllegalStateException("remove() was called before next()");
    }
}
