package com.google.android.gms.internal.places;

import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

final class zzkr implements Cloneable {
    private Object value;
    private zzkp<?, ?> zzaam;
    private List<zzkw> zzaan = new ArrayList();

    zzkr() {
    }

    private final byte[] toByteArray() throws IOException {
        byte[] bArr = new byte[zzal()];
        zzb(zzkm.zzi(bArr));
        return bArr;
    }

    private final zzkr zzhf() {
        zzkr zzkr = new zzkr();
        try {
            zzkr.zzaam = this.zzaam;
            if (this.zzaan == null) {
                zzkr.zzaan = null;
            } else {
                zzkr.zzaan.addAll(this.zzaan);
            }
            if (this.value != null) {
                Object obj;
                if (this.value instanceof zzku) {
                    obj = (zzku) ((zzku) this.value).clone();
                } else if (this.value instanceof byte[]) {
                    obj = ((byte[]) this.value).clone();
                } else {
                    int i = 0;
                    Object obj2;
                    if (this.value instanceof byte[][]) {
                        byte[][] bArr = (byte[][]) this.value;
                        obj2 = new byte[bArr.length][];
                        zzkr.value = obj2;
                        while (i < bArr.length) {
                            obj2[i] = (byte[]) bArr[i].clone();
                            i++;
                        }
                    } else if (this.value instanceof boolean[]) {
                        obj = ((boolean[]) this.value).clone();
                    } else if (this.value instanceof int[]) {
                        obj = ((int[]) this.value).clone();
                    } else if (this.value instanceof long[]) {
                        obj = ((long[]) this.value).clone();
                    } else if (this.value instanceof float[]) {
                        obj = ((float[]) this.value).clone();
                    } else if (this.value instanceof double[]) {
                        obj = ((double[]) this.value).clone();
                    } else if (this.value instanceof zzku[]) {
                        zzku[] zzkuArr = (zzku[]) this.value;
                        obj2 = new zzku[zzkuArr.length];
                        zzkr.value = obj2;
                        while (i < zzkuArr.length) {
                            obj2[i] = (zzku) zzkuArr[i].clone();
                            i++;
                        }
                    }
                }
                zzkr.value = obj;
            }
            return zzkr;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError(e);
        }
    }

    public final /* synthetic */ Object clone() throws CloneNotSupportedException {
        return zzhf();
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof zzkr)) {
            return false;
        }
        zzkr zzkr = (zzkr) obj;
        if (this.value != null && zzkr.value != null) {
            return this.zzaam != zzkr.zzaam ? false : !this.zzaam.zzaag.isArray() ? this.value.equals(zzkr.value) : this.value instanceof byte[] ? Arrays.equals((byte[]) this.value, (byte[]) zzkr.value) : this.value instanceof int[] ? Arrays.equals((int[]) this.value, (int[]) zzkr.value) : this.value instanceof long[] ? Arrays.equals((long[]) this.value, (long[]) zzkr.value) : this.value instanceof float[] ? Arrays.equals((float[]) this.value, (float[]) zzkr.value) : this.value instanceof double[] ? Arrays.equals((double[]) this.value, (double[]) zzkr.value) : this.value instanceof boolean[] ? Arrays.equals((boolean[]) this.value, (boolean[]) zzkr.value) : Arrays.deepEquals((Object[]) this.value, (Object[]) zzkr.value);
        } else {
            if (this.zzaan != null && zzkr.zzaan != null) {
                return this.zzaan.equals(zzkr.zzaan);
            }
            try {
                return Arrays.equals(toByteArray(), zzkr.toByteArray());
            } catch (Throwable e) {
                throw new IllegalStateException(e);
            }
        }
    }

    public final int hashCode() {
        try {
            return Arrays.hashCode(toByteArray()) + 527;
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    final int zzal() {
        int i = 0;
        int i2;
        if (this.value != null) {
            zzkp zzkp = this.zzaam;
            Object obj = this.value;
            if (!zzkp.zzaah) {
                return zzkp.zzt(obj);
            }
            int length = Array.getLength(obj);
            i2 = 0;
            while (i < length) {
                if (Array.get(obj, i) != null) {
                    i2 += zzkp.zzt(Array.get(obj, i));
                }
                i++;
            }
            return i2;
        }
        i2 = 0;
        for (zzkw zzkw : this.zzaan) {
            i2 += (zzkm.zzba(zzkw.tag) + 0) + zzkw.zzoa.length;
        }
        return i2;
    }

    final void zzb(zzkm zzkm) throws IOException {
        if (this.value != null) {
            zzkp zzkp = this.zzaam;
            Object obj = this.value;
            if (zzkp.zzaah) {
                int length = Array.getLength(obj);
                for (int i = 0; i < length; i++) {
                    Object obj2 = Array.get(obj, i);
                    if (obj2 != null) {
                        zzkp.zzb(obj2, zzkm);
                    }
                }
                return;
            }
            zzkp.zzb(obj, zzkm);
            return;
        }
        for (zzkw zzkw : this.zzaan) {
            zzkm.zzbt(zzkw.tag);
            zzkm.zzk(zzkw.zzoa);
        }
    }

    final void zzb(zzkw zzkw) throws IOException {
        if (this.zzaan != null) {
            this.zzaan.add(zzkw);
            return;
        }
        Object zzb;
        if (this.value instanceof zzku) {
            byte[] bArr = zzkw.zzoa;
            zzkl zzk = zzkl.zzk(bArr, 0, bArr.length);
            int zzcm = zzk.zzcm();
            if (zzcm == bArr.length - zzkm.zzat(zzcm)) {
                zzb = ((zzku) this.value).zzb(zzk);
            } else {
                throw zzkt.zzhg();
            }
        } else if (this.value instanceof zzku[]) {
            zzku[] zzkuArr = (zzku[]) this.zzaam.zzae(Collections.singletonList(zzkw));
            zzku[] zzkuArr2 = (zzku[]) this.value;
            Object obj = (zzku[]) Arrays.copyOf(zzkuArr2, zzkuArr2.length + zzkuArr.length);
            System.arraycopy(zzkuArr, 0, obj, zzkuArr2.length, zzkuArr.length);
            zzb = obj;
        } else {
            zzb = this.zzaam.zzae(Collections.singletonList(zzkw));
        }
        this.zzaam = this.zzaam;
        this.value = zzb;
        this.zzaan = null;
    }
}
