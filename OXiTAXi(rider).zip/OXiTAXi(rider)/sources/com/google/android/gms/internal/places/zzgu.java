package com.google.android.gms.internal.places;

final /* synthetic */ class zzgu {
    static final /* synthetic */ int[] zzru = new int[zzgv.values().length];
    static final /* synthetic */ int[] zzrv = new int[zzhj.values().length];

    static {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/952562199.run(Unknown Source)
*/
        /*
        r0 = com.google.android.gms.internal.places.zzhj.values();
        r0 = r0.length;
        r0 = new int[r0];
        zzrv = r0;
        r0 = 1;
        r1 = zzrv;	 Catch:{ NoSuchFieldError -> 0x0014 }
        r2 = com.google.android.gms.internal.places.zzhj.BYTE_STRING;	 Catch:{ NoSuchFieldError -> 0x0014 }
        r2 = r2.ordinal();	 Catch:{ NoSuchFieldError -> 0x0014 }
        r1[r2] = r0;	 Catch:{ NoSuchFieldError -> 0x0014 }
    L_0x0014:
        r1 = 2;
        r2 = zzrv;	 Catch:{ NoSuchFieldError -> 0x001f }
        r3 = com.google.android.gms.internal.places.zzhj.MESSAGE;	 Catch:{ NoSuchFieldError -> 0x001f }
        r3 = r3.ordinal();	 Catch:{ NoSuchFieldError -> 0x001f }
        r2[r3] = r1;	 Catch:{ NoSuchFieldError -> 0x001f }
    L_0x001f:
        r2 = 3;
        r3 = zzrv;	 Catch:{ NoSuchFieldError -> 0x002a }
        r4 = com.google.android.gms.internal.places.zzhj.STRING;	 Catch:{ NoSuchFieldError -> 0x002a }
        r4 = r4.ordinal();	 Catch:{ NoSuchFieldError -> 0x002a }
        r3[r4] = r2;	 Catch:{ NoSuchFieldError -> 0x002a }
    L_0x002a:
        r3 = com.google.android.gms.internal.places.zzgv.values();
        r3 = r3.length;
        r3 = new int[r3];
        zzru = r3;
        r3 = zzru;	 Catch:{ NoSuchFieldError -> 0x003d }
        r4 = com.google.android.gms.internal.places.zzgv.MAP;	 Catch:{ NoSuchFieldError -> 0x003d }
        r4 = r4.ordinal();	 Catch:{ NoSuchFieldError -> 0x003d }
        r3[r4] = r0;	 Catch:{ NoSuchFieldError -> 0x003d }
    L_0x003d:
        r0 = zzru;	 Catch:{ NoSuchFieldError -> 0x0047 }
        r3 = com.google.android.gms.internal.places.zzgv.VECTOR;	 Catch:{ NoSuchFieldError -> 0x0047 }
        r3 = r3.ordinal();	 Catch:{ NoSuchFieldError -> 0x0047 }
        r0[r3] = r1;	 Catch:{ NoSuchFieldError -> 0x0047 }
    L_0x0047:
        r0 = zzru;	 Catch:{ NoSuchFieldError -> 0x0051 }
        r1 = com.google.android.gms.internal.places.zzgv.SCALAR;	 Catch:{ NoSuchFieldError -> 0x0051 }
        r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0051 }
        r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0051 }
    L_0x0051:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.places.zzgu.<clinit>():void");
    }
}
