package com.google.android.gms.internal.places;

import com.google.android.gms.internal.places.zzgz.zzh;

final class zzhw implements zziz {
    private static final zzig zzur = new zzhx();
    private final zzig zzuq;

    public zzhw() {
        this(new zzhy(zzgy.zzdn(), zzeo()));
    }

    private zzhw(zzig zzig) {
        this.zzuq = (zzig) zzhb.zzb((Object) zzig, "messageInfoFactory");
    }

    private static boolean zzb(zzif zzif) {
        return zzif.zzev() == zzh.zztd;
    }

    private static com.google.android.gms.internal.places.zzig zzeo() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/952562199.run(Unknown Source)
*/
        /*
        r0 = "com.google.protobuf.DescriptorMessageInfoFactory";	 Catch:{ Exception -> 0x0019 }
        r0 = java.lang.Class.forName(r0);	 Catch:{ Exception -> 0x0019 }
        r1 = "getInstance";	 Catch:{ Exception -> 0x0019 }
        r2 = 0;	 Catch:{ Exception -> 0x0019 }
        r3 = new java.lang.Class[r2];	 Catch:{ Exception -> 0x0019 }
        r0 = r0.getDeclaredMethod(r1, r3);	 Catch:{ Exception -> 0x0019 }
        r1 = 0;	 Catch:{ Exception -> 0x0019 }
        r2 = new java.lang.Object[r2];	 Catch:{ Exception -> 0x0019 }
        r0 = r0.invoke(r1, r2);	 Catch:{ Exception -> 0x0019 }
        r0 = (com.google.android.gms.internal.places.zzig) r0;	 Catch:{ Exception -> 0x0019 }
        return r0;
    L_0x0019:
        r0 = zzur;
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.places.zzhw.zzeo():com.google.android.gms.internal.places.zzig");
    }

    public final <T> zziy<T> zzf(Class<T> cls) {
        zzja.zzh(cls);
        zzif zzd = this.zzuq.zzd(cls);
        if (zzd.zzew()) {
            return zzgz.class.isAssignableFrom(cls) ? zzim.zzb(zzja.zzgd(), zzgp.zzdd(), zzd.zzex()) : zzim.zzb(zzja.zzgb(), zzgp.zzde(), zzd.zzex());
        } else {
            if (zzgz.class.isAssignableFrom(cls)) {
                if (zzb(zzd)) {
                    return zzil.zzb(cls, zzd, zziq.zzfa(), zzhr.zzen(), zzja.zzgd(), zzgp.zzdd(), zzie.zzet());
                }
                return zzil.zzb(cls, zzd, zziq.zzfa(), zzhr.zzen(), zzja.zzgd(), null, zzie.zzet());
            } else if (zzb(zzd)) {
                return zzil.zzb(cls, zzd, zziq.zzez(), zzhr.zzem(), zzja.zzgb(), zzgp.zzde(), zzie.zzes());
            } else {
                return zzil.zzb(cls, zzd, zziq.zzez(), zzhr.zzem(), zzja.zzgc(), null, zzie.zzes());
            }
        }
    }
}
