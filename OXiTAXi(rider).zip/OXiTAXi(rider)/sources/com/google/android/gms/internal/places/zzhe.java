package com.google.android.gms.internal.places;

public interface zzhe extends zzhg<Integer> {
    zzhe zzbd(int i);

    void zzbe(int i);
}
