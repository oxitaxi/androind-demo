package com.google.android.gms.internal.places;

import java.io.IOException;

final class zzjs extends zzjq<zzjr, zzjr> {
    zzjs() {
    }

    private static void zzb(Object obj, zzjr zzjr) {
        ((zzgz) obj).zzsg = zzjr;
    }

    final /* synthetic */ void zzb(Object obj, int i, long j) {
        ((zzjr) obj).zzc(i << 3, Long.valueOf(j));
    }

    final /* synthetic */ void zzb(Object obj, int i, zzfr zzfr) {
        ((zzjr) obj).zzc((i << 3) | 2, zzfr);
    }

    final /* synthetic */ void zzb(Object obj, int i, Object obj2) {
        ((zzjr) obj).zzc((i << 3) | 3, (zzjr) obj2);
    }

    final /* synthetic */ void zzb(Object obj, zzkk zzkk) throws IOException {
        ((zzjr) obj).zzc(zzkk);
    }

    final boolean zzb(zzix zzix) {
        return false;
    }

    final /* synthetic */ void zzc(Object obj, int i, long j) {
        ((zzjr) obj).zzc((i << 3) | 1, Long.valueOf(j));
    }

    final void zzd(Object obj) {
        ((zzgz) obj).zzsg.zzbb();
    }

    final /* synthetic */ void zzd(Object obj, int i, int i2) {
        ((zzjr) obj).zzc((i << 3) | 5, Integer.valueOf(i2));
    }

    final /* synthetic */ void zzd(Object obj, zzkk zzkk) throws IOException {
        ((zzjr) obj).zzb(zzkk);
    }

    final /* synthetic */ void zzf(Object obj, Object obj2) {
        zzb(obj, (zzjr) obj2);
    }

    final /* synthetic */ void zzg(Object obj, Object obj2) {
        zzb(obj, (zzjr) obj2);
    }

    final /* synthetic */ Object zzgo() {
        return zzjr.zzgq();
    }

    final /* synthetic */ Object zzh(Object obj, Object obj2) {
        zzjr zzjr = (zzjr) obj;
        zzjr zzjr2 = (zzjr) obj2;
        return zzjr2.equals(zzjr.zzgp()) ? zzjr : zzjr.zzb(zzjr, zzjr2);
    }

    final /* synthetic */ Object zzk(Object obj) {
        zzjr zzjr = (zzjr) obj;
        zzjr.zzbb();
        return zzjr;
    }

    final /* synthetic */ int zzn(Object obj) {
        return ((zzjr) obj).zzdg();
    }

    final /* synthetic */ Object zzq(Object obj) {
        return ((zzgz) obj).zzsg;
    }

    final /* synthetic */ Object zzr(Object obj) {
        zzjr zzjr = ((zzgz) obj).zzsg;
        if (zzjr != zzjr.zzgp()) {
            return zzjr;
        }
        zzjr = zzjr.zzgq();
        zzb(obj, zzjr);
        return zzjr;
    }

    final /* synthetic */ int zzs(Object obj) {
        return ((zzjr) obj).zzgr();
    }
}
