package com.google.android.gms.internal.places;

import java.util.Arrays;

final class zzft implements zzfv {
    private zzft() {
    }

    public final byte[] zze(byte[] bArr, int i, int i2) {
        return Arrays.copyOfRange(bArr, i, i2 + i);
    }
}
