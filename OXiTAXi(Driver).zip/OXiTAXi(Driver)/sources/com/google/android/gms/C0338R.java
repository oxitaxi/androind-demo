package com.google.android.gms;

import com.oxitaxi_demo_driver.R;

/* renamed from: com.google.android.gms.R */
public final class C0338R {

    /* renamed from: com.google.android.gms.R$attr */
    public static final class attr {
        public static final int ambientEnabled = 2130903081;
        public static final int buttonSize = 2130903113;
        public static final int cameraBearing = 2130903118;
        public static final int cameraMaxZoomPreference = 2130903119;
        public static final int cameraMinZoomPreference = 2130903120;
        public static final int cameraTargetLat = 2130903121;
        public static final int cameraTargetLng = 2130903122;
        public static final int cameraTilt = 2130903123;
        public static final int cameraZoom = 2130903124;
        public static final int circleCrop = 2130903134;
        public static final int colorScheme = 2130903151;
        public static final int imageAspectRatio = 2130903233;
        public static final int imageAspectRatioAdjust = 2130903234;
        public static final int latLngBoundsNorthEastLatitude = 2130903246;
        public static final int latLngBoundsNorthEastLongitude = 2130903247;
        public static final int latLngBoundsSouthWestLatitude = 2130903248;
        public static final int latLngBoundsSouthWestLongitude = 2130903249;
        public static final int liteMode = 2130903273;
        public static final int mapType = 2130903276;
        public static final int scopeUris = 2130903321;
        public static final int uiCompass = 2130903420;
        public static final int uiMapToolbar = 2130903421;
        public static final int uiRotateGestures = 2130903422;
        public static final int uiScrollGestures = 2130903423;
        public static final int uiTiltGestures = 2130903424;
        public static final int uiZoomControls = 2130903425;
        public static final int uiZoomGestures = 2130903426;
        public static final int useViewLifecycle = 2130903428;
        public static final int zOrderOnTop = 2130903441;

        private attr() {
        }
    }

    /* renamed from: com.google.android.gms.R$color */
    public static final class color {
        public static final int common_google_signin_btn_text_dark = 2131034158;
        public static final int common_google_signin_btn_text_dark_default = 2131034159;
        public static final int common_google_signin_btn_text_dark_disabled = 2131034160;
        public static final int common_google_signin_btn_text_dark_focused = 2131034161;
        public static final int common_google_signin_btn_text_dark_pressed = 2131034162;
        public static final int common_google_signin_btn_text_light = 2131034163;
        public static final int common_google_signin_btn_text_light_default = 2131034164;
        public static final int common_google_signin_btn_text_light_disabled = 2131034165;
        public static final int common_google_signin_btn_text_light_focused = 2131034166;
        public static final int common_google_signin_btn_text_light_pressed = 2131034167;
        public static final int common_google_signin_btn_tint = 2131034168;
        public static final int place_autocomplete_prediction_primary_text = 2131034207;
        public static final int place_autocomplete_prediction_primary_text_highlight = 2131034208;
        public static final int place_autocomplete_prediction_secondary_text = 2131034209;
        public static final int place_autocomplete_search_hint = 2131034210;
        public static final int place_autocomplete_search_text = 2131034211;
        public static final int place_autocomplete_separator = 2131034212;

        private color() {
        }
    }

    /* renamed from: com.google.android.gms.R$dimen */
    public static final class dimen {
        public static final int place_autocomplete_button_padding = 2131099804;
        public static final int place_autocomplete_powered_by_google_height = 2131099805;
        public static final int place_autocomplete_powered_by_google_start = 2131099806;
        public static final int place_autocomplete_prediction_height = 2131099807;
        public static final int place_autocomplete_prediction_horizontal_margin = 2131099808;
        public static final int place_autocomplete_prediction_primary_text = 2131099809;
        public static final int place_autocomplete_prediction_secondary_text = 2131099810;
        public static final int place_autocomplete_progress_horizontal_margin = 2131099811;
        public static final int place_autocomplete_progress_size = 2131099812;
        public static final int place_autocomplete_separator_start = 2131099813;

        private dimen() {
        }
    }

    /* renamed from: com.google.android.gms.R$drawable */
    public static final class drawable {
        public static final int common_full_open_on_phone = 2131165281;
        public static final int common_google_signin_btn_icon_dark = 2131165282;
        public static final int common_google_signin_btn_icon_dark_focused = 2131165283;
        public static final int common_google_signin_btn_icon_dark_normal = 2131165284;
        public static final int common_google_signin_btn_icon_dark_normal_background = 2131165285;
        public static final int common_google_signin_btn_icon_disabled = 2131165286;
        public static final int common_google_signin_btn_icon_light = 2131165287;
        public static final int common_google_signin_btn_icon_light_focused = 2131165288;
        public static final int common_google_signin_btn_icon_light_normal = 2131165289;
        public static final int common_google_signin_btn_icon_light_normal_background = 2131165290;
        public static final int common_google_signin_btn_text_dark = 2131165291;
        public static final int common_google_signin_btn_text_dark_focused = 2131165292;
        public static final int common_google_signin_btn_text_dark_normal = 2131165293;
        public static final int common_google_signin_btn_text_dark_normal_background = 2131165294;
        public static final int common_google_signin_btn_text_disabled = 2131165295;
        public static final int common_google_signin_btn_text_light = 2131165296;
        public static final int common_google_signin_btn_text_light_focused = 2131165297;
        public static final int common_google_signin_btn_text_light_normal = 2131165298;
        public static final int common_google_signin_btn_text_light_normal_background = 2131165299;
        public static final int googleg_disabled_color_18 = 2131165311;
        public static final int googleg_standard_color_18 = 2131165312;
        public static final int places_ic_clear = 2131165373;
        public static final int places_ic_search = 2131165374;
        public static final int powered_by_google_dark = 2131165375;
        public static final int powered_by_google_light = 2131165376;

        private drawable() {
        }
    }

    /* renamed from: com.google.android.gms.R$id */
    public static final class id {
        public static final int adjust_height = 2131296283;
        public static final int adjust_width = 2131296284;
        public static final int auto = 2131296289;
        public static final int center = 2131296306;
        public static final int dark = 2131296333;
        public static final int hybrid = 2131296367;
        public static final int icon_only = 2131296370;
        public static final int light = 2131296387;
        public static final int none = 2131296412;
        public static final int normal = 2131296413;
        public static final int place_autocomplete_clear_button = 2131296422;
        public static final int place_autocomplete_powered_by_google = 2131296423;
        public static final int place_autocomplete_prediction_primary_text = 2131296424;
        public static final int place_autocomplete_prediction_secondary_text = 2131296425;
        public static final int place_autocomplete_progress = 2131296426;
        public static final int place_autocomplete_search_button = 2131296427;
        public static final int place_autocomplete_search_input = 2131296428;
        public static final int place_autocomplete_separator = 2131296429;
        public static final int radio = 2131296433;
        public static final int satellite = 2131296439;
        public static final int standard = 2131296473;
        public static final int terrain = 2131296483;
        public static final int text = 2131296484;
        public static final int text2 = 2131296485;
        public static final int toolbar = 2131296497;
        public static final int wide = 2131296537;
        public static final int wrap_content = 2131296539;

        private id() {
        }
    }

    /* renamed from: com.google.android.gms.R$integer */
    public static final class integer {
        public static final int google_play_services_version = 2131361799;

        private integer() {
        }
    }

    /* renamed from: com.google.android.gms.R$layout */
    public static final class layout {
        public static final int place_autocomplete_fragment = 2131427407;
        public static final int place_autocomplete_item_powered_by_google = 2131427408;
        public static final int place_autocomplete_item_prediction = 2131427409;
        public static final int place_autocomplete_progress = 2131427410;

        private layout() {
        }
    }

    /* renamed from: com.google.android.gms.R$string */
    public static final class string {
        public static final int common_google_play_services_enable_button = 2131689507;
        public static final int common_google_play_services_enable_text = 2131689508;
        public static final int common_google_play_services_enable_title = 2131689509;
        public static final int common_google_play_services_install_button = 2131689510;
        public static final int common_google_play_services_install_text = 2131689511;
        public static final int common_google_play_services_install_title = 2131689512;
        public static final int common_google_play_services_notification_channel_name = 2131689513;
        public static final int common_google_play_services_notification_ticker = 2131689514;
        public static final int common_google_play_services_unknown_issue = 2131689515;
        public static final int common_google_play_services_unsupported_text = 2131689516;
        public static final int common_google_play_services_update_button = 2131689517;
        public static final int common_google_play_services_update_text = 2131689518;
        public static final int common_google_play_services_update_title = 2131689519;
        public static final int common_google_play_services_updating_text = 2131689520;
        public static final int common_google_play_services_wear_update_text = 2131689521;
        public static final int common_open_on_phone = 2131689522;
        public static final int common_signin_button_text = 2131689523;
        public static final int common_signin_button_text_long = 2131689524;
        public static final int place_autocomplete_clear_button = 2131689552;
        public static final int place_autocomplete_search_hint = 2131689553;

        private string() {
        }
    }

    /* renamed from: com.google.android.gms.R$styleable */
    public static final class styleable {
        public static final int[] LoadingImageView = new int[]{R.attr.circleCrop, R.attr.imageAspectRatio, R.attr.imageAspectRatioAdjust};
        public static final int LoadingImageView_circleCrop = 0;
        public static final int LoadingImageView_imageAspectRatio = 1;
        public static final int LoadingImageView_imageAspectRatioAdjust = 2;
        public static final int[] MapAttrs = new int[]{R.attr.ambientEnabled, R.attr.cameraBearing, R.attr.cameraMaxZoomPreference, R.attr.cameraMinZoomPreference, R.attr.cameraTargetLat, R.attr.cameraTargetLng, R.attr.cameraTilt, R.attr.cameraZoom, R.attr.latLngBoundsNorthEastLatitude, R.attr.latLngBoundsNorthEastLongitude, R.attr.latLngBoundsSouthWestLatitude, R.attr.latLngBoundsSouthWestLongitude, R.attr.liteMode, R.attr.mapType, R.attr.uiCompass, R.attr.uiMapToolbar, R.attr.uiRotateGestures, R.attr.uiScrollGestures, R.attr.uiTiltGestures, R.attr.uiZoomControls, R.attr.uiZoomGestures, R.attr.useViewLifecycle, R.attr.zOrderOnTop};
        public static final int MapAttrs_ambientEnabled = 0;
        public static final int MapAttrs_cameraBearing = 1;
        public static final int MapAttrs_cameraMaxZoomPreference = 2;
        public static final int MapAttrs_cameraMinZoomPreference = 3;
        public static final int MapAttrs_cameraTargetLat = 4;
        public static final int MapAttrs_cameraTargetLng = 5;
        public static final int MapAttrs_cameraTilt = 6;
        public static final int MapAttrs_cameraZoom = 7;
        public static final int MapAttrs_latLngBoundsNorthEastLatitude = 8;
        public static final int MapAttrs_latLngBoundsNorthEastLongitude = 9;
        public static final int MapAttrs_latLngBoundsSouthWestLatitude = 10;
        public static final int MapAttrs_latLngBoundsSouthWestLongitude = 11;
        public static final int MapAttrs_liteMode = 12;
        public static final int MapAttrs_mapType = 13;
        public static final int MapAttrs_uiCompass = 14;
        public static final int MapAttrs_uiMapToolbar = 15;
        public static final int MapAttrs_uiRotateGestures = 16;
        public static final int MapAttrs_uiScrollGestures = 17;
        public static final int MapAttrs_uiTiltGestures = 18;
        public static final int MapAttrs_uiZoomControls = 19;
        public static final int MapAttrs_uiZoomGestures = 20;
        public static final int MapAttrs_useViewLifecycle = 21;
        public static final int MapAttrs_zOrderOnTop = 22;
        public static final int[] SignInButton = new int[]{R.attr.buttonSize, R.attr.colorScheme, R.attr.scopeUris};
        public static final int SignInButton_buttonSize = 0;
        public static final int SignInButton_colorScheme = 1;
        public static final int SignInButton_scopeUris = 2;

        private styleable() {
        }
    }

    private C0338R() {
    }
}
