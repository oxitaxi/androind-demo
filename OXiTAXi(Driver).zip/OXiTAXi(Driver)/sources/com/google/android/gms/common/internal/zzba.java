package com.google.android.gms.common.internal;

import android.os.IInterface;
import android.os.RemoteException;
import com.google.android.gms.common.zzn;
import com.google.android.gms.dynamic.IObjectWrapper;

@Hide
public interface zzba extends IInterface {
    boolean zza(zzn zzn, IObjectWrapper iObjectWrapper) throws RemoteException;
}
