package com.google.android.gms.common.util;

import android.os.Looper;

public final class zzy {
    public static boolean zzas() {
        return Looper.getMainLooper() == Looper.myLooper();
    }
}
