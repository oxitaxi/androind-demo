package com.google.android.gms.common.internal;

import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteException;

public interface zzaw extends IInterface {
    void zza(int i, Bundle bundle) throws RemoteException;

    void zza(int i, IBinder iBinder, Bundle bundle) throws RemoteException;
}
