package com.google.android.gms.common.internal;

import android.os.IInterface;
import android.os.RemoteException;
import com.google.android.gms.dynamic.IObjectWrapper;

@Hide
public interface zzbd extends IInterface {
    IObjectWrapper zza(IObjectWrapper iObjectWrapper, zzbv zzbv) throws RemoteException;
}
