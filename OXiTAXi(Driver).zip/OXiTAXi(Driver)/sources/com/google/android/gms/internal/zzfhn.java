package com.google.android.gms.internal;

abstract class zzfhn<T extends zzfhs<T>> {
    zzfhn() {
    }

    abstract zzfhq<T> zzcr(Object obj);

    abstract boolean zzh(Class<?> cls);
}
