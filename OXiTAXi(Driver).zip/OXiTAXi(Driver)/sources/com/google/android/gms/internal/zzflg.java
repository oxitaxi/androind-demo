package com.google.android.gms.internal;

import java.io.IOException;

enum zzflg extends zzfle {
    zzflg(String str, int i) {
        super(str, 1);
    }

    final Object zza(zzfhb zzfhb) throws IOException {
        return zzfhb.zzcye();
    }
}
