package com.google.android.gms.internal;

import com.google.android.gms.internal.zzfhu.zzd;

final class zzfho extends zzfhn<Object> {
    zzfho() {
    }

    final zzfhq<Object> zzcr(Object obj) {
        return ((zzd) obj).zzppp;
    }

    final boolean zzh(Class<?> cls) {
        return zzd.class.isAssignableFrom(cls);
    }
}
