package com.google.android.gms.internal;

final class zzfip extends zzfim {
    private zzfip() {
        super();
    }
}
