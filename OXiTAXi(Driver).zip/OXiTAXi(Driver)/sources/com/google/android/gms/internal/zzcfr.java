package com.google.android.gms.internal;

import android.os.DeadObjectException;
import android.os.IInterface;

final class zzcfr implements zzchr<zzcgw> {
    private /* synthetic */ zzcfq zzitl;

    zzcfr(zzcfq zzcfq) {
        this.zzitl = zzcfq;
    }

    public final void zzalv() {
        this.zzitl.zzalv();
    }

    public final /* synthetic */ IInterface zzalw() throws DeadObjectException {
        return (zzcgw) this.zzitl.zzalw();
    }
}
