package com.google.android.gms.internal;

import com.google.android.gms.common.api.Status;

final class zzbfm extends zzbfk {
    private /* synthetic */ zzbfl zzfqi;

    zzbfm(zzbfl zzbfl) {
        this.zzfqi = zzbfl;
        super();
    }

    public final void zzo(Status status) {
        this.zzfqi.setResult(status);
    }
}
