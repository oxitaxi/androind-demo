package com.google.android.gms.internal;

interface zzfli {
    void zzb(int i, Object obj);

    int zzcyz();
}
