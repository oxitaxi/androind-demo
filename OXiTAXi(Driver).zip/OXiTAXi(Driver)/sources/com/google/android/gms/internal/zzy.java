package com.google.android.gms.internal;

public interface zzy {
    void zzd(zzae zzae);
}
