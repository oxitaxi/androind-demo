package com.google.android.gms.internal;

import java.io.PrintStream;
import java.io.PrintWriter;

abstract class zzdyr {
    private static Throwable[] zzmmh = new Throwable[0];

    zzdyr() {
    }

    public abstract void zza(Throwable th, PrintStream printStream);

    public abstract void zza(Throwable th, PrintWriter printWriter);
}
