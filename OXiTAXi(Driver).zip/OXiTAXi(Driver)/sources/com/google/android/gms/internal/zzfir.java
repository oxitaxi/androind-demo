package com.google.android.gms.internal;

final class zzfir implements zzfjb {
    zzfir() {
    }

    public final boolean zzi(Class<?> cls) {
        return false;
    }

    public final zzfja zzj(Class<?> cls) {
        throw new IllegalStateException("This should never be called.");
    }
}
