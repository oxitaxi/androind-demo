package com.google.android.gms.internal;

public final class zzfif extends zzfie {
    public zzfif(String str) {
        super(str);
    }
}
