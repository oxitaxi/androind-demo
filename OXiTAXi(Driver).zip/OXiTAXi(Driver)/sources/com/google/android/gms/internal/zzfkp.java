package com.google.android.gms.internal;

final class zzfkp extends zzfkn<zzfko, zzfko> {
    zzfkp() {
    }

    final /* synthetic */ void zzb(Object obj, zzfli zzfli) {
        ((zzfko) obj).zza(zzfli);
    }

    final /* synthetic */ Object zzcu(Object obj) {
        return ((zzfhu) obj).zzpph;
    }

    final /* synthetic */ int zzcv(Object obj) {
        return ((zzfko) obj).zzdcc();
    }
}
