package com.google.android.gms.internal;

final class zzfiy implements zzfix {
    zzfiy() {
    }
}
