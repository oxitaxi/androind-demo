package com.google.android.gms.internal;

import java.nio.ByteBuffer;

final class zzfjg<T> implements zzfjv<T> {
    private final ByteBuffer buffer;

    static <T> zzfjg<T> zza(Class<T> cls, zzfja zzfja, zzfji zzfji, zzfim zzfim, zzfkn<?, ?> zzfkn, zzfhn<?> zzfhn, zzfix zzfix) {
        if (zzfja instanceof zzfjp) {
            throw new NoSuchMethodError();
        }
        zzfkg zzfkg = (zzfkg) zzfja;
        throw new NoSuchMethodError();
    }

    public final void zza(T t, zzfli zzfli) {
        throw new NoSuchMethodError();
    }

    public final int zzct(T t) {
        throw new NoSuchMethodError();
    }
}
