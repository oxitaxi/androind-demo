package com.google.android.gms.internal;

public interface zzm {
    zzp zzc(zzr<?> zzr) throws zzae;
}
