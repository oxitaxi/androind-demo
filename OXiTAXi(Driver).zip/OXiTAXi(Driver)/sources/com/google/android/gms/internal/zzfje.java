package com.google.android.gms.internal;

public interface zzfje {
    boolean isInitialized();

    zzfjc zzczu();
}
