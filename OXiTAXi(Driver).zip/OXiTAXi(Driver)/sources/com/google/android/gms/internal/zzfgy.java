package com.google.android.gms.internal;

abstract class zzfgy extends zzfgs {
    zzfgy() {
    }

    abstract boolean zza(zzfgs zzfgs, int i, int i2);

    protected final int zzcxr() {
        return 0;
    }

    protected final boolean zzcxs() {
        return true;
    }
}
