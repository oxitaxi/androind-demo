package com.google.android.gms.internal;

import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.data.zzd;
import com.google.android.gms.common.internal.Hide;
import com.google.android.gms.common.internal.zzbq;
import com.google.android.gms.location.places.PlacesStatusCodes;

@Hide
@Deprecated
public final class zzchx extends zzd<zzchw> implements Result {
    private final Status mStatus;

    @Hide
    public zzchx(DataHolder dataHolder) {
        this(dataHolder, PlacesStatusCodes.zzcm(dataHolder.getStatusCode()));
    }

    @Hide
    private zzchx(DataHolder dataHolder, Status status) {
        boolean z;
        super(dataHolder, zzchw.CREATOR);
        if (dataHolder != null) {
            if (dataHolder.getStatusCode() != status.getStatusCode()) {
                z = false;
                zzbq.checkArgument(z);
                this.mStatus = status;
            }
        }
        z = true;
        zzbq.checkArgument(z);
        this.mStatus = status;
    }

    public final Status getStatus() {
        return this.mStatus;
    }
}
