package com.google.android.gms.internal;

public interface zzb {
    void initialize();

    zzc zza(String str);

    void zza(String str, zzc zzc);
}
