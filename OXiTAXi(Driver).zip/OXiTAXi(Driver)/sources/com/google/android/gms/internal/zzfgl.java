package com.google.android.gms.internal;

public abstract class zzfgl implements zzfjc, Cloneable {
    private boolean zzpnq = true;
    private int zzpnr = -1;

    public /* synthetic */ Object clone() throws CloneNotSupportedException {
        throw new UnsupportedOperationException("clone() should be implemented by subclasses.");
    }
}
