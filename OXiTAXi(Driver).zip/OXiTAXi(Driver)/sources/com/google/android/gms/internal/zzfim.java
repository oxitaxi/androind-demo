package com.google.android.gms.internal;

class zzfim {
    private static final zzfim zzpqt = new zzfio();
    private static final zzfim zzpqu = new zzfip();

    private zzfim() {
    }

    static zzfim zzdaq() {
        return zzpqt;
    }

    static zzfim zzdar() {
        return zzpqu;
    }
}
