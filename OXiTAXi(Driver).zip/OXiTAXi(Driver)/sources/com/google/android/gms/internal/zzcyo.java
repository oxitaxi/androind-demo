package com.google.android.gms.internal;

import android.os.RemoteException;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.Status;

public class zzcyo extends zzcyq {
    public final void zza(ConnectionResult connectionResult, zzcym zzcym) throws RemoteException {
    }

    public final void zza(Status status, GoogleSignInAccount googleSignInAccount) throws RemoteException {
    }

    public final void zzas(Status status) throws RemoteException {
    }

    public final void zzat(Status status) throws RemoteException {
    }

    public void zzb(zzcyw zzcyw) throws RemoteException {
    }
}
