package com.google.android.gms.internal;

final class zzbfu {
    public final String zzfqn;
    public final long zzfqo;
    public final long zzfqp;

    public zzbfu(String str, long j, long j2) {
        this.zzfqn = str;
        this.zzfqo = j;
        this.zzfqp = j2;
    }
}
