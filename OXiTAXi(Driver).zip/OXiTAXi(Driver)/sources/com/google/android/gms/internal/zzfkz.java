package com.google.android.gms.internal;

enum zzfkz extends zzfky {
    zzfkz(String str, int i, zzfld zzfld, int i2) {
        super(str, 8, zzfld, 2);
    }
}
