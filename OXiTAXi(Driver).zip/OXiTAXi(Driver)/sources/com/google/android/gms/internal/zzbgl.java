package com.google.android.gms.internal;

public abstract class zzbgl implements zzbgp {
    public final int describeContents() {
        return 0;
    }
}
