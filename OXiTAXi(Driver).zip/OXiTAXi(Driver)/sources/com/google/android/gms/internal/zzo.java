package com.google.android.gms.internal;

public class zzo extends zzae {
    public zzo(Throwable th) {
        super(th);
    }
}
