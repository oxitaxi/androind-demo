package com.google.android.gms.internal;

import android.os.IInterface;
import android.os.RemoteException;

public interface zzbhb extends IInterface {
    void zzch(int i) throws RemoteException;
}
