package com.google.android.gms.internal;

public interface zzfic extends zzfid<Integer> {
    int getInt(int i);

    zzfic zzmk(int i);

    void zzml(int i);
}
