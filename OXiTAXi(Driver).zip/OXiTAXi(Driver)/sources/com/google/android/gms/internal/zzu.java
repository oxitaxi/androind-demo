package com.google.android.gms.internal;

public enum zzu {
    LOW,
    NORMAL,
    HIGH,
    IMMEDIATE
}
