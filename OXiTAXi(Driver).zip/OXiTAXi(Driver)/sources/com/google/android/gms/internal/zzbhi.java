package com.google.android.gms.internal;

import com.google.android.gms.common.internal.Hide;
import java.util.concurrent.ScheduledExecutorService;

@Hide
public interface zzbhi {
    ScheduledExecutorService newSingleThreadScheduledExecutor();
}
