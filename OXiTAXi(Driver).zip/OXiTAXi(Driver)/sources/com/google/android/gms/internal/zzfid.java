package com.google.android.gms.internal;

import java.util.List;
import java.util.RandomAccess;

public interface zzfid<E> extends List<E>, RandomAccess {
    void zzbkr();

    boolean zzcxk();

    zzfid<E> zzmo(int i);
}
