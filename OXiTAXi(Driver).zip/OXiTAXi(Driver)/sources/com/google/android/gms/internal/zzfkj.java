package com.google.android.gms.internal;

interface zzfkj {
    int size();

    byte zzld(int i);
}
