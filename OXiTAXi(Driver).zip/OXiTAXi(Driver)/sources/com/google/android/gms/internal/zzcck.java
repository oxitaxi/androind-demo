package com.google.android.gms.internal;

import com.google.android.gms.common.internal.Hide;
import java.util.ArrayList;
import java.util.Collection;

@Hide
public final class zzcck {
    private final Collection<zzcce> zzbkt = new ArrayList();
    private final Collection<zzccj> zzbku = new ArrayList();
    private final Collection<zzccj> zzbkv = new ArrayList();

    public final void zza(zzcce zzcce) {
        this.zzbkt.add(zzcce);
    }
}
