package com.google.android.gms.internal;

final class zzbfz extends zzbfx<Long> {
    zzbfz(String str, Long l) {
        super(str, l);
    }
}
