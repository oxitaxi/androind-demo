package com.google.android.gms.internal;

import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;

public class zzaj implements zzm {
    private static boolean DEBUG = zzaf.DEBUG;
    @Deprecated
    private zzar zzbo;
    private final zzai zzbp;
    private zzak zzbq;

    public zzaj(zzai zzai) {
        this(zzai, new zzak(4096));
    }

    private zzaj(zzai zzai, zzak zzak) {
        this.zzbp = zzai;
        this.zzbo = zzai;
        this.zzbq = zzak;
    }

    @Deprecated
    public zzaj(zzar zzar) {
        this(zzar, new zzak(4096));
    }

    @Deprecated
    private zzaj(zzar zzar, zzak zzak) {
        this.zzbo = zzar;
        this.zzbp = new zzah(zzar);
        this.zzbq = zzak;
    }

    private static List<zzl> zza(List<zzl> list, zzc zzc) {
        Set treeSet = new TreeSet(String.CASE_INSENSITIVE_ORDER);
        if (!list.isEmpty()) {
            for (zzl name : list) {
                treeSet.add(name.getName());
            }
        }
        List<zzl> arrayList = new ArrayList(list);
        if (zzc.zzg != null) {
            if (!zzc.zzg.isEmpty()) {
                for (zzl zzl : zzc.zzg) {
                    if (!treeSet.contains(zzl.getName())) {
                        arrayList.add(zzl);
                    }
                }
            }
        } else if (!zzc.zzf.isEmpty()) {
            for (Entry entry : zzc.zzf.entrySet()) {
                if (!treeSet.contains(entry.getKey())) {
                    arrayList.add(new zzl((String) entry.getKey(), (String) entry.getValue()));
                }
            }
        }
        return arrayList;
    }

    private static void zza(String str, zzr<?> zzr, zzae zzae) throws zzae {
        zzab zzi = zzr.zzi();
        int zzh = zzr.zzh();
        try {
            zzi.zza(zzae);
            zzr.zzb(String.format("%s-retry [timeout=%s]", new Object[]{str, Integer.valueOf(zzh)}));
        } catch (zzae zzae2) {
            zzr.zzb(String.format("%s-timeout-giveup [timeout=%s]", new Object[]{str, Integer.valueOf(zzh)}));
            throw zzae2;
        }
    }

    private final byte[] zza(java.io.InputStream r6, int r7) throws java.io.IOException, com.google.android.gms.internal.zzac {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1764696127.run(Unknown Source)
*/
        /*
        r5 = this;
        r0 = new com.google.android.gms.internal.zzau;
        r1 = r5.zzbq;
        r0.<init>(r1, r7);
        r7 = 0;
        r1 = 0;
        if (r6 == 0) goto L_0x003d;
    L_0x000b:
        r2 = r5.zzbq;	 Catch:{ all -> 0x0043 }
        r3 = 1024; // 0x400 float:1.435E-42 double:5.06E-321;	 Catch:{ all -> 0x0043 }
        r2 = r2.zzb(r3);	 Catch:{ all -> 0x0043 }
    L_0x0013:
        r1 = r6.read(r2);	 Catch:{ all -> 0x0038 }
        r3 = -1;	 Catch:{ all -> 0x0038 }
        if (r1 == r3) goto L_0x001e;	 Catch:{ all -> 0x0038 }
    L_0x001a:
        r0.write(r2, r7, r1);	 Catch:{ all -> 0x0038 }
        goto L_0x0013;	 Catch:{ all -> 0x0038 }
    L_0x001e:
        r1 = r0.toByteArray();	 Catch:{ all -> 0x0038 }
        if (r6 == 0) goto L_0x002f;
    L_0x0024:
        r6.close();	 Catch:{ IOException -> 0x0028 }
        goto L_0x002f;
    L_0x0028:
        r6 = "Error occurred when closing InputStream";
        r7 = new java.lang.Object[r7];
        com.google.android.gms.internal.zzaf.zza(r6, r7);
    L_0x002f:
        r6 = r5.zzbq;
        r6.zza(r2);
        r0.close();
        return r1;
    L_0x0038:
        r1 = move-exception;
        r4 = r2;
        r2 = r1;
        r1 = r4;
        goto L_0x0044;
    L_0x003d:
        r2 = new com.google.android.gms.internal.zzac;	 Catch:{ all -> 0x0043 }
        r2.<init>();	 Catch:{ all -> 0x0043 }
        throw r2;	 Catch:{ all -> 0x0043 }
    L_0x0043:
        r2 = move-exception;
    L_0x0044:
        if (r6 == 0) goto L_0x0051;
    L_0x0046:
        r6.close();	 Catch:{ IOException -> 0x004a }
        goto L_0x0051;
    L_0x004a:
        r6 = new java.lang.Object[r7];
        r7 = "Error occurred when closing InputStream";
        com.google.android.gms.internal.zzaf.zza(r7, r6);
    L_0x0051:
        r6 = r5.zzbq;
        r6.zza(r1);
        r0.close();
        throw r2;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzaj.zza(java.io.InputStream, int):byte[]");
    }

    public com.google.android.gms.internal.zzp zzc(com.google.android.gms.internal.zzr<?> r27) throws com.google.android.gms.internal.zzae {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1764696127.run(Unknown Source)
*/
        /*
        r26 = this;
        r1 = r26;
        r2 = r27;
        r3 = android.os.SystemClock.elapsedRealtime();
    L_0x0008:
        r5 = java.util.Collections.emptyList();
        r6 = 1;
        r7 = 2;
        r8 = 0;
        r9 = 0;
        r0 = r27.zze();	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x011a }
        if (r0 != 0) goto L_0x001b;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x011a }
    L_0x0016:
        r0 = java.util.Collections.emptyMap();	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x011a }
        goto L_0x003f;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x011a }
    L_0x001b:
        r10 = new java.util.HashMap;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x011a }
        r10.<init>();	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x011a }
        r11 = r0.zza;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x011a }
        if (r11 == 0) goto L_0x002b;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x011a }
    L_0x0024:
        r11 = "If-None-Match";	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x011a }
        r12 = r0.zza;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x011a }
        r10.put(r11, r12);	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x011a }
    L_0x002b:
        r11 = r0.zzc;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x011a }
        r13 = 0;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x011a }
        r15 = (r11 > r13 ? 1 : (r11 == r13 ? 0 : -1));	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x011a }
        if (r15 <= 0) goto L_0x003e;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x011a }
    L_0x0033:
        r11 = "If-Modified-Since";	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x011a }
        r12 = r0.zzc;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x011a }
        r0 = com.google.android.gms.internal.zzap.zzb(r12);	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x011a }
        r10.put(r11, r0);	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x011a }
    L_0x003e:
        r0 = r10;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x011a }
    L_0x003f:
        r10 = r1.zzbp;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x011a }
        r10 = r10.zza(r2, r0);	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x011a }
        r12 = r10.getStatusCode();	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0115 }
        r11 = r10.zzp();	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0115 }
        r0 = 304; // 0x130 float:4.26E-43 double:1.5E-321;
        if (r12 != r0) goto L_0x008d;
    L_0x0051:
        r0 = r27.zze();	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0087 }
        if (r0 != 0) goto L_0x006c;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0087 }
    L_0x0057:
        r0 = new com.google.android.gms.internal.zzp;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0087 }
        r14 = 304; // 0x130 float:4.26E-43 double:1.5E-321;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0087 }
        r15 = 0;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0087 }
        r16 = 1;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0087 }
        r12 = android.os.SystemClock.elapsedRealtime();	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0087 }
        r5 = 0;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0087 }
        r17 = r12 - r3;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0087 }
        r13 = r0;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0087 }
        r19 = r11;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0087 }
        r13.<init>(r14, r15, r16, r17, r19);	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0087 }
        return r0;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0087 }
    L_0x006c:
        r25 = zza(r11, r0);	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0087 }
        r5 = new com.google.android.gms.internal.zzp;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0087 }
        r20 = 304; // 0x130 float:4.26E-43 double:1.5E-321;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0087 }
        r0 = r0.data;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0087 }
        r22 = 1;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0087 }
        r12 = android.os.SystemClock.elapsedRealtime();	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0087 }
        r14 = 0;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0087 }
        r23 = r12 - r3;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0087 }
        r19 = r5;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0087 }
        r21 = r0;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0087 }
        r19.<init>(r20, r21, r22, r23, r25);	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0087 }
        return r5;
    L_0x0087:
        r0 = move-exception;
        r13 = r8;
    L_0x0089:
        r17 = r11;
        goto L_0x011f;
    L_0x008d:
        r0 = r10.getContent();	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x010e }
        if (r0 == 0) goto L_0x009c;
    L_0x0093:
        r5 = r10.getContentLength();	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0087 }
        r0 = r1.zza(r0, r5);	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0087 }
        goto L_0x009e;
    L_0x009c:
        r0 = new byte[r9];	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x010e }
    L_0x009e:
        r5 = r0;
        r13 = android.os.SystemClock.elapsedRealtime();	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0109 }
        r0 = 0;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0109 }
        r13 = r13 - r3;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0109 }
        r0 = DEBUG;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0109 }
        if (r0 != 0) goto L_0x00af;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0109 }
    L_0x00a9:
        r15 = 3000; // 0xbb8 float:4.204E-42 double:1.482E-320;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0109 }
        r0 = (r13 > r15 ? 1 : (r13 == r15 ? 0 : -1));	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0109 }
        if (r0 <= 0) goto L_0x00e4;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0109 }
    L_0x00af:
        r0 = "HTTP response for request=<%s> [lifetime=%d], [size=%s], [rc=%d], [retryCount=%s]";	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0109 }
        r8 = 5;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0109 }
        r8 = new java.lang.Object[r8];	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0109 }
        r8[r9] = r2;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0109 }
        r13 = java.lang.Long.valueOf(r13);	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0109 }
        r8[r6] = r13;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0109 }
        if (r5 == 0) goto L_0x00c7;
    L_0x00be:
        r13 = r5.length;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x00c4 }
        r13 = java.lang.Integer.valueOf(r13);	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x00c4 }
        goto L_0x00c9;
    L_0x00c4:
        r0 = move-exception;
        r13 = r5;
        goto L_0x0089;
    L_0x00c7:
        r13 = "null";	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0109 }
    L_0x00c9:
        r8[r7] = r13;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0109 }
        r13 = 3;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0109 }
        r14 = java.lang.Integer.valueOf(r12);	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0109 }
        r8[r13] = r14;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0109 }
        r13 = 4;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0109 }
        r14 = r27.zzi();	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0109 }
        r14 = r14.zzc();	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0109 }
        r14 = java.lang.Integer.valueOf(r14);	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0109 }
        r8[r13] = r14;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0109 }
        com.google.android.gms.internal.zzaf.zzb(r0, r8);	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0109 }
    L_0x00e4:
        r0 = 200; // 0xc8 float:2.8E-43 double:9.9E-322;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0109 }
        if (r12 < r0) goto L_0x00ff;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0109 }
    L_0x00e8:
        r0 = 299; // 0x12b float:4.19E-43 double:1.477E-321;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0109 }
        if (r12 > r0) goto L_0x00ff;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0109 }
    L_0x00ec:
        r0 = new com.google.android.gms.internal.zzp;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0109 }
        r14 = 0;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0109 }
        r15 = android.os.SystemClock.elapsedRealtime();	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0109 }
        r8 = 0;
        r15 = r15 - r3;
        r18 = r11;
        r11 = r0;
        r13 = r5;
        r17 = r18;
        r11.<init>(r12, r13, r14, r15, r17);	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0107 }
        return r0;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0107 }
    L_0x00ff:
        r18 = r11;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0107 }
        r0 = new java.io.IOException;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0107 }
        r0.<init>();	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0107 }
        throw r0;	 Catch:{ SocketTimeoutException -> 0x01af, MalformedURLException -> 0x018e, IOException -> 0x0107 }
    L_0x0107:
        r0 = move-exception;
        goto L_0x010c;
    L_0x0109:
        r0 = move-exception;
        r18 = r11;
    L_0x010c:
        r13 = r5;
        goto L_0x0112;
    L_0x010e:
        r0 = move-exception;
        r18 = r11;
        r13 = r8;
    L_0x0112:
        r17 = r18;
        goto L_0x011f;
    L_0x0115:
        r0 = move-exception;
        r17 = r5;
        r13 = r8;
        goto L_0x011f;
    L_0x011a:
        r0 = move-exception;
        r17 = r5;
        r10 = r8;
        r13 = r10;
    L_0x011f:
        if (r10 == 0) goto L_0x0188;
    L_0x0121:
        r0 = r10.getStatusCode();
        r5 = "Unexpected response code %d for %s";
        r7 = new java.lang.Object[r7];
        r8 = java.lang.Integer.valueOf(r0);
        r7[r9] = r8;
        r8 = r27.getUrl();
        r7[r6] = r8;
        com.google.android.gms.internal.zzaf.zzc(r5, r7);
        if (r13 == 0) goto L_0x0180;
    L_0x013a:
        r5 = new com.google.android.gms.internal.zzp;
        r14 = 0;
        r6 = android.os.SystemClock.elapsedRealtime();
        r15 = r6 - r3;
        r11 = r5;
        r12 = r0;
        r11.<init>(r12, r13, r14, r15, r17);
        r6 = 401; // 0x191 float:5.62E-43 double:1.98E-321;
        if (r0 == r6) goto L_0x0174;
    L_0x014c:
        r6 = 403; // 0x193 float:5.65E-43 double:1.99E-321;
        if (r0 != r6) goto L_0x0151;
    L_0x0150:
        goto L_0x0174;
    L_0x0151:
        r2 = 400; // 0x190 float:5.6E-43 double:1.976E-321;
        if (r0 < r2) goto L_0x0160;
    L_0x0155:
        r2 = 499; // 0x1f3 float:6.99E-43 double:2.465E-321;
        if (r0 <= r2) goto L_0x015a;
    L_0x0159:
        goto L_0x0160;
    L_0x015a:
        r0 = new com.google.android.gms.internal.zzg;
        r0.<init>(r5);
        throw r0;
    L_0x0160:
        r2 = 500; // 0x1f4 float:7.0E-43 double:2.47E-321;
        if (r0 < r2) goto L_0x016e;
    L_0x0164:
        r2 = 599; // 0x257 float:8.4E-43 double:2.96E-321;
        if (r0 > r2) goto L_0x016e;
    L_0x0168:
        r0 = new com.google.android.gms.internal.zzac;
        r0.<init>(r5);
        throw r0;
    L_0x016e:
        r0 = new com.google.android.gms.internal.zzac;
        r0.<init>(r5);
        throw r0;
    L_0x0174:
        r0 = "auth";
        r6 = new com.google.android.gms.internal.zza;
        r6.<init>(r5);
        zza(r0, r2, r6);
        goto L_0x0008;
    L_0x0180:
        r0 = "network";
        r5 = new com.google.android.gms.internal.zzo;
        r5.<init>();
        goto L_0x01b6;
    L_0x0188:
        r2 = new com.google.android.gms.internal.zzq;
        r2.<init>(r0);
        throw r2;
    L_0x018e:
        r0 = move-exception;
        r3 = new java.lang.RuntimeException;
        r4 = "Bad URL ";
        r2 = r27.getUrl();
        r2 = java.lang.String.valueOf(r2);
        r5 = r2.length();
        if (r5 == 0) goto L_0x01a6;
    L_0x01a1:
        r2 = r4.concat(r2);
        goto L_0x01ab;
    L_0x01a6:
        r2 = new java.lang.String;
        r2.<init>(r4);
    L_0x01ab:
        r3.<init>(r2, r0);
        throw r3;
    L_0x01af:
        r0 = "socket";
        r5 = new com.google.android.gms.internal.zzad;
        r5.<init>();
    L_0x01b6:
        zza(r0, r2, r5);
        goto L_0x0008;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzaj.zzc(com.google.android.gms.internal.zzr):com.google.android.gms.internal.zzp");
    }
}
