package com.google.android.gms.internal;

final class zzfkg implements zzfja {
    public final int zzdaz() {
        throw new NoSuchMethodError();
    }

    public final boolean zzdba() {
        throw new NoSuchMethodError();
    }

    public final zzfjc zzdbb() {
        throw new NoSuchMethodError();
    }
}
