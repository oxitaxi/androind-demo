package com.google.android.gms.internal;

final class zzfki implements zzfkj {
    private /* synthetic */ zzfgs zzpsv;

    zzfki(zzfgs zzfgs) {
        this.zzpsv = zzfgs;
    }

    public final int size() {
        return this.zzpsv.size();
    }

    public final byte zzld(int i) {
        return this.zzpsv.zzld(i);
    }
}
