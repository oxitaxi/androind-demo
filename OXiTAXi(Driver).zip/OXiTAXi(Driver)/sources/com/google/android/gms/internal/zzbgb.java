package com.google.android.gms.internal;

final class zzbgb extends zzbfx<Float> {
    zzbgb(String str, Float f) {
        super(str, f);
    }
}
