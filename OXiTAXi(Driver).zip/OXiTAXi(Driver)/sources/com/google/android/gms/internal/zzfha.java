package com.google.android.gms.internal;

final class zzfha implements zzfgw {
    private zzfha() {
    }

    public final byte[] zzg(byte[] bArr, int i, int i2) {
        Object obj = new byte[i2];
        System.arraycopy(bArr, i, obj, 0, i2);
        return obj;
    }
}
