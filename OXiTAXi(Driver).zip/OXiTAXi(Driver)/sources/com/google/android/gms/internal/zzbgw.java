package com.google.android.gms.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.Api.zzb;
import com.google.android.gms.common.api.GoogleApiClient;

final class zzbgw extends zzbgz {
    zzbgw(zzbgv zzbgv, GoogleApiClient googleApiClient) {
        super(googleApiClient);
    }

    protected final /* synthetic */ void zza(zzb zzb) throws RemoteException {
        ((zzbhd) ((zzbha) zzb).zzalw()).zza(new zzbgx(this));
    }
}
