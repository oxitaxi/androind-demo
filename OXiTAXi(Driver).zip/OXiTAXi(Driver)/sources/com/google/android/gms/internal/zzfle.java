package com.google.android.gms.internal;

import java.io.IOException;

enum zzfle {
    LOOSE,
    STRICT,
    LAZY;

    abstract Object zza(zzfhb zzfhb) throws IOException;
}
