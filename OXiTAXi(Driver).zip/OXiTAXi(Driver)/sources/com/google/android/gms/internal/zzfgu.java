package com.google.android.gms.internal;

import java.util.Arrays;

final class zzfgu implements zzfgw {
    private zzfgu() {
    }

    public final byte[] zzg(byte[] bArr, int i, int i2) {
        return Arrays.copyOfRange(bArr, i, i2 + i);
    }
}
