package com.google.android.gms.internal;

import android.content.Context;
import android.util.Log;
import com.bumptech.glide.load.Key;
import com.google.android.gms.clearcut.ClearcutLogger.zza;
import com.google.android.gms.phenotype.Phenotype;
import com.google.android.gms.phenotype.PhenotypeFlag;
import com.google.android.gms.phenotype.PhenotypeFlag.Factory;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Map;

public final class zzbft implements zza {
    private static final Charset UTF_8 = Charset.forName(Key.STRING_CHARSET_NAME);
    private static final Factory zzfqj = new Factory(Phenotype.getContentProviderUri("com.google.android.gms.clearcut.public")).withGservicePrefix("gms:playlog:service:sampling_").withPhenotypePrefix("LogSampling__");
    private static Map<String, PhenotypeFlag<String>> zzfqk = null;
    private static Boolean zzfql = null;
    private static Long zzfqm = null;
    private final Context zzaiq;

    public zzbft(Context context) {
        this.zzaiq = context;
        if (zzfqk == null) {
            zzfqk = new HashMap();
        }
        if (this.zzaiq != null) {
            PhenotypeFlag.maybeInit(this.zzaiq);
        }
    }

    private static boolean zzcc(Context context) {
        if (zzfql == null) {
            zzfql = Boolean.valueOf(zzbih.zzdd(context).checkCallingOrSelfPermission("com.google.android.providers.gsf.permission.READ_GSERVICES") == 0);
        }
        return zzfql.booleanValue();
    }

    private static zzbfu zzge(String str) {
        if (str == null) {
            return null;
        }
        String str2 = "";
        int indexOf = str.indexOf(44);
        int i = 0;
        if (indexOf >= 0) {
            str2 = str.substring(0, indexOf);
            i = indexOf + 1;
        }
        String str3 = str2;
        int indexOf2 = str.indexOf(47, i);
        if (indexOf2 <= 0) {
            str2 = "LogSamplerImpl";
            String str4 = "Failed to parse the rule: ";
            str = String.valueOf(str);
            Log.e(str2, str.length() != 0 ? str4.concat(str) : new String(str4));
            return null;
        }
        try {
            long parseLong = Long.parseLong(str.substring(i, indexOf2));
            long parseLong2 = Long.parseLong(str.substring(indexOf2 + 1));
            if (parseLong >= 0) {
                if (parseLong2 >= 0) {
                    return new zzbfu(str3, parseLong, parseLong2);
                }
            }
            StringBuilder stringBuilder = new StringBuilder(72);
            stringBuilder.append("negative values not supported: ");
            stringBuilder.append(parseLong);
            stringBuilder.append("/");
            stringBuilder.append(parseLong2);
            Log.e("LogSamplerImpl", stringBuilder.toString());
            return null;
        } catch (Throwable e) {
            str4 = "LogSamplerImpl";
            String str5 = "parseLong() failed while parsing: ";
            str = String.valueOf(str);
            Log.e(str4, str.length() != 0 ? str5.concat(str) : new String(str5), e);
            return null;
        }
    }

    public final boolean zzg(String str, int i) {
        String str2 = null;
        if (str == null || str.isEmpty()) {
            str = i >= 0 ? String.valueOf(i) : null;
        }
        if (str == null) {
            return true;
        }
        if (this.zzaiq != null) {
            if (zzcc(this.zzaiq)) {
                PhenotypeFlag phenotypeFlag = (PhenotypeFlag) zzfqk.get(str);
                if (phenotypeFlag == null) {
                    phenotypeFlag = zzfqj.createFlag(str, null);
                    zzfqk.put(str, phenotypeFlag);
                }
                str2 = (String) phenotypeFlag.get();
            }
        }
        zzbfu zzge = zzge(str2);
        if (zzge == null) {
            return true;
        }
        long j;
        byte[] bytes;
        long zzi;
        long j2;
        long j3;
        StringBuilder stringBuilder;
        str2 = zzge.zzfqn;
        Context context = this.zzaiq;
        if (zzfqm == null) {
            if (context != null) {
                zzfqm = zzcc(context) ? Long.valueOf(zzdnm.getLong(context.getContentResolver(), "android_id", 0)) : Long.valueOf(0);
            } else {
                j = 0;
                if (str2 != null) {
                    if (str2.isEmpty()) {
                        bytes = str2.getBytes(UTF_8);
                        ByteBuffer allocate = ByteBuffer.allocate(bytes.length + 8);
                        allocate.put(bytes);
                        allocate.putLong(j);
                        bytes = allocate.array();
                        zzi = zzbfo.zzi(bytes);
                        j2 = zzge.zzfqo;
                        j3 = zzge.zzfqp;
                        if (j2 >= 0 || j3 < 0) {
                            stringBuilder = new StringBuilder(72);
                            stringBuilder.append("negative values not supported: ");
                            stringBuilder.append(j2);
                            stringBuilder.append("/");
                            stringBuilder.append(j3);
                            throw new IllegalArgumentException(stringBuilder.toString());
                        }
                        if (j3 > 0) {
                            if ((zzi >= 0 ? zzi % j3 : (((Long.MAX_VALUE % j3) + 1) + ((zzi & Long.MAX_VALUE) % j3)) % j3) < j2) {
                                return true;
                            }
                        }
                        return false;
                    }
                }
                bytes = ByteBuffer.allocate(8).putLong(j).array();
                zzi = zzbfo.zzi(bytes);
                j2 = zzge.zzfqo;
                j3 = zzge.zzfqp;
                if (j2 >= 0) {
                }
                stringBuilder = new StringBuilder(72);
                stringBuilder.append("negative values not supported: ");
                stringBuilder.append(j2);
                stringBuilder.append("/");
                stringBuilder.append(j3);
                throw new IllegalArgumentException(stringBuilder.toString());
            }
        }
        j = zzfqm.longValue();
        if (str2 != null) {
            if (str2.isEmpty()) {
                bytes = str2.getBytes(UTF_8);
                ByteBuffer allocate2 = ByteBuffer.allocate(bytes.length + 8);
                allocate2.put(bytes);
                allocate2.putLong(j);
                bytes = allocate2.array();
                zzi = zzbfo.zzi(bytes);
                j2 = zzge.zzfqo;
                j3 = zzge.zzfqp;
                if (j2 >= 0) {
                }
                stringBuilder = new StringBuilder(72);
                stringBuilder.append("negative values not supported: ");
                stringBuilder.append(j2);
                stringBuilder.append("/");
                stringBuilder.append(j3);
                throw new IllegalArgumentException(stringBuilder.toString());
            }
        }
        bytes = ByteBuffer.allocate(8).putLong(j).array();
        zzi = zzbfo.zzi(bytes);
        j2 = zzge.zzfqo;
        j3 = zzge.zzfqp;
        if (j2 >= 0) {
        }
        stringBuilder = new StringBuilder(72);
        stringBuilder.append("negative values not supported: ");
        stringBuilder.append(j2);
        stringBuilder.append("/");
        stringBuilder.append(j3);
        throw new IllegalArgumentException(stringBuilder.toString());
    }
}
