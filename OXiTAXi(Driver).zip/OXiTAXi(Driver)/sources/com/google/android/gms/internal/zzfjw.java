package com.google.android.gms.internal;

interface zzfjw {
    <T> zzfjv<T> zzk(Class<T> cls);
}
