package com.google.android.gms.internal;

import android.os.IInterface;
import android.os.RemoteException;
import com.google.android.gms.clearcut.zze;

public interface zzbfr extends IInterface {
    void zza(zzbfp zzbfp, zze zze) throws RemoteException;
}
