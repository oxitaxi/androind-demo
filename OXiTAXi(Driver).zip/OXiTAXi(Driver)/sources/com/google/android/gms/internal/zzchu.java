package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.Hide;
import com.google.android.gms.common.internal.zzbg;
import java.util.Arrays;

@Hide
@Deprecated
public final class zzchu extends zzbgl {
    public static final Creator<zzchu> CREATOR = new zzchv();
    private static zzchu zzizc = new zzchu("Home");
    private static zzchu zzizd = new zzchu("Work");
    private final String zzize;

    zzchu(String str) {
        this.zzize = str;
    }

    @Hide
    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof zzchu)) {
            return false;
        }
        return zzbg.equal(this.zzize, ((zzchu) obj).zzize);
    }

    @Hide
    public final int hashCode() {
        return Arrays.hashCode(new Object[]{this.zzize});
    }

    @Hide
    public final String toString() {
        return zzbg.zzx(this).zzg("alias", this.zzize).toString();
    }

    @Hide
    public final void writeToParcel(Parcel parcel, int i) {
        i = zzbgo.zze(parcel);
        zzbgo.zza(parcel, 1, this.zzize, false);
        zzbgo.zzai(parcel, i);
    }
}
