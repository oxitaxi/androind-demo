package com.google.android.gms.internal;

enum zzflb extends zzfky {
    zzflb(String str, int i, zzfld zzfld, int i2) {
        super(str, 10, zzfld, 2);
    }
}
