package com.google.android.gms.internal;

public class zzac extends zzae {
    public zzac(zzp zzp) {
        super(zzp);
    }
}
