package com.google.android.gms.internal;

final class zzcza implements Runnable {
    private /* synthetic */ zzcyz zzkmj;

    zzcza(zzcyz zzcyz) {
        this.zzkmj = zzcyz;
    }

    public final void run() {
        this.zzkmj.zzew(0);
    }
}
