package com.google.android.gms.internal;

import android.os.RemoteException;

public class zzbgr extends zzbhc {
    public void zzch(int i) throws RemoteException {
    }
}
