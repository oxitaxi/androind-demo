package com.google.android.gms.internal;

import java.io.IOException;
import java.util.Arrays;

public final class zzfmr extends zzflm<zzfmr> implements Cloneable {
    private String tag;
    private int zzaky;
    private boolean zznet;
    private zzfmt zzorb;
    public long zzpyu;
    public long zzpyv;
    private long zzpyw;
    private int zzpyx;
    private zzfms[] zzpyy;
    private byte[] zzpyz;
    private zzfmp zzpza;
    public byte[] zzpzb;
    private String zzpzc;
    private String zzpzd;
    private zzfmo zzpze;
    private String zzpzf;
    public long zzpzg;
    private zzfmq zzpzh;
    public byte[] zzpzi;
    private String zzpzj;
    private int zzpzk;
    private int[] zzpzl;
    private long zzpzm;
    private boolean zzpzn;

    public zzfmr() {
        this.zzpyu = 0;
        this.zzpyv = 0;
        this.zzpyw = 0;
        this.tag = "";
        this.zzpyx = 0;
        this.zzaky = 0;
        this.zznet = false;
        this.zzpyy = zzfms.zzddf();
        this.zzpyz = zzflv.zzpwe;
        this.zzpza = null;
        this.zzpzb = zzflv.zzpwe;
        this.zzpzc = "";
        this.zzpzd = "";
        this.zzpze = null;
        this.zzpzf = "";
        this.zzpzg = 180000;
        this.zzpzh = null;
        this.zzpzi = zzflv.zzpwe;
        this.zzpzj = "";
        this.zzpzk = 0;
        this.zzpzl = zzflv.zzpvy;
        this.zzpzm = 0;
        this.zzorb = null;
        this.zzpzn = false;
        this.zzpvl = null;
        this.zzpnr = -1;
    }

    private final com.google.android.gms.internal.zzfmr zzbn(com.google.android.gms.internal.zzflj r7) throws java.io.IOException {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1764696127.run(Unknown Source)
*/
        /*
        r6 = this;
    L_0x0000:
        r0 = r7.zzcxx();
        r1 = 0;
        switch(r0) {
            case 0: goto L_0x01b6;
            case 8: goto L_0x01ae;
            case 18: goto L_0x01a6;
            case 26: goto L_0x0166;
            case 34: goto L_0x015e;
            case 50: goto L_0x0156;
            case 58: goto L_0x0144;
            case 66: goto L_0x013c;
            case 74: goto L_0x012e;
            case 80: goto L_0x0126;
            case 88: goto L_0x011e;
            case 96: goto L_0x0116;
            case 106: goto L_0x010e;
            case 114: goto L_0x0106;
            case 120: goto L_0x00fe;
            case 130: goto L_0x00f0;
            case 136: goto L_0x00e8;
            case 146: goto L_0x00e0;
            case 152: goto L_0x00af;
            case 160: goto L_0x007b;
            case 162: goto L_0x003a;
            case 168: goto L_0x0033;
            case 176: goto L_0x002c;
            case 186: goto L_0x001d;
            case 194: goto L_0x0016;
            case 200: goto L_0x000f;
            default: goto L_0x0008;
        };
    L_0x0008:
        r0 = super.zza(r7, r0);
        if (r0 != 0) goto L_0x0000;
    L_0x000e:
        return r6;
    L_0x000f:
        r0 = r7.zzcyd();
        r6.zzpzn = r0;
        goto L_0x0000;
    L_0x0016:
        r0 = r7.readString();
        r6.zzpzj = r0;
        goto L_0x0000;
    L_0x001d:
        r0 = r6.zzorb;
        if (r0 != 0) goto L_0x0028;
    L_0x0021:
        r0 = new com.google.android.gms.internal.zzfmt;
        r0.<init>();
        r6.zzorb = r0;
    L_0x0028:
        r0 = r6.zzorb;
        goto L_0x0151;
    L_0x002c:
        r0 = r7.zzcxz();
        r6.zzpzm = r0;
        goto L_0x0000;
    L_0x0033:
        r0 = r7.zzcxz();
        r6.zzpyw = r0;
        goto L_0x0000;
    L_0x003a:
        r0 = r7.zzcym();
        r0 = r7.zzli(r0);
        r2 = r7.getPosition();
        r3 = 0;
    L_0x0047:
        r4 = r7.zzcyo();
        if (r4 <= 0) goto L_0x0053;
    L_0x004d:
        r7.zzcya();
        r3 = r3 + 1;
        goto L_0x0047;
    L_0x0053:
        r7.zzmw(r2);
        r2 = r6.zzpzl;
        if (r2 != 0) goto L_0x005c;
    L_0x005a:
        r2 = 0;
        goto L_0x005f;
    L_0x005c:
        r2 = r6.zzpzl;
        r2 = r2.length;
    L_0x005f:
        r3 = r3 + r2;
        r3 = new int[r3];
        if (r2 == 0) goto L_0x0069;
    L_0x0064:
        r4 = r6.zzpzl;
        java.lang.System.arraycopy(r4, r1, r3, r1, r2);
    L_0x0069:
        r1 = r3.length;
        if (r2 >= r1) goto L_0x0075;
    L_0x006c:
        r1 = r7.zzcya();
        r3[r2] = r1;
        r2 = r2 + 1;
        goto L_0x0069;
    L_0x0075:
        r6.zzpzl = r3;
        r7.zzlj(r0);
        goto L_0x0000;
    L_0x007b:
        r0 = 160; // 0xa0 float:2.24E-43 double:7.9E-322;
        r0 = com.google.android.gms.internal.zzflv.zzb(r7, r0);
        r2 = r6.zzpzl;
        if (r2 != 0) goto L_0x0087;
    L_0x0085:
        r2 = 0;
        goto L_0x008a;
    L_0x0087:
        r2 = r6.zzpzl;
        r2 = r2.length;
    L_0x008a:
        r0 = r0 + r2;
        r0 = new int[r0];
        if (r2 == 0) goto L_0x0094;
    L_0x008f:
        r3 = r6.zzpzl;
        java.lang.System.arraycopy(r3, r1, r0, r1, r2);
    L_0x0094:
        r1 = r0.length;
        r1 = r1 + -1;
        if (r2 >= r1) goto L_0x00a5;
    L_0x0099:
        r1 = r7.zzcya();
        r0[r2] = r1;
        r7.zzcxx();
        r2 = r2 + 1;
        goto L_0x0094;
    L_0x00a5:
        r1 = r7.zzcya();
        r0[r2] = r1;
        r6.zzpzl = r0;
        goto L_0x0000;
    L_0x00af:
        r1 = r7.getPosition();
        r2 = r7.zzcya();	 Catch:{ IllegalArgumentException -> 0x00d8 }
        switch(r2) {
            case 0: goto L_0x00bd;
            case 1: goto L_0x00bd;
            case 2: goto L_0x00bd;
            default: goto L_0x00ba;
        };	 Catch:{ IllegalArgumentException -> 0x00d8 }
    L_0x00ba:
        r3 = new java.lang.IllegalArgumentException;	 Catch:{ IllegalArgumentException -> 0x00d8 }
        goto L_0x00c1;	 Catch:{ IllegalArgumentException -> 0x00d8 }
    L_0x00bd:
        r6.zzpzk = r2;	 Catch:{ IllegalArgumentException -> 0x00d8 }
        goto L_0x0000;	 Catch:{ IllegalArgumentException -> 0x00d8 }
    L_0x00c1:
        r4 = 45;	 Catch:{ IllegalArgumentException -> 0x00d8 }
        r5 = new java.lang.StringBuilder;	 Catch:{ IllegalArgumentException -> 0x00d8 }
        r5.<init>(r4);	 Catch:{ IllegalArgumentException -> 0x00d8 }
        r5.append(r2);	 Catch:{ IllegalArgumentException -> 0x00d8 }
        r2 = " is not a valid enum InternalEvent";	 Catch:{ IllegalArgumentException -> 0x00d8 }
        r5.append(r2);	 Catch:{ IllegalArgumentException -> 0x00d8 }
        r2 = r5.toString();	 Catch:{ IllegalArgumentException -> 0x00d8 }
        r3.<init>(r2);	 Catch:{ IllegalArgumentException -> 0x00d8 }
        throw r3;	 Catch:{ IllegalArgumentException -> 0x00d8 }
    L_0x00d8:
        r7.zzmw(r1);
        r6.zza(r7, r0);
        goto L_0x0000;
    L_0x00e0:
        r0 = r7.readBytes();
        r6.zzpzi = r0;
        goto L_0x0000;
    L_0x00e8:
        r0 = r7.zzcxz();
        r6.zzpyv = r0;
        goto L_0x0000;
    L_0x00f0:
        r0 = r6.zzpzh;
        if (r0 != 0) goto L_0x00fb;
    L_0x00f4:
        r0 = new com.google.android.gms.internal.zzfmq;
        r0.<init>();
        r6.zzpzh = r0;
    L_0x00fb:
        r0 = r6.zzpzh;
        goto L_0x0151;
    L_0x00fe:
        r0 = r7.zzcyl();
        r6.zzpzg = r0;
        goto L_0x0000;
    L_0x0106:
        r0 = r7.readString();
        r6.zzpzf = r0;
        goto L_0x0000;
    L_0x010e:
        r0 = r7.readString();
        r6.zzpzd = r0;
        goto L_0x0000;
    L_0x0116:
        r0 = r7.zzcya();
        r6.zzaky = r0;
        goto L_0x0000;
    L_0x011e:
        r0 = r7.zzcya();
        r6.zzpyx = r0;
        goto L_0x0000;
    L_0x0126:
        r0 = r7.zzcyd();
        r6.zznet = r0;
        goto L_0x0000;
    L_0x012e:
        r0 = r6.zzpza;
        if (r0 != 0) goto L_0x0139;
    L_0x0132:
        r0 = new com.google.android.gms.internal.zzfmp;
        r0.<init>();
        r6.zzpza = r0;
    L_0x0139:
        r0 = r6.zzpza;
        goto L_0x0151;
    L_0x013c:
        r0 = r7.readString();
        r6.zzpzc = r0;
        goto L_0x0000;
    L_0x0144:
        r0 = r6.zzpze;
        if (r0 != 0) goto L_0x014f;
    L_0x0148:
        r0 = new com.google.android.gms.internal.zzfmo;
        r0.<init>();
        r6.zzpze = r0;
    L_0x014f:
        r0 = r6.zzpze;
    L_0x0151:
        r7.zza(r0);
        goto L_0x0000;
    L_0x0156:
        r0 = r7.readBytes();
        r6.zzpzb = r0;
        goto L_0x0000;
    L_0x015e:
        r0 = r7.readBytes();
        r6.zzpyz = r0;
        goto L_0x0000;
    L_0x0166:
        r0 = 26;
        r0 = com.google.android.gms.internal.zzflv.zzb(r7, r0);
        r2 = r6.zzpyy;
        if (r2 != 0) goto L_0x0172;
    L_0x0170:
        r2 = 0;
        goto L_0x0175;
    L_0x0172:
        r2 = r6.zzpyy;
        r2 = r2.length;
    L_0x0175:
        r0 = r0 + r2;
        r0 = new com.google.android.gms.internal.zzfms[r0];
        if (r2 == 0) goto L_0x017f;
    L_0x017a:
        r3 = r6.zzpyy;
        java.lang.System.arraycopy(r3, r1, r0, r1, r2);
    L_0x017f:
        r1 = r0.length;
        r1 = r1 + -1;
        if (r2 >= r1) goto L_0x0196;
    L_0x0184:
        r1 = new com.google.android.gms.internal.zzfms;
        r1.<init>();
        r0[r2] = r1;
        r1 = r0[r2];
        r7.zza(r1);
        r7.zzcxx();
        r2 = r2 + 1;
        goto L_0x017f;
    L_0x0196:
        r1 = new com.google.android.gms.internal.zzfms;
        r1.<init>();
        r0[r2] = r1;
        r1 = r0[r2];
        r7.zza(r1);
        r6.zzpyy = r0;
        goto L_0x0000;
    L_0x01a6:
        r0 = r7.readString();
        r6.tag = r0;
        goto L_0x0000;
    L_0x01ae:
        r0 = r7.zzcxz();
        r6.zzpyu = r0;
        goto L_0x0000;
    L_0x01b6:
        return r6;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzfmr.zzbn(com.google.android.gms.internal.zzflj):com.google.android.gms.internal.zzfmr");
    }

    private final zzfmr zzdde() {
        try {
            zzfmr zzfmr = (zzfmr) super.zzdck();
            if (this.zzpyy != null && this.zzpyy.length > 0) {
                zzfmr.zzpyy = new zzfms[this.zzpyy.length];
                for (int i = 0; i < this.zzpyy.length; i++) {
                    if (this.zzpyy[i] != null) {
                        zzfmr.zzpyy[i] = (zzfms) this.zzpyy[i].clone();
                    }
                }
            }
            if (this.zzpza != null) {
                zzfmr.zzpza = (zzfmp) this.zzpza.clone();
            }
            if (this.zzpze != null) {
                zzfmr.zzpze = (zzfmo) this.zzpze.clone();
            }
            if (this.zzpzh != null) {
                zzfmr.zzpzh = (zzfmq) this.zzpzh.clone();
            }
            if (this.zzpzl != null && this.zzpzl.length > 0) {
                zzfmr.zzpzl = (int[]) this.zzpzl.clone();
            }
            if (this.zzorb != null) {
                zzfmr.zzorb = (zzfmt) this.zzorb.clone();
            }
            return zzfmr;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError(e);
        }
    }

    public final /* synthetic */ Object clone() throws CloneNotSupportedException {
        return zzdde();
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof zzfmr)) {
            return false;
        }
        zzfmr zzfmr = (zzfmr) obj;
        if (this.zzpyu != zzfmr.zzpyu || this.zzpyv != zzfmr.zzpyv || this.zzpyw != zzfmr.zzpyw) {
            return false;
        }
        if (this.tag == null) {
            if (zzfmr.tag != null) {
                return false;
            }
        } else if (!this.tag.equals(zzfmr.tag)) {
            return false;
        }
        if (this.zzpyx != zzfmr.zzpyx || this.zzaky != zzfmr.zzaky || this.zznet != zzfmr.zznet || !zzflq.equals(this.zzpyy, zzfmr.zzpyy) || !Arrays.equals(this.zzpyz, zzfmr.zzpyz)) {
            return false;
        }
        if (this.zzpza == null) {
            if (zzfmr.zzpza != null) {
                return false;
            }
        } else if (!this.zzpza.equals(zzfmr.zzpza)) {
            return false;
        }
        if (!Arrays.equals(this.zzpzb, zzfmr.zzpzb)) {
            return false;
        }
        if (this.zzpzc == null) {
            if (zzfmr.zzpzc != null) {
                return false;
            }
        } else if (!this.zzpzc.equals(zzfmr.zzpzc)) {
            return false;
        }
        if (this.zzpzd == null) {
            if (zzfmr.zzpzd != null) {
                return false;
            }
        } else if (!this.zzpzd.equals(zzfmr.zzpzd)) {
            return false;
        }
        if (this.zzpze == null) {
            if (zzfmr.zzpze != null) {
                return false;
            }
        } else if (!this.zzpze.equals(zzfmr.zzpze)) {
            return false;
        }
        if (this.zzpzf == null) {
            if (zzfmr.zzpzf != null) {
                return false;
            }
        } else if (!this.zzpzf.equals(zzfmr.zzpzf)) {
            return false;
        }
        if (this.zzpzg != zzfmr.zzpzg) {
            return false;
        }
        if (this.zzpzh == null) {
            if (zzfmr.zzpzh != null) {
                return false;
            }
        } else if (!this.zzpzh.equals(zzfmr.zzpzh)) {
            return false;
        }
        if (!Arrays.equals(this.zzpzi, zzfmr.zzpzi)) {
            return false;
        }
        if (this.zzpzj == null) {
            if (zzfmr.zzpzj != null) {
                return false;
            }
        } else if (!this.zzpzj.equals(zzfmr.zzpzj)) {
            return false;
        }
        if (this.zzpzk != zzfmr.zzpzk || !zzflq.equals(this.zzpzl, zzfmr.zzpzl) || this.zzpzm != zzfmr.zzpzm) {
            return false;
        }
        if (this.zzorb == null) {
            if (zzfmr.zzorb != null) {
                return false;
            }
        } else if (!this.zzorb.equals(zzfmr.zzorb)) {
            return false;
        }
        if (this.zzpzn != zzfmr.zzpzn) {
            return false;
        }
        if (this.zzpvl != null) {
            if (!this.zzpvl.isEmpty()) {
                return this.zzpvl.equals(zzfmr.zzpvl);
            }
        }
        if (zzfmr.zzpvl != null) {
            if (!zzfmr.zzpvl.isEmpty()) {
                return false;
            }
        }
        return true;
    }

    public final int hashCode() {
        int i = 0;
        int i2 = 1237;
        int hashCode = ((((((((((((((((((getClass().getName().hashCode() + 527) * 31) + ((int) (this.zzpyu ^ (this.zzpyu >>> 32)))) * 31) + ((int) (this.zzpyv ^ (this.zzpyv >>> 32)))) * 31) + ((int) (this.zzpyw ^ (this.zzpyw >>> 32)))) * 31) + (this.tag == null ? 0 : this.tag.hashCode())) * 31) + this.zzpyx) * 31) + this.zzaky) * 31) + (this.zznet ? 1231 : 1237)) * 31) + zzflq.hashCode(this.zzpyy)) * 31) + Arrays.hashCode(this.zzpyz);
        zzfmp zzfmp = this.zzpza;
        hashCode = (((((((hashCode * 31) + (zzfmp == null ? 0 : zzfmp.hashCode())) * 31) + Arrays.hashCode(this.zzpzb)) * 31) + (this.zzpzc == null ? 0 : this.zzpzc.hashCode())) * 31) + (this.zzpzd == null ? 0 : this.zzpzd.hashCode());
        zzfmo zzfmo = this.zzpze;
        hashCode = (((((hashCode * 31) + (zzfmo == null ? 0 : zzfmo.hashCode())) * 31) + (this.zzpzf == null ? 0 : this.zzpzf.hashCode())) * 31) + ((int) (this.zzpzg ^ (this.zzpzg >>> 32)));
        zzfmq zzfmq = this.zzpzh;
        hashCode = (((((((((((hashCode * 31) + (zzfmq == null ? 0 : zzfmq.hashCode())) * 31) + Arrays.hashCode(this.zzpzi)) * 31) + (this.zzpzj == null ? 0 : this.zzpzj.hashCode())) * 31) + this.zzpzk) * 31) + zzflq.hashCode(this.zzpzl)) * 31) + ((int) (this.zzpzm ^ (this.zzpzm >>> 32)));
        zzfmt zzfmt = this.zzorb;
        hashCode = ((hashCode * 31) + (zzfmt == null ? 0 : zzfmt.hashCode())) * 31;
        if (this.zzpzn) {
            i2 = 1231;
        }
        hashCode = (hashCode + i2) * 31;
        if (this.zzpvl != null) {
            if (!this.zzpvl.isEmpty()) {
                i = this.zzpvl.hashCode();
            }
        }
        return hashCode + i;
    }

    public final /* synthetic */ zzfls zza(zzflj zzflj) throws IOException {
        return zzbn(zzflj);
    }

    public final void zza(zzflk zzflk) throws IOException {
        if (this.zzpyu != 0) {
            zzflk.zzf(1, this.zzpyu);
        }
        if (!(this.tag == null || this.tag.equals(""))) {
            zzflk.zzp(2, this.tag);
        }
        if (this.zzpyy != null && this.zzpyy.length > 0) {
            for (zzfls zzfls : this.zzpyy) {
                if (zzfls != null) {
                    zzflk.zza(3, zzfls);
                }
            }
        }
        if (!Arrays.equals(this.zzpyz, zzflv.zzpwe)) {
            zzflk.zzc(4, this.zzpyz);
        }
        if (!Arrays.equals(this.zzpzb, zzflv.zzpwe)) {
            zzflk.zzc(6, this.zzpzb);
        }
        if (this.zzpze != null) {
            zzflk.zza(7, this.zzpze);
        }
        if (!(this.zzpzc == null || this.zzpzc.equals(""))) {
            zzflk.zzp(8, this.zzpzc);
        }
        if (this.zzpza != null) {
            zzflk.zza(9, this.zzpza);
        }
        if (this.zznet) {
            zzflk.zzl(10, this.zznet);
        }
        if (this.zzpyx != 0) {
            zzflk.zzad(11, this.zzpyx);
        }
        if (this.zzaky != 0) {
            zzflk.zzad(12, this.zzaky);
        }
        if (!(this.zzpzd == null || this.zzpzd.equals(""))) {
            zzflk.zzp(13, this.zzpzd);
        }
        if (!(this.zzpzf == null || this.zzpzf.equals(""))) {
            zzflk.zzp(14, this.zzpzf);
        }
        if (this.zzpzg != 180000) {
            zzflk.zzg(15, this.zzpzg);
        }
        if (this.zzpzh != null) {
            zzflk.zza(16, this.zzpzh);
        }
        if (this.zzpyv != 0) {
            zzflk.zzf(17, this.zzpyv);
        }
        if (!Arrays.equals(this.zzpzi, zzflv.zzpwe)) {
            zzflk.zzc(18, this.zzpzi);
        }
        if (this.zzpzk != 0) {
            zzflk.zzad(19, this.zzpzk);
        }
        if (this.zzpzl != null && this.zzpzl.length > 0) {
            for (int zzad : this.zzpzl) {
                zzflk.zzad(20, zzad);
            }
        }
        if (this.zzpyw != 0) {
            zzflk.zzf(21, this.zzpyw);
        }
        if (this.zzpzm != 0) {
            zzflk.zzf(22, this.zzpzm);
        }
        if (this.zzorb != null) {
            zzflk.zza(23, this.zzorb);
        }
        if (!(this.zzpzj == null || this.zzpzj.equals(""))) {
            zzflk.zzp(24, this.zzpzj);
        }
        if (this.zzpzn) {
            zzflk.zzl(25, this.zzpzn);
        }
        super.zza(zzflk);
    }

    public final /* synthetic */ zzflm zzdck() throws CloneNotSupportedException {
        return (zzfmr) clone();
    }

    public final /* synthetic */ zzfls zzdcl() throws CloneNotSupportedException {
        return (zzfmr) clone();
    }

    protected final int zzq() {
        int i;
        int zzq = super.zzq();
        if (this.zzpyu != 0) {
            zzq += zzflk.zzc(1, this.zzpyu);
        }
        if (!(this.tag == null || this.tag.equals(""))) {
            zzq += zzflk.zzq(2, this.tag);
        }
        if (this.zzpyy != null && this.zzpyy.length > 0) {
            i = zzq;
            for (zzfls zzfls : this.zzpyy) {
                if (zzfls != null) {
                    i += zzflk.zzb(3, zzfls);
                }
            }
            zzq = i;
        }
        if (!Arrays.equals(this.zzpyz, zzflv.zzpwe)) {
            zzq += zzflk.zzd(4, this.zzpyz);
        }
        if (!Arrays.equals(this.zzpzb, zzflv.zzpwe)) {
            zzq += zzflk.zzd(6, this.zzpzb);
        }
        if (this.zzpze != null) {
            zzq += zzflk.zzb(7, this.zzpze);
        }
        if (!(this.zzpzc == null || this.zzpzc.equals(""))) {
            zzq += zzflk.zzq(8, this.zzpzc);
        }
        if (this.zzpza != null) {
            zzq += zzflk.zzb(9, this.zzpza);
        }
        if (this.zznet) {
            zzq += zzflk.zzlw(10) + 1;
        }
        if (this.zzpyx != 0) {
            zzq += zzflk.zzag(11, this.zzpyx);
        }
        if (this.zzaky != 0) {
            zzq += zzflk.zzag(12, this.zzaky);
        }
        if (!(this.zzpzd == null || this.zzpzd.equals(""))) {
            zzq += zzflk.zzq(13, this.zzpzd);
        }
        if (!(this.zzpzf == null || this.zzpzf.equals(""))) {
            zzq += zzflk.zzq(14, this.zzpzf);
        }
        if (this.zzpzg != 180000) {
            zzq += zzflk.zzh(15, this.zzpzg);
        }
        if (this.zzpzh != null) {
            zzq += zzflk.zzb(16, this.zzpzh);
        }
        if (this.zzpyv != 0) {
            zzq += zzflk.zzc(17, this.zzpyv);
        }
        if (!Arrays.equals(this.zzpzi, zzflv.zzpwe)) {
            zzq += zzflk.zzd(18, this.zzpzi);
        }
        if (this.zzpzk != 0) {
            zzq += zzflk.zzag(19, this.zzpzk);
        }
        if (this.zzpzl != null && this.zzpzl.length > 0) {
            i = 0;
            for (int zzlx : this.zzpzl) {
                i += zzflk.zzlx(zzlx);
            }
            zzq = (zzq + i) + (this.zzpzl.length * 2);
        }
        if (this.zzpyw != 0) {
            zzq += zzflk.zzc(21, this.zzpyw);
        }
        if (this.zzpzm != 0) {
            zzq += zzflk.zzc(22, this.zzpzm);
        }
        if (this.zzorb != null) {
            zzq += zzflk.zzb(23, this.zzorb);
        }
        if (!(this.zzpzj == null || this.zzpzj.equals(""))) {
            zzq += zzflk.zzq(24, this.zzpzj);
        }
        return this.zzpzn ? zzq + (zzflk.zzlw(25) + 1) : zzq;
    }
}
