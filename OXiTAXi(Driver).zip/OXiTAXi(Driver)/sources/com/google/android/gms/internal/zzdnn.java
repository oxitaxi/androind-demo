package com.google.android.gms.internal;

import android.database.ContentObserver;
import android.os.Handler;

final class zzdnn extends ContentObserver {
    zzdnn(Handler handler) {
        super(null);
    }

    public final void onChange(boolean z) {
        zzdnm.zzlxi.set(true);
    }
}
