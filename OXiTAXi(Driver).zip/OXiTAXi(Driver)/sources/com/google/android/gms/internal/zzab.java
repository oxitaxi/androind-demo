package com.google.android.gms.internal;

public interface zzab {
    void zza(zzae zzae) throws zzae;

    int zzb();

    int zzc();
}
