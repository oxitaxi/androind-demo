package com.google.android.gms.internal;

import android.os.IBinder;

public final class zzcvx extends zzev implements zzcvw {
    zzcvx(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.phenotype.internal.IPhenotypeService");
    }
}
