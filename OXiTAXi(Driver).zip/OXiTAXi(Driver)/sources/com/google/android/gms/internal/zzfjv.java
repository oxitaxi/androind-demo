package com.google.android.gms.internal;

interface zzfjv<T> {
    void zza(T t, zzfli zzfli);

    int zzct(T t);
}
