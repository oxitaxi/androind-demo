package com.google.android.gms.internal;

final class zzbga extends zzbfx<Integer> {
    zzbga(String str, Integer num) {
        super(str, num);
    }
}
