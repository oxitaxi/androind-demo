package com.google.android.gms.internal;

import java.io.IOException;

enum zzflf extends zzfle {
    zzflf(String str, int i) {
        super(str, 0);
    }

    final Object zza(zzfhb zzfhb) throws IOException {
        return zzfhb.readString();
    }
}
