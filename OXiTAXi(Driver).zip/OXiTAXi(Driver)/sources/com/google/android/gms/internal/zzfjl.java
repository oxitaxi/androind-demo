package com.google.android.gms.internal;

public interface zzfjl<MessageType> {
    MessageType zzc(zzfhb zzfhb, zzfhm zzfhm) throws zzfie;

    MessageType zze(zzfhb zzfhb, zzfhm zzfhm) throws zzfie;
}
