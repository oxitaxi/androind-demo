package com.google.android.gms.internal;

final class zzag {
    public final String name;
    public final long time;
    public final long zzbn;

    public zzag(String str, long j, long j2) {
        this.name = str;
        this.zzbn = j;
        this.time = j2;
    }
}
