package com.google.android.gms.internal;

import java.util.Iterator;

final class zzfkc implements Iterable<Object> {
    zzfkc() {
    }

    public final Iterator<Object> iterator() {
        return zzfka.zzpsp;
    }
}
