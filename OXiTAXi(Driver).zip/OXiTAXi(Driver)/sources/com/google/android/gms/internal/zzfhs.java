package com.google.android.gms.internal;

public interface zzfhs<T extends zzfhs<T>> extends Comparable<T> {
    zzfky zzczl();

    zzfld zzczm();

    boolean zzczn();

    boolean zzczo();

    int zzhu();
}
