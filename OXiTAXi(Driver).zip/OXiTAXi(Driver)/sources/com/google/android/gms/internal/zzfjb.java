package com.google.android.gms.internal;

interface zzfjb {
    boolean zzi(Class<?> cls);

    zzfja zzj(Class<?> cls);
}
