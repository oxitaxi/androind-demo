package com.google.android.gms.internal;

import java.util.Iterator;

final class zzfka {
    private static final Iterator<Object> zzpsp = new zzfkb();
    private static final Iterable<Object> zzpsq = new zzfkc();

    static <T> Iterable<T> zzdbt() {
        return zzpsq;
    }
}
