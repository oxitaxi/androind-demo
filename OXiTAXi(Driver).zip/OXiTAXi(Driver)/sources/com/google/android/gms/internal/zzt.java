package com.google.android.gms.internal;

interface zzt {
    void zza(zzr<?> zzr);

    void zza(zzr<?> zzr, zzx<?> zzx);
}
