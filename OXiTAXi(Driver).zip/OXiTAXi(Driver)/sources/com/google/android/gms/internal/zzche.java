package com.google.android.gms.internal;

import com.google.android.gms.location.zzs;

final class zzche extends zzs {
}
