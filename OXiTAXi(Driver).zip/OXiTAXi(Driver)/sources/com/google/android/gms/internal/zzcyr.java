package com.google.android.gms.internal;

import android.os.IInterface;
import android.os.RemoteException;
import com.google.android.gms.common.internal.zzan;

public interface zzcyr extends IInterface {
    void zza(zzan zzan, int i, boolean z) throws RemoteException;

    void zza(zzcyu zzcyu, zzcyp zzcyp) throws RemoteException;

    void zzev(int i) throws RemoteException;
}
