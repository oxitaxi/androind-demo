package com.google.android.gms.internal;

import java.util.List;

public interface zzfil extends List {
    void zzba(zzfgs zzfgs);

    List<?> zzdap();
}
