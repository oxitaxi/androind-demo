package com.google.android.gms.internal;

import com.google.android.gms.clearcut.zzc;
import com.google.android.gms.clearcut.zze;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.data.DataHolder;

class zzbfk extends zzbfq {
    private zzbfk() {
    }

    public final void zza(Status status, long j) {
        throw new UnsupportedOperationException();
    }

    public final void zza(Status status, zzc zzc) {
        throw new UnsupportedOperationException();
    }

    public final void zza(Status status, zze[] zzeArr) {
        throw new UnsupportedOperationException();
    }

    public final void zza(DataHolder dataHolder) {
        throw new UnsupportedOperationException();
    }

    public final void zzb(Status status, long j) {
        throw new UnsupportedOperationException();
    }

    public final void zzb(Status status, zzc zzc) {
        throw new UnsupportedOperationException();
    }

    public void zzo(Status status) {
        throw new UnsupportedOperationException();
    }

    public final void zzp(Status status) {
        throw new UnsupportedOperationException();
    }

    public final void zzq(Status status) {
        throw new UnsupportedOperationException();
    }
}
