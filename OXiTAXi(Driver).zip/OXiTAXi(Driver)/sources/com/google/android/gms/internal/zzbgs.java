package com.google.android.gms.internal;

import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.Api.ApiOptions.NoOptions;
import com.google.android.gms.common.api.Api.zza;
import com.google.android.gms.common.api.Api.zzf;

public final class zzbgs {
    public static final Api<NoOptions> API = new Api("Common.API", zzegv, zzegu);
    public static final zzf<zzbha> zzegu = new zzf();
    private static final zza<zzbha, NoOptions> zzegv = new zzbgt();
    public static final zzbgu zzgif = new zzbgv();
}
