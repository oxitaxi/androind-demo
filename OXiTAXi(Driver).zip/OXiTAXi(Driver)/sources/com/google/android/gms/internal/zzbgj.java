package com.google.android.gms.internal;

import android.graphics.Canvas;
import android.net.Uri;
import android.widget.ImageView;
import com.google.android.gms.common.internal.Hide;

@Hide
public final class zzbgj extends ImageView {
    public static int zzalp() {
        throw new NoSuchMethodError();
    }

    public static void zzcc(int i) {
        throw new NoSuchMethodError();
    }

    public static void zzn(Uri uri) {
        throw new NoSuchMethodError();
    }

    protected final void onDraw(Canvas canvas) {
        throw new NoSuchMethodError();
    }

    protected final void onMeasure(int i, int i2) {
        throw new NoSuchMethodError();
    }
}
