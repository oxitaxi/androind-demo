package com.google.android.gms.internal;

import android.os.IInterface;
import android.os.RemoteException;
import com.google.android.gms.common.internal.Hide;

@Hide
public interface zzcgr extends IInterface {
    void zza(zzcgl zzcgl) throws RemoteException;
}
