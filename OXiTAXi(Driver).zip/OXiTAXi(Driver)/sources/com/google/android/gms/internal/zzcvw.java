package com.google.android.gms.internal;

import android.os.IInterface;

public interface zzcvw extends IInterface {
}
