package com.google.android.gms.internal;

final class zzbgc extends zzbfx<String> {
    zzbgc(String str, String str2) {
        super(str, str2);
    }
}
