package com.google.android.gms.internal;

public interface zzaa {
    void zza(zzr<?> zzr, zzae zzae);

    void zza(zzr<?> zzr, zzx<?> zzx, Runnable runnable);

    void zzb(zzr<?> zzr, zzx<?> zzx);
}
