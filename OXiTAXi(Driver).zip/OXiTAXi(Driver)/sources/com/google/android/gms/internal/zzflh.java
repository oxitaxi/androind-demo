package com.google.android.gms.internal;

import java.io.IOException;

enum zzflh extends zzfle {
    zzflh(String str, int i) {
        super(str, 2);
    }

    final Object zza(zzfhb zzfhb) throws IOException {
        return zzfhb.zzcyf();
    }
}
