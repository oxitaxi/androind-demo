package com.google.android.gms.internal;

public interface zzw<T> {
    void zzg(zzr<T> zzr);
}
