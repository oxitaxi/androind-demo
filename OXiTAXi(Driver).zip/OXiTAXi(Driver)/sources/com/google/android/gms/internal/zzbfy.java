package com.google.android.gms.internal;

final class zzbfy extends zzbfx<Boolean> {
    zzbfy(String str, Boolean bool) {
        super(str, bool);
    }
}
