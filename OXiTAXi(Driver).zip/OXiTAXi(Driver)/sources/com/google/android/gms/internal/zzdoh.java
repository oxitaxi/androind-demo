package com.google.android.gms.internal;

import java.io.IOException;

public final class zzdoh extends zzflm<zzdoh> {
    public String[] zzlyi;
    public int[] zzlyj;
    public byte[][] zzlyk;

    public zzdoh() {
        this.zzlyi = zzflv.EMPTY_STRING_ARRAY;
        this.zzlyj = zzflv.zzpvy;
        this.zzlyk = zzflv.zzpwd;
        this.zzpvl = null;
        this.zzpnr = -1;
    }

    public static zzdoh zzae(byte[] bArr) throws zzflr {
        return (zzdoh) zzfls.zza(new zzdoh(), bArr);
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof zzdoh)) {
            return false;
        }
        zzdoh zzdoh = (zzdoh) obj;
        if (!zzflq.equals(this.zzlyi, zzdoh.zzlyi) || !zzflq.equals(this.zzlyj, zzdoh.zzlyj) || !zzflq.zza(this.zzlyk, zzdoh.zzlyk)) {
            return false;
        }
        if (this.zzpvl != null) {
            if (!this.zzpvl.isEmpty()) {
                return this.zzpvl.equals(zzdoh.zzpvl);
            }
        }
        if (zzdoh.zzpvl != null) {
            if (!zzdoh.zzpvl.isEmpty()) {
                return false;
            }
        }
        return true;
    }

    public final int hashCode() {
        int hashCode;
        int hashCode2 = (((((((getClass().getName().hashCode() + 527) * 31) + zzflq.hashCode(this.zzlyi)) * 31) + zzflq.hashCode(this.zzlyj)) * 31) + zzflq.zzd(this.zzlyk)) * 31;
        if (this.zzpvl != null) {
            if (!this.zzpvl.isEmpty()) {
                hashCode = this.zzpvl.hashCode();
                return hashCode2 + hashCode;
            }
        }
        hashCode = 0;
        return hashCode2 + hashCode;
    }

    public final /* synthetic */ zzfls zza(zzflj zzflj) throws IOException {
        while (true) {
            int zzcxx = zzflj.zzcxx();
            if (zzcxx == 0) {
                return this;
            }
            int length;
            Object obj;
            if (zzcxx == 10) {
                zzcxx = zzflv.zzb(zzflj, 10);
                length = this.zzlyi == null ? 0 : this.zzlyi.length;
                obj = new String[(zzcxx + length)];
                if (length != 0) {
                    System.arraycopy(this.zzlyi, 0, obj, 0, length);
                }
                while (length < obj.length - 1) {
                    obj[length] = zzflj.readString();
                    zzflj.zzcxx();
                    length++;
                }
                obj[length] = zzflj.readString();
                this.zzlyi = obj;
            } else if (zzcxx == 16) {
                zzcxx = zzflv.zzb(zzflj, 16);
                length = this.zzlyj == null ? 0 : this.zzlyj.length;
                obj = new int[(zzcxx + length)];
                if (length != 0) {
                    System.arraycopy(this.zzlyj, 0, obj, 0, length);
                }
                while (length < obj.length - 1) {
                    obj[length] = zzflj.zzcym();
                    zzflj.zzcxx();
                    length++;
                }
                obj[length] = zzflj.zzcym();
                this.zzlyj = obj;
            } else if (zzcxx == 18) {
                zzcxx = zzflj.zzli(zzflj.zzcym());
                length = zzflj.getPosition();
                int i = 0;
                while (zzflj.zzcyo() > 0) {
                    zzflj.zzcym();
                    i++;
                }
                zzflj.zzmw(length);
                length = this.zzlyj == null ? 0 : this.zzlyj.length;
                Object obj2 = new int[(i + length)];
                if (length != 0) {
                    System.arraycopy(this.zzlyj, 0, obj2, 0, length);
                }
                while (length < obj2.length) {
                    obj2[length] = zzflj.zzcym();
                    length++;
                }
                this.zzlyj = obj2;
                zzflj.zzlj(zzcxx);
            } else if (zzcxx == 26) {
                zzcxx = zzflv.zzb(zzflj, 26);
                length = this.zzlyk == null ? 0 : this.zzlyk.length;
                obj = new byte[(zzcxx + length)][];
                if (length != 0) {
                    System.arraycopy(this.zzlyk, 0, obj, 0, length);
                }
                while (length < obj.length - 1) {
                    obj[length] = zzflj.readBytes();
                    zzflj.zzcxx();
                    length++;
                }
                obj[length] = zzflj.readBytes();
                this.zzlyk = obj;
            } else if (!super.zza(zzflj, zzcxx)) {
                return this;
            }
        }
    }

    public final void zza(zzflk zzflk) throws IOException {
        if (this.zzlyi != null && this.zzlyi.length > 0) {
            for (String str : this.zzlyi) {
                if (str != null) {
                    zzflk.zzp(1, str);
                }
            }
        }
        if (this.zzlyj != null && this.zzlyj.length > 0) {
            for (int zzad : this.zzlyj) {
                zzflk.zzad(2, zzad);
            }
        }
        if (this.zzlyk != null && this.zzlyk.length > 0) {
            for (byte[] bArr : this.zzlyk) {
                if (bArr != null) {
                    zzflk.zzc(3, bArr);
                }
            }
        }
        super.zza(zzflk);
    }

    protected final int zzq() {
        int i;
        int i2;
        int i3;
        int zzq = super.zzq();
        if (this.zzlyi != null && this.zzlyi.length > 0) {
            i = 0;
            i2 = 0;
            for (String str : this.zzlyi) {
                if (str != null) {
                    i2++;
                    i += zzflk.zztx(str);
                }
            }
            zzq = (zzq + i) + (i2 * 1);
        }
        if (this.zzlyj != null && this.zzlyj.length > 0) {
            i = 0;
            for (int i22 : this.zzlyj) {
                i += zzflk.zzlx(i22);
            }
            zzq = (zzq + i) + (this.zzlyj.length * 1);
        }
        if (this.zzlyk == null || this.zzlyk.length <= 0) {
            return zzq;
        }
        i3 = 0;
        i = 0;
        for (byte[] bArr : this.zzlyk) {
            if (bArr != null) {
                i++;
                i3 += zzflk.zzbg(bArr);
            }
        }
        return (zzq + i3) + (i * 1);
    }
}
