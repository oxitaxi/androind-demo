package com.google.android.gms.internal;

final class zzfiv<K, V> {
    public final V zzinq;
    public final zzfky zzpra;
    public final K zzprb;
    public final zzfky zzprc;

    public zzfiv(zzfky zzfky, K k, zzfky zzfky2, V v) {
        this.zzpra = zzfky;
        this.zzprb = k;
        this.zzprc = zzfky2;
        this.zzinq = v;
    }
}
