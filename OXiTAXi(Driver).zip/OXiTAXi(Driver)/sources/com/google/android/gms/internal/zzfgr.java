package com.google.android.gms.internal;

import java.io.IOException;

public abstract class zzfgr {
    public abstract void zze(byte[] bArr, int i, int i2) throws IOException;
}
