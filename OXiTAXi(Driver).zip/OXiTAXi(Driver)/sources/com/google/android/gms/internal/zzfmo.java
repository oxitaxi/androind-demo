package com.google.android.gms.internal;

import java.io.IOException;

public final class zzfmo extends zzflm<zzfmo> implements Cloneable {
    private String[] zzpyk;
    private String[] zzpyl;
    private int[] zzpym;
    private long[] zzpyn;
    private long[] zzpyo;

    public zzfmo() {
        this.zzpyk = zzflv.EMPTY_STRING_ARRAY;
        this.zzpyl = zzflv.EMPTY_STRING_ARRAY;
        this.zzpym = zzflv.zzpvy;
        this.zzpyn = zzflv.zzpvz;
        this.zzpyo = zzflv.zzpvz;
        this.zzpvl = null;
        this.zzpnr = -1;
    }

    private zzfmo zzddb() {
        try {
            zzfmo zzfmo = (zzfmo) super.zzdck();
            if (this.zzpyk != null && this.zzpyk.length > 0) {
                zzfmo.zzpyk = (String[]) this.zzpyk.clone();
            }
            if (this.zzpyl != null && this.zzpyl.length > 0) {
                zzfmo.zzpyl = (String[]) this.zzpyl.clone();
            }
            if (this.zzpym != null && this.zzpym.length > 0) {
                zzfmo.zzpym = (int[]) this.zzpym.clone();
            }
            if (this.zzpyn != null && this.zzpyn.length > 0) {
                zzfmo.zzpyn = (long[]) this.zzpyn.clone();
            }
            if (this.zzpyo != null && this.zzpyo.length > 0) {
                zzfmo.zzpyo = (long[]) this.zzpyo.clone();
            }
            return zzfmo;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError(e);
        }
    }

    public final /* synthetic */ Object clone() throws CloneNotSupportedException {
        return zzddb();
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof zzfmo)) {
            return false;
        }
        zzfmo zzfmo = (zzfmo) obj;
        if (!zzflq.equals(this.zzpyk, zzfmo.zzpyk) || !zzflq.equals(this.zzpyl, zzfmo.zzpyl) || !zzflq.equals(this.zzpym, zzfmo.zzpym) || !zzflq.equals(this.zzpyn, zzfmo.zzpyn) || !zzflq.equals(this.zzpyo, zzfmo.zzpyo)) {
            return false;
        }
        if (this.zzpvl != null) {
            if (!this.zzpvl.isEmpty()) {
                return this.zzpvl.equals(zzfmo.zzpvl);
            }
        }
        if (zzfmo.zzpvl != null) {
            if (!zzfmo.zzpvl.isEmpty()) {
                return false;
            }
        }
        return true;
    }

    public final int hashCode() {
        int hashCode;
        int hashCode2 = (((((((((((getClass().getName().hashCode() + 527) * 31) + zzflq.hashCode(this.zzpyk)) * 31) + zzflq.hashCode(this.zzpyl)) * 31) + zzflq.hashCode(this.zzpym)) * 31) + zzflq.hashCode(this.zzpyn)) * 31) + zzflq.hashCode(this.zzpyo)) * 31;
        if (this.zzpvl != null) {
            if (!this.zzpvl.isEmpty()) {
                hashCode = this.zzpvl.hashCode();
                return hashCode2 + hashCode;
            }
        }
        hashCode = 0;
        return hashCode2 + hashCode;
    }

    public final /* synthetic */ zzfls zza(zzflj zzflj) throws IOException {
        while (true) {
            int zzcxx = zzflj.zzcxx();
            if (zzcxx == 0) {
                return this;
            }
            int length;
            Object obj;
            if (zzcxx == 10) {
                zzcxx = zzflv.zzb(zzflj, 10);
                length = this.zzpyk == null ? 0 : this.zzpyk.length;
                obj = new String[(zzcxx + length)];
                if (length != 0) {
                    System.arraycopy(this.zzpyk, 0, obj, 0, length);
                }
                while (length < obj.length - 1) {
                    obj[length] = zzflj.readString();
                    zzflj.zzcxx();
                    length++;
                }
                obj[length] = zzflj.readString();
                this.zzpyk = obj;
            } else if (zzcxx == 18) {
                zzcxx = zzflv.zzb(zzflj, 18);
                length = this.zzpyl == null ? 0 : this.zzpyl.length;
                obj = new String[(zzcxx + length)];
                if (length != 0) {
                    System.arraycopy(this.zzpyl, 0, obj, 0, length);
                }
                while (length < obj.length - 1) {
                    obj[length] = zzflj.readString();
                    zzflj.zzcxx();
                    length++;
                }
                obj[length] = zzflj.readString();
                this.zzpyl = obj;
            } else if (zzcxx != 24) {
                int i;
                Object obj2;
                if (zzcxx == 26) {
                    zzcxx = zzflj.zzli(zzflj.zzcym());
                    length = zzflj.getPosition();
                    i = 0;
                    while (zzflj.zzcyo() > 0) {
                        zzflj.zzcya();
                        i++;
                    }
                    zzflj.zzmw(length);
                    length = this.zzpym == null ? 0 : this.zzpym.length;
                    obj2 = new int[(i + length)];
                    if (length != 0) {
                        System.arraycopy(this.zzpym, 0, obj2, 0, length);
                    }
                    while (length < obj2.length) {
                        obj2[length] = zzflj.zzcya();
                        length++;
                    }
                    this.zzpym = obj2;
                } else if (zzcxx == 32) {
                    zzcxx = zzflv.zzb(zzflj, 32);
                    length = this.zzpyn == null ? 0 : this.zzpyn.length;
                    obj = new long[(zzcxx + length)];
                    if (length != 0) {
                        System.arraycopy(this.zzpyn, 0, obj, 0, length);
                    }
                    while (length < obj.length - 1) {
                        obj[length] = zzflj.zzcxz();
                        zzflj.zzcxx();
                        length++;
                    }
                    obj[length] = zzflj.zzcxz();
                    this.zzpyn = obj;
                } else if (zzcxx == 34) {
                    zzcxx = zzflj.zzli(zzflj.zzcym());
                    length = zzflj.getPosition();
                    i = 0;
                    while (zzflj.zzcyo() > 0) {
                        zzflj.zzcxz();
                        i++;
                    }
                    zzflj.zzmw(length);
                    length = this.zzpyn == null ? 0 : this.zzpyn.length;
                    obj2 = new long[(i + length)];
                    if (length != 0) {
                        System.arraycopy(this.zzpyn, 0, obj2, 0, length);
                    }
                    while (length < obj2.length) {
                        obj2[length] = zzflj.zzcxz();
                        length++;
                    }
                    this.zzpyn = obj2;
                } else if (zzcxx == 40) {
                    zzcxx = zzflv.zzb(zzflj, 40);
                    length = this.zzpyo == null ? 0 : this.zzpyo.length;
                    obj = new long[(zzcxx + length)];
                    if (length != 0) {
                        System.arraycopy(this.zzpyo, 0, obj, 0, length);
                    }
                    while (length < obj.length - 1) {
                        obj[length] = zzflj.zzcxz();
                        zzflj.zzcxx();
                        length++;
                    }
                    obj[length] = zzflj.zzcxz();
                    this.zzpyo = obj;
                } else if (zzcxx == 42) {
                    zzcxx = zzflj.zzli(zzflj.zzcym());
                    length = zzflj.getPosition();
                    i = 0;
                    while (zzflj.zzcyo() > 0) {
                        zzflj.zzcxz();
                        i++;
                    }
                    zzflj.zzmw(length);
                    length = this.zzpyo == null ? 0 : this.zzpyo.length;
                    obj2 = new long[(i + length)];
                    if (length != 0) {
                        System.arraycopy(this.zzpyo, 0, obj2, 0, length);
                    }
                    while (length < obj2.length) {
                        obj2[length] = zzflj.zzcxz();
                        length++;
                    }
                    this.zzpyo = obj2;
                } else if (!super.zza(zzflj, zzcxx)) {
                    return this;
                }
                zzflj.zzlj(zzcxx);
            } else {
                zzcxx = zzflv.zzb(zzflj, 24);
                length = this.zzpym == null ? 0 : this.zzpym.length;
                obj = new int[(zzcxx + length)];
                if (length != 0) {
                    System.arraycopy(this.zzpym, 0, obj, 0, length);
                }
                while (length < obj.length - 1) {
                    obj[length] = zzflj.zzcya();
                    zzflj.zzcxx();
                    length++;
                }
                obj[length] = zzflj.zzcya();
                this.zzpym = obj;
            }
        }
    }

    public final void zza(zzflk zzflk) throws IOException {
        if (this.zzpyk != null && this.zzpyk.length > 0) {
            for (String str : this.zzpyk) {
                if (str != null) {
                    zzflk.zzp(1, str);
                }
            }
        }
        if (this.zzpyl != null && this.zzpyl.length > 0) {
            for (String str2 : this.zzpyl) {
                if (str2 != null) {
                    zzflk.zzp(2, str2);
                }
            }
        }
        if (this.zzpym != null && this.zzpym.length > 0) {
            for (int zzad : this.zzpym) {
                zzflk.zzad(3, zzad);
            }
        }
        if (this.zzpyn != null && this.zzpyn.length > 0) {
            for (long zzf : this.zzpyn) {
                zzflk.zzf(4, zzf);
            }
        }
        if (this.zzpyo != null && this.zzpyo.length > 0) {
            for (long zzf2 : this.zzpyo) {
                zzflk.zzf(5, zzf2);
            }
        }
        super.zza(zzflk);
    }

    public final /* synthetic */ zzflm zzdck() throws CloneNotSupportedException {
        return (zzfmo) clone();
    }

    public final /* synthetic */ zzfls zzdcl() throws CloneNotSupportedException {
        return (zzfmo) clone();
    }

    protected final int zzq() {
        int i;
        int i2;
        int i3;
        int zzq = super.zzq();
        if (this.zzpyk != null && this.zzpyk.length > 0) {
            i = 0;
            i2 = 0;
            for (String str : this.zzpyk) {
                if (str != null) {
                    i2++;
                    i += zzflk.zztx(str);
                }
            }
            zzq = (zzq + i) + (i2 * 1);
        }
        if (this.zzpyl != null && this.zzpyl.length > 0) {
            i = 0;
            i2 = 0;
            for (String str2 : this.zzpyl) {
                if (str2 != null) {
                    i2++;
                    i += zzflk.zztx(str2);
                }
            }
            zzq = (zzq + i) + (i2 * 1);
        }
        if (this.zzpym != null && this.zzpym.length > 0) {
            i = 0;
            for (int i22 : this.zzpym) {
                i += zzflk.zzlx(i22);
            }
            zzq = (zzq + i) + (this.zzpym.length * 1);
        }
        if (this.zzpyn != null && this.zzpyn.length > 0) {
            i = 0;
            for (long zzdj : this.zzpyn) {
                i += zzflk.zzdj(zzdj);
            }
            zzq = (zzq + i) + (this.zzpyn.length * 1);
        }
        if (this.zzpyo == null || this.zzpyo.length <= 0) {
            return zzq;
        }
        i3 = 0;
        for (long zzdj2 : this.zzpyo) {
            i3 += zzflk.zzdj(zzdj2);
        }
        return (zzq + i3) + (this.zzpyo.length * 1);
    }
}
