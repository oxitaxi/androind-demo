package com.google.android.gms.internal;

abstract class zzfkn<T, B> {
    zzfkn() {
    }

    abstract void zzb(T t, zzfli zzfli);

    abstract T zzcu(Object obj);

    abstract int zzcv(T t);
}
