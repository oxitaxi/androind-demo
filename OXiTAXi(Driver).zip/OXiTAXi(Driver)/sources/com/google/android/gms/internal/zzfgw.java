package com.google.android.gms.internal;

interface zzfgw {
    byte[] zzg(byte[] bArr, int i, int i2);
}
