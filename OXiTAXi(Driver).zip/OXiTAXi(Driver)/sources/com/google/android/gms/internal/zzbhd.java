package com.google.android.gms.internal;

import android.os.IInterface;
import android.os.RemoteException;

public interface zzbhd extends IInterface {
    void zza(zzbhb zzbhb) throws RemoteException;
}
