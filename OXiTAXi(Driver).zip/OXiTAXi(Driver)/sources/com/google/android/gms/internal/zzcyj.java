package com.google.android.gms.internal;

import com.google.android.gms.common.api.Api.zze;
import com.google.android.gms.common.internal.zzan;

public interface zzcyj extends zze {
    void connect();

    void zza(zzan zzan, boolean z);

    void zza(zzcyp zzcyp);

    void zzbet();
}
