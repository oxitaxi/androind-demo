package com.google.android.gms.internal;

public interface zzz<T> {
    void zzb(T t);
}
