package com.google.android.gms.internal;

import java.io.IOException;

public interface zzfjd extends zzfje, Cloneable {
    zzfjd zzb(zzfhb zzfhb, zzfhm zzfhm) throws IOException;

    zzfjc zzczy();

    zzfjc zzczz();

    zzfjd zzd(zzfjc zzfjc);
}
