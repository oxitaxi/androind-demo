package com.google.android.gms.internal;

public final class zza extends zzae {
    public zza(zzp zzp) {
        super(zzp);
    }
}
