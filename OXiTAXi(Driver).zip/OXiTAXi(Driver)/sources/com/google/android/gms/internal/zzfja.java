package com.google.android.gms.internal;

interface zzfja {
    int zzdaz();

    boolean zzdba();

    zzfjc zzdbb();
}
