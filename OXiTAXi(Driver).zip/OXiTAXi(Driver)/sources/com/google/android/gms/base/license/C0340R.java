package com.google.android.gms.base.license;

/* renamed from: com.google.android.gms.base.license.R */
public final class C0340R {
    private C0340R() {
    }
}
